"""썸네일(출입증 스타일): 목걸이 줄 + 출입증 카드(도형 흉상·이름) + 큰 숫자 48:47 + 마스코트"""
from PIL import Image, ImageDraw, ImageFont, ImageFilter
FX='/home/claude/pixel_kit/fonts/pretendard/Pretendard-ExtraBold.otf'; FB='/home/claude/pixel_kit/fonts/pretendard/Pretendard-Bold.otf'
F=lambda s,f=FX: ImageFont.truetype(f,s)
W,H=1080,1920; im=Image.new('RGB',(W,H),(11,16,38)); d=ImageDraw.Draw(im)
for y in range(H): d.line([(0,y),(W,y)],fill=(11+int(8*y/H),16+int(10*y/H),38+int(26*y/H)))
for y in range(60,H,60):
    for x in range(30,W,60): d.rectangle([x-2,y-2,x+2,y+2],fill=(30,40,78))
d.text((540,300),'한 표 차로 연준에 들어온 사람',font=F(64),fill=(255,255,255),anchor='mm',stroke_width=6,stroke_fill=(5,8,20))
d.text((540,460),'48 : 47',font=F(230),fill=(255,214,64),anchor='mm',stroke_width=10,stroke_fill=(5,8,20))
# 목걸이 줄
d.polygon([(380,560),(430,560),(520,760),(490,770)],fill=(98,214,255)); d.polygon([(700,560),(650,560),(560,760),(590,770)],fill=(70,180,230))
# 카드
card=Image.new('RGBA',(640,820),(0,0,0,0)); c=ImageDraw.Draw(card)
c.rounded_rectangle([0,0,639,819],40,fill=(246,247,250),outline=(20,26,50),width=8); c.rounded_rectangle([250,26,390,56],15,fill=(20,26,50))
c.rounded_rectangle([40,90,600,470],24,fill=(22,32,72))
b=Image.open('/home/claude/w3d/bust.png').convert('RGBA'); bb=b.getbbox(); b=b.crop(bb); b.thumbnail((430,370)); card.paste(b,(320-b.width//2,470-b.height),b)
c.text((320,535),'1분 인물사전',font=F(38,FB),fill=(110,120,150),anchor='mm'); c.text((320,620),'월러 이사',font=F(96),fill=(20,26,50),anchor='mm')
c.rounded_rectangle([110,700,530,776],38,fill=(255,214,64)); c.text((320,738),'누구길래?',font=F(52),fill=(20,26,50),anchor='mm')
card=card.rotate(-5,expand=True,resample=Image.BICUBIC); sh=Image.new('RGBA',card.size,(0,0,0,0)); sh.paste((0,0,0,150),mask=card.split()[3]); sh=sh.filter(ImageFilter.GaussianBlur(18))
im.paste(sh,(190,760),sh); im.paste(card,(170,730),card)
m=Image.open('/home/claude/pixel_kit/waller/out/m_v3/host_0/00040.png').convert('RGBA'); m=m.resize((int(m.width*0.95),int(m.height*0.95)),Image.LANCZOS); im.paste(m,(560,1190),m)
im.save('/home/claude/pixel_kit/waller/out/thumb.jpg',quality=92)

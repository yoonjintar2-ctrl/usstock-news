#!/bin/bash
cd /home/claude/mascot3d
W=/home/claude/pixel_kit/waller/out/mix_narr.wav; O=/home/claude/pixel_kit/waller/out/m
python3 - <<'PY' > /home/claude/pixel_kit/waller/out/hosts.txt
import json; S=json.load(open('/home/claude/pixel_kit/waller/out/spec.json'))
for h in S['hosts']: print(h['k'], h['t0'], h['t1']-h['t0'])
PY
while read k t0 dur; do
  CUES=/home/claude/pixel_kit/waller/out/cues.json LIGHT=navy MODE=host STEP=1 python3 talk_render2.py $W $O/host_$k $t0 $dur 600 16 --resume
done < /home/claude/pixel_kit/waller/out/hosts.txt
echo ALLDONE

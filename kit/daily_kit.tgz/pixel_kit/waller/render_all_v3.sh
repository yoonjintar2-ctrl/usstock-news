#!/bin/bash
cd /home/claude/mascot3d
python3 demo_v3.py v3/demo > v3/demo.log 2>&1
cd /home/claude/pixel_kit && python3 /home/claude/mascot3d/demo_comp.py > /home/claude/mascot3d/v3/demo_comp.log 2>&1
bash /home/claude/pixel_kit/waller/render_hosts_v3.sh

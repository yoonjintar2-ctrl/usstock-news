#!/bin/bash
# 시연 클립 렌더가 끝나면 월러 진행자 컷을 v3 조명으로 다시 렌더 → m_v3
cd /home/claude/mascot3d
until grep -q DEMODONE v3/demo.log; do sleep 10; done
W=/home/claude/pixel_kit/waller/out/mix_narr.wav; O=/home/claude/pixel_kit/waller/out/m_v3
while read k t0 dur; do
  CUES=/home/claude/pixel_kit/waller/out/cues.json LIGHT=v3_studio MODE=host STEP=1 python3 talk_render2.py $W $O/host_$k $t0 $dur 600 16 --resume
done < /home/claude/pixel_kit/waller/out/hosts.txt
echo ALLDONE

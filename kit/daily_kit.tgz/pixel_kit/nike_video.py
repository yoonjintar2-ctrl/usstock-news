import os, sys, math, subprocess, wave
import numpy as np
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, shutter_mask
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, tone, mtof, SR, dissolve_mask)
import mid_video as mv
from mid_video import eout

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "nike/out"); os.makedirs(OUT, exist_ok=True)
FD = os.path.join(BASE, "fonts/galmuri-2.40.3/package/dist")
F36 = ImageFont.truetype(f"{FD}/Galmuri11-Bold.ttf", 36)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
SKIN = (240, 196, 150); DARK = (14, 16, 30); LIME = (190, 240, 60)

# ================================================================ sprites & effects
def dk(c, f=0.65): return tuple(int(v * f) for v in c)

@lru_cache(None)
def sneaker_img(col=SRED, scale=2, flip=False):
    im = Image.new("RGBA", (26, 13), (0, 0, 0, 0)); g = ImageDraw.Draw(im)
    g.polygon([(2, 9), (2, 2), (6, 1), (10, 3), (15, 5), (21, 6), (25, 8), (25, 9)], fill=col)
    g.rectangle([1, 3, 2, 9], fill=dk(col))
    g.line([(3, 2), (7, 2)], fill=DARK)
    for i in range(4): g.point((10 + i * 2, 4 + (i + 1) // 2), fill=WHITE)
    g.line([(20, 7), (24, 8)], fill=dk(col))
    g.rectangle([1, 10, 25, 11], fill=(244, 244, 244)); g.line([(1, 12), (25, 12)], fill=(150, 150, 165))
    g.line([(4, 7), (12, 8)], fill=dk(col, 0.8))
    im = im.resize((26 * scale, 13 * scale), Image.NEAREST)
    return im.transpose(Image.FLIP_LEFT_RIGHT) if flip else im

def put(img, spr, x, y): img.paste(spr, (int(x), int(y)), spr)

def shoebox(d, x, y, col=ORG, w=24, h=12):
    d.rectangle([x, y, x + w, y + h], fill=dk(col, 0.8), outline=dk(col, 0.5))
    d.rectangle([x, y, x + w, y + 3], fill=col)
    d.rectangle([x + w // 2 - 3, y + 6, x + w // 2 + 3, y + 9], fill=WHITE)

def debris(d, cx, cy, t, t0, n=14, cols=(YEL, WHITE, ORG), speed=55, life=0.9, seed=0, size=3):
    u = t - t0
    if u < 0 or u > life: return
    for i in range(n):
        ang = (i * 2.39996 + seed * 0.7) % (2 * math.pi)
        v = speed * (0.45 + ((i * 37 + seed * 11) % 10) / 12)
        x = cx + math.cos(ang) * v * u; y = cy + math.sin(ang) * v * u * 0.8 + 70 * u * u
        s = size if (i % 3) else size - 1
        square(d, x, y, cols[i % len(cols)], max(1, s))

def confetti(d, t, t0, n=18, cols=(YEL, GRN, CYAN, SRED), y0=120, y1=300):
    if t < t0: return
    for k in range(n):
        ph = ((t - t0) * 0.55 + k * 0.137) % 1
        x = SX0 + (k * 41) % (SX1 - SX0); y = y0 + ph * (y1 - y0)
        square(d, x + math.sin((t + k) * 3) * 3, y, cols[k % len(cols)], 2)

@lru_cache(None)
def stamp_img(s, col, font_key="24", angle=-12):
    font = F24 if font_key == "24" else F12
    tmp = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    w = int(tmp.textlength(s, font=font)) + 14; h = (font.size + 12)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); g = ImageDraw.Draw(im); g.fontmode = "1"
    g.rectangle([0, 0, w - 1, h - 1], outline=col); g.rectangle([2, 2, w - 3, h - 3], outline=col)
    g.text((w // 2, 5), s, font=font, fill=col, anchor="ma")
    return im.rotate(angle, expand=True, resample=Image.NEAREST)

def stamp_slam(img, cx, cy, s, col, t, t0, font_key="24", angle=-12):
    if t < t0: return
    base = stamp_img(s, col, font_key, angle)
    u = prog(t, t0, t0 + 0.16)
    sc = lerp(2.0, 1.0, ease(u))
    im = base.resize((max(1, int(base.width * sc)), max(1, int(base.height * sc))), Image.NEAREST)
    put(img, im, cx - im.width // 2, cy - im.height // 2)

def crack(d, x0, y0, x1, y1, t, t0, col=WHITE, seed=1):
    if t < t0: return
    n = 9; k = int(prog(t, t0, t0 + 0.25) * n)
    pts = []
    for i in range(k + 1):
        f = i / n
        jx = ((i * 7 + seed * 3) % 5 - 2) * 2
        pts.append((lerp(x0, x1, f) + jx, lerp(y0, y1, f) + ((i * 5 + seed) % 3 - 1) * 2))
    if len(pts) > 1: d.line(pts, fill=col, width=1)

def bank(d, x, y, w=70, col=WHT2):
    d.polygon([(x, y + 14), (x + w // 2, y), (x + w, y + 14)], fill=col)
    d.rectangle([x + 2, y + 15, x + w - 2, y + 18], fill=col)
    for i in range(5):
        cx = x + 8 + i * (w - 16) // 4
        d.rectangle([cx - 2, y + 20, cx + 2, y + 44], fill=col)
    d.rectangle([x, y + 45, x + w, y + 49], fill=col)

def runner(d, x, y, t, col=SRED):
    ph = t * 11
    d.rectangle([x + 3, y, x + 7, y + 4], fill=SKIN)
    d.line([(x + 5, y + 5), (x + 4, y + 13)], fill=col, width=2)
    a = math.sin(ph) * 4
    d.line([(x + 5, y + 7), (x + 1 - a, y + 11)], fill=SKIN); d.line([(x + 5, y + 7), (x + 9 + a, y + 10)], fill=SKIN)
    d.line([(x + 4, y + 13), (x + 1 + a, y + 20)], fill=DARK, width=2); d.line([(x + 4, y + 13), (x + 7 - a, y + 20)], fill=DARK, width=2)
    d.rectangle([x + a, y + 20, x + 3 + a, y + 21], fill=WHITE); d.rectangle([x + 6 - a, y + 20, x + 9 - a, y + 21], fill=WHITE)

def soccer(d, x, y, r=7):
    d.ellipse([x - r, y - r, x + r, y + r], fill=WHITE, outline=GRAY)
    d.polygon([(x, y - 3), (x + 3, y - 1), (x + 2, y + 3), (x - 2, y + 3), (x - 3, y - 1)], fill=DARK)
def tennis(d, x, y, r=6):
    d.ellipse([x - r, y - r, x + r, y + r], fill=LIME)
    d.arc([x - r - 4, y - r, x + 2, y + r], -60, 60, fill=WHITE); d.arc([x - 2, y - r, x + r + 4, y + r], 120, 240, fill=WHITE)
def golf(d, x, y):
    d.line([(x + 4, y - 12), (x + 4, y + 6)], fill=WHT2); d.polygon([(x + 5, y - 12), (x + 13, y - 9), (x + 5, y - 6)], fill=SRED)
    d.ellipse([x - 4, y + 2, x + 2, y + 8], fill=WHITE, outline=GRAY)

def coin_stack(d, x, y, n=4):
    for i in range(n):
        d.ellipse([x, y - i * 4, x + 18, y + 6 - i * 4], fill=YEL, outline=(180, 130, 30))

def person(d, x, y, col=CYAN):
    d.rectangle([x + 4, y, x + 10, y + 6], fill=SKIN)
    d.rectangle([x + 1, y + 8, x + 13, y + 20], fill=col)
    d.rectangle([x + 6, y + 8, x + 8, y + 14], fill=WHITE)

def scissors(d, x, y):
    d.ellipse([x, y + 10, x + 7, y + 17], outline=SRED, width=2); d.ellipse([x + 10, y + 10, x + 17, y + 17], outline=SRED, width=2)
    d.line([(x + 5, y + 10), (x + 14, y)], fill=WHT2, width=2); d.line([(x + 12, y + 10), (x + 3, y)], fill=WHT2, width=2)

def lantern(d, x, y, t):
    sw = int(math.sin(t * 2.5) * 2)
    d.line([(x, y - 6), (x + sw, y)], fill=GRAY)
    d.ellipse([x - 5 + sw, y, x + 5 + sw, y + 11], fill=SRED); d.rectangle([x - 2 + sw, y + 11, x + 2 + sw, y + 13], fill=YEL)

def warn_icon(d, x, y, col=YEL):
    d.polygon([(x + 8, y), (x + 16, y + 14), (x, y + 14)], fill=col)
    d.rectangle([x + 7, y + 4, x + 9, y + 9], fill=DARK); d.rectangle([x + 7, y + 11, x + 9, y + 12], fill=DARK)

# ================================================================ scenes  -> return dict(shake, flash, zoom)
NKE = [(0, 177.5), (0.08, 150), (0.16, 100), (0.24, 90), (0.33, 125), (0.45, 105), (0.55, 75), (0.66, 90),
       (0.76, 60), (0.84, 72), (0.92, 48), (1.0, 34)]
def price_at(f):
    for j in range(len(NKE) - 1):
        (a, p), (b, q) = NKE[j], NKE[j + 1]
        if a <= f <= b: return lerp(p, q, (f - a) / (b - a))
    return NKE[-1][1]

def s_hook(img, d, t, seg, dur):
    ctext(d, 62, "NIKE (NKE) · 2026.10", F9, GRAY)
    u = eout(prog(t, 0.05, 1.5))
    ctext(d, 74, f"-{int(round(80 * u))}%", F36, SRED, full="-80%")
    ctext(d, 116, "고점 $177.5 → 지금 $34", F9, WHITE)
    bx0, by0, bx1, by1 = SX0 + 2, 130, SX1 - 4, 232
    box(d, bx0, by0, bx1, by1, DIM)
    mp = lambda f, p: (bx0 + 8 + f * (bx1 - bx0 - 16), by1 - 8 - (p - 20) / (190 - 20) * (by1 - by0 - 16))
    pts = [mp(i / 80, price_at(i / 80)) for i in range(int(u * 80) + 1)]
    if len(pts) > 1: d.line(pts, fill=SRED, width=2)
    d.text((bx0 + 4, by0 + 3), "'21", font=F9, fill=GRAY); d.text((bx1 - 4, by0 + 3), "'26", font=F9, fill=GRAY, anchor="ra")
    x, y = pts[-1]
    put(img, sneaker_img(WHITE, 2), x - 50, y - 24)
    if t < 1.5:
        for k in range(4): square(d, x - 54 - k * 4, y - 4 + (k % 2) * 3, GRAY if k % 2 else WHT2, 2)
    stamp_slam(img, 170, 165, "13년 최저", SRED, t, 1.55, "12", -10)
    debris(d, 170, 165, t, 1.55, 10, (SRED, WHITE), 40, 0.6, 3)
    fx = {}
    if t > seg[1]:
        bank(d, 36, 244, 64)
        d.text((68, 296), "골드만삭스", font=F9, fill=WHT2, anchor="ma")
        stamp_slam(img, 160, 266, "SELL", SRED, t, seg[1] + 0.5)
        debris(d, 160, 266, t, seg[1] + 0.5, 16, (SRED, YEL, WHITE), 60, 0.8, 5)
        if t > seg[1] + 0.8: d.text((160, 290), "목표가 $27.5", font=F9, fill=YEL, anchor="ma")
        if seg[1] + 0.5 < t < seg[1] + 0.62: fx["flash"] = 0.55
        if seg[1] + 0.5 < t < seg[1] + 0.8: fx["zoom"] = 1 + 0.06 * (1 - prog(t, seg[1] + 0.5, seg[1] + 0.8))
    if 1.55 < t < 1.75: fx["shake"] = (int(math.sin(t * 70) * 2), 0)
    return fx

def s_many(img, d, t, seg, dur):
    header(d, t, "WHY 1", "TOO MANY", "인기 운동화를 너무 많이 풀었다", ORG)
    for row in range(3):
        y = 160 + row * 34
        d.rectangle([34, y, 216, y + 3], fill=(120, 84, 50))
    cols = [SRED, WHITE, CYAN, YEL, GRN, PURP]
    k = 0
    for row in range(3):
        for c in range(6):
            ts = 0.3 + k * 0.14
            if t > ts:
                yy = 160 + row * 34 - 26 + int((1 - ease(prog(t, ts, ts + 0.2))) * -10)
                put(img, sneaker_img(cols[(row + c) % 6], 1), 38 + c * 30, yy + 12)
            k += 1
    # overflow boxes pile
    n_box = int(prog(t, 2.6, seg[1] + 1.2) * 12)
    for i in range(n_box):
        col_ = i % 6; lay = i // 6
        shoebox(d, 36 + col_ * 30, 280 - lay * 13, [ORG, SRED, CYAN][i % 3])
    if t > seg[1]:
        stamp_slam(img, CX, 232, "공급 과잉", SRED, t, seg[1] + 0.2)
        debris(d, CX, 232, t, seg[1] + 0.2, 14, (SRED, WHITE, ORG), 55, 0.8, 7)
        if t > seg[1] + 1.0:
            d.rectangle([40, 128, 210, 144], fill=(30, 14, 8), outline=ORG)
            d.text((CX, 131), "CEO \"레트로 운동화 공급 과잉\" 인정", font=F9, fill=WHITE, anchor="ma")
    fx = {}
    if seg[1] + 0.2 < t < seg[1] + 0.32: fx["flash"] = 0.4
    return fx

def s_rivals(img, d, t, seg, dur):
    header(d, t, "WHY 2", "NEW RIVALS", "진입장벽이 낮아졌다", CYAN)
    cx, cy, r = CX, 186, 46
    share = lerp(0.85, 0.62, ease(prog(t, seg[1], seg[1] + 2.2)))
    start = -90
    nike_end = start + 360 * share
    d.pieslice([cx - r, cy - r, cx + r, cy + r], start, nike_end, fill=WHT2, outline=DARK)
    rest = 360 * (1 - share); rc = [CYAN, GRN, PURP, YEL]
    a = nike_end
    for i, c in enumerate(rc):
        d.pieslice([cx - r, cy - r, cx + r, cy + r], a, a + rest / 4, fill=c, outline=DARK); a += rest / 4
    mid = math.radians(start + 180 * share)
    d.text((cx + math.cos(mid) * r * 0.45, cy + math.sin(mid) * r * 0.45 - 6), "나이키", font=F12, fill=DARK, anchor="ma")
    d.text((SX1 - 4, 136), "※ 그림은 예시", font=F9, fill=DIM, anchor="ra")
    # rival sneakers dashing in
    for i, c in enumerate(rc):
        ts = seg[1] + 0.2 + i * 0.35
        if t < ts: continue
        side = -1 if i % 2 == 0 else 1
        tx = cx + side * (62 + (i // 2) * 8); ty = 226 + (i // 2) * 16
        x = lerp(cx + side * 140, tx, ease(prog(t, ts, ts + 0.5)))
        put(img, sneaker_img(c, 1, flip=side > 0), x - 13, ty)
        if t < ts + 0.5:
            for k in range(3): square(d, x - side * (16 + k * 5), ty + 10, GRAY, 2)
    if t > seg[1]: d.text((cx, 236), "신생 브랜드들", font=F9, fill=CYAN, anchor="ma")
    if len(seg) > 2 and t > seg[2]:
        bank(d, 34, 270, 30)
        d.rectangle([72, 274, 216, 298], fill=(10, 14, 30), outline=WHT2)
        d.text((144, 278), "골드만삭스: \"구조적 변화\"", font=F9, fill=WHITE, anchor="ma")
        d.text((144, 289), "점유율 되찾기 어렵다", font=F9, fill=YEL, anchor="ma")
    return {}

def s_china(img, d, t, seg, dur):
    header(d, t, "WHY 3", "CHINA", "중화권 매출 급감", SRED)
    x0, x1, y0 = 52, 198, 138
    # awning stripes (vertical)
    for i in range(10):
        c = SRED if i % 2 == 0 else WHITE
        d.rectangle([x0 + i * 15, y0, x0 + i * 15 + 14, y0 + 10], fill=c)
    d.rectangle([x0, y0 + 11, x1 - 4, y0 + 62], fill=(40, 30, 40), outline=GRAY)
    d.rectangle([x0 + 8, y0 + 20, x0 + 70, y0 + 54], fill=(20, 40, 70), outline=WHT2)
    put(img, sneaker_img(SRED, 1), x0 + 14, y0 + 34)
    d.rectangle([x0 + 92, y0 + 22, x0 + 124, y0 + 62], fill=(30, 20, 20), outline=WHT2)
    on = blink(t, 1.3)
    d.text((x0 + 108, y0 + 28), "OPEN" if on else "", font=F9, fill=YEL if on else DIM, anchor="ma")
    lantern(d, x0 + 4, y0 + 18, t); lantern(d, x1 - 8, y0 + 18, t + 1)
    for i in range(3):
        ts = 0.8 + i * 0.6
        if t > ts:
            px = x0 + 110 + (t - ts) * 26 + i * 6
            if px < SX1 - 8: mv_person(d, px, y0 + 44)
    if t > seg[1]:
        base = 298
        u1 = ease(prog(t, seg[1] + 0.1, seg[1] + 0.7)); u2 = ease(prog(t, seg[1] + 0.8, seg[1] + 1.4))
        h1 = int(44 * u1); h2 = int(34 * u2)
        d.line([(44, base + 1), (206, base + 1)], fill=GRAY)
        d.rectangle([62, base - h1, 100, base], fill=GRAY)
        d.rectangle([150, base - h2, 188, base], fill=SRED)
        if u1 > 0.9: d.text((81, base - h1 + 3), "$15.1억", font=F9, fill=DARK, anchor="ma")
        if u2 > 0.9: d.text((169, base - h2 + 3), "$11.8억", font=F9, fill=WHITE, anchor="ma")
        d.text((81, base + 3), "1년 전", font=F9, fill=GRAY, anchor="ma"); d.text((169, base + 3), "지금", font=F9, fill=SRED, anchor="ma")
        crack(d, 152, base - h2 + 12, 186, base - 3, t, seg[1] + 1.5, DARK, 3)
        if t > seg[1] + 1.5:
            vis, o = slam(t, seg[1] + 1.5)
            ctext(d, 206 + o, "-26%", F24, SRED)
            d.text((CX, 232 + o), "환율 효과 제외 · 1년 전 대비", font=F9, fill=GRAY, anchor="ma")
        debris(d, 169, base - h2, t, seg[1] + 1.5, 12, (SRED, WHITE), 45, 0.7, 4)
    fx = {}
    if t > seg[1] + 1.5 and t < seg[1] + 1.7: fx["shake"] = (int(math.sin(t * 70) * 2), 0)
    return fx

def mv_person(d, x, y):
    d.rectangle([x + 1, y, x + 4, y + 3], fill=SKIN); d.rectangle([x, y + 4, x + 5, y + 10], fill=CYAN)
    d.line([(x + 1, y + 11), (x + 1, y + 14)], fill=GRAY); d.line([(x + 4, y + 11), (x + 4, y + 14)], fill=GRAY)

def s_guide(img, d, t, seg, dur):
    header(d, t, "WHY 4", "WEAK GUIDE", "올해 전망도 실망", YEL)
    # chalkboard
    d.rectangle([34, 132, 216, 202], fill=(16, 40, 28), outline=(150, 110, 60), width=2)
    d.text((44, 140), "FY2027 회사 전망", font=F9, fill=GRAY)
    d.text((44, 156), typed_k("매출  ▼ 한 자릿수 후반", t, 0.5), font=F12, fill=WHITE)
    d.text((44, 176), typed_k("이익  ▼ 기대 이하", t, 1.3), font=F12, fill=WHITE)
    # chalk dust
    if t < 2.4:
        for k in range(4): square(d, 160 + (k * 13) % 30, 190 - ((t * 20 + k * 7) % 12), (200, 220, 200), 1)
    if t > seg[1]:
        base = 292
        u1 = ease(prog(t, seg[1] + 0.1, seg[1] + 0.7)); u2 = ease(prog(t, seg[1] + 0.8, seg[1] + 1.4))
        h1 = int(161 * 0.4 * u1); h2a = int(115 * 0.4 * u2); h2b = int(135 * 0.4 * u2)
        d.line([(44, base + 1), (206, base + 1)], fill=GRAY)
        d.rectangle([62, base - h1, 100, base], outline=GRAY)
        for yy in range(base - h1 + 2, base, 3): d.line([(64, yy), (98, yy)], fill=(60, 66, 90))
        d.rectangle([150, base - h2a, 188, base], fill=SRED)
        if h2b > h2a: d.rectangle([150, base - h2b, 188, base - h2a], fill=dk(SRED, 0.6))
        if u1 > 0.9: d.text((81, base - h1 - 11), "$1.61", font=F9, fill=WHITE, anchor="ma")
        if u2 > 0.9: d.text((169, base - h2b - 11), "$1.15~1.35", font=F9, fill=WHITE, anchor="ma")
        d.text((81, base + 3), "시장 기대", font=F9, fill=GRAY, anchor="ma"); d.text((169, base + 3), "회사 전망", font=F9, fill=SRED, anchor="ma")
        if u2 >= 1:
            yt = base - h1; yb = base - h2b
            d.line([(104, yt), (146, yt)], fill=YEL); d.line([(125, yt), (125, yb)], fill=YEL)
            d.polygon([(121, yb - 4), (129, yb - 4), (125, yb)], fill=YEL)
        stamp_slam(img, 150, 172, "실망", SRED, t, seg[1] + 1.6)
        debris(d, 150, 172, t, seg[1] + 1.6, 14, (SRED, YEL, WHITE), 55, 0.8, 9)
    fx = {}
    if seg[1] + 1.6 < t < seg[1] + 1.72: fx["flash"] = 0.4
    if seg[1] + 1.6 < t < seg[1] + 1.9: fx["zoom"] = 1 + 0.05 * (1 - prog(t, seg[1] + 1.6, seg[1] + 1.9))
    return fx

def typed_k(s, t, t0, cps=16): return s[:int(max(0, t - t0) * cps)]

def s_hope(img, d, t, seg, dur):
    header(d, t, "BUT", "SIGNS OF LIFE", "본업은 살아나는 중", GRN)
    items = [("러닝", 0), ("축구", 1), ("테니스", 2), ("골프", 3)]
    for i, (name, kind) in enumerate(items):
        ts = seg[1] + i * 0.35
        x = 46 + i * 46; y = 150
        if t < ts:
            continue
        bounce = -abs(math.sin((t - ts) * 5)) * 6 * max(0, 1 - (t - ts) / 1.5)
        yy = y + bounce
        if kind == 0: put(img, sneaker_img(SRED, 1), x - 13, yy - 6)
        elif kind == 1: soccer(d, x, yy)
        elif kind == 2: tennis(d, x, yy)
        else: golf(d, x - 4, yy)
        d.text((x, 166), name, font=F9, fill=WHITE, anchor="ma")
        d.text((x, 178), "10%+↑", font=F9, fill=GRN, anchor="ma")
        if t < ts + 0.6:
            for k in range(5):
                a = (k * 2.4 + i) % 6.28; r = (t - ts) * 30
                square(d, x + math.cos(a) * r, yy + math.sin(a) * r * 0.7, YEL, 2)
    # track + runner
    for ln in range(3): d.line([(SX0 + 2, 206 + ln * 10), (SX1 - 4, 206 + ln * 10)], fill=(90, 50, 40) if ln else WHITE)
    rx = SX0 + ((t * 45) % (SX1 - SX0 - 12))
    runner(d, rx, 194, t, SRED)
    for k in range(3): square(d, rx - 6 - k * 6, 214 + (k % 2), (160, 120, 90), 2)
    if t < seg[1]:
        d.rectangle([60, 140, 190, 180], fill=(8, 24, 14), outline=GRN)
        ctext(d, 152, "HOPE?", F12, GRN if blink(t, 2) else YEL)
    if len(seg) > 2 and t > seg[2]:
        vis, o = slam(t, seg[2] + 0.2)
        if vis:
            d.rectangle([36, 248 + o, 214, 296 + o], fill=(8, 24, 14), outline=GRN)
            d.text((CX, 254 + o), "스포츠 성능 제품 매출 ↑", font=F12, fill=GRN, anchor="ma")
            d.text((CX, 274 + o), "매출총이익률 42.8% (+0.6%p)", font=F9, fill=WHITE, anchor="ma")
    confetti(d, t, seg[1] + 1.4, 10, (GRN, YEL), 124, 240) if len(seg) > 1 else None
    return {}

def s_cushion(img, d, t, seg, dur):
    header(d, t, "PLUS", "CUSHION", "버틸 힘은 있다", YEL)
    cards = [(0.3, "배당 수익률 약 4.7%", "24년 연속 배당 인상", 0),
             (0.9, "팀 쿡(이사) 25,000주 매수", "2026년 4월", 1),
             (1.5, "비용 절감 25억 달러", "효과는 2029~30 회계연도", 2)]
    for ts, a, b, k in cards:
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 130 + k * 38 + o
        d.rectangle([34, y, 216, y + 32], fill=(10, 14, 30), outline=[YEL, CYAN, SRED][k])
        if k == 0: coin_stack(d, 40, y + 20, 4)
        elif k == 1: person(d, 42, y + 6)
        else: scissors(d, 40, y + 8)
        d.text((66, y + 5), a, font=F12 if k != 1 else F9, fill=WHITE)
        d.text((66, y + 20), b, font=F9, fill=GRAY)
    if k == 0 and t > 0.3:
        for j in range(3):
            ph = ((t - 0.3) * 0.8 + j * 0.33) % 1
            square(d, 44 + j * 5, 120 + ph * 20, YEL, 2)
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([34, 250 + o, 216, 296 + o], fill=(30, 22, 6), outline=YEL if blink(t, 2.5) else ORG)
            warn_icon(d, 42, 258 + o)
            d.text((66, 256 + o), "배당 > 이익", font=F12, fill=YEL)
            d.text((66, 276 + o), "배당성향 120% 이상 (전망 기준)", font=F9, fill=WHITE)
    return {}

def s_verdict(img, d, t, seg, dur):
    header(d, t, "VERDICT", "NOT OVER?", "숫자로 증명할 시간", CYAN)
    px, py = CX, 150
    tilt = math.sin(t * 2.2) * 6 * max(0.25, 1 - t / 4) - 3
    d.polygon([(px - 6, 230), (px + 6, 230), (px, py)], fill=GRAY)
    d.rectangle([px - 20, 230, px + 20, 234], fill=GRAY)
    lx, ly = px - 60, py + tilt; rx, ry = px + 60, py - tilt
    d.line([(lx, ly), (rx, ry)], fill=WHT2, width=3)
    d.ellipse([px - 3, py - 3, px + 3, py + 3], fill=YEL)
    for (x, y, col, label, items) in [(lx, ly, SRED, "하락 요인", ["점유율", "중국", "전망"]),
                                      (rx, ry, GRN, "반등 신호", ["러닝", "배당", "절감"])]:
        d.line([(x, y), (x - 18, y + 30)], fill=GRAY); d.line([(x, y), (x + 18, y + 30)], fill=GRAY)
        d.rectangle([x - 26, y + 30, x + 26, y + 34], fill=col)
        for i, s in enumerate(items):
            d.rectangle([x - 24 + i * 17, y + 18, x - 10 + i * 17, y + 29], fill=dk(col, 0.7))
        d.text((x, y + 38), label, font=F9, fill=col, anchor="ma")
        for i, s in enumerate(items): d.text((x, y + 50 + i * 11), s, font=F9, fill=WHITE, anchor="ma")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([44, 262 + o, 206, 300 + o], fill=(10, 14, 30), outline=YEL)
            d.rectangle([44, 262 + o, 206, 272 + o], fill=SRED)
            d.text((CX, 263 + o), "NOV 16~17", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 279 + o), "인베스터 데이", font=F12, fill=YEL, anchor="ma")
        confetti(d, t, seg[1] + 0.4, 12, (YEL, CYAN, WHITE), 124, 260)
    d.text((CX, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=GRAY, anchor="ma")
    return {}

SCRIPT = [
    (s_hook, [("한때 177달러였던 나이키가\n지금은 34달러, 고점 대비 -80%", "한때 백칠십칠 달러였던 나이키가, 지금은 삼십사 달러. 고점 대비 팔십 퍼센트 하락이에요."),
              ("골드만삭스마저 매도로 돌아섰죠\n나이키, 진짜 끝일까요?", "골드만삭스마저 매도로 돌아섰죠. 나이키, 진짜 끝일까요?")]),
    (s_many, [("첫째, 인기 운동화를\n너무 많이 풀었어요", "첫째, 인기 운동화를 너무 많이 풀었어요."),
              ("흔해진 한정판은 특별하지 않죠\nCEO도 공급 과잉을 인정했어요", "흔해진 한정판은 특별하지 않죠. 씨이오도 공급 과잉을 인정했어요.")]),
    (s_rivals, [("둘째, 경쟁자가 너무 많아졌어요", "둘째, 경쟁자가 너무 많아졌어요."),
                ("신생 브랜드들이 틈새를 파고들며\n점유율이 밀리고 있죠", "신생 브랜드들이 틈새를 파고들면서, 점유율이 밀리고 있죠."),
                ("골드만삭스는 이 변화가\n되돌리기 어렵다고 봐요", "골드만삭스는 이 변화가, 되돌리기 어렵다고 봐요.")]),
    (s_china, [("셋째, 중국에서\n크게 고전 중이에요", "셋째, 중국에서 크게 고전 중이에요."),
               ("중화권 매출이 1년 새\n26%나 줄었어요", "중화권 매출이 일 년 새, 이십육 퍼센트나 줄었어요.")]),
    (s_guide, [("넷째, 올해 전망도\n실망스러웠어요", "넷째, 올해 전망도 실망스러웠어요."),
               ("매출은 더 줄고, 이익 전망도\n시장 기대보다 한참 낮았죠", "매출은 더 줄고, 이익 전망도 시장 기대보다 한참 낮았죠.")]),
    (s_hope, [("그래도 희망은 있어요", "그래도 희망은 있어요."),
              ("러닝·축구·테니스·골프는\n모두 두 자릿수 성장했어요", "러닝, 축구, 테니스, 골프는 모두 두 자릿수 성장했어요."),
              ("본업인 스포츠 성능 제품이\n다시 살아나고 있다는 신호죠", "본업인 스포츠 성능 제품이, 다시 살아나고 있다는 신호죠.")]),
    (s_cushion, [("배당 수익률은 약 4.7%\n이사인 팀 쿡도 2만 5천 주를 샀죠", "배당 수익률은 약 사 점 칠 퍼센트. 이사회 멤버인 팀 쿡도 이만 오천 주를 샀죠."),
                 ("다만 지금은 이익보다 배당이 많아\n배당 유지 여부는 지켜봐야 해요", "다만 지금은 이익보다 배당이 많아서, 배당이 유지될지는 지켜봐야 해요.")]),
    (s_verdict, [("살아나는 신호는 있지만\n증명까진 시간이 필요해요", "정리하면, 살아나는 신호는 있지만, 증명까진 시간이 필요해요."),
                 ("첫 시험대는 11월 16일\n인베스터 데이입니다", "첫 시험대는, 십일월 십육일 인베스터 데이입니다.")]),
]
TITLES = ["", "TOO MANY", "NEW RIVALS", "CHINA", "WEAK GUIDE", "SIGNS OF LIFE", "CUSHION", "NOT OVER?"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

TR = 0.4
WHITE_IMG = Image.new("RGB", (W, H), (255, 255, 255))
def render_low(sc, t):
    img = bg_img("grid").copy(); d = ImageDraw.Draw(img); d.fontmode = "1"
    fx = sc["fn"](img, d, t, sc["seg"], sc["dur"]) or {}
    dx, dy = fx.get("shake", (0, 0))
    if dx or dy:
        out = bg_img("grid").copy(); out.paste(img, (dx, dy)); img = out
    z = fx.get("zoom", 1.0)
    if z > 1.001:
        cw, ch = int(W / z), int(H / z)
        img = img.crop(((W - cw) // 2, (H - ch) // 2, (W - cw) // 2 + cw, (H - ch) // 2 + ch)).resize((W, H), Image.NEAREST)
    fl = fx.get("flash", 0)
    if fl > 0: img = Image.blend(img, WHITE_IMG, fl)
    return img

def render_frame(T, scenes, starts, total):
    k = min(max(i for i in range(len(scenes)) if starts[i] <= T + 1e-9), len(scenes) - 1)
    t = T - starts[k]; sc = scenes[k]
    low = render_low(sc, t)
    if k > 0 and t < TR:
        prev = render_low(scenes[k - 1], scenes[k - 1]["dur"] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T > total - 0.8: a = (a * clamp((total - T) / 0.8)).astype(np.uint8)
    big = Image.fromarray(a)
    segs = sc["seg"] + [sc["dur"]]
    for i, s in enumerate(sc["subs"]):
        if segs[i] <= t < segs[i + 1] and T < total - 0.5:
            si = sub_img(s); big.paste(si, (0, sv.SUB_Y), si)
    return big

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    bpm = 120; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    minor = [([57, 60, 64], 45), ([53, 57, 60], 41), ([55, 59, 62], 43), ([52, 56, 59], 40)]   # Am F G E
    major = [([60, 64, 67], 48), ([55, 59, 62], 43), ([57, 60, 64], 45), ([53, 57, 60], 41)]   # C G Am F
    mel = [[72, None, 74, 76, 79, None, 76, 74], [74, None, 71, 67, 71, None, 74, None],
           [72, None, 76, 79, 81, 79, 76, None], [77, None, 76, 74, 72, None, None, None]]
    def sec(T):
        if T < S[1]: return "hook"
        if T < S[5]: return "tense"
        if T < S[7]: return "hope"
        return "outro"
    for b in range(int(total / bar) + 1):
        t0 = b * bar; name = sec(t0)
        notes, root = (major if name in ("hope", "outro") else minor)[b % 4]
        drums = name != "tense" or b % 2 == 0
        for st in range(16):
            T = t0 + st * s16
            if T >= total: break
            tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + 12), 0.045, "sq", 0.125, decay=0.08)
            if st % 2 == 0: tone(bgm, T, 0.03, 0, 0.028 if st % 4 else 0.016, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.9, mtof(root - 12 + (12 if st % 2 else 0)), 0.16, "tri")
            m = mel[b % 4][st]
            if m and name in ("hope", "outro"): tone(bgm, T, e * 0.95, mtof(m - 12), 0.04, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2): tone(bgm, T, 0.16, 150, 0.33, "sin", f1=45, decay=0.07)
            if bt in (1, 3) and drums:
                tone(bgm, T, 0.12, 0, 0.11, "noise", decay=0.04); tone(bgm, T, 0.08, 190, 0.07, "tri", decay=0.04)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05); tone(sfx, T + 0.02, 0.1, 300, 0.06, "sq", 0.5, f1=80)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def coin(T): tone(sfx, T, 0.04, 988, 0.05, "sq", 0.5); tone(sfx, T + 0.04, 0.1, 1319, 0.05, "sq", 0.5, decay=0.05)
    def crackfx(T):
        for j in range(5): tone(sfx, T + j * 0.05, 0.04, 0, 0.12, "noise", decay=0.015)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    tone(sfx, S[0] + 0.05, 1.45, 1300, 0.05, "sq", 0.5, f1=150); stampfx(S[0] + 1.55)
    stampfx(sg(0, 1) + 0.5)
    for k in range(1, len(scenes)): swoosh(S[k]); typing(S[k] + 0.1, TITLES[k])
    for j in range(18): pop(S[1] + 0.3 + j * 0.14)
    for j in range(12): blip(S[1] + 2.6 + j * 0.15, 400, 0.04)
    stampfx(sg(1, 1) + 0.2)
    for i in range(4): swoosh(sg(2, 1) + 0.2 + i * 0.35)
    thump(sg(2, 2) + 0.1)
    for i in range(3): blip(S[3] + 0.8 + i * 0.6, 900, 0.03)
    crackfx(sg(3, 1) + 1.5); thump(sg(3, 1) + 1.5)
    stampfx(sg(4, 1) + 1.6)
    for i in range(4): pop(sg(5, 1) + i * 0.35); ding(sg(5, 1) + i * 0.35 + 0.05) if i == 3 else None
    for j in range(int(scenes[5]["dur"] / 0.18)): tone(sfx, S[5] + j * 0.18, 0.02, 0, 0.02, "noise", decay=0.01)
    thump(sg(5, 2) + 0.2)
    for ts in (0.3, 0.9, 1.5): thump(S[6] + ts); coin(S[6] + ts + 0.05)
    tone(sfx, sg(6, 1) + 0.2, 0.12, 880, 0.06, "sq", 0.5); tone(sfx, sg(6, 1) + 0.35, 0.12, 660, 0.06, "sq", 0.5)
    thump(sg(7, 1) + 0.2); ding(sg(7, 1) + 0.25)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

"""특별편 11 · 미국이 AI 투자를 절대 멈출 수 없는 이유 5가지 (memneck_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-24 기준):
 · 빅테크 4사 2026 설비투자 가이던스 합계 약 7,300억$ (아마존 ~2,200억 · 알파벳 1,950~2,050억 · MS ~1,750억 · 메타 1,350~1,450억) vs 2025년 약 4,100억$(+78%) (ValueAdd VC 10/2 정리, 메타 10/21 실적 반영)
 · ING(IndexBox 8/20): 2026년 2분기 미국 GDP 전년비 성장률의 약 36%가 AI 관련 투자(수입 제외, ING 선호 지표) · 넓게 보면 50%
 · TS Lombard(Forbes 6/5): 2026년 AI·데이터센터 투자 GDP의 약 2% · 국방비 2025년 GDP 2.9%(9,540억$)
 · JP모건 AI 41종목 바스켓 = S&P500 시총 49%(10월 초) · 한 테마가 이보다 컸던 건 19세기 철도뿐 (Crypto Briefing 10/19)
 · Epoch AI(알자지라 9/24): 세계 AI 연산 능력 미국 약 3/4, 중국 14% 남짓 · 트렌드포스: 2026 중국 4대 클라우드 설비투자 +80%↑(미국 +76%) · CSIS 7월: 중국 모델 '몇 년이 아니라 몇 달' 뒤
 · 백악관 AI 행동계획(2025.7.23) 제목 'Winning the Race'
 · 메타 3분기(10/21): 설비투자 349억$ · 잉여현금흐름 −21억$(전년 +106억$) · 올해 가이던스 하단 1,300억→1,350억$ (Benzinga) · 다음 날 주가 약 −7%(CNBC 10/22)
 · 오픈AI: 앞으로 8년간 약 1.4조$ 컴퓨팅 약정(2025년 11월 공개) · 스타게이트 5,000억$·약 10GW(소프트뱅크·오라클)
 · 엔비디아 10/22 '네오클라우드 수요 폭발, 중간 운전자금 부족' 발언 → 하루 −4.4%(212.21$, TradingKey)
10/24 사용자 지시: 배경음악은 밝고 잔잔한 곡 하나로 쭉 · 배경색은 웬만하면 그대로(챕터 카드도 한 가지 색, 번쩍임은 큰 장면만).
실존 인물 없음. 상승·하락 빨강/초록 구분 안 함.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, coin, F36, GOLD
from ackman_video import tower, money_bag, up_arrow
from semicrash_video import news_card, qmark, TEAL
from aibubble_video import datacenter, path_until, balance
from survive_video import ant, speech, checkmark, xmark, PINK, MINT
from squeeze_video import CH, chapter_card, with_card, ring

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "aiinvest/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
CARD = YEL                                                                     # 챕터 카드는 한 가지 색(배경색 자주 바꾸지 않기)

# ================================================================ drawings
def pie(d, cx, cy, r, frac, col, rest=(34, 40, 62)):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rest, outline=GRAY)
    if frac > 0.002: d.pieslice([cx - r, cy - r, cx + r, cy + r], -90, -90 + 360 * frac, fill=col)

def train(d, x, y, t, col=ORG):
    """19세기 증기기관차 + 연기"""
    d.rectangle([x, y, x + 40, y + 16], fill=dk(col, 0.8), outline=col); d.rectangle([x + 28, y - 12, x + 40, y], fill=dk(col, 0.6), outline=col)
    d.rectangle([x + 6, y - 8, x + 11, y], fill=GRAY)
    for k in range(3): d.ellipse([x + 4 + k * 13, y + 13, x + 14 + k * 13, y + 23], fill=DARK, outline=GRAY)
    for k in range(3):
        u = (t * 0.8 + k * 0.33) % 1; r = 3 + int(5 * u)
        d.ellipse([x + 8 - r - int(10 * u), y - 12 - int(18 * u) - r, x + 8 + r - int(10 * u), y - 12 - int(18 * u) + r], outline=dk(WHT2, 1 - 0.6 * u))
    d.line([(x - 14, y + 24), (x + 60, y + 24)], fill=GRAY)

def flag_us(d, x, y):
    for k in range(7): d.rectangle([x, y + k * 3, x + 30, y + k * 3 + 1], fill=(200, 50, 60) if k % 2 == 0 else WHITE)
    d.rectangle([x, y, x + 12, y + 9], fill=(40, 60, 150))
    for k in range(4): d.point((x + 2 + k * 3, y + 3), fill=WHITE); d.point((x + 3 + k * 3, y + 6), fill=WHITE)

def flag_cn(d, x, y):
    d.rectangle([x, y, x + 30, y + 20], fill=(210, 40, 40))
    d.rectangle([x + 3, y + 3, x + 7, y + 7], fill=YEL)
    for (a, b) in ((10, 2), (12, 5), (12, 9), (10, 12)): d.rectangle([x + a, y + b, x + a + 1, y + b + 1], fill=YEL)

def contract(d, x, y, lbl, signed=1.0, col=WHT2):
    d.rectangle([x, y, x + 46, y + 58], fill=(230, 228, 214), outline=col)
    d.text((x + 23, y + 4), lbl, font=F9, fill=DARK, anchor="ma")
    for k in range(5): d.line([(x + 6, y + 18 + k * 6), (x + 40, y + 18 + k * 6)], fill=(150, 150, 150))
    if signed > 0:
        pts = [(x + 8 + i * 2, y + 50 + int(math.sin(i * 1.3) * 3)) for i in range(int(14 * signed))]
        if len(pts) > 1: d.line(pts, fill=(40, 60, 150))

def crane(d, x, y, t, col=YEL):
    """공사 크레인(갈고리가 흔들림)"""
    d.rectangle([x, y, x + 4, y + 70], fill=col)
    for k in range(8): d.line([(x, y + k * 9), (x + 4, y + k * 9 + 9)], fill=dk(col, 0.6))
    d.rectangle([x - 20, y - 4, x + 54, y], fill=col); d.rectangle([x - 22, y, x - 12, y + 8], fill=GRAY)
    hx = x + 40 + int(math.sin(t * 2) * 3)
    d.line([(x + 40, y), (hx, y + 30)], fill=GRAY); d.rectangle([hx - 3, y + 30, hx + 3, y + 34], fill=GRAY)

def race_lane(d, x0, x1, y, t, u_us, u_cn):
    d.line([(x0, y + 22), (x1, y + 22)], fill=GRAY); d.line([(x0, y + 46), (x1, y + 46)], fill=GRAY)
    d.rectangle([x1 - 2, y, x1, y + 48], fill=WHITE)
    for k, (u, fl) in enumerate(((u_us, flag_us), (u_cn, flag_cn))):
        px = int(lerp(x0, x1 - 40, u)); py = y + 2 + k * 24
        fl(d, px, py)
        for j in range(3): d.line([(px - 4 - j * 6, py + 6 + j * 3), (px - 10 - j * 6, py + 6 + j * 3)], fill=DIM)

# ================================================================ scenes
def punch_fx(t, t0, flash=False):
    fx = {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2))}
    if flash: fx["flash"] = 0.25
    return fx if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · AI 투자", "못 멈추는 이유", "미국이 AI에 돈을 붓는 진짜 이유", YEL)
    s1 = seg[1]
    datacenter(d, 90, 156, t, CYAN)
    for k in range(6):                                                             # 돈 자루가 데이터센터로
        u = ((t * 0.6 + k / 6) % 1)
        if t > 0.3: money_bag(d, int(lerp(30, 100, u)), int(lerp(126, 166, u)) - int(math.sin(u * math.pi) * 18))
    if t > 0.8:
        v = 7300 * ease(prog(t, 0.8, 2.2))
        d.text((CX, 226), "빅테크 4곳 · 2026년 설비투자", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 238), f"약 {v:,.0f}억 달러", font=F24, fill=YEL, anchor="ma")
    if t > s1:
        vis, o = slam(t, s1 + 0.3, 0.2)
        box(d, 34, 270 + o, 216, 300 + o, YEL, (30, 26, 8))
        d.text((CX, 278 + o), "절대 못 멈추는 이유 5가지", font=F12, fill=WHITE, anchor="ma")
    return {}

def s_gdp(img, d, t, seg, dur):
    header(d, t, "01 · 경제", "성장의 3분의 1", "2026년 2분기 · ING", CYAN)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        pie(d, CX, 180, 48, 0.36 * ease(prog(t, 0.3, 1.8)), CYAN)
        if t > 1.8:
            d.text((CX, 172), "36%", font=F24, fill=WHITE, anchor="ma")
            d.text((CX, 238), "미국 경제성장 중 AI 투자 몫", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 252), "(수입 빼고 계산 · 넓게 보면 50%)", font=F9, fill=DIM, anchor="ma")
    elif t < s2:
        d.text((CX, 124), "GDP 대비 · 2026년", font=F9, fill=GRAY, anchor="ma")
        for i, (nm, v, col) in enumerate([("AI·데이터센터", 2.0, CYAN), ("국방비(2025)", 2.9, GRAY)]):
            u = ease(prog(t, s1 + 0.2 + i * 0.4, s1 + 0.9 + i * 0.4)); h = int(v * 34 * u); x = 64 + i * 92
            d.rectangle([x, 270 - h, x + 36, 270], fill=col)
            d.text((x + 18, 276), nm, font=F9, fill=WHITE, anchor="ma")
            if u >= 1: d.text((x + 18, 270 - h - 14), f"{v}%", font=F12, fill=col, anchor="ma")
        d.text((CX, 300), "TS롬바드 · 피터슨재단", font=F9, fill=DIM, anchor="ma")
    else:
        tower(d, 56, 170, 40, 96, CYAN, None, 1.0)
        tower(d, 150, 170, 40, 96, CYAN, None, 1.0 - ease(prog(t, s2 + 0.3, s2 + 1.3)))
        d.text((76, 156), "투자 계속", font=F9, fill=WHITE, anchor="ma"); d.text((170, 156), "멈추면", font=F9, fill=WHITE, anchor="ma")
        if t > s2 + 1.0: crack(d, 150, 170, 190, 266, t, s2 + 1.0)
    return {}

def s_market(img, d, t, seg, dur):
    header(d, t, "02 · 증시", "S&P500 절반이 AI", "JP모건 AI 41종목 · 10월 초", PURP)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        cells = 100; on = int(49 * ease(prog(t, 0.3, 2.0)))
        for k in range(cells):
            r, c = divmod(k, 10); x = 70 + c * 11; y = 124 + r * 11
            d.rectangle([x, y, x + 8, y + 8], fill=PURP if k < on else (34, 40, 62))
        if t > 2.0: d.text((CX, 240), "시가총액의 49%", font=F24, fill=YEL, anchor="ma")
    elif t < s2:
        train(d, 92, 170, t)
        d.text((CX, 128), "한 테마가 이보다 컸던 건", font=F12, fill=WHITE, anchor="ma")
        if t > s1 + 0.8:
            vis, o = slam(t, s1 + 0.8, 0.2)
            box(d, 50, 214 + o, 200, 242 + o, ORG, (30, 16, 6))
            d.text((CX, 222 + o), "19세기 철도뿐", font=F12, fill=ORG, anchor="ma")
    else:
        for k in range(5): mini_person(d, 50 + k * 34, 210, (CYAN, PINK, GRN, ORG, MINT)[k], t, k)
        for k in range(5):
            x = 44 + k * 34; d.rectangle([x, 236, x + 22, 252], fill=(20, 26, 44), outline=GOLD)
            d.text((x + 11, 240), "연금", font=F9, fill=GOLD, anchor="ma")
        d.text((CX, 140), "미국 가계 노후자금도", font=F12, fill=WHITE, anchor="ma")
        d.text((CX, 158), "대부분 S&P500에 묶여 있어요", font=F9, fill=GRAY, anchor="ma")
    return {}

def s_china(img, d, t, seg, dur):
    header(d, t, "03 · 미·중", "중국이 쫓아온다", "멈추는 순간 따라잡힘", ORG)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        d.text((CX, 124), "세계 AI 연산 능력 · Epoch AI", font=F9, fill=GRAY, anchor="ma")
        for i, (fl, nm, v, col) in enumerate([(flag_us, "미국", 75, CYAN), (flag_cn, "중국", 14, ORG)]):
            y = 146 + i * 40; fl(d, 34, y)
            w = int(v / 75 * 120 * ease(prog(t, 0.3 + i * 0.4, 1.2 + i * 0.4)))
            d.rectangle([72, y + 4, 72 + w, y + 16], fill=col)
            if t > 1.2 + i * 0.4: d.text((76 + w, y + 5), f"약 {v}%", font=F9, fill=WHITE)
        d.text((CX, 236), "아직은 미국이 압도적", font=F12, fill=WHITE, anchor="ma") if t > 2.0 else None
    elif t < s2:
        u = ease(prog(t, s1 + 0.2, s1 + 3.0))
        race_lane(d, 34, 216, 140, t, 0.2 + 0.6 * u, 0.05 + 0.72 * u)
        vis, o = slam(t, s1 + 0.6, 0.2)
        d.text((CX, 206 + o), "중국 4대 빅테크 투자 +80%↑", font=F12, fill=ORG, anchor="ma")
        if t > s1 + 1.8: d.text((CX, 226), "모델 격차는 '몇 년'이 아니라 '몇 달'", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 300), "트렌드포스 · CSIS", font=F9, fill=DIM, anchor="ma")
    else:
        flag_us(d, CX - 15, 132)
        vis, o = slam(t, s2 + 0.3, 0.2)
        box(d, 34, 166 + o, 216, 224 + o, CYAN, (8, 20, 30))
        d.text((CX, 172 + o), "미국 정부 AI 행동계획(2025.7)", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 188 + o), "'경쟁에서 이기기'", font=F24, fill=YEL, anchor="ma")
        if t > s2 + 1.2: d.text((CX, 244), "AI = 안보 문제", font=F12, fill=WHITE, anchor="ma")
    return {}

CO = [("아마존", 2200), ("알파벳", 2000), ("MS", 1750), ("메타", 1400)]

def s_dilemma(img, d, t, seg, dur):
    header(d, t, "04 · 눈치 게임", "먼저 멈추면 진다", "빅테크끼리의 죄수의 딜레마", GRN)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        for i, (nm, v) in enumerate(CO):
            x = 36 + i * 46; ts = 0.3 + i * 0.25
            if t < ts: continue
            h = int(v / 2200 * 80 * ease(prog(t, ts, ts + 0.6)))
            d.rectangle([x, 250 - h, x + 32, 250], fill=GRN if i != 3 else GOLD)
            d.text((x + 16, 254), nm, font=F9, fill=WHITE, anchor="ma")
            if t > ts + 0.6: d.text((x + 16, 250 - h - 12), f"{v // 10}0억", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 128), "2026년 설비투자 계획($)", font=F9, fill=GRAY, anchor="ma")
        if t > 1.8: speech(d, 120, 144, "너 먼저 멈춰", tail_left=True)
    elif t < s2:
        d.text((CX, 124), "메타 · 3분기 실적(10월 21일)", font=F9, fill=GRAY, anchor="ma")
        rows = [("잉여현금흐름", "−21억 달러", "첫 적자 전환"), ("올해 투자 하단", "1,350억 달러", "오히려 올림")]
        for i, (a, b, c) in enumerate(rows):
            ts = s1 + 0.3 + i * 0.6
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 142 + i * 44 + o
            d.rectangle([34, y, 216, y + 36], fill=(10, 14, 30), outline=GOLD)
            d.text((42, y + 4), a, font=F9, fill=GRAY); d.text((208, y + 4), c, font=F9, fill=GOLD, anchor="ra")
            d.text((CX, y + 18), b, font=F12, fill=WHITE, anchor="ma")
    else:
        d.text((CX, 128), "다음 날 주가 약 −7%", font=F12, fill=WHITE, anchor="ma")
        ant(d, 112, 160, t, "sweat")
        if t > s2 + 0.8: stamp_slam(img, CX, 240, "그래도 GO", YEL, t, s2 + 0.8, "24", -8)
    return punch_fx(t, s2 + 0.8) if t > s2 else {}

def s_contract(img, d, t, seg, dur):
    header(d, t, "05 · 계약", "이미 도장 찍었다", "중간에 못 내리는 열차", TEAL)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        for k in range(4):
            ts = 0.2 + k * 0.3
            if t > ts: contract(d, 40 + k * 44, 132 + (k % 2) * 8, ("GPU", "전력", "클라우드", "부지")[k], prog(t, ts, ts + 0.6))
        if t > 1.6:
            v = 1.4 * ease(prog(t, 1.6, 2.6))
            d.text((CX, 214), "오픈AI 컴퓨팅 약정 · 8년간", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 228), f"약 {v:.1f}조 달러", font=F24, fill=YEL, anchor="ma")
    elif t < s2:
        crane(d, 50, 150, t)
        for k in range(3): datacenter(d, 110 + (k % 2) * 34, 140 + k * 36 - (k // 2) * 36, t, TEAL) if k < 2 else None
        d.text((CX, 238), "스타게이트 5,000억 달러 · 약 10GW", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 252), "소프트뱅크·오라클과 공사 중", font=F9, fill=GRAY, anchor="ma")
    else:
        datacenter(d, 90, 150, t, GRAY, chained=True, shake=int(math.sin(t * 40) * 2) if t < s2 + 0.6 else 0)
        d.text((CX, 246), "멈추면 짓다 만 건물 + 빚", font=F12, fill=WHITE, anchor="ma")
    return {}

def s_risk(img, d, t, seg, dur):
    header(d, t, "주의", "못 멈춘다 ≠ 오른다", "돈 걱정은 언제든 터질 수 있음", GRAY)
    s1 = seg[1]
    balance(d, CX, 150, 0.4 * math.sin(t * 1.2), CYAN, GRAY, "AI 수요", "자금", 4, 4)
    if t > s1:
        vis, o = slam(t, s1 + 0.2, 0.2)
        news_card(d, 34, 254, o, "10/22 '중간 운전자금이 부족' 발언", GRAY)
        d.text((CX, 282 + o), "엔비디아 하루 −4.4%", font=F12, fill=WHITE, anchor="ma")
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "정리", "못 멈추는 5가지", "미국이 AI 투자를 계속하는 이유", YEL)
    rows = [("성장의 1/3", CYAN), ("증시 49%", PURP), ("중국 추격", ORG), ("눈치 게임", GRN), ("계약 1.4조$", TEAL)]
    for i, (s, col) in enumerate(rows):
        ts = 0.2 + i * 0.22
        if t < ts: continue
        vis, o = slam(t, ts, 0.18); x = 36 + (i % 2) * 92 if i < 4 else 82; y = 122 + (i // 2) * 32 + o
        d.rectangle([x, y, x + 86, y + 26], fill=(10, 14, 30), outline=col); d.text((x + 43, y + 7), s, font=F12, fill=WHITE, anchor="ma")
    if t > 1.6: stamp_slam(img, CX, 240, "STOP 불가", YEL, t, 1.6, "24", -8)
    if len(seg) > 1 and t > seg[1] + 0.2:
        d.text((CX, 274), "단, 속도 조절은 올 수 있어요", font=F12, fill=WHITE, anchor="ma")
    d.text((32, 306), "※ 제작자 해설 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.6, True)

SCRIPT = [
    (s_hook, [("빅테크 4곳이 올해 AI에 쓰는 돈\n약 7,300억 달러", "빅테크 네 곳이 올해 에이아이에 쓰는 돈, 약 칠천삼백억 달러예요."),
              ("버블 걱정에도 미국이 AI 투자를\n절대 못 멈추는 이유 5가지", "버블 걱정이 나와도, 미국이 에이아이 투자를 절대 멈출 수 없는 이유 다섯 가지를 볼게요.")]),
    (with_card(s_gdp, "01", "성장의 3분의 1", CARD), [
        ("올해 2분기 미국 경제성장의\n약 3분의 1이 AI 투자 (ING)", "올해 이 분기, 미국 경제 성장의 약 삼분의 일이 에이아이 관련 투자에서 나왔어요."),
        ("AI·데이터센터 투자는 GDP의 약 2%\n국방비 2.9%에 육박", "에이아이와 데이터센터 투자는 국내총생산의 약 이 퍼센트로, 국방비 이 점 구 퍼센트에 다가가고 있어요."),
        ("멈추면 성장률이 바로 꺾여요", "투자를 멈추면, 성장률이 바로 꺾이는 구조예요.")]),
    (with_card(s_market, "02", "증시 절반이 AI", CARD), [
        ("AI 관련 41개 종목이\nS&P500 시가총액의 49% (JP모건)", "제이피모건이 꼽은 에이아이 관련 사십일 개 종목이, 에스앤피 오백 시가총액의 사십구 퍼센트예요."),
        ("한 테마가 이보다 컸던 건\n19세기 철도뿐", "한 가지 테마가 이보다 컸던 건, 십구 세기 철도 시대뿐이래요."),
        ("멈추면 미국 사람들 노후자금도 흔들려요", "투자가 멈추면, 미국 사람들의 연금과 노후 자금까지 같이 흔들려요.")]),
    (with_card(s_china, "03", "중국이 쫓아온다", CARD), [
        ("세계 AI 연산 능력\n미국 약 75%, 중국 약 14%", "전 세계 에이아이 연산 능력의 약 칠십오 퍼센트는 미국, 중국은 약 십사 퍼센트예요."),
        ("그런데 중국 빅테크 투자는 올해 +80% 넘게\n모델 격차는 '몇 달' 수준", "그런데 중국 빅테크의 올해 투자는 팔십 퍼센트 넘게 늘고, 모델 격차는 몇 년이 아니라 몇 달 수준이래요."),
        ("미국 정부 AI 전략 제목부터\n'경쟁에서 이기기'", "그래서 미국 정부의 에이아이 전략 제목부터, 경쟁에서 이기기예요.")]),
    (with_card(s_dilemma, "04", "먼저 멈추면 진다", CARD), [
        ("빅테크끼리는 먼저 멈추는 쪽이 지는 게임", "빅테크끼리는, 먼저 투자를 멈추는 쪽이 고객을 뺏기는 게임이에요."),
        ("메타는 3분기 잉여현금이 적자로 돌아섰는데도\n올해 투자 하단을 1,350억 달러로 올렸어요", "메타는 삼 분기 잉여현금흐름이 적자로 돌아섰는데도, 올해 투자 계획 하단을 천삼백오십억 달러로 올렸어요."),
        ("다음 날 주가가 약 7% 빠졌는데도 GO", "다음 날 주가가 칠 퍼센트 가까이 빠졌는데도요.")]),
    (with_card(s_contract, "05", "이미 도장 찍었다", CARD), [
        ("오픈AI 혼자 약속한 컴퓨팅만\n8년간 약 1조 4천억 달러", "오픈에이아이 혼자 약속한 컴퓨팅 계약만, 팔 년 동안 약 일조 사천억 달러예요."),
        ("스타게이트 5,000억 달러 · 약 10GW\n이미 공사 중", "스타게이트에만 오천억 달러, 약 십 기가와트. 이미 공사가 진행 중이에요."),
        ("멈추면 짓다 만 데이터센터와 빚만 남아요", "중간에 멈추면, 짓다 만 데이터센터와 빚만 남아요.")]),
    (s_risk, [("단, 못 멈춘다고 주가가\n꼭 오르는 건 아니에요", "단, 못 멈춘다고 해서, 주가가 꼭 오른다는 뜻은 아니에요."),
              ("10월 22일 '자금이 부족하다'는 말 한마디에\n엔비디아 하루 −4.4%", "시월 이십이 일, 중간에 자금이 부족하다는 말 한마디에, 엔비디아가 하루 사 점 사 퍼센트 빠졌죠.")]),
    (s_end, [("성장의 3분의 1, 증시의 절반, 중국 추격\n먼저 멈추면 패배, 이미 맺은 계약", "성장의 삼분의 일, 증시의 절반, 중국의 추격, 먼저 멈추면 지는 게임, 그리고 이미 맺은 계약. 그래서 미국은 에이아이 투자를 못 멈춰요."),
             ("멈추진 못해도 속도 조절은 올 수 있어요", "다만 멈추진 못해도, 속도 조절은 올 수 있다는 것만 기억하세요.")]),
]
TITLES = ["", "성장의 3분의 1", "S&P500 절반이 AI", "중국이 쫓아온다", "먼저 멈추면 진다", "이미 도장 찍었다", "못 멈춘다 ≠ 오른다", "못 멈추는 5가지"]


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    MINLINE = {(0, 0): 2.8, (1, 0): 2.8, (2, 0): 2.8, (3, 0): 2.6, (3, 1): 3.2, (4, 0): 2.6, (5, 0): 2.8, (7, 0): 3.2}
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (CH + 0.5 if 1 <= k <= 5 else 0.3)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += max(L, MINLINE.get((k, i), 0)) + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.4, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    # 10/24 지시: 밝고 잔잔한 장조 칩튠 하나를 처음부터 끝까지(장면마다 곡을 바꾸지 않음) · 96bpm · 드럼은 아주 약하게
    bpm = 96; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = [([60, 64, 67], 48), ([67, 71, 74], 55), ([69, 72, 76], 57), ([65, 69, 72], 53)]       # C G Am F
    mel = [[76, None, 79, None, 81, None, 79, None], [74, None, 79, None, 83, None, 81, 79], [76, None, 72, None, 76, None, 79, None], [77, None, 76, None, 74, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            m = mm[st]
            if m: tone(bgm, T, e * 1.6, mtof(m), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR); fi = int(1.0 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.07, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.06, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.06, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.06, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.035, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.04, "sq", 0.5, f1=150, decay=d)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    def choo(T):
        for j in range(4): tone(sfx, T + j * 0.25, 0.12, 0, 0.05, "noise", decay=0.06)
        tone(sfx, T + 1.0, 0.5, 880, 0.04, "sq", 0.5, decay=0.4); tone(sfx, T + 1.0, 0.5, 1109, 0.03, "sq", 0.5, decay=0.4)
    # hook
    typing(S[0] + 0.1, "못멈추는이유")
    for k in range(6): coin_s(S[0] + 0.4 + k * 0.28)
    rise(S[0] + 0.8, 1.4); ding(S[0] + 2.2); pop(sg(0, 1) + 0.3); ding(sg(0, 1) + 0.5)
    for k in range(1, len(scenes)):
        if 1 <= k <= 5: chapter(S[k]); swoosh(S[k] + CH - 0.25); typing(S[k] + CH + 0.6, TITLES[k])
        else: swoosh(S[k]); typing(S[k] + 0.3, TITLES[k])
    C = lambda k: S[k] + CH
    # 01
    rise(C(1) + 0.3, 1.5); ding(C(1) + 1.8)
    pop(sg(1, 1) + 0.2); pop(sg(1, 1) + 0.6); ding(sg(1, 1) + 1.3)
    fall(sg(1, 2) + 0.3, 1.0); tone(sfx, sg(1, 2) + 1.0, 0.3, 0, 0.08, "noise", decay=0.1)
    # 02
    for k in range(10): blip(C(2) + 0.3 + k * 0.17, 1100 + k * 60)
    ding(C(2) + 2.0); choo(sg(2, 1) + 0.1); stampfx(sg(2, 1) + 0.8)
    for k in range(5): pop(sg(2, 2) + 0.2 + k * 0.15)
    # 03
    pop(C(3) + 0.3); pop(C(3) + 0.7); ding(C(3) + 2.0)
    for k in range(10): blip(sg(3, 1) + 0.2 + k * 0.25, 1800 if k % 2 else 1400)
    pop(sg(3, 1) + 0.6); stampfx(sg(3, 2) + 0.3)
    # 04
    for i in range(4): pop(C(4) + 0.3 + i * 0.25)
    pop(C(4) + 1.8)
    pop(sg(4, 1) + 0.3); fall(sg(4, 1) + 0.4, 0.6); pop(sg(4, 1) + 0.9); rise(sg(4, 1) + 1.0, 0.6)
    fall(sg(4, 2) + 0.1, 0.8); stampfx(sg(4, 2) + 0.8)
    # 05
    for k in range(4): tone(sfx, C(5) + 0.4 + k * 0.3, 0.2, 2200, 0.025, "sq", 0.5, f1=1600, decay=0.15)   # 사인 펜
    rise(C(5) + 1.6, 1.0); ding(C(5) + 2.6)
    for k in range(8): tone(sfx, sg(5, 1) + 0.2 + k * 0.3, 0.08, 0, 0.04, "noise", decay=0.04)          # 공사
    thump(sg(5, 2) + 0.1)
    # risk
    pop(sg(6, 1) + 0.2); fall(sg(6, 1) + 0.4, 0.8)
    # end
    for i in range(5): pop(S[7] + 0.2 + i * 0.22)
    stampfx(S[7] + 1.6); ding(sg(7, 1) + 0.3)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "scan":
        from nike_video import render_low
        for k, s in enumerate(scenes):
            for i in range(int(s["dur"] * FPS) + 1): render_low(s, i / FPS)
        print("scan ok"); sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

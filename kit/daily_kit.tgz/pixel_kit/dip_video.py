"""특별편 · 폭락장, 지금 뭘 주워야 할까? 줍줍 전 체크리스트 (kospi1015_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-15 정오): 센머니 10:31(코스피 -7.84% 5,537.55 · 삼성전자 -8.94% · SK하이닉스 -11.28% · 삼성바이오로직스 +1.86% · KB금융 -1.32% · 외국인 1조8,439억 순매도),
파이낸셜뉴스 11:20(9월 말 6,838.04 → 5,583.17, -18.35%), EBN(삼성증권 10/13 보고서: 이익 훼손보다 수급·심리, 저가매수보다 안정 확인),
파이낸셜뉴스(강관우 대표: 27~28년 이익 전망은 상향, 분할 매수), 한국경제 10/13(목표가 대비 반값 이하 15곳 · 방산·조선·바이오), 서울경제(키움 한지영: 5거래일+ 연속 급락 뒤엔 바닥 다지기),
센머니(대신 이정훈: 연준 비둘기 전환 기대 어려움)
규칙: 급락 알럿은 급락이 그려지기 전에 먼저.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK, bank)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from ackman_video import up_arrow, money_bag
from semicrash_video import alert_card, crash_line, qmark, shield, flask, TEAL

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "dip/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6

# ================================================================ drawings
def claw(d, x, y, t, grab=0.0, col=WHT2):
    """인형뽑기 집게 (줍줍)"""
    d.line([(x, 60), (x, y)], fill=GRAY, width=2)
    d.rectangle([x - 8, y, x + 8, y + 8], fill=col, outline=GRAY)
    o = int(8 * (1 - grab))
    d.line([(x - 6, y + 8), (x - 10 - o, y + 20)], fill=col, width=2); d.line([(x - 10 - o, y + 20), (x - 4, y + 26)], fill=col, width=2)
    d.line([(x + 6, y + 8), (x + 10 + o, y + 20)], fill=col, width=2); d.line([(x + 10 + o, y + 20), (x + 4, y + 26)], fill=col, width=2)

def panic_btn(d, x, y, t, label="전량 매도"):
    on = blink(t, 5)
    d.rectangle([x, y, x + 64, y + 20], fill=SRED if on else dk(SRED, 0.6), outline=WHITE)
    d.text((x + 32, y + 4), label, font=F9, fill=WHITE, anchor="ma")

def mini_chart_up(d, x, y, col=GRN):
    d.rectangle([x, y, x + 26, y + 20], outline=col)
    d.line([(x + 3, y + 16), (x + 10, y + 11), (x + 15, y + 13), (x + 23, y + 4)], fill=col, width=2)

def coin_stacks(d, x, y, t, n=3):
    for s in range(n):
        h = 1 + s
        for k in range(h):
            yy = y + 20 - k * 5
            d.ellipse([x + s * 18, yy, x + s * 18 + 14, yy + 6], fill=GOLD, outline=dk(GOLD, 0.6))

def magnifier(d, x, y, col=YEL):
    d.ellipse([x, y, x + 22, y + 22], outline=col, width=2)
    d.line([(x + 19, y + 19), (x + 30, y + 30)], fill=col, width=3)

def ship(d, x, y, col=CYAN):
    d.polygon([(x, y + 10), (x + 40, y + 10), (x + 34, y + 20), (x + 6, y + 20)], fill=dk(col, 0.6), outline=col)
    d.rectangle([x + 14, y, x + 26, y + 10], fill=WHT2)

def jet(d, x, y, col=WHT2):
    d.polygon([(x, y + 8), (x + 30, y + 6), (x + 38, y + 8), (x + 30, y + 10)], fill=col)
    d.polygon([(x + 12, y + 7), (x + 22, y - 2), (x + 26, y + 7)], fill=col); d.polygon([(x + 12, y + 9), (x + 22, y + 18), (x + 26, y + 9)], fill=col)

def stairs_floor(d, x, y, t, u):
    pts = [(x, y), (x + 20, y), (x + 20, y + 14), (x + 40, y + 14), (x + 40, y + 28), (x + 60, y + 28)]
    n = int(len(pts) * u)
    if n > 1: d.line(pts[:n], fill=SRED, width=2)
    if u >= 1:
        pts2 = [(x + 60 + k * 6, y + 28 + int(3 * math.sin(k * 1.6 + t * 2))) for k in range(16)]
        d.line(pts2, fill=YEL, width=2)

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 10.15 폭락장", "뭘 주워야 하나?", "다들 던질 때 줍줍 체크", SRED)
    s1 = seg[1]
    if t < s1:
        box(d, 34, 122, 216, 234, DIM)
        d.rectangle([40, 127, 44, 131], fill=WHITE); d.text((48, 125), "코스피 · 10월", font=F9, fill=WHITE)
        uf = ease(prog(t, 0.3, 1.2)); ud = prog(t, 2.45, 3.3)
        crash_line(d, 42, 120, 210, 146, 74, uf, ud, WHITE, 5)
        alert_card(img, d, t, 1.25, 2.4, CX, 176, "폭락 경보", "PANIC")       # 경보 먼저
        if t > 3.3:
            u = ease(prog(t, 3.3, 4.2))
            glitch_text(img, 86, 186, f"-{18.35 * u:.1f}%", F24, SRED, t, 5 if t < 4.3 else 1)
            d.text((86, 216), "9월 말 → 오늘 오전", font=F9, fill=GRAY, anchor="ma")
        if t > 3.6:
            vis, o = slam(t, 3.6, 0.2)
            d.rectangle([34, 242 + o, 216, 300 + o], fill=(40, 10, 16), outline=SRED if blink(t, 3) else ORG)
            d.text((42, 248 + o), "코스피 장중", font=F9, fill=GRAY); d.text((210, 246 + o), "-7.84%", font=F12, fill=SRED, anchor="ra")
            d.text((42, 266 + o), "외국인 순매도", font=F9, fill=GRAY); d.text((210, 264 + o), "1조 8,439억", font=F12, fill=WHITE, anchor="ra")
            d.text((42, 284 + o), "연속 하락", font=F9, fill=GRAY); d.text((210, 282 + o), "7거래일째", font=F12, fill=ORG, anchor="ra")
        if t > 4.6:
            for k in range(3): mini_person(d, 50 + k * 14, 214, (CYAN, ORG, WHT2)[k], t * 3, k)
        d.text((CX, 312), "오전 10~11시 기준", font=F9, fill=DIM, anchor="ma")
    else:
        g = ease(prog(t, s1 + 0.2, s1 + 1.0)); y = int(lerp(120, 200, g))
        if t > s1 + 1.3: y = int(lerp(200, 140, ease(prog(t, s1 + 1.3, s1 + 2.0))))
        for k in range(4):
            if not (t > s1 + 1.3 and k == 1):
                coin(d, 70 + k * 30, 238, 9, "?")
        claw(d, 100, y, t, prog(t, s1 + 1.0, s1 + 1.3))
        if t > s1 + 1.3: coin(d, 100, y + 32, 9, "?")
        panic_btn(d, 140, 140, t); panic_btn(d, 140, 166, t + 0.3, "손절!!")
        if t > s1 + 0.6:
            vis, o = slam(t, s1 + 0.6, 0.2)
            d.rectangle([34, 262 + o, 216, 300 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((CX, 268 + o), "줍기 전에 3가지만 체크!", font=F12, fill=GOLD, anchor="ma")
            d.text((CX, 284 + o), "※ 특정 종목 매수 권유 아님", font=F9, fill=GRAY, anchor="ma")
    fx = {}
    if 2.45 < t < 3.0: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
    if 1.25 < t < 1.35: fx["flash"] = 0.3
    return fx

def s_check(img, d, t, seg, dur):
    header(d, t, "01 · 줍기 전 체크리스트", "3가지 기준", "실적 · 체력 · 분할", GOLD)
    items = [(seg[0] + 0.1, "① 실적은 멀쩡한가", "수급 때문에 빠진 건지", GRN, "chart"),
             (seg[1] + 0.1, "② 덜 빠지는 체력", "이런 날에도 버티는지", CYAN, "shield"),
             (seg[2] + 0.1, "③ 나눠서 담기", "한 번에 다 사지 않기", GOLD, "coins")]
    for i, (ts, a, b, col, ic) in enumerate(items):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 126 + i * 58 + o
        d.rectangle([34, y, 216, y + 50], fill=(10, 14, 30), outline=col)
        if ic == "chart": mini_chart_up(d, 42, y + 14, col)
        elif ic == "shield": shield(d, 46, y + 14, col)
        else: coin_stacks(d, 38, y + 14, t)
        d.text((96, y + 9), a, font=F12, fill=WHITE); d.text((96, y + 29), b, font=F9, fill=col)
        if t > ts + 0.6:
            d.rectangle([200, y + 18, 210, y + 28], outline=col); d.line([(201, y + 23), (204, y + 27), (209, y + 19)], fill=col, width=2)
    chapter_flash(img, d, t, "01", "체크리스트", GOLD)
    return {}

def s_big(img, d, t, seg, dur):
    header(d, t, "02 · 후보 유형 ①", "낙폭과대 대장주", "실적보다 수급에 맞은 종목", SRED)
    s1 = seg[1]
    if t < s1:
        base = 140
        alert_card(img, d, t, 0.75, 1.5, CX, 186, "급락 경보", "ALERT")
        rows = [("삼성전자", 8.94, BLUE), ("SK하이닉스", 11.28, SRED), ("코스피", 7.84, WHT2)]
        if t >= 1.55:
            for i, (nm, v, col) in enumerate(rows):
                ts = 1.55 + i * 0.3
                if t < ts: continue
                q = ease(prog(t, ts, ts + 0.5)); y = base + i * 34
                d.text((40, y), nm, font=F12, fill=col)
                d.rectangle([40, y + 16, 40 + int(14 * v * q), y + 26], fill=col)
                d.text((212, y), f"-{v:.2f}%", font=F12, fill=SRED, anchor="ra")
        if t > 3.0:
            vis, o = slam(t, 3.0, 0.2); stamp_slam(img, 168, 268, "대장주 급락", SRED, t, 3.0, "12", -8)
        d.text((CX, 306), "오전 10시 31분 기준", font=F9, fill=DIM, anchor="ma")
    else:
        box(d, 34, 124, 122, 220, GRN); box(d, 128, 124, 216, 220, SRED)
        d.text((78, 130), "이익 전망", font=F12, fill=GRN, anchor="ma"); d.text((172, 130), "수급·심리", font=F12, fill=SRED, anchor="ma")
        u = ease(prog(t, s1 + 0.2, s1 + 1.2))
        pts = [(44 + j * 7, int(204 - 40 * (j / 10) * u)) for j in range(11)]
        d.line(pts, fill=GRN, width=2); up_arrow(d, 104, 150, GRN, 16)
        d.text((78, 206), "'27~'28 상향", font=F9, fill=WHITE, anchor="ma")
        pts2 = [(138 + j * 7, int(164 + 36 * (j / 10) * u)) for j in range(11)]
        d.line(pts2, fill=SRED, width=2)
        d.text((172, 206), "외국인 매도", font=F9, fill=WHITE, anchor="ma")
        if t > s1 + 1.3:
            vis, o = slam(t, s1 + 1.3, 0.2)
            d.rectangle([34, 230 + o, 216, 290 + o], fill=(10, 14, 30), outline=GOLD)
            d.text((CX, 236 + o), "삼성증권: 이익 훼손보다", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 250 + o), "수급·심리가 조정 주도", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 270 + o), "강관우 대표: 내후년 이익 전망은 상향", font=F9, fill=GOLD, anchor="ma")
        magnifier(d, 184, 150 + int(4 * math.sin(t * 3)))
    chapter_flash(img, d, t, "02", "대장주", SRED)
    return {"shake": (int(math.sin(t * 80) * 2), 0)} if 1.55 < t < 1.85 else {}

def s_strong(img, d, t, seg, dur):
    header(d, t, "03 · 후보 유형 ②", "버틴 종목", "-7.8% 속 방어 체력", CYAN)
    zero = 210
    d.line([(40, zero), (212, zero)], fill=GRAY)
    rows = [("코스피", -7.84, WHT2, 0.75), ("KB금융", -1.32, CYAN, 1.2), ("삼성바이오", 1.86, GRN, 1.65)]
    for i, (nm, v, col, ts) in enumerate(rows):
        if t < ts: continue
        u = ease(prog(t, ts, ts + 0.45)); h = int(abs(v) * 10 * u); x = 52 + i * 56
        if v < 0: d.rectangle([x, zero, x + 34, zero + h], fill=col)
        else: d.rectangle([x, zero - h, x + 34, zero], fill=col)
        d.text((x + 17, 126 if False else zero - 34 if v < 0 else zero - h - 14), f"{v:+.2f}%", font=F12 if v > 0 else F9, fill=SRED if v < 0 else GRN, anchor="ma")
        d.text((x + 17, zero + h + 4 if v < 0 else zero + 4), nm, font=F9, fill=col, anchor="ma")
    if t > 2.3:
        vis, o = slam(t, 2.3, 0.2); shield(d, 160, 140 + o, GRN)
        d.text((168, 164 + o), "체력", font=F9, fill=GRN, anchor="ma")
    if t > seg[-1] + 0.2 if len(seg) > 1 else t > 3.2:
        vis, o = slam(t, (seg[-1] if len(seg) > 1 else 3.0) + 0.2, 0.2)
        d.rectangle([34, 292 + o, 216, 312 + o], fill=(10, 20, 24), outline=CYAN)
        d.text((CX, 297 + o), "오늘 버틴 이유가 계속될지는 따로 확인!", font=F9, fill=CYAN, anchor="ma")
    chapter_flash(img, d, t, "03", "버틴 종목", CYAN)
    return {}

def s_half(img, d, t, seg, dur):
    header(d, t, "04 · 후보 유형 ③", "목표가 반값", "증권사 목표주가의 절반 이하", PURP)
    s1 = seg[1]
    if t < s1:
        d.text((CX, 124), "목표주가 vs 지금 주가", font=F9, fill=GRAY, anchor="ma")
        u = ease(prog(t, 0.8, 1.6)); v = ease(prog(t, 1.4, 2.4))
        d.rectangle([44, 140, 44 + int(160 * u), 158], fill=WHT2); d.text((48, 143), "목표가", font=F9, fill=DARK)
        d.rectangle([44, 166, 44 + int(76 * v), 184], fill=PURP); d.text((48, 169), "현재가", font=F9, fill=WHITE)
        if v >= 1:
            d.line([(124, 162), (124, 190)], fill=YEL); d.text((128, 170), "반값 이하", font=F9, fill=YEL)
        if t > 2.4:
            vis, o = slam(t, 2.4, 0.2)
            ctext(d, 200 + o, "15곳", F36, GOLD)
            d.text((CX, 246 + o), "한국경제 집계 · 10월 13일", font=F9, fill=GRAY, anchor="ma")
    else:
        icons = [(s1 + 0.1, "방산", 0), (s1 + 0.4, "조선", 1), (s1 + 0.7, "바이오", 2)]
        for ts, nm, k in icons:
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); x = 38 + k * 62
            d.rectangle([x, 128 + o, x + 54, 182 + o], fill=(10, 14, 30), outline=PURP)
            if k == 0: jet(d, x + 8, 144 + o)
            elif k == 1: ship(d, x + 7, 142 + o)
            else: flask(d, x + 15, 134 + o, t)
            d.text((x + 27, 168 + o), nm, font=F9, fill=WHITE, anchor="ma")
        if t > s1 + 1.2:
            magnifier(d, 92 + int(40 * math.sin(t * 1.5)), 196)
            vis, o = slam(t, s1 + 1.4, 0.2)
            d.rectangle([34, 236 + o, 216, 280 + o], fill=(24, 12, 34), outline=YEL)
            d.text((CX, 242 + o), "싼 데는 이유가 있을 수도", font=F12, fill=YEL, anchor="ma")
            d.text((CX, 262 + o), "목표가 하향 · 실적 변화부터 확인", font=F9, fill=WHITE, anchor="ma")
    chapter_flash(img, d, t, "04", "목표가 반값", PURP)
    return {}

def s_warn(img, d, t, seg, dur):
    header(d, t, "05 · 꼭 기억", "하락은 더 갈 수 있다", "줍줍은 천천히", ORG)
    s1, s2 = seg[1], seg[2]
    warn_icon(d, 117, 120, YEL if blink(t, 3) else ORG)
    if t < s1:
        if t > 0.75:
            vis, o = slam(t, 0.75, 0.2)
            d.rectangle([34, 146 + o, 216, 200 + o], fill=(40, 10, 16), outline=SRED if blink(t, 3) else ORG)
            d.text((CX, 154 + o), "바닥 확인 전엔", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 174 + o), "더 빠질 수 있어요", font=F12, fill=SRED, anchor="ma")
        if t > 1.6:
            vis, o = slam(t, 1.6, 0.2)
            d.text((CX, 214 + o), "삼성증권: 저가매수보다", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 228 + o), "시장 안정 확인이 먼저", font=F12, fill=WHITE, anchor="ma")
    elif t < s2:
        stairs_floor(d, 40, 150, t, ease(prog(t, s1 + 0.1, s1 + 1.0)))
        d.text((70, 200), "연속 급락", font=F9, fill=SRED, anchor="ma"); d.text((160, 200), "바닥 다지기", font=F9, fill=YEL, anchor="ma") if t > s1 + 1.0 else None
        if t > s1 + 1.2:
            vis, o = slam(t, s1 + 1.2, 0.2)
            d.rectangle([34, 222 + o, 216, 262 + o], fill=(10, 14, 30), outline=YEL)
            d.text((CX, 228 + o), "키움증권: 5거래일+ 연속 급락 뒤엔", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 244 + o), "급반등보다 바닥 다지기", font=F12, fill=YEL, anchor="ma")
    else:
        if t > s2 + 0.1:
            vis, o = slam(t, s2 + 0.1, 0.2)
            bank(d, 44, 150 + o, 60, WHT2)
            d.rectangle([118, 152 + o, 216, 184 + o], fill=WHITE); d.polygon([(118, 170 + o), (110, 174 + o), (118, 178 + o)], fill=WHITE)
            d.text((167, 156 + o), "금리 인하?", font=F12, fill=DARK, anchor="ma"); d.text((167, 170 + o), "기대 약해짐", font=F9, fill=SRED, anchor="ma")
        if t > s2 + 1.0:
            vis, o = slam(t, s2 + 1.0, 0.2)
            coin_stacks(d, 46, 230 + o, t); money_bag(d, 110, 226 + o, "₩" if False else "$")
            d.text((180, 232 + o), "현금 남기기", font=F9, fill=GOLD, anchor="ma"); d.text((180, 246 + o), "나눠서 천천히", font=F9, fill=GOLD, anchor="ma")
    d.text((CX, 300), "대신증권: 연준 비둘기 전환 기대 어려워", font=F9, fill=DIM, anchor="ma") if t > s2 else None
    chapter_flash(img, d, t, "05", "조심", ORG)
    return {}

def s_outro(img, d, t, seg, dur):
    marquee(d, 246, 2, 26, t, "실적 · 체력 · 분할 · 그리고 현금", (dk(GOLD, 0.5), dk(CYAN, 0.5)))
    header(d, t, "SUMMARY", "폭락장 줍줍", "체크 3 · 후보 3 · 경고 1", GOLD)
    rows = [("CHECK", "실적·체력·분할", "3가지 기준", GOLD), ("TYPE", "대장주·버틴 종목", "목표가 반값", CYAN), ("WARN", "하락 지속 가능", "천천히·현금", SRED)]
    for i, (a, b, c, col) in enumerate(rows):
        ts = 0.3 + i * 0.4
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 126 + i * 32
        d.rectangle([34, y + o, 216, y + 24 + o], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y + o, 78, y + 24 + o], fill=col)
        d.text((56, y + 7 + o), a, font=F9, fill=WHITE if col != GOLD else DARK, anchor="ma")
        d.text((84, y + 5 + o), b, font=F12, fill=WHITE); d.text((212, y + 8 + o), c, font=F9, fill=col, anchor="ra")
    d.text((32, 306), "※ 특정 종목 매수 권유가 아닌 정보 제공용", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("코스피 장중 -7%대, 10월에만 18% 증발\n계좌 다 파랗죠?", "코스피 장중 칠 퍼센트대 폭락, 시월에만 십팔 퍼센트가 증발했어요. 계좌 다 파랗죠?"),
              ("다들 던질 때\n도대체 뭘 주워야 할까요?", "다들 던질 때, 도대체 뭘 주워야 할까요?")]),
    (s_check, [("첫째, 실적은 멀쩡한데\n수급 때문에 빠진 종목인지", "첫째, 실적은 멀쩡한데 수급 때문에 빠진 종목인지."),
               ("둘째, 이런 날에도\n덜 빠지는 체력이 있는지", "둘째, 이런 날에도 덜 빠지는 체력이 있는지."),
               ("셋째, 한 번에 다 사지 말고\n나눠서 담기", "셋째, 한 번에 다 사지 말고 나눠서 담기.")]),
    (s_big, [("삼성전자 -9%, SK하이닉스 -11%\n대장주가 제일 크게 빠졌어요", "삼성전자 구, 에스케이하이닉스 십일 퍼센트. 대장주가 제일 크게 빠졌어요."),
             ("증권가는 이익보다 수급·심리 탓,\n내후년 이익 전망은 올랐다는 분석도", "증권가는 이익보다 수급과 심리 탓이라고 봤고, 내후년 이익 전망은 오히려 올랐다는 분석도 있어요.")]),
    (s_strong, [("코스피 -7.8% 속 삼성바이오로직스 +1.9%\nKB금융은 -1.3%로 버텼어요", "코스피가 칠 점 팔 퍼센트 빠질 때, 삼성바이오로직스는 오히려 올랐고, 케이비금융은 일 퍼센트대 하락에 그쳤어요.")]),
    (s_half, [("증권사 목표주가의 반값 이하로\n떨어진 종목도 15곳", "증권사 목표주가의 반값 이하로 떨어진 종목도 열다섯 곳이나 돼요."),
              ("방산·조선·바이오에 많다는데\n싼 데는 이유가 있는지 확인!", "방산, 조선, 바이오에 많다는데, 싼 데는 이유가 있는지 꼭 확인해야 해요.")]),
    (s_warn, [("하지만 하락은\n더 이어질 수 있어요", "하지만, 하락은 더 이어질 수 있어요."),
              ("연속 급락 뒤엔 급반등보다\n바닥을 다지는 경우가 많았고", "연속 급락 뒤엔, 급반등보다 바닥을 다지는 경우가 많았고,"),
              ("금리 인하 기대도 약해졌어요\n현금을 남기고 천천히!", "금리 인하 기대도 약해졌어요. 현금을 남겨 두고 천천히 담으세요.")]),
    (s_outro, [("줍기 전 체크는 실적·체력·분할\n그리고 조심 또 조심!", "줍기 전 체크는 실적, 체력, 분할. 그리고 조심 또 조심!")]),
]
TITLES = ["", "체크리스트", "대장주", "버틴 종목", "목표가 반값", "조심", "정리"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + (0.8 if fn is s_strong else 0), subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # A minor panic (122 bpm) → C major 'treasure hunt' for the checklist/candidates → back to minor for the warning
    bpm = 122; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([69, 72, 76], 45), ([65, 69, 72], 41), ([67, 71, 74], 43), ([64, 68, 71], 40)]
    prog_major = [([72, 76, 79], 48), ([67, 71, 74], 43), ([69, 72, 76], 45), ([65, 69, 72], 41)]
    mel_m = [[76, None, 74, 72, 71, None, 72, None], [72, 74, 76, None, 77, None, 76, 74], [74, None, 71, None, 79, None, 77, 76], [76, 74, 72, None, 71, None, None, None]]
    mel_M = [[79, None, 76, 79, 84, None, 83, 81], [79, None, 74, None, 79, 81, 83, None], [84, None, 81, 79, 76, None, 79, None], [77, 79, 81, None, 79, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = S[1] <= t0 < S[5]
        tense = t0 < S[1]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and not tense: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
            if m and tense and st % 4 == 0 and T > 3.3: tone(bgm, T, e * 1.6, mtof(m - 12), 0.03, "sq", 0.5, decay=0.4)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if 1.25 <= T < 2.45: continue                                        # 경보 동안 드럼 멈춤 → 급락 때 다시
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def claw_fx(T, d=0.8): tone(sfx, T, d, 400, 0.035, "sq", 0.5, f1=200, decay=d)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    typing(S[0] + 0.1, "특별편뭘주워야하나"); alarm(S[0] + 1.25, 6); fall(S[0] + 2.45, 0.9); thump(S[0] + 2.5); glitch(S[0] + 3.3, 8)
    thump(S[0] + 3.6)
    for j in range(6): tone(sfx, S[0] + 4.6 + j * 0.12, 0.08, 1200, 0.03, "sq", 0.5, decay=0.06)
    claw_fx(sg(0, 1) + 0.2); stampfx(sg(0, 1) + 1.0); coin_s(sg(0, 1) + 1.3); ding(sg(0, 1) + 0.6)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    for i in range(3): pop(sg(1, i) + 0.1); ding(sg(1, i) + 0.7)
    alarm(S[2] + 0.75, 4)
    for i in range(3): thump(S[2] + 1.55 + i * 0.3); fall(S[2] + 1.6 + i * 0.3, 0.4)
    stampfx(S[2] + 3.0); rise(sg(2, 1) + 0.2, 1.0); pop(sg(2, 1) + 1.3)
    fall(S[3] + 0.75, 0.6); pop(S[3] + 1.2); rise(S[3] + 1.65, 0.5); coin_s(S[3] + 2.1); ding(S[3] + 2.3)
    rise(S[4] + 0.8, 0.8); fall(S[4] + 1.4, 1.0); stampfx(S[4] + 2.4); coin_s(S[4] + 2.5)
    for j in range(3): pop(sg(4, 1) + 0.1 + j * 0.3)
    pop(sg(4, 1) + 1.4)
    alarm(S[5] + 0.75, 3); thump(S[5] + 0.8); pop(S[5] + 1.6)
    fall(sg(5, 1) + 0.1, 0.9); pop(sg(5, 1) + 1.2); pop(sg(5, 2) + 0.1); coin_s(sg(5, 2) + 1.0)
    for i in range(3): thump(S[6] + 0.3 + i * 0.4)
    ding(S[6] + 1.6)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

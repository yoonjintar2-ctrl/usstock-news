"""개념편 · 반도체 중에서도 왜 메모리? 그리고 왜 낸드? (상시용 개념 설명 · 60초 이내 · 하단에 진행자 캐릭터)
- 시의성 이슈 없이 개념만: 계산 칩 vs 기억 칩 → D램(작업 책상·HBM) → 낸드(서랍장·SSD) → AI가 낸드도 찾는 이유 → 정리
- 2026-10-30 사용자 지시: 화면 아래쪽에 진행자 캐릭터(이름 소개·호칭 없음), 목소리는 sandy_voice(후보 6번)
- 레이아웃: 픽셀 그림은 저해상도 y 60~230(풀 240~920), 자막은 풀 y 940, 그 아래는 캐릭터 자리
"""
import os, sys, math, subprocess, wave, hashlib
import numpy as np
from PIL import Image

import sandisk_video as sv
from sandisk_video import header, box, slam, CX, PURP, WHT2, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, lerp, prog, ease, tone, mtof, SR)
import mid_video as mv
from nike_video import stamp_slam, render_frame, dk, DARK
from option_video import big_text, GOLD
from survive_video import ant, speech
from squeeze_video import CH, with_card
from semicrash_video import hbm_stack
from semireb_video import dram_stick
from aibubble_video import datacenter

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "memnand/out"); os.makedirs(OUT, exist_ok=True)
NDIR = os.path.join(BASE, "narr_v6"); os.makedirs(NDIR, exist_ok=True)
mv.clip_path = lambda n: os.path.join(NDIR, hashlib.md5(f"v6|{n}".encode()).hexdigest() + ".npy")
sv.SUB_Y = 936; sv.SUB_CX = 540; sv.SUB_MAXW = 900          # 자막은 그림과 캐릭터 사이
GAP, TAIL = 0.24, 0.35
CARD = YEL
WOOD = (150, 98, 60); WOODD = (100, 62, 36); PAPER = (236, 232, 214)

# ================================================================ drawings
def desk(d, x, y, t, papers=1.0, lit=True):
    """작업 책상(D램): 위에 서류가 빠르게 쌓였다 사라짐"""
    d.rectangle([x, y, x + 76, y + 7], fill=WOOD, outline=WOODD)
    d.rectangle([x + 4, y + 7, x + 9, y + 34], fill=WOODD); d.rectangle([x + 67, y + 7, x + 72, y + 34], fill=WOODD)
    n = int(6 * papers)
    for k in range(n):
        px = x + 8 + (k % 3) * 21; py = y - 7 - (k // 3) * 6 + (int(t * 12 + k) % 2 if lit else 0)
        d.rectangle([px, py, px + 16, py + 5], fill=PAPER, outline=GRAY)

def cabinet(d, x, y, t, open_k=-1, glow=True):
    """서랍장(낸드): 서랍 4칸, 꺼져도 불빛 유지"""
    d.rectangle([x, y, x + 46, y + 64], fill=(70, 74, 92), outline=WHT2)
    for k in range(4):
        dy = y + 4 + k * 15; ox = 8 if k == open_k else 0
        d.rectangle([x + 4 + ox, dy, x + 42 + ox, dy + 12], fill=(96, 102, 124), outline=GRAY)
        d.rectangle([x + 20 + ox, dy + 5, x + 26 + ox, dy + 7], fill=YEL if glow else DIM)
        if k == open_k:
            for j in range(3): d.rectangle([x + 10 + ox + j * 9, dy - 4, x + 16 + ox + j * 9, dy + 2], fill=PAPER)

def plug(d, x, y, on=True):
    d.rectangle([x, y, x + 14, y + 10], fill=(200, 200, 210) if on else (110, 110, 120), outline=GRAY)
    d.line([(x + 3, y - 4), (x + 3, y)], fill=GRAY, width=2); d.line([(x + 10, y - 4), (x + 10, y)], fill=GRAY, width=2)
    d.line([(x + 7, y + 10), (x + 7, y + 20)], fill=DIM, width=2)
    if not on: d.line([(x - 4, y - 6), (x + 18, y + 14)], fill=RED, width=2); d.line([(x + 18, y - 6), (x - 4, y + 14)], fill=RED, width=2)

def ssd(d, x, y, col=ORG, lbl="SSD"):
    d.rectangle([x, y, x + 40, y + 16], fill=(28, 32, 50), outline=col)
    for k in range(3): d.rectangle([x + 4 + k * 11, y + 4, x + 12 + k * 11, y + 11], fill=dk(col, 0.6))
    d.text((x + 20, y + 19), lbl, font=F9, fill=col, anchor="ma")

def photo_phone(d, x, y, t):
    d.rounded_rectangle([x, y, x + 22, y + 38], radius=3, fill=DARK, outline=WHT2)
    for k in range(6):
        cx_, cy_ = x + 3 + (k % 2) * 9, y + 4 + (k // 2) * 10
        d.rectangle([cx_, cy_, cx_ + 7, cy_ + 8], fill=[(80, 150, 220), (240, 180, 90), (110, 200, 140)][k % 3])

def packet(d, x, y, col=CYAN): d.rectangle([x, y, x + 5, y + 5], fill=col, outline=dk(col, 0.6))

def arrow_r(d, x0, x1, y, col=WHT2):
    d.line([(x0, y), (x1, y)], fill=col, width=2); d.polygon([(x1, y - 4), (x1 + 6, y), (x1, y + 4)], fill=col)

def tag(d, t, t0, x, y, s, col):
    vis, o = slam(t, t0, 0.18)
    if not vis: return
    w = int(d.textlength(s, font=F9)) + 8
    d.rectangle([x, y + o, x + w, y + 13 + o], fill=dk(col, 0.35), outline=col); d.text((x + 4, y + 2 + o), s, font=F9, fill=WHITE)

# ================================================================ scenes  (그림은 y 118~230 안에)
def s_hook(img, d, t, seg, dur):
    d.text((CX, 62), "반도체 개념 1분", font=F9, fill=GRAY, anchor="ma")          # 첫 프레임부터 완성(타자 효과 없음)
    d.text((CX, 76), "AI 시대, 반도체 중에서도", font=F12, fill=WHITE, anchor="ma")
    big_text(img, CX, 92, "왜 메모리?", YEL, 3, F12)
    chip(d, 34, 168, 44, CYAN, t); d.text((56, 216), "계산", font=F12, fill=CYAN, anchor="ma")
    dram_stick(d, 150, 172, GRN); d.text((182, 216), "기억", font=F12, fill=GRN, anchor="ma")
    for k in range(4):
        x = 86 + int(((t * 40) + k * 14) % 56); packet(d, x, 186)
    if int(t * 2) % 2: d.text((CX - 4, 150), "?", font=F24, fill=YEL, anchor="ma")
    return {}

def s_two(img, d, t, seg, dur):
    header(d, t, "반도체 두 종류", "계산 칩 · 기억 칩", "", CYAN)
    s1 = seg[1]
    chip(d, 34, 130, 44, CYAN, t); d.text((56, 178), "계산 (CPU·GPU)", font=F9, fill=CYAN, anchor="ma")
    for k in range(4): d.rectangle([150 + (k % 2) * 26, 128 + (k // 2) * 22, 172 + (k % 2) * 26, 146 + (k // 2) * 22], fill=dk(GRN, 0.5), outline=GRN)
    d.text((176, 178), "기억 (메모리)", font=F9, fill=GRN, anchor="ma")
    if t < s1:
        for k in range(5):
            x = 146 - int(((t * 46) + k * 13) % 62); packet(d, x, 150, GRN)
    else:
        u = t - s1
        d.rectangle([84, 146, 144, 160], fill=(30, 34, 52), outline=DIM)
        for k in range(7): packet(d, 138 - k * 7, 150, GRN)            # 길이 막힘
        ant(d, 44, 196, t, "sweat"); speech(d, 74, 196, "데이터 언제 와...", tail_left=True)
        if u > 0.6 and int(u * 3) % 2: d.text((56, 112), "멈춤!", font=F12, fill=RED, anchor="ma")
    return {}

def s_dram(img, d, t, seg, dur):
    header(d, t, "D램", "빠른 작업 책상", "", GRN)
    s1 = seg[1]
    if t < s1:
        on = not (2.2 < t % 4.0 < 3.3)
        desk(d, 40, 160, t, papers=(1.0 if on else 0.0)); plug(d, 160, 160, on)
        d.text((78, 202), "빠르다!", font=F12, fill=GRN, anchor="ma")
        d.text((167, 190), "전원 OFF" if not on else "전원 ON", font=F9, fill=RED if not on else GRAY, anchor="ma")
        if not on: d.text((78, 138), "싹 잊음", font=F12, fill=RED, anchor="ma")
    else:
        u = t - s1
        chip(d, 40, 140, 48, CYAN, t); d.text((64, 194), "AI 칩", font=F9, fill=CYAN, anchor="ma")
        n = min(5, 1 + int(u * 3)); hbm_stack(d, 140, 136, GOLD, n)
        d.text((160, 190), "D램을 층층이", font=F9, fill=GOLD, anchor="ma")
        if u > 1.4: stamp_slam(img, CX + 24, 212, "HBM", GOLD, t, s1 + 1.4, "24", -8)
    return {}

def s_nand(img, d, t, seg, dur):
    header(d, t, "낸드", "꺼져도 기억하는 서랍장", "", ORG)
    s1 = seg[1]
    if t < s1:
        on = not (2.0 < t % 4.0 < 3.4)
        cabinet(d, 50, 130, t, open_k=int(t * 1.5) % 4, glow=True); plug(d, 160, 160, on)
        d.text((73, 200), "그대로 남음", font=F12, fill=ORG, anchor="ma")
        d.text((167, 190), "전원 OFF" if not on else "전원 ON", font=F9, fill=RED if not on else GRAY, anchor="ma")
    else:
        u = t - s1
        photo_phone(d, 44, 136, t); d.text((55, 180), "폰 사진", font=F9, fill=WHITE, anchor="ma")
        ssd(d, 100, 146, ORG, "SSD")
        cabinet(d, 168, 130, t, open_k=1)
        if u > 0.8: tag(d, t, s1 + 0.8, 70, 204, "전부 낸드!", ORG)
    return {}

def s_ai(img, d, t, seg, dur):
    header(d, t, "AI는 낸드도", "저장할 게 폭발", "", YEL)
    s1 = seg[1]
    if t < s1:
        items = [("학습 데이터", CYAN, 0.2), ("AI 모델", GRN, 0.9), ("대화 기록", ORG, 1.6)]
        for k, (s, col, t0) in enumerate(items): tag(d, t, t0, 36 + k * 4, 128 + k * 22, s, col)
        cabinet(d, 160, 130, t, open_k=int(t * 2) % 4)
        if t > 2.2:
            for k in range(3): arrow_r(d, 120, 148, 136 + k * 22, DIM)
    else:
        u = t - s1
        datacenter(d, 30, 140, t, CYAN)
        n = min(8, int(u * 4) + 1)
        for k in range(n): ssd(d, 120 + (k % 2) * 46, 128 + (k // 2) * 24, ORG, "")
        if u > 1.8: stamp_slam(img, CX, 222, "낸드 ↑" if False else "낸드 더 많이", ORG, t, s1 + 1.8, "12", -6)
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "정리", "계산은 두뇌, 기억은 메모리", "", YEL)
    s1 = seg[1]
    chip(d, 30, 136, 40, CYAN, t); desk(d, 92, 160, t, 1.0); cabinet(d, 182, 130, t, open_k=int(t) % 4)
    d.text((50, 180), "계산", font=F9, fill=CYAN, anchor="ma"); d.text((130, 200), "D램", font=F9, fill=GRN, anchor="ma"); d.text((205, 200), "낸드", font=F9, fill=ORG, anchor="ma")
    if t > s1 + 0.2: speech(d, 52, 212, "여러분은 D램파? 낸드파?", tail_left=True)
    return {}

SCRIPT = [
    (s_hook, [("AI 시대, 반도체 중에서도\n왜 하필 메모리일까?", "에이아이 시대, 반도체 중에서도 왜 하필 메모리가 이렇게 중요해졌을까요?")]),
    (with_card(s_two, "01", "계산 vs 기억", CARD), [
        ("반도체는 크게 둘\n계산하는 칩 · 기억하는 칩", "반도체는 크게 두 가지예요. 계산하는 칩, 그리고 기억하는 칩."),
        ("두뇌가 빨라도\n데이터가 늦으면 멈춰요", "두뇌가 아무리 빨라도, 데이터가 늦게 오면 계산이 멈춰요.")]),
    (with_card(s_dram, "02", "D램", CARD), [
        ("D램 = 빠른 작업 책상\n전원이 꺼지면 다 잊어요", "디램은 작업 책상이에요. 아주 빠르지만, 전원이 꺼지면 다 잊어버려요."),
        ("AI 칩 옆에 D램을 층층이 쌓은 게\nHBM", "에이아이 칩 바로 옆에 디램을 층층이 쌓아 붙인 게, 에이치비엠이에요.")]),
    (with_card(s_nand, "03", "낸드", CARD), [
        ("낸드 = 서랍장\n전원이 꺼져도 기억해요", "낸드는 서랍장이에요. 조금 느리지만, 전원이 꺼져도 기억해요."),
        ("폰 사진, 컴퓨터 SSD\n전부 낸드예요", "스마트폰 사진, 컴퓨터의 에스에스디가 다 낸드예요.")]),
    (with_card(s_ai, "04", "AI는 낸드도", CARD), [
        ("학습 데이터 · AI 모델 · 대화 기록\n저장할 게 계속 늘어요", "에이아이는 학습 데이터, 모델, 대화하며 쌓이는 기록까지, 저장할 게 계속 늘어요."),
        ("그래서 데이터센터는\n대용량 SSD(낸드)를 더 많이", "그래서 데이터센터는 대용량 에스에스디, 즉 낸드를 점점 더 많이 써요.")]),
    (s_end, [
        ("계산은 두뇌, 기억은 메모리\nAI가 클수록 둘 다 커져요", "계산은 두뇌, 기억은 메모리. 에이아이가 클수록 책상도 서랍장도 커져야 해요."),
        ("여러분은 D램파? 낸드파?\n댓글로 알려주세요", "여러분은 디램파예요, 낸드파예요? 댓글로 알려주세요!")]),
]
NCH0, NCH = 1, 4

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts
    from sandy_voice import voice_line
    tts = make_tts()
    for n in todo:
        x, sr = voice_line(tts, n); assert sr == SR
        np.save(mv.clip_path(n), x); print(f"{len(x)/sr:.2f}s", n, flush=True)

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.05 if k == 0 else (CH + 0.25 if NCH0 <= k <= NCH else 0.2)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.15, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts); sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    bpm = 96; beat = 60 / bpm; e = beat / 2; bar = beat * 4                  # 밝고 잔잔한 장조 하나 (C-G-Am-F)
    prog_ = [([60, 64, 67], 48), ([67, 71, 74], 55), ([69, 72, 76], 57), ([65, 69, 72], 53)]
    mel = [[76, None, 79, None, 77, None, 76, None], [74, None, 71, None, 74, None, 79, None], [76, None, 72, None, 74, None, 76, None], [77, None, 76, None, 72, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            if mm[st]: tone(bgm, T, e * 1.6, mtof(mm[st]), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(1.5 * SR); fi = int(0.3 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    thump(S[0] + 0.02)
    for k in range(NCH0, NCH + 1): bell3(S[k]); thump(S[k] + 0.12); swoosh(S[k] + CH - 0.25)
    stampfx(sg(2, 1) + 1.4); stampfx(sg(4, 1) + 1.8)
    pop(sg(3, 1) + 0.8)
    for dt in (0.2, 0.9, 1.6): pop(S[4] + CH + dt)
    pop(sg(5, 1) + 0.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    g = 0.89 / max(1e-6, np.abs(mix).max()); mix = mix * g
    for p, a in ((path, mix), (path.replace(".wav", "_narr.wav"), nv * g)):
        pcm = (np.clip(a, -1, 1) * 32767).astype(np.int16)
        with wave.open(p, "wb") as w:
            w.setnchannels(1 if a is not mix else 2); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes() if a is not mix else np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    if mode == "audio": sys.exit()
    n = int(total * FPS); os.makedirs(f"{OUT}/px", exist_ok=True)
    for i in range(n):                                                      # 픽셀 프레임만 저장 → 캐릭터 합성은 vtuber/talk/sandy_overlay.py
        render_frame(i / FPS, scenes, starts, total).save(f"{OUT}/px/{i:05d}.png", compress_level=1)
        if i % 300 == 0: print(i, "/", n, flush=True)
    open(f"{OUT}/total.txt", "w").write(f"{total:.3f}")
    print("done", total)

"""특별편 · 하락장 생활백서 (살아남는 법 6가지, 유머) — aibubble_video.py 복사 → 대본·장면·효과음 교체
사실 확인(보너스 장면, S&P500 지수 종가 · 배당 제외):
 · 2000/3/24 1,527.46 → 2002/10/9 776.76 (-49.1%) → 2007/5/30 전고점 회복(약 7년 2개월)
 · 2007/10/9 1,565.15 → 2009/3/9 676.53 (-56.8%) → 2013/3/28 전고점 회복(약 5년 5개월)
 · 2020/2/19 3,386.15 → 2020/3/23 2,237.40 (-33.9%) → 2020/8/18 전고점 회복(약 6개월)
나머지는 생활 수칙(유머). 종목명은 가상(주식 A·B·C), 실존 인물·로고 없음. 주인공은 직접 그린 개미 캐릭터.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person, moon, stars, sun, bungeo, BROWN, SKY
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from kospi1015_video import price_tag, cart
from semicrash_video import qmark

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "survive/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
ANT = (210, 110, 60); PINK = (255, 130, 170); MINT = (110, 230, 190)

# ================================================================ drawings
def ant(d, x, y, t, mood="ok", col=ANT, bob=True):
    """주인공 개미(직접 그린 캐릭터). (x,y)=머리 왼쪽 위, 약 26x34"""
    b = int(abs(math.sin(t * 5)) * 2) if bob and mood != "sleep" else 0
    y -= b
    d.line([(x + 8, y + 2), (x + 4, y - 7)], fill=col); d.line([(x + 18, y + 2), (x + 22, y - 7)], fill=col)
    d.rectangle([x + 3, y - 9, x + 5, y - 7], fill=col); d.rectangle([x + 21, y - 9, x + 23, y - 7], fill=col)
    d.ellipse([x + 3, y, x + 23, y + 16], fill=col, outline=dk(col, 0.55))                 # 머리
    d.ellipse([x + 7, y + 16, x + 19, y + 24], fill=dk(col, 0.85), outline=dk(col, 0.55))  # 가슴
    d.ellipse([x + 4, y + 23, x + 22, y + 36], fill=col, outline=dk(col, 0.55))            # 배
    for k in range(3):
        yy = y + 18 + k * 3
        d.line([(x + 7, yy), (x, yy + 4)], fill=dk(col, 0.6)); d.line([(x + 19, yy), (x + 26, yy + 4)], fill=dk(col, 0.6))
    ex = [(x + 9, y + 6), (x + 15, y + 6)]
    if mood == "dazed":
        for a, c in ex: d.line([(a - 1, c - 1), (a + 2, c + 2)], fill=WHITE); d.line([(a - 1, c + 2), (a + 2, c - 1)], fill=WHITE)
    elif mood == "sleep":
        for a, c in ex: d.line([(a - 1, c + 1), (a + 2, c + 1)], fill=DARK)
    elif mood == "happy":
        for a, c in ex: d.arc([a - 2, c - 1, a + 3, c + 4], 200, 340, fill=DARK, width=1)
    else:
        for a, c in ex: d.rectangle([a, c, a + 2, c + 3], fill=WHITE); d.point((a + 1, c + 2), fill=DARK)
    if mood in ("happy", "ok"): d.arc([x + 9, y + 8, x + 17, y + 13], 20, 160, fill=DARK)
    elif mood == "sweat":
        d.line([(x + 10, y + 12), (x + 16, y + 12)], fill=DARK)
        sy = y + 2 + int((t * 12) % 6); d.ellipse([x + 22, sy, x + 26, sy + 6], fill=CYAN)
    elif mood == "dazed": d.ellipse([x + 11, y + 10, x + 15, y + 14], outline=DARK)

def headphones(d, x, y, col=PINK):
    d.arc([x + 1, y - 4, x + 25, y + 16], 180, 360, fill=col, width=2)
    d.rectangle([x, y + 4, x + 4, y + 12], fill=col); d.rectangle([x + 22, y + 4, x + 26, y + 12], fill=col)

def note(d, x, y, col=YEL):
    d.ellipse([x, y + 8, x + 6, y + 13], fill=col); d.line([(x + 5, y + 10), (x + 5, y)], fill=col)
    d.line([(x + 5, y), (x + 9, y + 3)], fill=col, width=2)

def chicken(d, x, y):
    d.ellipse([x, y, x + 18, y + 13], fill=(200, 120, 50), outline=(140, 70, 30))
    d.line([(x + 16, y + 9), (x + 24, y + 13)], fill=WHITE, width=2); d.ellipse([x + 22, y + 11, x + 27, y + 16], fill=WHITE)

def speech(d, x, y, s, col=WHITE, font=F9, tail_left=True, fill=(250, 250, 250), tcol=DARK):
    w = int(d.textlength(s, font=font)) + 10; h = font.size + 7
    d.rounded_rectangle([x, y, x + w, y + h], radius=4, fill=fill, outline=col)
    tx = x + 8 if tail_left else x + w - 12
    d.polygon([(tx, y + h), (tx + 6, y + h), (tx + 2, y + h + 5)], fill=fill)
    d.text((x + 5, y + 3), s, font=font, fill=tcol)
    return w

def app_icon(d, x, y, col, lbl, down=False):
    d.rounded_rectangle([x, y, x + 22, y + 22], radius=5, fill=col)
    if down:
        d.polygon([(x + 6, y + 8), (x + 16, y + 8), (x + 11, y + 16)], fill=WHITE)
    d.text((x + 11, y + 24), lbl, font=F9, fill=WHITE, anchor="ma")

def folder(d, x, y, lbl, col=GOLD):
    d.rectangle([x, y + 4, x + 12, y + 8], fill=dk(col, 0.8))
    d.rectangle([x, y + 7, x + 30, y + 26], fill=col, outline=dk(col, 0.6))
    d.text((x + 15, y + 28), lbl, font=F9, fill=WHITE, anchor="ma")

def checkmark(d, x, y, col=GRN):
    d.line([(x, y + 6), (x + 5, y + 11), (x + 14, y)], fill=col, width=3)

def xmark(d, x, y, col=SRED, s=12):
    d.line([(x, y), (x + s, y + s)], fill=col, width=3); d.line([(x, y + s), (x + s, y)], fill=col, width=3)

def cloud(d, x, y, col=(235, 240, 255)):
    for dx, dy, r in ((0, 6, 7), (9, 2, 9), (19, 6, 7)):
        d.ellipse([x + dx - r + 7, y + dy - r + 7, x + dx + r + 7, y + dy + r + 7], fill=col)

def bed(d, x, y):
    d.rectangle([x, y + 14, x + 70, y + 24], fill=(120, 80, 60))
    d.rectangle([x, y + 2, x + 6, y + 30], fill=(140, 90, 70)); d.rectangle([x + 64, y + 8, x + 70, y + 30], fill=(140, 90, 70))
    d.rectangle([x + 6, y + 8, x + 22, y + 15], fill=WHITE)
    d.rectangle([x + 22, y + 8, x + 64, y + 16], fill=(90, 120, 200))

def book(d, cx, y, title, col=CYAN, sub="", w=120, h=86):
    x0 = cx - w // 2
    d.rectangle([x0 + 4, y + 4, x0 + w + 4, y + h + 4], fill=(6, 8, 18))
    d.rectangle([x0, y, x0 + w, y + h], fill=dk(col, 0.45), outline=col)
    d.rectangle([x0, y, x0 + 10, y + h], fill=dk(col, 0.7))
    d.text((cx + 5, y + 14), title, font=F12, fill=WHITE, anchor="ma")
    d.line([(x0 + 22, y + 32), (x0 + w - 12, y + 32)], fill=col)
    if sub: d.text((cx + 5, y + 38), sub, font=F9, fill=YEL, anchor="ma")

def zzz(d, x, y, t):
    for k in range(3):
        ph = (t * 0.8 + k * 0.33) % 1
        d.text((x + k * 7 + int(ph * 6), y - int(ph * 22)), "Z", font=F12 if k == 2 else F9, fill=dk(WHITE, 1 - ph * 0.6))

# ================================================================ scenes
def punch_fx(t, t0):
    return {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2)), "flash": 0.25} if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 생활 정보", "하락장 생활백서", "살아남는 법 6가지", CYAN)
    s1 = seg[1]
    if t < s1:
        x, y = 40, 124
        d.rounded_rectangle([x, y, x + 110, y + 150], radius=8, fill=(20, 22, 34), outline=WHT2)
        d.rectangle([x + 6, y + 12, x + 104, y + 138], fill=(12, 14, 26))
        d.text((x + 55, y + 16), "내 계좌", font=F9, fill=GRAY, anchor="ma")
        rows = [("주식 A", "-12.4%"), ("주식 B", "-8.9%"), ("주식 C", "-15.1%")]
        for i, (nm, pc) in enumerate(rows):
            ts = 0.4 + i * 0.35
            if t < ts: continue
            yy = y + 34 + i * 26
            d.text((x + 12, yy), nm, font=F9, fill=WHITE); d.text((x + 98, yy), pc, font=F12, fill=BLUE, anchor="ra")
            d.line([(x + 10, yy + 18), (x + 100, yy + 18)], fill=(40, 44, 64))
        if t > 1.6:
            u = ease(prog(t, 1.6, 2.2))
            d.rectangle([x + 6, y + 12, x + 104, y + 138], outline=dk(BLUE, 0.5 + 0.5 * u))
            d.text((x + 55, y + 116), "파랗게 질림", font=F9, fill=BLUE, anchor="ma") if u > 0.5 else None
        ant(d, 168, 210, t, "sweat")
        if t > 1.0: qmark(d, 182, 182, t)
    else:
        u = prog(t, s1, s1 + 0.3)
        vis, o = slam(t, s1, 0.25)
        book(d, CX, 132 + o, "하락장 생활백서", CYAN, "살아남는 법 6가지")
        ant(d, 56, 250, t, "happy")
        if t > s1 + 0.6: stamp_slam(img, 168, 262, "필독!", SRED, t, s1 + 0.6, "24", -10)
        if t > s1 + 0.6: confetti(d, t, s1 + 0.6, 16, (YEL, GRN, CYAN, PINK))
    return punch_fx(t, s1 + 0.6) if t > s1 else {}

def s_app(img, d, t, seg, dur):
    header(d, t, "수칙 01", "주식 앱은 이사", "'나중에' 폴더 맨 끝으로", BLUE)
    s1 = seg[1]
    if t < s1:
        x, y = 56, 122
        d.rounded_rectangle([x, y, x + 140, y + 176], radius=10, fill=(20, 22, 34), outline=WHT2)
        icons = [((255, 200, 60), "사진"), ((90, 200, 120), "지도"), (PINK, "음악"), ((120, 160, 255), "날씨"), ((200, 120, 255), "게임")]
        for k, (col, lb) in enumerate(icons):
            r, c = divmod(k, 3)
            app_icon(d, x + 12 + c * 42, y + 14 + r * 40, col, lb)
        u = ease(prog(t, 1.2, 2.4))                                         # 주식 앱 → 폴더
        sx, sy = x + 96, y + 54; fx_, fy = x + 98, y + 120
        if u < 1: app_icon(d, int(lerp(sx, fx_ + 4, u)), int(lerp(sy, fy, u)), BLUE, "주식" if u < 0.3 else "", True)
        folder(d, x + 96, y + 116, "나중에")
        if t > 2.4:
            d.text((x + 70, y + 154), "잘 가~", font=F9, fill=YEL, anchor="ma")
        ant(d, 200, 238, t, "happy" if t > 2.4 else "ok")
    else:
        n = min(30, int(30 * ease(prog(t, s1 + 0.1, s1 + 1.6))))
        d.text((CX, 124), "하루 확인 횟수", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 136), f"{n}번", font=F24, fill=SRED if n >= 30 else WHITE, anchor="ma")
        for k in range(n):                                                   # 바를정(正) 대신 막대 표시
            gx, gy = 46 + (k % 15) * 12, 172 + (k // 15) * 16
            d.rectangle([gx, gy, gx + 3, gy + 11], fill=SRED if k % 5 == 4 else WHT2)
        ant(d, 112, 216, t, "dazed" if n >= 30 else "sweat")
        if n >= 30:
            for k in range(3):
                a = t * 5 + k * 2.1
                d.text((125 + int(math.cos(a) * 18), 204 + int(math.sin(a) * 4)), "*", font=F9, fill=YEL, anchor="ma")
            vis, o = slam(t, s1 + 1.7, 0.2)
            box(d, 34, 262 + o, 216, 286 + o, SRED, (40, 10, 16))
            d.text((CX, 267 + o), "30번 보면 30번 아프다", font=F12, fill=WHITE, anchor="ma")
    chapter_flash(img, d, t, "01", "앱은 이사", BLUE)
    return {"flash": 0.2} if s1 + 1.6 < t < s1 + 1.7 else {}

def s_music(img, d, t, seg, dur):
    header(d, t, "수칙 02", "좋은 음악 듣기", "차트는 차트인데, 음악 차트", PINK)
    s1 = seg[1]
    if t < s1:
        ant(d, 110, 168, t, "happy"); headphones(d, 110, 168, PINK)
        for k in range(6):
            ph = (t * 0.6 + k / 6) % 1
            nx = 60 + (k * 37) % 140; ny = 230 - int(ph * 110)
            if ph < 0.9: note(d, nx + int(math.sin(t * 3 + k) * 6), ny, (YEL, PINK, MINT, CYAN)[k % 4])
        bars(d, 46, 286, 160, 40, 16, t, prog(t, 0.3, 1.2), accent=7, col=dk(PINK, 0.8), acol=YEL)
    else:
        for i, (ttl, col, good, ts) in enumerate([("주식 차트", BLUE, False, 0.1), ("음악 차트 TOP 100", PINK, True, 0.6)]):
            if t < s1 + ts: continue
            vis, o = slam(t, s1 + ts, 0.2); y = 128 + i * 74 + o
            d.rectangle([34, y, 216, y + 62], fill=(10, 14, 30), outline=col)
            d.text((42, y + 4), ttl, font=F12, fill=col)
            if not good:
                pts = [(46 + j * 9, y + 24 + int(j * 1.6) + (j % 2) * 3) for j in range(14)]
                d.line(pts, fill=BLUE, width=2)
                if t > s1 + 1.2: xmark(d, 186, y + 24, SRED, 16)
            else:
                for j, nm in enumerate(["1. 신나는 노래", "2. 더 신나는 노래"]):
                    d.text((46, y + 24 + j * 14), nm, font=F9, fill=WHITE)
                note(d, 168, y + 26, YEL); note(d, 180, y + 22, MINT)
                if t > s1 + 1.6: checkmark(d, 194, y + 30, GRN)
        if t > s1 + 2.0:
            d.text((CX, 282), "심장은 음악 때문에 뛰게", font=F9, fill=PINK, anchor="ma")
    chapter_flash(img, d, t, "02", "음악 듣기", PINK)
    return {}

def s_people(img, d, t, seg, dur):
    header(d, t, "수칙 03", "사람들 만나기", "단, 주식 얘기 금지", ORG)
    s1 = seg[1]
    d.rectangle([44, 238, 206, 246], fill=(120, 80, 50)); d.rectangle([60, 246, 66, 276], fill=(90, 60, 40)); d.rectangle([184, 246, 190, 276], fill=(90, 60, 40))
    chicken(d, 108, 224); chicken(d, 128, 228)
    ant(d, 52, 200, t, "ok", ANT); ant(d, 166, 200, t + 0.7, "ok", (150, 110, 200))
    if t < s1:
        if t > 0.8:
            speech(d, 40, 160, "요즘 주식 어때?", WHT2)
        if t > 1.6:
            xmark(d, 64, 158, SRED, 16)
            stamp_slam(img, 168, 148, "금지어!", SRED, t, 1.6, "12", 8)
    else:
        bubbles = [(0.2, 40, 156, "어제 뭐 먹었어?", True), (0.8, 116, 138, "맛집 찾았어!", False), (1.4, 40, 176, "하하하하", True)]
        for ts, x, y, s, left in bubbles:
            if t < s1 + ts: continue
            vis, o = slam(t, s1 + ts, 0.18)
            speech(d, x, y + o, s, WHT2, F9, left)
        if t > s1 + 1.8:
            ant(d, 52, 200, t, "happy", ANT); ant(d, 166, 200, t + 0.7, "happy", (150, 110, 200))
            confetti(d, t, s1 + 1.8, 12, (YEL, PINK, MINT))
    chapter_flash(img, d, t, "03", "사람 만나기", ORG)
    return punch_fx(t, 1.6) if t < s1 else {}

def s_think(img, d, t, seg, dur):
    header(d, t, "수칙 04", "좋은 생각하기", "말만 바꿔도 기분이 바뀐다", GRN)
    s1 = seg[1]
    if t < s1:
        ant(d, 40, 236, t, "ok")
        for k, (dx, dy, r) in enumerate([(70, 228, 3), (80, 216, 5)]):
            d.ellipse([dx - r, dy - r, dx + r, dy + r], fill=WHT2)
        d.rounded_rectangle([88, 126, 214, 214], radius=14, fill=(250, 250, 250), outline=WHT2)
        d.text((151, 136), "물렸다", font=F12, fill=GRAY, anchor="ma")
        if t > 1.2:
            u = ease(prog(t, 1.2, 1.6)); d.line([(118, 144), (118 + int(66 * u), 144)], fill=SRED, width=2)
        if t > 1.8:
            vis, o = slam(t, 1.8, 0.2)
            d.text((151, 164 + o), "장기투자", font=F24, fill=GRN, anchor="ma")
            d.text((151, 192 + o), "시작!", font=F12, fill=DARK, anchor="ma")
        if t > 2.4: ant(d, 40, 236, t, "happy")
    else:
        d.rectangle([40, 126, 210, 150], fill=SRED); d.text((CX, 130), "세일 기간", font=F12, fill=WHITE, anchor="ma")
        for k in range(8):
            d.rectangle([40 + k * 22, 150, 50 + k * 22, 158], fill=WHITE if k % 2 else SRED)
        bungeo(d, 60, 190, 1.0); price_tag(d, 116, 178, "50% 할인?", SRED, 0)
        u = ease(prog(t, s1 + 0.8, s1 + 2.0))
        cart(d, int(lerp(220, 120, u)), 236, t, 1 if u < 1 else 2)
        if t > s1 + 2.0:
            vis, o = slam(t, s1 + 2.0, 0.2)
            box(d, 34, 276 + o, 216, 296 + o, GOLD, (30, 22, 6))
            d.text((CX, 280 + o), "장바구니는 천천히, 나눠서", font=F9, fill=WHITE, anchor="ma")
    chapter_flash(img, d, t, "04", "좋은 생각", GRN)
    return {"flash": 0.2} if 1.8 < t < 1.9 else {}

def s_walk(img, d, t, seg, dur):
    header(d, t, "수칙 05", "밖에 나가 걷기", "계좌가 파랗다면?", SKY)
    s1 = seg[1]
    d.rectangle([34, 124, 216, 250], fill=SKY if t > 0.9 else (30, 40, 70))
    if t > 0.9:
        sun(d, 190, 146, 11, t)
        for k in range(3):
            cx_ = 34 + int((t * 10 + k * 70) % 190) - 20
            if 34 < cx_ < 190: cloud(d, cx_, 132 + k * 22)
    d.rectangle([34, 250, 216, 262], fill=(70, 150, 80)); d.rectangle([34, 262, 216, 266], fill=(140, 110, 70))
    wx = 40 + int((t * 18) % 150)
    ant(d, wx, 218, t, "happy" if t > 1.4 else "ok")
    if t < s1:
        if t > 0.9:
            vis, o = slam(t, 0.9, 0.2)
            d.text((CX, 172 + o), "하늘을 보세요", font=F12, fill=DARK, anchor="ma")
    else:
        vis, o = slam(t, s1 + 0.1, 0.2)
        d.text((CX, 166 + o), "여기도 파랗지만", font=F12, fill=DARK, anchor="ma")
        d.text((CX, 184 + o), "예쁘죠?", font=F24, fill=WHITE, anchor="ma")
        steps = int(10000 * ease(prog(t, s1 + 0.6, s1 + 2.0)))
        d.text((CX, 272), f"걸음 {steps:,}보", font=F12, fill=YEL if steps >= 10000 else WHITE, anchor="ma")
        if steps >= 10000:
            stamp_slam(img, 168, 292, "기분 상한가", SRED, t, s1 + 2.1, "12", -8)
    chapter_flash(img, d, t, "05", "걷기", SKY)
    return punch_fx(t, s1 + 2.1) if t > s1 else {}

def s_sleep(img, d, t, seg, dur):
    header(d, t, "수칙 06", "푹 자기", "새벽 미장은 아침에 확인", PURP)
    s1 = seg[1]
    d.rectangle([34, 124, 216, 268], fill=(14, 20, 52))
    moon(d, 190, 146, 10); stars(d, 40, 130, 170, 200, t, 9)
    bed(d, 70, 226)
    ant_y = 222
    ant(d, 96, ant_y, t, "sleep", bob=False)
    d.rectangle([104, 234, 150, 246], fill=(90, 120, 200))                    # 이불
    zzz(d, 122, 216, t)
    if t < s1:
        px, py = 168, 248                                                     # 뒤집어 둔 폰
        d.rectangle([px, py, px + 22, py + 6], fill=DARK, outline=WHT2)
        if t > 1.2:
            vis, o = slam(t, 1.2, 0.2)
            d.text((180, 274 + o), "폰은 뒤집어", font=F9, fill=WHITE, anchor="ma")
    else:
        if t > s1 + 0.3:
            vis, o = slam(t, s1 + 0.3, 0.2)
            box(d, 34, 274 + o, 216, 298 + o, PURP, (24, 12, 34))
            d.text((CX, 279 + o), "잠은 복리로 돌아온다", font=F12, fill=WHITE, anchor="ma")
        for k in range(3):
            u = prog(t, s1 + 0.9 + k * 0.3, s1 + 1.4 + k * 0.3)
            if 0 < u < 1: coin(d, 60 + k * 30, int(lerp(170, 150, u)), 6, "Z")
    chapter_flash(img, d, t, "06", "푹 자기", PURP)
    return {}

def s_outro(img, d, t, seg, dur):
    header(d, t, "BONUS · S&P500 지수", "하락장은 지나갔다", "", GOLD)
    s1 = seg[1]
    if t < s1:
        rows = [("2000~02", 49.1, "7년", 0.4), ("2007~09", 56.8, "5년 반", 0.9), ("2020", 33.9, "6개월", 1.4)]
        d.text((112, 106), "고점→바닥", font=F9, fill=GRAY, anchor="ma"); d.text((200, 106), "전고점 회복", font=F9, fill=GRAY, anchor="ma")
        for i, (yr, v, rec, ts) in enumerate(rows):
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.5)); y = 126 + i * 46
            d.text((36, y + 4), yr, font=F9, fill=WHITE)
            w = int(v * 1.3 * u); d.rectangle([80, y, 80 + w, y + 16], fill=BLUE)
            if u >= 1: d.text((82, y + 3), f"-{v:.0f}%", font=F9, fill=WHITE)
            if t > ts + 0.6:
                vis, o = slam(t, ts + 0.6, 0.2)
                d.rectangle([166, y + o, 214, y + 18 + o], fill=(10, 30, 16), outline=GRN)
                d.text((190, y + 4 + o), rec, font=F9, fill=GRN, anchor="ma")
                up_tri = [(170, y + 26 + o), (176, y + 20 + o), (182, y + 26 + o)]
        if t > 2.4:
            d.text((CX, 268), "지수 기준 · 과거가 미래를 보장하진 않아요", font=F9, fill=DIM, anchor="ma")
    else:
        book(d, CX, 124, "하락장 생활백서", CYAN, "")
        items = [("앱 이사", BLUE), ("음악", PINK), ("사람", ORG), ("좋은 생각", GRN), ("걷기", SKY), ("잠", PURP)]
        for k, (nm, col) in enumerate(items):
            ts = s1 + 0.2 + k * 0.15
            if t < ts: continue
            vis, o = slam(t, ts, 0.18); r, c = divmod(k, 3)
            letter_x = 62 + c * 62; y = 164 + r * 18 + o
            d.text((letter_x, y), nm, font=F9, fill=col, anchor="ma")
        ant(d, 56, 240, t, "happy"); headphones(d, 56, 240, PINK)
        if t > s1 + 1.3:
            vis, o = slam(t, s1 + 1.3, 0.2)
            box(d, 92, 236 + o, 216, 278 + o, YEL if blink(t, 3) else ORG, (30, 22, 6))
            d.text((154, 242 + o), "계좌보다", font=F9, fill=WHITE, anchor="ma")
            d.text((154, 256 + o), "몸과 마음 먼저!", font=F12, fill=YEL, anchor="ma")
    d.text((32, 306), "※ 생활 정보 · 투자 권유 아님", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("요즘 계좌, 파랗게 질렸나요?", "요즘 계좌, 파랗게 질렸나요?"),
              ("그래서 준비했어요\n하락장 생활백서!", "그래서 준비했어요. 하락장 생활백서!")]),
    (s_app, [("수칙 1. 주식 앱은\n'나중에' 폴더 맨 끝으로 이사", "수칙 일 번. 주식 앱은 폴더 맨 끝, 나중에 폴더로 이사시키세요."),
             ("하루 30번 보면 30번 아파요\n쳐다본다고 잔고가 오르진 않아요", "하루 서른 번 보면, 서른 번 아파요. 쳐다본다고 잔고가 오르진 않거든요.")]),
    (s_music, [("수칙 2. 좋은 음악 듣기\n차트는 보되, 음악 차트로!", "수칙 이 번, 좋은 음악 듣기. 차트는 보되, 음악 차트로 보세요."),
               ("파란 캔들 대신 신나는 비트,\n심장은 음악 때문에 뛰게!", "파란 캔들 대신 신나는 비트. 심장은 음악 때문에 뛰게 하자고요.")]),
    (s_people, [("수칙 3. 사람들 만나기\n단, 주식 얘기는 금지!", "수칙 삼 번, 사람들 만나기. 단, 주식 얘기는 금지예요."),
                ("'너 뭐 샀어?' 대신 '너 뭐 먹었어?'\n웃다 보면 시간은 가요", "너 뭐 샀어 대신, 너 뭐 먹었어? 웃다 보면 시간은 가요.")]),
    (s_think, [("수칙 4. 좋은 생각하기\n'물렸다'가 아니라 '장기투자 시작'", "수칙 사 번, 좋은 생각하기. 물린 게 아니라, 장기투자를 시작한 거예요."),
               ("폭락이 아니라 세일 기간!\n단, 장바구니는 천천히 나눠서", "폭락이 아니라 세일 기간. 단, 장바구니는 천천히, 나눠서 담기.")]),
    (s_walk, [("수칙 5. 밖에 나가 걷기\n계좌가 파랗다면, 하늘을 보세요", "수칙 오 번, 밖에 나가 걷기. 계좌가 파랗다면, 하늘을 보세요."),
              ("하늘도 파랗지만 예쁘잖아요\n만 보 걸으면 기분은 상한가!", "하늘도 파랗지만, 예쁘잖아요. 만 보 걷고 나면, 기분은 상한가!")]),
    (s_sleep, [("수칙 6. 푹 자기\n새벽 미국장은 아침에 확인해도 OK", "수칙 육 번, 푹 자기. 새벽 미국장은, 아침에 확인해도 늦지 않아요."),
               ("밤새 지켜본다고 안 올라요\n잠은 복리로 돌아와요", "밤새 지켜본다고 오르지 않아요. 잠은 복리로 돌아옵니다.")]),
    (s_outro, [("보너스: S&P500은 반 토막이 나도\n결국 전 고점을 되찾았어요", "보너스. 에스앤피 오백은 반 토막이 났을 때도, 결국 전 고점을 되찾았어요."),
               ("하락장은 지나가요\n계좌보다 몸과 마음 먼저 챙기기!", "하락장은 지나가요. 계좌보다, 몸과 마음부터 챙기세요!")]),
]
TITLES = ["", "주식 앱은 이사", "좋은 음악 듣기", "사람들 만나기", "좋은 생각하기", "밖에 나가 걷기", "푹 자기", "하락장은 지나갔다"]


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    MINLINE = {(0, 0): 2.3}                                                   # 훅 첫 줄은 계좌 화면이 다 보일 때까지
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else 0.75
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += max(L, MINLINE.get((k, i), 0)) + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.3, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # F major, bouncy comic 'oom-pah' (124 bpm) · 수칙 6(잠)은 드럼 빼고 자장가 · 훅 첫 줄은 단조 느낌
    bpm = 124; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_major = [([65, 69, 72], 41), ([58, 62, 65], 34), ([60, 64, 67], 36), ([65, 69, 72], 41)]   # F Bb C F
    prog_minor = [([62, 65, 69], 38), ([58, 62, 65], 34), ([60, 64, 67], 36), ([57, 61, 64], 33)]   # Dm Bb C A
    mel_M = [[77, None, 76, 77, 81, None, 79, 77], [74, None, 77, None, 74, 72, 70, None], [72, 74, 76, None, 79, None, 76, 72], [77, None, 72, None, 69, None, None, None]]
    mel_m = [[74, None, 72, 69, 70, None, 69, None], [70, 72, 74, None, 77, None, 74, 72], [72, None, 67, None, 76, None, 74, 72], [73, None, 69, None, 64, None, None, None]]
    sleep0, sleep1 = S[6], S[7]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        minor = t0 < sg(0, 1)
        notes, root = (prog_minor if minor else prog_major)[b % 4]
        mel = (mel_m if minor else mel_M)[b % 4]
        lull = sleep0 <= t0 < sleep1
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if lull:
                if st % 2 == 0: tone(bgm, T, e * 1.6, mtof(notes[(st // 2) % 3] + 12), 0.03, "sin", decay=0.5)
                continue
            if st % 2 == 0: tone(bgm, T, e * 0.6, mtof(root - 12 + (7 if st % 4 == 2 else 0)), 0.15, "tri")   # 쿵-짝 베이스
            else:
                for nn in notes: tone(bgm, T, e * 0.35, mtof(nn), 0.022, "sq", 0.25, decay=0.04)
            m = mel[st]
            if m and T > 1.0: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total or lull: continue
            if bt in (0, 2): tone(bgm, T, 0.12, 150, 0.26, "sin", f1=55, decay=0.05)
            else: tone(bgm, T, 0.08, 0, 0.08, "noise", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def buzzer(T): tone(sfx, T, 0.45, 110, 0.09, "sq", 0.5, decay=0.4); tone(sfx, T, 0.45, 116, 0.06, "sq", 0.5, decay=0.4)
    def boing(T): tone(sfx, T, 0.35, 200, 0.07, "sq", 0.5, f1=700, decay=0.3)
    def wahwah(T):
        for j, m in enumerate([67, 66, 65, 64]): tone(sfx, T + j * 0.25, 0.28 if j < 3 else 0.6, mtof(m), 0.06, "sq", 0.5, f1=mtof(m) * 0.98, decay=0.3)
    def laugh(T):
        for j in range(4): tone(sfx, T + j * 0.11, 0.08, 900 - j * 60, 0.04, "sq", 0.5, f1=700 - j * 60, decay=0.06)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.06, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.03, "sin", decay=0.2)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    # hook
    typing(S[0] + 0.1, "하락장생활백서")
    for i in range(3): pop(S[0] + 0.4 + i * 0.35)
    wahwah(S[0] + 1.6)
    swoosh(sg(0, 1)); stampfx(sg(0, 1) + 0.6); ding(sg(0, 1) + 0.7)
    for k in range(1, len(scenes)):
        chapter(S[k]); typing(S[k] + 0.6, TITLES[k])
    # 01 app
    swoosh(S[1] + 1.2); pop(S[1] + 2.4); ding(S[1] + 2.45)
    for k in range(30): blip(sg(1, 1) + 0.1 + k * 0.05, 700 + k * 30, 0.025)
    boing(sg(1, 1) + 1.6); stampfx(sg(1, 1) + 1.7)
    # 02 music
    for k in range(4): coin_s(S[2] + 0.4 + k * 0.4)
    pop(sg(2, 1) + 0.1); fall(sg(2, 1) + 0.2, 0.7); buzzer(sg(2, 1) + 1.2); pop(sg(2, 1) + 0.6); ding(sg(2, 1) + 1.6)
    # 03 people
    pop(S[3] + 0.8); buzzer(S[3] + 1.6); stampfx(S[3] + 1.65)
    for i in range(3): pop(sg(3, 1) + 0.2 + i * 0.6)
    laugh(sg(3, 1) + 1.4); ding(sg(3, 1) + 1.8)
    # 04 think
    swoosh(S[4] + 1.2); boing(S[4] + 1.8); ding(S[4] + 2.4)
    stampfx(sg(4, 1) + 0.0); rise(sg(4, 1) + 0.8, 1.2); coin_s(sg(4, 1) + 2.0)
    # 05 walk
    rise(S[5] + 0.9, 0.6); pop(S[5] + 0.9)
    pop(sg(5, 1) + 0.1); rise(sg(5, 1) + 0.6, 1.4); stampfx(sg(5, 1) + 2.1); ding(sg(5, 1) + 2.2)
    # 06 sleep (조용히)
    pop(S[6] + 1.2)
    for k in range(3): coin_s(sg(6, 1) + 0.9 + k * 0.3)
    # outro
    for i in range(3): fall(S[7] + 0.4 + i * 0.5, 0.4); ding(S[7] + 1.0 + i * 0.5)
    for k in range(6): pop(sg(7, 1) + 0.2 + k * 0.15)
    stampfx(sg(7, 1) + 1.3)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "scan":
        from nike_video import render_low
        for k, s in enumerate(scenes):
            for i in range(int(s["dur"] * FPS) + 1): render_low(s, i / FPS)
        print("scan ok"); sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

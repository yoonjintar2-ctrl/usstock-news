"""특별편 · 서킷브레이커가 뭐예요? (10/15 코스닥·코스피 1단계 발동) — dip_video.py 복사 → 대본·장면·효과음 교체
사실 확인(2026-10-15 12:40): 아시아투데이(코스닥 12시 23분 13초 1단계), 이데일리 12:24(코스닥 이어 코스피도 발동), 디지털데일리(코스닥 -8.02% 757.81 · 20분 정지 후 10분 단일가),
토스뱅크 설명(1단계 8%·2단계 15%·3단계 20%, 각 1분 지속, 직전 단계보다 1%p 추가 하락, 1·2단계 하루 1회·장 마감 40분 전 이후 미발동, 사이드카 5% · 프로그램 매매 5분)
규칙: 급락 알럿은 급락이 그려지기 전에 먼저.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, glitch_text, marquee, coin, F36, GOLD
from semicrash_video import alert_card, crash_line, qmark, shield
from kospi1015_video import thermo

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "circuit/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6

# ================================================================ drawings
def breaker_box(d, x, y, t, tripped=0.0, label="주식시장"):
    """두꺼비집(차단기): tripped 0→1 이면 레버가 내려감"""
    d.rectangle([x, y, x + 64, y + 80], fill=(46, 50, 66), outline=WHT2)
    d.rectangle([x + 6, y + 6, x + 58, y + 18], fill=DARK); d.text((x + 32, y + 7), label, font=F9, fill=YEL, anchor="ma")
    for k in range(3):
        cx = x + 14 + k * 18
        d.rectangle([cx - 5, y + 28, cx + 5, y + 66], fill=(24, 26, 36), outline=GRAY)
        pos = tripped if k == 1 else 0.0
        ly = int(lerp(y + 32, y + 52, ease(pos)))
        d.rectangle([cx - 4, ly, cx + 4, ly + 10], fill=SRED if k == 1 and pos > 0.5 else GRN)
    d.text((x + 32, y + 68), "ON" if tripped < 0.5 else "OFF", font=F9, fill=GRN if tripped < 0.5 else SRED, anchor="ma")

def bolt(d, x, y, col=YEL, s=1.0):
    p = [(0, 0), (8, 0), (4, 9), (10, 9), (-2, 24), (2, 12), (-4, 12)]
    d.polygon([(x + px * s, y + py * s) for px, py in p], fill=col)

def stop_sign(d, x, y, r=14, label="STOP"):
    pts = [(x + r * math.cos(math.pi / 8 + k * math.pi / 4), y + r * math.sin(math.pi / 8 + k * math.pi / 4)) for k in range(8)]
    d.polygon(pts, fill=SRED, outline=WHITE)
    d.text((x, y - 5), label, font=F9, fill=WHITE, anchor="ma")

def clock(d, x, y, r, frac, col=YEL):
    d.ellipse([x - r, y - r, x + r, y + r], fill=(16, 20, 36), outline=col, width=2)
    a = -math.pi / 2 + frac * math.tau
    d.line([(x, y), (x + math.cos(a) * (r - 4), y + math.sin(a) * (r - 4))], fill=col, width=2)
    d.line([(x, y), (x, y - r // 2)], fill=WHT2, width=2)

def order_bubble(d, x, y, s, col):
    w = int(d.textlength(s, font=F9)) + 8
    d.rectangle([x, y, x + w, y + 12], fill=(16, 20, 36), outline=col); d.text((x + 4, y + 1), s, font=F9, fill=col)

def sidecar_bike(d, x, y, t, col=CYAN):
    """사이드카 달린 오토바이 (원작 픽셀)"""
    b = int(abs(math.sin(t * 8)))
    d.ellipse([x, y + 14, x + 14, y + 28], outline=WHT2, width=2); d.ellipse([x + 34, y + 14, x + 48, y + 28], outline=WHT2, width=2)
    d.polygon([(x + 6, y + 14 - b), (x + 40, y + 14 - b), (x + 34, y + 6 - b), (x + 14, y + 6 - b)], fill=col)
    d.rectangle([x + 20, y - b, x + 26, y + 6 - b], fill=SKIN); d.rectangle([x + 19, y - 4 - b, x + 27, y - b], fill=SRED)
    d.rectangle([x + 50, y + 10, x + 72, y + 22], fill=dk(col, 0.7), outline=col); d.ellipse([x + 56, y + 18, x + 66, y + 28], outline=WHT2, width=2)
    d.line([(x + 44, y + 14), (x + 50, y + 16)], fill=GRAY, width=2)

def stairs(d, x, y, n, t, labels):
    for k in range(n):
        yy = y + k * 34
        d.rectangle([x + k * 40, yy, x + k * 40 + 60, yy + 30], fill=(16, 20, 36), outline=(ORG, SRED, PURP)[k])
        d.text((x + k * 40 + 30, yy + 3), labels[k][0], font=F12, fill=(ORG, SRED, PURP)[k], anchor="ma")
        d.text((x + k * 40 + 30, yy + 18), labels[k][1], font=F9, fill=WHITE, anchor="ma")

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 10.15 낮 12시 23분", "시장이 멈췄다!", "서킷브레이커 1단계 발동", SRED)
    s1 = seg[1]
    if t < s1:
        box(d, 34, 122, 216, 226, DIM)
        d.text((40, 125), "코스닥 · 코스피", font=F9, fill=WHITE)
        uf = ease(prog(t, 0.3, 1.2)); ud = prog(t, 2.4, 3.2)
        end = crash_line(d, 42, 130, 208, 146, 60, uf, ud, WHITE, 7)
        alert_card(img, d, t, 1.25, 2.35, CX, 172, "급락 경보", "-8% 임박")              # 경보 먼저
        if t > 3.2:
            d.line([(42, 206), (208, 206)], fill=SRED); d.text((44, 196), "-8% 선", font=F9, fill=SRED)
            stop_sign(d, 186, 196, 16)
        if t > 3.5:
            vis, o = slam(t, 3.5, 0.2)
            d.rectangle([34, 234 + o, 216, 290 + o], fill=(40, 10, 16), outline=SRED if blink(t, 3) else ORG)
            d.text((42, 240 + o), "코스닥 12:23:13", font=F12, fill=WHITE); d.text((210, 242 + o), "-8.02%", font=F12, fill=SRED, anchor="ra")
            d.text((42, 262 + o), "이어 코스피도 발동", font=F12, fill=WHITE); d.text((210, 264 + o), "-8%", font=F12, fill=SRED, anchor="ra")
    else:
        breaker_box(d, 40, 130, t, prog(t, s1 + 0.4, s1 + 0.6))
        if s1 + 0.6 < t < s1 + 1.2: bolt(d, 118, 140, YEL); bolt(d, 128, 170, ORG, 0.8)
        clock(d, 168, 166, 26, prog(t, s1 + 0.8, dur) * 0.6, YEL)
        d.text((168, 198), "20분 정지", font=F12, fill=YEL, anchor="ma")
        if t > s1 + 1.0:
            vis, o = slam(t, s1 + 1.0, 0.2)
            d.rectangle([34, 234 + o, 216, 270 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((CX, 240 + o), "주식시장이 멈춘다고?", font=F12, fill=GOLD, anchor="ma")
            d.text((CX, 256 + o), "1분 만에 쉽게 정리!", font=F9, fill=WHITE, anchor="ma")
    fx = {}
    if 2.4 < t < 2.95: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
    if 1.25 < t < 1.35 or s1 + 0.4 < t < s1 + 0.5: fx["flash"] = 0.3
    return fx

def s_what(img, d, t, seg, dur):
    header(d, t, "01 · 뜻", "비상 차단기", "Circuit Breaker", CYAN)
    s1 = seg[1]
    if t < s1:
        tr = prog(t, 1.6, 1.8)
        breaker_box(d, 40, 130, t, tr, "우리 집")
        if t < 1.8:
            for k in range(3):
                if blink(t + k * 0.2, 6): bolt(d, 126 + k * 22, 140 + (k % 2) * 16, YEL)
            d.text((160, 190), "과부하!", font=F12, fill=SRED, anchor="ma")
        else:
            d.text((160, 166), "탁!", font=F24, fill=WHITE, anchor="ma")
        if t > 2.2:
            vis, o = slam(t, 2.2, 0.2)
            d.rectangle([34, 234 + o, 216, 262 + o], fill=(10, 14, 30), outline=CYAN)
            d.text((CX, 241 + o), "전기가 넘치면 차단기가 내려가죠", font=F9, fill=CYAN, anchor="ma")
    else:
        thermo(d, 44, 128, lerp(0.95, 0.35, ease(prog(t, s1 + 1.2, s1 + 3.0))), SRED)
        for k in range(3):
            if t > s1 + 1.0:
                y = 140 + k * 18; x = int(110 + ((t * 30 + k * 20) % 60))
                d.line([(x, y), (x + 14, y)], fill=CYAN, width=2)
        d.text((160, 200), "열 식히기", font=F12, fill=CYAN, anchor="ma")
        if t > s1 + 0.3:
            vis, o = slam(t, s1 + 0.3, 0.2)
            d.rectangle([34, 234 + o, 216, 290 + o], fill=(10, 14, 30), outline=CYAN)
            d.text((CX, 240 + o), "주가가 너무 빨리 떨어지면", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 256 + o), "거래를 잠깐 멈추는 장치", font=F12, fill=CYAN, anchor="ma")
            d.text((CX, 274 + o), "공포가 공포를 부르는 걸 막아요", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "01", "뜻", CYAN)
    return {"flash": 0.3} if 1.6 < t < 1.7 else {}

def s_steps(img, d, t, seg, dur):
    header(d, t, "02 · 발동 조건", "3단계", "전날 종가보다 얼마나 빠졌나", ORG)
    s1 = seg[1]
    labs = [("1단계 -8%", "20분 정지"), ("2단계 -15%", "20분 정지"), ("3단계 -20%", "그날 장 끝")]
    n = 1 if t < s1 else (2 if t < s1 + 1.6 else 3)
    for k in range(n):
        ts = 0.75 if k == 0 else (s1 + 0.1 if k == 1 else s1 + 1.6)
        vis, o = slam(t, ts, 0.2); yy = 126 + k * 40 + o; x = 36 + k * 40
        col = (ORG, SRED, PURP)[k]
        d.rectangle([x, yy, x + 96, yy + 34], fill=(16, 20, 36), outline=col)
        d.text((x + 48, yy + 4), labs[k][0], font=F12, fill=col, anchor="ma")
        d.text((x + 48, yy + 20), labs[k][1], font=F9, fill=WHITE, anchor="ma")
        if k < 2: stop_sign(d, x + 108, yy + 17, 11)
        else: d.text((x + 108, yy + 10), "END", font=F9, fill=PURP, anchor="ma")
    if t > 1.6 and t < s1:
        vis, o = slam(t, 1.6, 0.2)
        d.rectangle([34, 250 + o, 216, 290 + o], fill=(10, 14, 30), outline=ORG)
        d.text((CX, 256 + o), "8% 넘게 빠진 상태가", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 270 + o), "1분 이어지면 발동!", font=F12, fill=ORG, anchor="ma")
    if t > s1 + 2.4:
        d.text((CX, 262), "2·3단계는 직전 단계보다", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 276), "1%p 더 빠져야 해요", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "02", "3단계", ORG)
    return {}

def s_resume(img, d, t, seg, dur):
    header(d, t, "03 · 멈춘 다음엔?", "재개 방법", "20분 휴식 → 10분 주문 모으기", GRN)
    s1 = seg[1]
    if t < s1:
        clock(d, 60, 160, 24, prog(t, 0.8, 2.0) * 0.33, YEL); d.text((60, 190), "20분 정지", font=F9, fill=YEL, anchor="ma")
        if t > 2.0:
            orders = [("사자 5만", GRN), ("팔자 4.9만", SRED), ("사자 5.1만", GRN), ("팔자 5만", SRED)]
            for k, (s, col) in enumerate(orders):
                ts = 2.0 + k * 0.2
                if t < ts: continue
                q = ease(prog(t, 2.9, 3.5)); x0, y0 = 110 + (k % 2) * 50, 132 + (k // 2) * 20
                order_bubble(d, int(lerp(x0, 150, q)), int(lerp(y0, 176, q)), s, col)
            if t > 3.5:
                d.rectangle([118, 172, 210, 196], fill=(10, 20, 14), outline=GRN)
                d.text((164, 178), "한 가격에 체결!", font=F9, fill=GRN, anchor="ma")
        if t > 3.8:
            vis, o = slam(t, 3.8, 0.2)
            d.rectangle([34, 234 + o, 216, 270 + o], fill=(10, 14, 30), outline=GRN)
            d.text((CX, 240 + o), "10분 동안 주문을 모아(단일가)", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 254 + o), "그다음 평소처럼 다시 거래", font=F9, fill=GRN, anchor="ma")
    else:
        for k, (lab, col) in enumerate([("1단계", ORG), ("2단계", SRED)]):
            vis, o = slam(t, s1 + 0.1 + k * 0.3, 0.2); x = 44 + k * 90
            d.rectangle([x, 132 + o, x + 74, 172 + o], fill=(16, 20, 36), outline=col)
            d.text((x + 37, 138 + o), lab, font=F12, fill=col, anchor="ma"); d.text((x + 37, 156 + o), "하루 1번만", font=F9, fill=WHITE, anchor="ma")
        if t > s1 + 1.0:
            vis, o = slam(t, s1 + 1.0, 0.2)
            clock(d, 60, 214 + o, 16, 0.92, ORG)
            d.text((140, 202 + o), "장 마감 40분 전부터는", font=F9, fill=WHITE, anchor="ma")
            d.text((140, 216 + o), "1·2단계 발동 안 함", font=F12, fill=ORG, anchor="ma")
    chapter_flash(img, d, t, "03", "재개", GRN)
    return {}

def s_side(img, d, t, seg, dur):
    header(d, t, "04 · 헷갈리는 친구", "사이드카 vs 서킷", "오늘 둘 다 나왔어요", PURP)
    x = int(lerp(-80, 40, ease(prog(t, 0.75, 1.5))))
    sidecar_bike(d, x, 136, t)
    if t > 1.5:
        d.text((150, 134), "사이드카", font=F12, fill=CYAN, anchor="ma")
        d.text((150, 150), "프로그램 매매만", font=F9, fill=WHITE, anchor="ma"); d.text((150, 162), "5분 멈춤 · 오전 9:07", font=F9, fill=GRAY, anchor="ma")
    if t > 2.6:
        vis, o = slam(t, 2.6, 0.2)
        breaker_box(d, 42, 196 + o, t, 1.0)
        d.text((150, 204 + o), "서킷브레이커", font=F12, fill=SRED, anchor="ma")
        d.text((150, 220 + o), "시장 전체 거래가", font=F9, fill=WHITE, anchor="ma"); d.text((150, 232 + o), "20분 멈춤 · 낮 12:23~", font=F9, fill=GRAY, anchor="ma")
    if t > 3.6:
        vis, o = slam(t, 3.6, 0.2)
        d.text((CX, 290 + o), "사이드카 = 선물 5% 급변 · 서킷 = 지수 8% 급락", font=F9, fill=GOLD, anchor="ma")
    chapter_flash(img, d, t, "04", "사이드카", PURP)
    return {}

def s_mean(img, d, t, seg, dur):
    header(d, t, "05 · 그래서?", "생각할 시간", "하락을 막는 장치는 아니에요", GOLD)
    s1 = seg[1]
    if t < s1:
        for k in range(3):
            if t > 0.75 + k * 0.3: mini_person(d, 60 + k * 30, 170, (CYAN, ORG, GRN)[k], t * 0.5, k)
        if t > 1.6:
            d.text((105, 140), "잠깐 멈추고 숨 고르기", font=F9, fill=GOLD, anchor="ma")
        clock(d, 186, 172, 18, prog(t, 0.8, s1) * 0.3, GOLD)
        if t > 2.2:
            vis, o = slam(t, 2.2, 0.2)
            d.rectangle([34, 224 + o, 216, 268 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((CX, 230 + o), "급락을 멈춰 주는 게 아니라", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 246 + o), "판단할 시간을 주는 장치", font=F12, fill=GOLD, anchor="ma")
    else:
        warn_icon(d, 117, 124, YEL if blink(t, 3) else ORG)
        if t > s1 + 0.1:
            vis, o = slam(t, s1 + 0.1, 0.2)
            d.rectangle([34, 148 + o, 216, 200 + o], fill=(40, 10, 16), outline=SRED if blink(t, 3) else ORG)
            d.text((CX, 156 + o), "재개 후에도 크게 출렁일 수 있어요", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 174 + o), "급하게 사고팔지 않기", font=F12, fill=SRED, anchor="ma")
        if t > s1 + 1.2:
            vis, o = slam(t, s1 + 1.2, 0.2)
            d.text((CX, 216 + o), "올해 3월·6월·7월에도 발동했던 장치", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "05", "의미", GOLD)
    return {}

def s_outro(img, d, t, seg, dur):
    marquee(d, 246, 2, 26, t, "8% · 1분 · 20분 정지 · 10분 단일가", (dk(SRED, 0.55), dk(CYAN, 0.5)))
    header(d, t, "오늘의 용어", "서킷브레이커", "시장의 비상 차단기", GOLD)
    rows = [("8%", "1분 지속 → 1단계", ORG), ("20분", "모든 거래 정지", SRED), ("10분", "단일가로 재개", GRN)]
    for i, (a, b, col) in enumerate(rows):
        ts = 0.3 + i * 0.4
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 126 + i * 32
        d.rectangle([34, y + o, 216, y + 24 + o], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y + o, 78, y + 24 + o], fill=col)
        d.text((56, y + 5 + o), a, font=F12, fill=WHITE, anchor="ma")
        d.text((86, y + 5 + o), b, font=F12, fill=WHITE)
    d.text((32, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("오늘 낮 12시 23분 코스닥, 이어 코스피까지\n서킷브레이커 1단계 발동!", "오늘 낮 열두 시 이십삼 분 코스닥, 이어서 코스피까지 서킷브레이커 일단계가 발동됐어요."),
              ("주식시장이 멈춘다고?\n쉽게 알려 드릴게요", "주식시장이 멈춘다고? 쉽게 알려 드릴게요.")]),
    (s_what, [("서킷브레이커는 원래 '전기 차단기'\n과부하가 걸리면 탁! 내려가죠", "서킷브레이커는 원래 전기 차단기예요. 과부하가 걸리면 탁 내려가죠."),
              ("주가가 너무 빨리 떨어지면\n거래를 잠깐 멈춰 열을 식히는 장치예요", "주식에선 주가가 너무 빨리 떨어질 때, 거래를 잠깐 멈춰 열을 식히는 장치예요.")]),
    (s_steps, [("1단계: 전날보다 8% 넘게 빠진 채 1분,\n20분간 모든 거래 정지", "일단계는 전날보다 팔 퍼센트 넘게 빠진 채 일 분이 지나면, 이십 분간 모든 거래가 멈춰요."),
               ("2단계는 15%, 또 20분 정지\n3단계 20%면 그날 장이 끝나요", "이단계는 십오 퍼센트로 또 이십 분 정지, 삼단계 이십 퍼센트면 그날 장이 끝나요.")]),
    (s_resume, [("20분 쉰 뒤 10분 동안 주문을 모아\n한 가격에 체결하고 다시 시작", "이십 분 쉬고 나면, 십 분 동안 주문을 모아 한 가격에 체결하고 다시 시작해요."),
                ("1·2단계는 하루 한 번,\n장 마감 40분 전부터는 발동 안 해요", "일단계와 이단계는 하루 한 번씩만, 장 마감 사십 분 전부터는 발동하지 않아요.")]),
    (s_side, [("아침 사이드카는 프로그램 매매만 5분,\n서킷브레이커는 시장 전체가 멈춰요", "아침에 나온 사이드카는 프로그램 매매만 오 분 멈추는 거고, 서킷브레이커는 시장 전체가 멈춰요.")]),
    (s_mean, [("서킷브레이커는 하락을 막는 게 아니라\n생각할 시간을 주는 장치예요", "서킷브레이커는 하락을 막아 주는 게 아니라, 생각할 시간을 주는 장치예요."),
              ("재개 후에도 크게 출렁일 수 있으니\n급하게 사고팔지 마세요", "재개 후에도 크게 출렁일 수 있으니, 급하게 사고팔지 마세요.")]),
    (s_outro, [("오늘의 용어, 서킷브레이커!\n시장의 비상 차단기예요", "오늘의 용어, 서킷브레이커! 시장의 비상 차단기예요.")]),
]
TITLES = ["", "뜻", "3단계", "재개", "사이드카", "의미", "정리"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        extra = 1.0 if fn is s_side else 0.0
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + extra, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # D minor alarm for the hook → F major 'term explainer' bounce (용어 편 느낌) from scene 1
    bpm = 120; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([62, 65, 69], 38), ([58, 62, 65], 34), ([60, 64, 67], 36), ([57, 61, 64], 33)]
    prog_major = [([65, 69, 72], 41), ([60, 64, 67], 36), ([62, 65, 69], 38), ([58, 62, 65], 34)]
    mel_m = [[74, None, 72, 69, 70, None, 69, None], [70, 72, 74, None, 77, None, 74, 72], [72, None, 67, None, 76, None, 74, 72], [73, None, 69, None, 64, None, None, None]]
    mel_M = [[77, None, 76, 77, 81, None, 79, 77], [76, None, 72, None, 76, 77, 79, None], [81, None, 77, 74, 72, None, 74, None], [74, 76, 77, None, 74, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = t0 >= S[1]
        tense = t0 < S[1]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and not tense: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
            if m and tense and st % 4 == 0 and T > 3.2: tone(bgm, T, e * 1.6, mtof(m - 12), 0.03, "sq", 0.5, decay=0.4)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if 1.25 <= T < 2.4: continue                                         # 경보 동안 드럼 멈춤
            if S[0] + scenes[0]["seg"][1] + 0.4 <= T < S[1]: continue             # 차단기 내려간 뒤 정적
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def clack(T): thump(T); tone(sfx, T, 0.06, 2400, 0.08, "sq", 0.5, decay=0.03); tone(sfx, T, 0.15, 0, 0.14, "noise", decay=0.03)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def zap(T):
        for j in range(4): tone(sfx, T + j * 0.06, 0.05, 2000 - j * 300, 0.04, "sq", 0.5, decay=0.03)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def tick(T, n):
        for j in range(n): tone(sfx, T + j * 0.25, 0.02, 2200 if j % 2 else 1800, 0.03, "sq", 0.5, decay=0.01)
    def engine(T, d=0.8): tone(sfx, T, d, 90, 0.08, "sq", 0.5, f1=140, decay=d)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    typing(S[0] + 0.1, "특별편시장이멈췄다"); alarm(S[0] + 1.25, 6); fall(S[0] + 2.4, 0.8); thump(S[0] + 2.45); pop(S[0] + 3.2); thump(S[0] + 3.5)
    zap(sg(0, 1) + 0.3); clack(sg(0, 1) + 0.45); tick(sg(0, 1) + 0.8, 8); pop(sg(0, 1) + 1.0)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    for j in range(4): zap(S[1] + 0.8 + j * 0.2)
    clack(S[1] + 1.6); ding(S[1] + 2.2); swoosh(sg(1, 1) + 1.0); pop(sg(1, 1) + 0.3)
    thump(S[2] + 0.75); pop(S[2] + 1.6); thump(sg(2, 1) + 0.1); thump(sg(2, 1) + 1.6); ding(sg(2, 1) + 2.4)
    tick(S[3] + 0.8, 5)
    for j in range(4): pop(S[3] + 2.0 + j * 0.2)
    coin_s(S[3] + 3.5); ding(S[3] + 3.8); pop(sg(3, 1) + 0.1); pop(sg(3, 1) + 0.4); thump(sg(3, 1) + 1.0)
    engine(S[4] + 0.75, 0.8); ding(S[4] + 1.5); clack(S[4] + 2.6); pop(S[4] + 3.6)
    for j in range(3): pop(S[5] + 0.75 + j * 0.3)
    ding(S[5] + 2.2); alarm(sg(5, 1) + 0.1, 2); pop(sg(5, 1) + 1.2)
    for i in range(3): thump(S[6] + 0.3 + i * 0.4)
    ding(S[6] + 1.5)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

"""특별편 · 반도체 찐반등 머지않았다? 지금 켜진 상승 신호 5가지 (kospi1015_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-20 오전 7시 기준):
 · 뉴스핌 10/20(10/19 뉴욕 마감: 필라델피아 반도체지수 +1.61%, 8거래일 연속 하락 마감 · 그동안 -15.7% · 2008년 10월 이후 최장)
 · 스톡허브 10/8(삼성전자 3분기 잠정 영업이익 107.4조, 전년 대비 +782.5%) · 24/7 Wall St 10/19(마이크론 9/30 실적 발표: 2027년 HBM 물량 매진)
 · vlsi.kr 10/17(트렌드포스 4분기 범용 D램 고정가 +10~15%, 낸드 +15~20% · 교보증권 HBM의 D램 생산능력 비중 27%→40%)
 · CBC뉴스 10/20(10/19 삼성전자 장중 -4.18% → 종가 +1.16%, SK하이닉스 장중 -5% → +0.39%, 기관 +5,760억)
 · 이코노미스트 10/9(SK하이닉스 3분기 영업이익 컨센서스 78조577억, 전 분기 대비 +29%, 10/28~29 발표)
 · 파이낸셜뉴스 10/18(외국인 9/16~10/16 순매도 30.6조 · 하나증권 'W자' 2차 저점 5,300선), 뉴스핌 10/20(WTI 103.66달러)
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from ackman_video import up_arrow, money_bag
from semicrash_video import alert_card, qmark, shield, hbm_stack, TEAL
from kospi1015_video import candle, price_tag, ai_core
from dip_video import claw

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "semireb/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
UPG = (90, 230, 120)

# ================================================================ drawings
def lamp(d, x, y, on, col=UPG, t=0.0):
    """신호등 램프 (켜지면 빛 테두리)"""
    if on and blink(t, 3): d.ellipse([x - 9, y - 9, x + 9, y + 9], outline=dk(col, 0.6))
    d.ellipse([x - 6, y - 6, x + 6, y + 6], fill=col if on else (40, 44, 64), outline=WHT2)
    if on: d.rectangle([x - 3, y - 4, x - 1, y - 2], fill=WHITE)

def dram_stick(d, x, y, col=GRN):
    d.rectangle([x, y, x + 64, y + 22], fill=(20, 70, 50), outline=col)
    for k in range(4): d.rectangle([x + 5 + k * 15, y + 4, x + 15 + k * 15, y + 14], fill=(24, 28, 44), outline=GRAY)
    for k in range(15): d.line([(x + 3 + k * 4, y + 22), (x + 3 + k * 4, y + 26)], fill=GOLD)
    d.rectangle([x + 30, y + 22, x + 33, y + 26], fill=BG)

def wafer(d, x, y, r, u, t):
    """웨이퍼: u만큼 HBM(금색) 칸이 차오름"""
    d.ellipse([x - r, y - r, x + r, y + r], fill=(36, 40, 64), outline=WHT2)
    n = 0
    for gy in range(-r + 4, r - 4, 6):
        for gx in range(-r + 4, r - 4, 6):
            if gx * gx + gy * gy < (r - 5) ** 2:
                n += 1
                col = GOLD if (n * 37 % 100) / 100 < u else (70, 80, 120)
                d.rectangle([x + gx, y + gy, x + gx + 4, y + gy + 4], fill=col)

def trigger(d, x, y, t, pulled=0.0):
    """반등 방아쇠 레버"""
    d.rectangle([x, y + 24, x + 40, y + 34], fill=(40, 44, 64), outline=WHT2)
    a = math.radians(lerp(-50, 40, ease(pulled)))
    ex, ey = x + 20 + int(26 * math.sin(a)), y + 24 - int(26 * math.cos(a))
    d.line([(x + 20, y + 24), (ex, ey)], fill=WHT2, width=3)
    d.ellipse([ex - 5, ey - 5, ex + 5, ey + 5], fill=SRED if pulled < 1 else UPG, outline=WHITE)

def mini_line(d, pts, col, width=2):
    if len(pts) > 1: d.line(pts, fill=col, width=width)

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 2026.10.20 아침", "반도체 찐반등?", "지금 켜진 상승 신호", UPG)
    s1 = seg[1]
    box(d, 34, 122, 216, 230, DIM)
    d.text((40, 125), "美 반도체지수 · 일봉", font=F9, fill=GRAY)
    for k in range(8):                                                    # 8일 연속 음봉
        ts = 0.3 + k * 0.17
        if t < ts: continue
        yo = 140 + k * 8; candle(d, 44 + k * 16, yo, yo + 9 + (k % 3) * 2, SRED)
    if t > 1.75:                                                          # 그리고 양봉
        vis, o = slam(t, 1.75, 0.2)
        candle(d, 44 + 8 * 16 + 6, 190 + o, 168 + o, UPG)
        up_arrow(d, 192, 150 + o, UPG, 18)
        target_lock(d, 182, 178, t, 2.0, "+1.61%", UPG, "10/19")
    if t > 0.9: glitch_text(img, CX, 236, "머지않았다!", F24, UPG, t, 6 if t < 1.6 else 1)
    if t > s1:                                                            # 신호등 5개가 켜짐
        box(d, 34, 270, 216, 310, DIM)
        for k in range(5):
            on = t > s1 + 0.3 + k * 0.28
            lamp(d, 56 + k * 35, 284, on, UPG, t + k * 0.2)
        d.text((CX, 297), "상승 신호 5가지", font=F9, fill=UPG if t > s1 + 1.7 else GRAY, anchor="ma")
    fx = {}
    if 1.75 < t < 1.9: fx["flash"] = 0.25
    if 0.9 < t < 1.2: fx["shake"] = (int(math.sin(t * 80) * 2), 0)
    return fx

def s_oversold(img, d, t, seg, dur):
    header(d, t, "01 · 과매도 탈출", "너무 빠졌다", "필라델피아 반도체지수", SRED)
    s1 = seg[1]
    box(d, 34, 122, 216, 236, DIM)
    vals = [100, 97, 96.3, 93, 92.1, 89.6, 88.1, 86.4, 84.3]               # 8일 동안 -15.7% (모양)
    k_n = int(clamp(prog(t, 0.6, 2.6)) * 8)
    pts = [(46 + i * 18, int(140 + (100 - v) * 5.2)) for i, v in enumerate(vals[:k_n + 1])]
    mini_line(d, pts, SRED)
    for i, p in enumerate(pts[1:]): d.text((p[0], 222), str(i + 1), font=F9, fill=GRAY, anchor="ma")
    u = ease(prog(t, 0.6, 2.6))
    d.text((210, 128), f"-{15.7 * u:.1f}%", font=F12, fill=SRED, anchor="ra")
    if t > 2.7:
        vis, o = slam(t, 2.7, 0.2)
        d.rectangle([34, 242 + o, 216, 262 + o], fill=(40, 10, 16), outline=SRED)
        d.text((CX, 246 + o), "8거래일 연속 하락 · 2008년 이후 최장", font=F9, fill=WHITE, anchor="ma")
    if t > s1:
        q = ease(prog(t, s1 + 0.2, s1 + 0.8))
        ex, ey = 46 + 9 * 18 - 4, int(lerp(140 + 15.7 * 5.2, 140 + (100 - 86) * 5.2, q))
        d.line([pts[-1], (ex, ey)], fill=UPG, width=3) if pts else None
        if q >= 1: target_lock(d, ex, ey, t, s1 + 0.8, "+1.61%", UPG, "10.19")
        if t > s1 + 1.8:
            stamp_slam(img, CX, 290, "연속 하락 끝", UPG, t, s1 + 1.8, "24", -8)
            debris(d, CX, 290, t, s1 + 1.8, 14, (UPG, WHITE, YEL), 50, 0.8, 4)
    chapter_flash(img, d, t, "01", "과매도 탈출", SRED)
    return {"flash": 0.25} if s1 + 1.8 < t < s1 + 1.92 else {}

def s_earn(img, d, t, seg, dur):
    header(d, t, "02 · 실적", "숫자는 역대급", "삼성전자 3분기 잠정 (10/8)", GOLD)
    s1 = seg[1]
    if t < s1 + 0.2:
        base = 252
        cols = [("작년 3Q", 12.2, GRAY, 0.8), ("올해 3Q", 107.4, GOLD, 1.3)]
        for i, (nm, v, col, ts) in enumerate(cols):
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.9)); h = int(v * 1.0 * u); x = 70 + i * 70
            d.rectangle([x, base - h, x + 40, base], fill=col)
            d.text((x + 20, base + 3), nm, font=F9, fill=col, anchor="ma")
            d.text((x + 20, base - h - 13), f"{v * u:.1f}조", font=F12 if i else F9, fill=WHITE, anchor="ma")
        d.line([(56, base + 1), (200, base + 1)], fill=GRAY)
        d.text((40, 124), "영업이익", font=F9, fill=GRAY)
        if t > 2.4:
            vis, o = slam(t, 2.4, 0.2)
            d.rectangle([150, 128 + o, 216, 148 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((183, 132 + o), "약 9배", font=F12, fill=GOLD, anchor="ma")
            confetti(d, t, 2.4, 16, (GOLD, YEL, WHITE, UPG), 130, 250)
        d.text((CX, 284), "매출 195조 · 영업이익률 55%", font=F9, fill=GRAY, anchor="ma")
    else:
        hbm_stack(d, 50, 150, GOLD, 6); hbm_stack(d, 100, 158, GOLD, 5)
        d.text((95, 212), "HBM", font=F12, fill=GOLD, anchor="ma")
        if t > s1 + 0.9:
            stamp_slam(img, 176, 172, "완판", SRED, t, s1 + 0.9, "24", -14)
        if t > s1 + 1.5:
            vis, o = slam(t, s1 + 1.5, 0.2)
            d.rectangle([34, 232 + o, 216, 280 + o], fill=(10, 14, 30), outline=GOLD)
            d.text((CX, 238 + o), "마이크론 (9/30 실적 발표)", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 252 + o), "2027년 HBM 물량 매진", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 268 + o), "가격도 올해보다 훨씬 높게", font=F9, fill=GOLD, anchor="ma")
    chapter_flash(img, d, t, "02", "실적", GOLD)
    return {"flash": 0.2} if s1 + 0.9 < t < s1 + 1.0 else {}

def s_price(img, d, t, seg, dur):
    header(d, t, "03 · 메모리 가격", "값이 오른다", "트렌드포스 4분기 고정가격 전망", CYAN)
    s1 = seg[1]
    if t < s1:
        rows = [(0.8, "D램", 10, 15, GRN), (1.5, "낸드", 15, 20, CYAN)]
        for i, (ts, nm, lo, hi, col) in enumerate(rows):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 130 + i * 62 + o
            if i == 0: dram_stick(d, 40, y + 4, col)
            else:
                d.rectangle([40, y + 4, 104, y + 26], fill=(20, 50, 70), outline=col)
                d.rectangle([46, y + 9, 70, y + 21], fill=(24, 28, 44), outline=GRAY); d.text((88, y + 9), "SSD", font=F9, fill=WHITE, anchor="ma")
            d.text((72, y + 32), nm, font=F12, fill=col, anchor="ma")
            u = ease(prog(t, ts + 0.2, ts + 1.0))
            d.text((210, y + 6), f"+{lo}~{int(lerp(lo, hi, u))}%", font=F12, fill=UPG, anchor="ra")
            up_arrow(d, 124, y + 6, UPG, 18 + int(6 * u))
            price_tag(d, 116, y + 30, "4분기 계약가", col)
    else:
        u = ease(prog(t, s1 + 0.1, s1 + 1.6))
        wafer(d, 78, 182, 40, lerp(0.27, 0.40, u), t)
        d.text((78, 228), "D램 생산능력", font=F9, fill=GRAY, anchor="ma")
        d.text((170, 140), "HBM 비중", font=F9, fill=GOLD, anchor="ma")
        d.text((170, 154), f"{int(lerp(27, 40, u))}%", font=F24, fill=GOLD, anchor="ma")
        d.text((170, 184), "2025 → 2027", font=F9, fill=GRAY, anchor="ma")
        if t > s1 + 1.7:
            vis, o = slam(t, s1 + 1.7, 0.2)
            d.rectangle([34, 244 + o, 216, 286 + o], fill=(10, 20, 30), outline=CYAN)
            d.text((CX, 250 + o), "HBM이 라인을 가져가니", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 268 + o), "일반 D램이 모자란다", font=F9, fill=CYAN, anchor="ma")
        d.text((CX, 300), "교보증권 추정", font=F9, fill=DIM, anchor="ma")
    chapter_flash(img, d, t, "03", "메모리 가격", CYAN)
    return {}

def s_dip(img, d, t, seg, dur):
    header(d, t, "04 · 수급", "떨어지면 산다", "10월 19일 · 유가증권시장", BLUE)
    s1 = seg[1]
    if t < s1:
        box(d, 34, 122, 216, 246, DIM)
        zero = 160; sc = 7.5
        d.line([(40, zero), (210, zero)], fill=GRAY); d.text((212, zero - 12), "0%", font=F9, fill=GRAY, anchor="ra")
        paths = [("삼성전자", [0, -3.9, -4.18, -3.0, -1.5, 0.2, 0.8, 1.16], BLUE), ("SK하이닉스", [0, -4.2, -5.0, -3.8, -2.0, -0.6, 0.1, 0.39], SRED)]
        k = clamp(prog(t, 0.6, 2.6))
        for j, (nm, vs, col) in enumerate(paths):
            n = int(k * (len(vs) - 1)) + 1
            pts = [(46 + i * 22, int(zero - v * sc)) for i, v in enumerate(vs[:n])]
            mini_line(d, pts, col)
            if k >= 1:
                d.text((40, 128 + j * 12), nm, font=F9, fill=col)
                d.text((210, 128 + j * 12), f"{vs[-1]:+.2f}%", font=F9, fill=UPG, anchor="ra")
        if 0.9 < t < 2.2: claw(d, 92, int(lerp(130, 176, ease(prog(t, 0.9, 1.4)))), t, prog(t, 1.4, 1.6))
        if t > 2.7:
            vis, o = slam(t, 2.7, 0.2)
            d.rectangle([34, 254 + o, 216, 276 + o], fill=(10, 14, 30), outline=BLUE)
            d.text((CX, 259 + o), "장중 -4~5% → 둘 다 플러스 마감", font=F9, fill=WHITE, anchor="ma")
    else:
        rows = [("기관", 5760, UPG), ("외국인", -364, SRED), ("개인", -10876, SRED)]
        d.text((CX, 124), "투자자별 순매수 (억 원)", font=F9, fill=GRAY, anchor="ma")
        mid = 130
        d.line([(mid, 140), (mid, 240)], fill=GRAY)
        for i, (nm, v, col) in enumerate(rows):
            ts = s1 + 0.2 + i * 0.35
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.5)); w = int(min(80, abs(v) / 140) * u); y = 148 + i * 30
            d.text((40, y + 2), nm, font=F9, fill=WHITE)
            if v > 0: d.rectangle([mid, y, mid + w, y + 14], fill=col)
            else: d.rectangle([mid - w, y, mid, y + 14], fill=col)
            d.text((214 if v > 0 else mid - w - 2, y + 2) if v > 0 else (mid + 4, y + 2), f"{v:+,}", font=F9, fill=col, anchor="ra" if v > 0 else "la")
        if t > s1 + 1.4:
            coin(d, 196, 252, 8, "$"); coin(d, 180, 262, 8, "$")
            vis, o = slam(t, s1 + 1.4, 0.2)
            d.rectangle([34, 246 + o, 160, 278 + o], fill=(10, 20, 14), outline=UPG)
            d.text((97, 252 + o), "기관 저가 매수", font=F12, fill=UPG, anchor="ma")
        d.text((CX, 296), "삼성전자 외국인 순매수 1위", font=F9, fill=GRAY, anchor="ma") if t > s1 + 2.0 else None
    chapter_flash(img, d, t, "04", "수급", BLUE)
    return {}

def s_next(img, d, t, seg, dur):
    header(d, t, "05 · 다음 이벤트", "실적 D-8", "SK하이닉스 3분기 실적", PURP)
    s1 = seg[1]
    if t > 0.75:
        vis, o = slam(t, 0.75, 0.2)
        calendar(d, 44, 130 + o, "10.28", "실적", PURP)
        chip(d, 100, 132 + o, 34, PURP, t, 2)
    if t > 1.2:
        u = ease(prog(t, 1.2, 2.6))
        d.text((CX + 40, 132), "예상 영업이익", font=F9, fill=GRAY, anchor="ma")
        d.text((CX + 40, 146), f"{78 * u:.0f}조", font=F24, fill=WHITE if u < 1 else GOLD, anchor="ma")
    if t > 2.7:
        vis, o = slam(t, 2.7, 0.2)
        d.text((CX, 184 + o), "전 분기보다 +29% (컨센서스)", font=F9, fill=UPG, anchor="ma")
    if t > s1:
        trigger(d, 52, 216, t, prog(t, s1 + 0.6, s1 + 1.2))
        if t > s1 + 1.2:
            vis, o = slam(t, s1 + 1.2, 0.2)
            d.rectangle([104, 214 + o, 216, 256 + o], fill=(24, 12, 34), outline=PURP)
            d.text((160, 220 + o), "숫자가 확인되면", font=F9, fill=WHITE, anchor="ma")
            d.text((160, 236 + o), "반등 방아쇠", font=F12, fill=GOLD, anchor="ma")
            debris(d, 72, 216, t, s1 + 1.2, 12, (UPG, YEL, WHITE), 40, 0.7, 5)
        d.text((CX, 290), "발표일 10/28~29 예정 · 예상치는 바뀔 수 있음", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "05", "다음 이벤트", PURP)
    return {}

def s_risk(img, d, t, seg, dur):
    header(d, t, "CHECK · 아직 조심", "바닥 확정 X", "반등을 막는 변수들", ORG)
    s1 = seg[1]
    alert_card(img, d, t, 0.35, 0.95, CX, 180, "잠깐!", "RISK")
    items = [(1.0, "AI 투자, 돈이 될까?", "수익성 의구심 여전", ORG),
             (1.6, "유가 100달러 위 · 금리 5%대", "WTI 103.66달러 (10/19)", SRED),
             (s1 + 0.1, "외국인 한 달 30.6조 순매도", "9/16~10/16 · 하이닉스 16조", BLUE),
             (s1 + 0.9, "코스피 5,300 재하락 시나리오", "하나증권 'W자' 2차 바닥", PURP)]
    for i, (ts, a, b, col) in enumerate(items):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 124 + i * 46 + o
        d.rectangle([34, y, 216, y + 40], fill=(24, 12, 10), outline=col)
        warn_icon(d, 40, y + 12, col)
        d.text((62, y + 5), a, font=F12 if d.textlength(a, font=F12) < 150 else F9, fill=WHITE); d.text((62, y + 23), b, font=F9, fill=col)
    chapter_flash(img, d, t, "06", "체크", ORG)
    return {"shake": (int(math.sin(t * 80) * 2), 0)} if 0.35 < t < 0.6 else {}

def s_outro(img, d, t, seg, dur):
    marquee(d, 246, 2, 26, t, "과매도 탈출 · 역대급 실적 · 메모리값 상승 · 저가 매수 · 28일 실적", (dk(UPG, 0.5), dk(GOLD, 0.5)))
    header(d, t, "SUMMARY · 10.20 기준", "신호는 켜졌다", "확인은 숫자로", UPG)
    rows = [("과매도 탈출", "SOX 8일 하락 끝"), ("역대급 실적", "영업익 107조"), ("메모리값 ↑", "D램 +10~15%"), ("저가 매수", "기관 +5,760억"), ("다음 실적", "10/28 하이닉스")]
    for i, (a, b) in enumerate(rows):
        ts = 0.3 + i * 0.3
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 124 + i * 23
        d.rectangle([34, y + o, 216, y + 19 + o], fill=(10, 14, 30), outline=dk(UPG, 0.7))
        lamp(d, 46, y + 9 + o, True, UPG, t + i * 0.3)
        d.text((58, y + 3 + o), a, font=F12, fill=WHITE); d.text((212, y + 5 + o), b, font=F9, fill=UPG, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1], 0.2)
        d.rectangle([34, 244 + o, 216, 270 + o], fill=(40, 22, 6), outline=ORG if blink(t, 3) else YEL)
        warn_icon(d, 40, 251 + o, YEL)
        d.text((62, 250 + o), "하락이 더 이어질 수도", font=F12, fill=WHITE)
    d.text((32, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("반도체 찐반등, 머지않았다?\n상승 신호가 하나둘 켜지고 있어요", "반도체 찐반등, 머지않았다? 상승 신호가 하나둘 켜지고 있어요."),
              ("지금 켜진 신호 5가지,\n바로 짚어 볼게요", "지금 켜진 신호 다섯 가지, 바로 짚어 볼게요.")]),
    (s_oversold, [("미국 반도체지수 8거래일 연속 하락,\n그동안 -15.7%", "첫째, 너무 빠졌다. 미국 필라델피아 반도체지수가 팔 거래일 연속 떨어지며, 십오 점 칠 퍼센트 빠졌어요."),
                  ("2008년 이후 가장 긴 하락,\n10월 19일 +1.61%로 끊었어요", "이천팔 년 이후 가장 긴 하락이었는데, 시월 십구 일 일 점 육일 퍼센트 오르며 드디어 끊었어요.")]),
    (s_earn, [("삼성전자 3분기 영업이익 107.4조 원,\n작년보다 9배 가까이", "둘째, 실적은 역대급. 삼성전자 삼분기 영업이익은 백칠 점 사 조 원, 작년보다 아홉 배 가까이 늘었어요."),
              ("마이크론은 내년 HBM 물량이\n이미 다 팔렸다고 밝혔고요", "마이크론은 내년 에이치비엠 물량이, 이미 다 팔렸다고 밝혔고요.")]),
    (s_price, [("4분기 D램 값 +10~15%,\n낸드는 +15~20% 오를 전망", "셋째, 메모리 값이 오른다. 트렌드포스는 사분기 디램 고정가격이 십에서 십오 퍼센트, 낸드는 십오에서 이십 퍼센트 오를 걸로 봤어요."),
               ("HBM이 생산 라인을 가져가면서\n일반 D램이 모자라서예요", "에이치비엠이 생산 라인을 가져가면서, 일반 디램이 모자라서예요.")]),
    (s_dip, [("19일 삼성전자 -4%, 하이닉스 -5%까지\n밀렸다가 둘 다 플러스 마감", "넷째, 떨어지면 산다. 십구 일 삼성전자는 사 퍼센트, 에스케이하이닉스는 오 퍼센트까지 밀렸다가, 둘 다 오름세로 마감했어요."),
             ("너무 빠졌다는 인식에 저가 매수,\n기관은 5,760억 원 순매수", "너무 빠졌다는 인식에 저가 매수가 몰렸고, 기관은 오천칠백육십억 원어치를 사들였어요.")]),
    (s_next, [("SK하이닉스 3분기 실적 10월 28일쯤,\n예상 영업이익 78조 원", "다섯째, 다음 주 빅 이벤트. 에스케이하이닉스 삼분기 실적이 시월 이십팔 일쯤 나오는데, 예상 영업이익은 칠십팔 조 원이에요."),
              ("전 분기보다 29% 많은 숫자,\n실제로 찍히면 반등의 방아쇠", "전 분기보다 이십구 퍼센트 많은 숫자. 실제로 찍히면, 반등의 방아쇠가 될 수 있어요.")]),
    (s_risk, [("하지만 바닥이라고 단정하긴 일러요\nAI 투자 의구심, 유가는 100달러 위", "하지만 바닥이라고 단정하긴 일러요. 에이아이 투자 의구심이 여전하고, 유가는 백 달러를 넘었어요."),
              ("외국인은 한 달간 30조 원 넘게 팔았고\n코스피 5,300 재하락 시나리오도 있어요", "외국인은 한 달 동안 삼십조 원 넘게 팔았고, 코스피가 오천삼백 선까지 한 번 더 빠지는 시나리오도 나왔어요.")]),
    (s_outro, [("신호는 켜졌지만\n확인은 숫자로!", "정리하면, 신호는 켜졌지만 확인은 숫자로!"),
               ("하락이 더 이어질 수도 있으니\n무리한 베팅은 금물이에요", "하락이 더 이어질 수도 있으니, 무리한 베팅은 금물이에요.")]),
]
TITLES = ["", "너무 빠졌다", "숫자는 역대급", "값이 오른다", "떨어지면 산다", "실적 D-8", "바닥 확정 X", "신호는 켜졌다"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # A minor hush (hook) → C major lift on the signals → A minor again on the risk check → C major outro
    bpm = 122; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([69, 72, 76], 45), ([65, 69, 72], 41), ([67, 71, 74], 43), ([64, 68, 71], 40)]   # Am F G E
    prog_major = [([72, 76, 79], 48), ([67, 71, 74], 43), ([69, 72, 76], 45), ([65, 69, 72], 41)]   # C G Am F
    mel_m = [[81, None, 79, 76, 77, None, 76, None], [77, 79, 81, None, 84, None, 81, 79], [79, None, 74, None, 83, None, 81, 79], [80, None, 76, None, 71, None, None, None]]
    mel_M = [[84, None, 83, 84, 88, None, 86, 84], [83, None, 79, None, 83, 84, 86, None], [88, None, 84, 81, 79, None, 81, None], [81, 83, 84, None, 81, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        minor = t0 < S[1] or S[6] <= t0 < S[7]
        notes, root = (prog_minor if minor else prog_major)[b % 4]
        mel = (mel_m if minor else mel_M)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and T > 1.75: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total or T < 1.75: continue                                   # 훅: 음봉 동안 드럼 없음 → 양봉에서 시작
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def powerup(T):
        for j, m in enumerate([60, 64, 67, 72, 76, 79]): tone(sfx, T + j * 0.06, 0.07, mtof(m), 0.06, "sq", 0.5, decay=0.05)
    def lampon(T, k): tone(sfx, T, 0.12, mtof(72 + k * 2), 0.06, "sq", 0.25, decay=0.1)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # hook: 8 red candles (low thumps) → the green candle
    typing(S[0] + 0.1, "특별편반도체찐반등")
    for k in range(8): tone(sfx, S[0] + 0.3 + k * 0.17, 0.08, 220 - k * 12, 0.05, "sq", 0.5, decay=0.06)
    glitch(S[0] + 0.9, 6); powerup(S[0] + 1.75); thump(S[0] + 1.75); lock(S[0] + 2.0)
    for k in range(5): lampon(sg(0, 1) + 0.3 + k * 0.28, k)
    ding(sg(0, 1) + 1.7)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # 01 oversold: falling line, then the bounce + stamp
    fall(S[1] + 0.6, 2.0)
    for k in range(8): blip(S[1] + 0.6 + k * 0.25, 900 - k * 60, 0.04)
    pop(S[1] + 2.7); rise(sg(1, 1) + 0.2, 0.6); lock(sg(1, 1) + 0.8); stampfx(sg(1, 1) + 1.8); fanfare(sg(1, 1) + 1.9)
    # 02 earnings
    rise(S[2] + 0.8, 0.9); rise(S[2] + 1.3, 1.0); coin_s(S[2] + 2.3); fanfare(S[2] + 2.4)
    pop(sg(2, 1) + 0.3); stampfx(sg(2, 1) + 0.9); pop(sg(2, 1) + 1.5)
    # 03 prices
    pop(S[3] + 0.8); rise(S[3] + 1.0, 0.8); pop(S[3] + 1.5); rise(S[3] + 1.7, 0.8)
    rise(sg(3, 1) + 0.1, 1.5); pop(sg(3, 1) + 1.7)
    # 04 dip buying: the claw grabs, the lines climb back
    fall(S[4] + 0.6, 0.5); tone(sfx, S[4] + 1.4, 0.1, 400, 0.06, "sq", 0.5, decay=0.06); rise(S[4] + 1.5, 1.1); ding(S[4] + 2.7)
    for i in range(3): pop(sg(4, 1) + 0.2 + i * 0.35)
    coin_s(sg(4, 1) + 1.4); coin_s(sg(4, 1) + 1.55)
    # 05 next earnings
    pop(S[5] + 0.75); rise(S[5] + 1.2, 1.4); ding(S[5] + 2.6); pop(S[5] + 2.7)
    tone(sfx, sg(5, 1) + 0.6, 0.5, 200, 0.05, "sq", 0.5, f1=500, decay=0.4); thump(sg(5, 1) + 1.2); fanfare(sg(5, 1) + 1.25)
    # risk check
    alarm(S[6] + 0.35, 3)
    for ts in (1.0, 1.6): thump(S[6] + ts)
    thump(sg(6, 1) + 0.1); thump(sg(6, 1) + 0.9)
    # outro
    for i in range(5): lampon(S[7] + 0.3 + i * 0.3, i)
    alarm(sg(7, 1), 2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

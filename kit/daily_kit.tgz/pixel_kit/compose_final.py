"""8비트 픽셀 프레임 + 마스코트 원형 인서트 + 말풍선 자막 + 오디오 → 최종 mp4
python3 compose_final.py <px_dir> <mascot_dir> <bubbles.json> <mix.wav> <out.mp4> [n_frames]
(마스코트 프레임이 아직 다 안 나왔으면 마지막 프레임을 유지 — 미리보기용)"""
import sys, os, glob, json, subprocess
import numpy as np, cv2
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mascot_pip as P, bubble_fx as B
FPS = 30
pxdir, mdir, bj, wav, out = sys.argv[1:6]
frames = sorted(glob.glob(os.path.join(pxdir, '*.png'))); ms = sorted(glob.glob(os.path.join(mdir, '*.png')))
J = json.load(open(bj)); total = J['total']
n = int(sys.argv[6]) if len(sys.argv) > 6 else len(frames)
track = B.BubbleTrack(J['bubbles'])
p = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', '1080x1920', '-r', str(FPS), '-i', '-',
                      '-i', wav, '-t', f'{n / FPS:.3f}', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p',
                      '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-shortest',
                      '-movflags', '+faststart', out], stdin=subprocess.PIPE)
for i in range(n):
    t = i / FPS
    fr = cv2.imread(frames[min(i, len(frames) - 1)]).astype(np.float32)
    fade = min(1.0, max(0.0, (total - t) / 0.8)) if t > total - 0.8 else 1.0
    m = cv2.imread(ms[min(i, len(ms) - 1)], cv2.IMREAD_UNCHANGED)
    if fade > 0.01:
        fr2 = fr.copy(); P.compose(fr2, m); track.draw(fr2, t)
        fr = fr * (1 - fade) + fr2 * fade
    p.stdin.write(np.clip(fr, 0, 255).astype(np.uint8).tobytes())
    if i % 300 == 0: print(i, '/', n, flush=True)
p.stdin.close(); p.wait(); print('done', out)

"""샌디스크 올인 채널 진행자 목소리 (2026-10-30 사용자 확정: 후보 6번)
Supertonic 3 sid 0, speed 1.10 → WORLD 보코더로 피치 +2반음 · 포먼트 ×1.06 (더 젊은 여성 톤)
사용: from sandy_voice import voice_line; x, sr = voice_line(tts, "문장")  (tts = tts_synth.make_tts())
순번 쉼(narr_pause.synth_line)도 그대로 적용된다."""
import numpy as np
import pyworld as pw
from tts_synth import make_tts, synth
from narr_pause import synth_line

VOICE_SID, SPEED, SEMI, FORMANT = 0, 1.10, 2.0, 1.06

def youthen(x, sr, semi=SEMI, form=FORMANT):
    x = x.astype(np.float64)
    f, t = pw.harvest(x, sr, f0_floor=80, f0_ceil=700)
    sp = pw.cheaptrick(x, f, t, sr); ap = pw.d4c(x, f, t, sr)
    f = f * 2 ** (semi / 12)
    n = sp.shape[1]; idx = np.clip(np.arange(n) / form, 0, n - 1); base = np.arange(n)
    sp2 = np.array([np.interp(idx, base, r) for r in sp]); ap2 = np.array([np.interp(idx, base, r) for r in ap])
    y = pw.synthesize(f, sp2, ap2, sr)
    return (y / (np.abs(y).max() + 1e-9) * 0.9).astype(np.float32)

def voice_line(tts, text):
    x, sr = synth_line(tts, text, VOICE_SID, SPEED, synth)
    return youthen(x, sr), sr

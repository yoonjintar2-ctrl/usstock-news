"""특별편 15 · 클로드가 반도체 붐 신호탄? 앤트로픽 매출 체감 (60초 이내 · 첫 프레임 후킹 · 희망적 · 잔잔한 BGM 하나 · 카드 한 색)
사실 확인(2026-10-27 기준):
 · 10/26(미국) SEC에 S-1 제출, 나스닥 글로벌 셀렉트 'ANT', 골드만·모건스탠리, 11월 상장 가능 · 공모 자금은 운영·기술개발·컴퓨팅 인프라·채용 (중앙이코노미뉴스·뉴스1 10/26)
 · 상반기 매출 163억$ (작년 상반기 12억$의 13배+) · 상반기 순손실 807억$(모델 개발·인프라 지출, 회계상 손익 변동) (중앙이코노미뉴스)
 · 분기 매출 1Q 47억$(로이터) → 2Q 116억$(로이터) → 3Q 168억$(블룸버그, +45% QoQ) · 3Q 조정 영업이익률 11%+ (ZDNet 10/15)
 · 컴퓨팅 1$당 매출 1.70$ (FT, ZDNet 10/15 인용)
 · 아마존: 10년간 1,000억$+ AWS 약정, 최대 5GW, 트레이니엄2 100만 개+ 사용 중 (anthropic.com 4/20)
 · 구글·브로드컴: 차세대 TPU 수 GW, 2027년부터 (anthropic.com 4/6)
 · 환율 1,325원/달러: 168억$ ≈ 22.3조 원 · 하루 ≈ 1.83억$ ≈ 2,420억 원 · 1초 ≈ 2,113$ ≈ 280만 원 · 1,000억$ ≈ 132.5조 원
 · 회사는 로봇 캐릭터로 의인화(로고·실존 인물 그림 없음)
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image

from sandisk_video import header, box, slam, CX, PURP, WHT2, chip
from make_video import (FW, FH, FPS, F24, F12, F9, WHITE, YEL, CYAN, ORG, GRAY, DIM, lerp, prog, ease, tone, mtof, SR)
import mid_video as mv
from nike_video import stamp_slam, render_frame, dk, DARK
from option_video import big_text, coin, GOLD
from survive_video import ant, speech
from squeeze_video import CH, with_card
from citadel_video import punch_fx, money_bag
from semicrash_video import hbm_stack
from aibubble_video import datacenter

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "claude/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
GAP, TAIL = 0.22, 0.35
CARD = YEL
BOT = (214, 160, 120); BOTD = (150, 100, 76); PAPER = (230, 228, 214)

# ================================================================ drawings
def robot(d, x, y, t, mood="happy", lbl="앤트로픽", wave_=False):
    """회사 의인화 로봇 약 44x58 (로고 아님)"""
    b = int(abs(math.sin(t * 4)) * 2); y -= b
    d.line([(x + 22, y), (x + 22, y - 7)], fill=GRAY); d.ellipse([x + 19, y - 11, x + 25, y - 5], fill=YEL if int(t * 3) % 2 else ORG)
    d.rounded_rectangle([x + 4, y, x + 40, y + 26], radius=6, fill=BOT, outline=BOTD)
    d.rectangle([x + 9, y + 6, x + 35, y + 19], fill=(30, 30, 44))
    if mood == "happy":
        for ex in (x + 14, x + 26): d.arc([ex, y + 8, ex + 6, y + 14], 200, 340, fill=CYAN, width=2)
    else:
        for ex in (x + 15, x + 27): d.rectangle([ex, y + 9, ex + 3, y + 13], fill=CYAN)
    d.rounded_rectangle([x + 8, y + 28, x + 36, y + 52], radius=4, fill=BOT, outline=BOTD)
    d.text((x + 22, y + 34), lbl[:2], font=F9, fill=DARK, anchor="ma")
    ay = int(math.sin(t * 8) * 4) if wave_ else 0
    d.line([(x + 8, y + 32), (x - 2, y + 24 - ay)], fill=BOTD, width=3); d.line([(x + 36, y + 32), (x + 44, y + 40)], fill=BOTD, width=3)
    for lx in (x + 14, x + 26): d.rectangle([lx, y + 52, lx + 4, y + 58], fill=BOTD)

def flare(d, x, ybase, t, t0, col=YEL):
    """신호탄: 작은 로켓이 올라가며 연기 → 꼭대기에서 점 불꽃(방사선 없음)"""
    u = prog(t, t0, t0 + 1.0); y = int(ybase - 90 * ease(u))
    for k in range(6):
        sy = ybase - int((90 * ease(u)) * k / 6)
        if sy > y: d.ellipse([x - 2 - k % 2, sy, x + 2 + k % 2, sy + 4], fill=(120, 124, 140))
    if u < 1:
        d.polygon([(x, y - 8), (x - 4, y + 2), (x + 4, y + 2)], fill=WHITE); d.rectangle([x - 3, y + 2, x + 3, y + 10], fill=col)
        d.polygon([(x - 2, y + 10), (x + 2, y + 10), (x, y + 15 + int(t * 30) % 4)], fill=ORG)
    else:
        v = t - t0 - 1.0
        for k in range(14):
            a = k * 2.399; r = 6 + v * 26 * (0.6 + 0.4 * ((k * 7) % 5) / 4)
            if v < 1.6: d.rectangle([x + int(math.cos(a) * r) - 1, y + int(math.sin(a) * r) + int(v * v * 8) - 1, x + int(math.cos(a) * r) + 1, y + int(math.sin(a) * r) + int(v * v * 8) + 1], fill=[YEL, CYAN, WHITE, ORG][k % 4])

def vbar(d, x, ybot, w, h, col, u=1.0):
    hh = int(h * ease(u))
    if hh <= 0: return
    d.rectangle([x, ybot - hh, x + w, ybot], fill=dk(col, 0.55), outline=col)
    d.rectangle([x + 2, ybot - hh + 2, x + 4, ybot - 2], fill=dk(col, 1.25) if False else col)

def arrow_d(d, x, y0, y1, col=WHT2):
    d.line([(x, y0), (x, y1)], fill=col, width=2); d.polygon([(x - 4, y1 - 4), (x + 4, y1 - 4), (x, y1 + 2)], fill=col)

def flow_box(d, t, t0, y, s, col, w=150):
    vis, o = slam(t, t0, 0.18)
    if not vis: return False
    box(d, CX - w // 2, y + o, CX + w // 2, y + 20 + o, col, (10, 14, 28)); d.text((CX, y + 4 + o), s, font=F12, fill=col, anchor="ma")
    return True

def won(v):
    s = f"{int(v):,}"
    return s

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    d.text((CX, 62), "10/26 나스닥 상장 신청 · 티커 ANT", font=F9, fill=GRAY, anchor="ma")     # 첫 프레임부터 완성(타자 효과 없음)
    d.text((CX, 76), "클로드 만든 앤트로픽", font=F12, fill=WHITE, anchor="ma")
    d.text((CX, 94), "반도체 붐", font=F24, fill=CYAN, anchor="ma")
    big_text(img, CX, 122, "신호탄?", YEL, 3, F12)
    robot(d, 36, 210, t, "happy", wave_=True)
    chip(d, 150, 230, 40, CYAN, t)
    flare(d, 170, 226, t, 0.3)
    d.text((CX, 294), "1분기 47억$ → 3분기 168억$", font=F9, fill=WHITE, anchor="ma")
    return {}

def s_rev(img, d, t, seg, dur):
    header(d, t, "얼마나 버나", "분기마다 껑충", "", YEL)
    s1 = seg[1]
    data = [("1분기", 47, 0.3), ("2분기", 116, 0.9), ("3분기", 168, 1.6)]
    for k, (lbl, v, t0) in enumerate(data):
        x = 46 + k * 60; u = prog(t, t0, t0 + 0.7)
        vbar(d, x, 262, 40, int(v / 168 * 118), [GRAY, CYAN, YEL][k], u)
        d.text((x + 20, 266), lbl, font=F9, fill=WHITE, anchor="ma")
        if u >= 1: d.text((x + 20, 262 - int(v / 168 * 118) - 13), f"{v}억$", font=F9, fill=WHITE, anchor="ma")
    if t > 2.4: d.text((CX, 282), "3분기 = 약 22조 원", font=F12, fill=YEL, anchor="ma")
    if t > s1: stamp_slam(img, 186, 140, "13배", YEL, t, s1 + 0.1, "24", -10)
    if t > s1 + 0.6: d.text((CX, 300), "상반기: 작년 12억$ → 올해 163억$", font=F9, fill=GRAY, anchor="ma")
    return punch_fx(t, s1 + 0.1) if t > s1 else {}

def s_feel(img, d, t, seg, dur):
    header(d, t, "체감해 보면", "하루 약 2,400억 원", "", CYAN)
    money_bag(d, 40, 150, "₩" if False else "W", GOLD)
    for k in range(8):
        cy = 120 + int(((t * 70) + k * 23) % 60)
        coin(d, 58 + (k % 3) * 10 - 10, cy, 5, "")
    ant(d, 186, 152, t, "dazed")
    d.text((150, 136), "와...", font=F9, fill=WHITE)
    u = max(0.0, t - 0.4)
    box(d, 30, 200, 220, 270, YEL, (10, 14, 28))
    d.text((CX, 205), "1초에 약 280만 원", font=F12, fill=YEL, anchor="ma")
    d.text((CX, 225), "이 영상 보는 동안", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 240), f"+{won(280 * u)}만 원", font=F24, fill=WHITE, anchor="ma")
    d.text((CX, 284), "(3분기 매출 ÷ 92일 기준)" if False else "3분기 매출을 하루·1초로 나눈 값", font=F9, fill=DIM, anchor="ma")
    return {}

def s_chip(img, d, t, seg, dur):
    header(d, t, "왜 반도체?", "칩을 살수록 돈이 된다", "", ORG)
    s1 = seg[1]
    if t < s1:
        chip(d, 46, 140, 46, CYAN, t)
        d.text((69, 196), "컴퓨팅 1$", font=F12, fill=CYAN, anchor="ma")
        d.line([(104, 163), (136, 163)], fill=WHT2, width=2); d.polygon([(136, 158), (142, 163), (136, 168)], fill=WHT2)
        n = int(prog(t, 0.6, 1.6) * 17)
        for k in range(n): coin(d, 160 + (k % 4) * 12, 186 - (k // 4) * 10, 5, "")
        if t > 1.6: d.text((180, 196), "매출 1.7$", font=F12, fill=YEL, anchor="ma")
        if t > 2.2: d.text((CX, 222), "(FT 보도 · 3분기)", font=F9, fill=GRAY, anchor="ma")
    else:
        datacenter(d, 36, 132, t, CYAN)
        for k in range(min(12, int((t - s1) * 8))): chip(d, 124 + (k % 4) * 22, 126 + (k // 4) * 22, 14, YEL, t, k)
        vis, o = slam(t, s1 + 0.2, 0.18)
        if vis:
            box(d, 30, 200 + o, 220, 236 + o, YEL, (10, 14, 28))
            d.text((38, 204 + o), "아마존 칩 10년 1,000억$+", font=F12, fill=YEL); d.text((38, 221 + o), "약 132조 원 · 트레이니엄 100만 개+", font=F9, fill=WHITE)
        vis, o = slam(t, s1 + 2.6, 0.18)
        if vis:
            box(d, 30, 244 + o, 220, 280 + o, CYAN, (10, 14, 28))
            d.text((38, 248 + o), "구글 TPU 수 기가와트", font=F12, fill=CYAN); d.text((38, 265 + o), "2027년부터 순차 가동", font=F9, fill=WHITE)
    return {}

def s_signal(img, d, t, seg, dur):
    header(d, t, "신호탄 될까?", "돈이 흐르는 길", "", YEL)
    s1 = seg[1]
    steps = [("나스닥 상장 · ANT", WHITE, 0.2), ("공모 자금", YEL, 0.8), ("칩 · 데이터센터", CYAN, 1.4), ("HBM 메모리", GOLD, 2.4)]
    for k, (s, col, t0) in enumerate(steps):
        y = 122 + k * 34
        if flow_box(d, t, t0, y, s, col) and k < 3 and t > t0 + 0.3: arrow_d(d, CX, y + 21, y + 31)
    if t > 2.6: hbm_stack(d, 180, 222, GOLD)
    if t > s1:
        vis, o = slam(t, s1 + 0.1, 0.18)
        if vis:
            box(d, 30, 262 + o, 220, 302 + o, GRAY, (10, 14, 28))
            d.text((CX, 266 + o), "회계상 순손실은 아직 커요", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 282 + o), "그래도 돈 버는 AI = 칩 수요는 진짜", font=F9, fill=YEL, anchor="ma")
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "결론", "첫 관문은 상장 흥행", "", YEL)
    robot(d, 40, 140, t, "happy", wave_=True)
    chip(d, 160, 150, 40, CYAN, t); flare(d, 180, 146, t, 0.2)
    if t > 1.4: stamp_slam(img, CX, 232, "신호탄?", YEL, t, 1.4, "24", -8)
    if t > 2.0: speech(d, 46, 262, "앤트로픽 상장, 기대돼요?", tail_left=True)
    d.text((32, 306), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.4)

SCRIPT = [
    (s_hook, [("클로드 만든 앤트로픽, 나스닥 상장 신청\n반도체 붐 신호탄 될까?", "클로드를 만든 앤트로픽이 나스닥 상장을 신청했어요. 반도체 붐의 신호탄이 될까요?")]),
    (with_card(s_rev, "01", "얼마나 버나", CARD), [
        ("올해 1분기 47억$ → 3분기 168억$\n3분기만 약 22조 원", "올해 매출, 일분기 사십칠억 달러에서 삼분기 백육십팔억 달러. 우리 돈 약 이십이조 원이에요."),
        ("상반기 매출, 작년보다 13배", "상반기만 보면 작년보다 열세 배예요.")]),
    (with_card(s_feel, "02", "체감해 보면", CARD), [("하루 약 2,400억 원\n1초에 약 280만 원", "하루로 치면 약 이천사백억 원, 일 초에 이백팔십만 원씩 버는 셈이에요.")]),
    (with_card(s_chip, "03", "왜 반도체?", CARD), [
        ("컴퓨팅에 1$ 쓰면 매출 1.7$\n칩을 살수록 돈이 된다", "핵심은 이거예요. 컴퓨팅에 일 달러를 쓰면, 매출이 일 점 칠 달러 나온대요."),
        ("아마존 칩 10년 1,000억$+(약 132조 원)\n구글 TPU도 수 기가와트", "그래서 아마존 칩에만 십 년간 천억 달러, 약 백삼십이조 원. 구글 칩도 수 기가와트 더 들여요.")]),
    (with_card(s_signal, "04", "신호탄 될까?", CARD), [
        ("상장 자금도 칩·데이터센터로\n그 칩마다 HBM 메모리", "상장으로 모은 돈도 칩과 데이터센터에 쓴대요. 그 칩마다 들어가는 게 에이치비엠 메모리죠."),
        ("회계상 손실은 아직 크지만\n돈 버는 AI = 칩 수요는 진짜", "물론 회계상 손실은 아직 커요. 그래도 돈 버는 에이아이가 나왔다는 건, 칩 수요가 진짜라는 신호예요.")]),
    (s_end, [("여러분은 앤트로픽 상장, 기대돼요?\n댓글로 알려주세요", "여러분은 앤트로픽 상장, 기대되세요? 댓글로 알려주세요!")]),
]
NCH0, NCH = 1, 4


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    from narr_pause import synth_line
    tts = make_tts()
    for n in todo:
        x, sr = synth_line(tts, n, VOICE_SID, SPEED, synth)
        np.save(mv.clip_path(n), x)

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.05 if k == 0 else (CH + 0.25 if NCH0 <= k <= NCH else 0.2)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.15, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts); sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    bpm = 96; beat = 60 / bpm; e = beat / 2; bar = beat * 4                  # 밝고 잔잔한 장조 하나 (C-G-Am-F)
    prog_ = [([60, 64, 67], 48), ([67, 71, 74], 55), ([69, 72, 76], 57), ([65, 69, 72], 53)]
    mel = [[76, None, 79, None, 77, None, 76, None], [74, None, 71, None, 74, None, 79, None], [76, None, 72, None, 74, None, 76, None], [77, None, 76, None, 72, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            if mm[st]: tone(bgm, T, e * 1.6, mtof(mm[st]), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(1.5 * SR); fi = int(0.3 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def ding(T): tone(sfx, T, 0.09, 1568, 0.07, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.06, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=0.8): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def sparkle(T):
        for j in range(6): tone(sfx, T + j * 0.05, 0.08, 1800 + (j % 3) * 400, 0.03, "sq", 0.5, decay=0.06)
    def coinfx(T): tone(sfx, T, 0.05, 1976, 0.04, "sq", 0.5, decay=0.03); tone(sfx, T + 0.05, 0.12, 2637, 0.035, "sq", 0.5, decay=0.08)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    thump(S[0] + 0.02); rise(S[0] + 0.3, 1.0); sparkle(S[0] + 1.3)
    for k in range(NCH0, NCH + 1): bell3(S[k]); thump(S[k] + 0.12); swoosh(S[k] + CH - 0.25)
    for j, dt in enumerate((0.3, 0.9, 1.6)): rise(S[1] + CH + dt, 0.6); pop(S[1] + CH + dt + 0.7)
    stampfx(sg(1, 1) + 0.1)
    for j in range(14): coinfx(S[2] + CH + 0.2 + j * 0.3)
    for j in range(6): coinfx(S[3] + CH + 0.7 + j * 0.16)
    pop(sg(3, 1) + 0.2); pop(sg(3, 1) + 2.6)
    for j, dt in enumerate((0.2, 0.8, 1.4, 2.4)): pop(S[4] + CH + dt)
    ding(S[4] + CH + 2.6); pop(sg(4, 1) + 0.1)
    swoosh(S[5]); rise(S[5] + 0.2, 1.0); sparkle(S[5] + 1.2); stampfx(S[5] + 1.4); ding(S[5] + 2.0)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

"""특별편 13 · 이번 하락장도 시타델의 작품? 덜덜 (onlyme_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-24 기준):
 · 시타델: 1990년 켄 그리핀 설립 · 운용자산 약 770억$ (로이터 8/21) · 시타델 증권은 별도 법인(시장조성자)
 · 게임스탑 2021: 1/28 장중 483$ (SEC 보고서) · 멜빈캐피털 1월 -53% · 1/25 시타델 20억$ + 포인트72 7.5억$ 투입
   · 1/28 로빈후드 매수 제한 · SEC 2021.10.18 보고서: 시타델-로빈후드 공모 증거 없음, 제한은 청산소 증거금 요구 때문 (Fortune)
 · 2022: 웰링턴 +38.1% (한국경제 7/31), 한 해 160억$ 헤지펀드 역대 최대(LCH) · 루나 배후설 → 시타델 증권 부인
 · 2026.7 Situational Awareness(레오폴드 아셴브레너) 7월 -67%·마진콜 · 7월 말 시타델 증권 '깜짝 인상' 노트(블룸버그 7/28, 한경 7/27)
   · 7/29 협상 개시(Stocktwits) · 7/30 시타델 인수, 약 160억$ 규모(한국경제 7/31) · 그날 해당 종목 +20~27% (SpotGamma)
   · 8/21 그리핀 서한: 블록딜 약 100건, 40억$ 넘게 처분(위험의 80%↑) · 7월 웰링턴 +5.94% (로이터)
 · 7/29 FOMC 동결(9:3, 3명 인상 주장) → 9월 0.25%p 인상 3.75~4% (MUFG)
 · 10/20 그리핀 'AI는 거의 확실히 버블' (뉴욕 행사) · 10/21 NVDA +2.5% · SOXL +5.8%
 · 원화 환산: 원·달러 1,325원(10/21 종가) 기준
10/24 지시: 밝고 잔잔한 BGM 하나 · 배경색 그대로(챕터 카드 한 색) · 달러 금액엔 원화 환산 병기. 실존 인물 그림·가짜 대사 없음, 회사는 '성'으로 의인화.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from option_video import big_text, coin, F36, GOLD
from semicrash_video import news_card, qmark, TEAL
from survive_video import ant, speech, checkmark, xmark, PINK, MINT
from squeeze_video import CH, chapter_card, with_card, gme_pts
from aibubble_video import path_until
from onlyme_video import suit, hbar

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "citadel/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
CARD = YEL
STONE = (96, 100, 132)

# ================================================================ drawings
def castle(d, x, y, t, s=1.0, glow=1.0, col=STONE):
    """시타델 = '요새'. 의인화한 성(로고 아님). (x,y)=왼쪽 위, 약 74x70*s, 창문 두 개가 눈"""
    S = lambda v: int(round(v * s))
    R = lambda a, b, c, e, **k: d.rectangle([x + S(a), y + S(b), x + S(c), y + S(e)], **k)
    ol = dk(col, 0.55)
    R(10, 26, 64, 70, fill=col, outline=ol)                                   # 성벽
    for a in (0, 58): R(a, 12, a + 16, 70, fill=dk(col, 0.9), outline=ol)     # 양쪽 탑
    R(24, 4, 50, 28, fill=col, outline=ol)                                    # 중앙 탑
    for a in (0, 58):
        for k in range(3): R(a + k * 6, 6, a + k * 6 + 4, 12, fill=dk(col, 0.9), outline=ol)
    for k in range(4): R(24 + k * 7, -2, 24 + k * 7 + 4, 4, fill=col, outline=ol)
    for k in range(4): R(14 + k * 12, 20, 14 + k * 12 + 6, 26, fill=col, outline=ol)
    d.line([(x + S(37), y + S(-2)), (x + S(37), y + S(-14))], fill=WHT2)                         # 깃발
    d.polygon([(x + S(38), y + S(-14)), (x + S(48), y + S(-10)), (x + S(38), y + S(-6))], fill=PURP)
    R(30, 52, 44, 70, fill=DARK)
    d.pieslice([x + S(30), y + S(46), x + S(44), y + S(58)], 180, 360, fill=DARK)          # 성문
    for k in range(6): d.line([(x + S(31 + k * 2.4), y + S(54)), (x + S(31 + k * 2.4), y + S(70))], fill=dk(col, 0.7))
    e = glow * (0.55 + 0.45 * (0.5 + 0.5 * math.sin(t * 4)))
    ec = tuple(int(lerp(c0, c1, e)) for c0, c1 in zip(DARK, YEL))
    for a in (28, 40): R(a, 10, a + 6, 16, fill=ec)                           # 눈(창문)
    if glow > 0.5: d.line([(x + S(28), y + S(9)), (x + S(34), y + S(11))], fill=dk(col, 0.4)); d.line([(x + S(46), y + S(9)), (x + S(40), y + S(11))], fill=dk(col, 0.4))

def shiver(t, k=0, a=1.6):
    return int(math.sin(t * 55 + k * 1.7) * a)

def deul(d, x, y, t, s="덜덜덜", col=WHITE, font=F12):
    for i, ch in enumerate(s):
        d.text((x + i * (font.size + 1) + shiver(t, i, 1.2), y + shiver(t, i + 3, 1.2)), ch, font=font, fill=col)

def trembling_ants(d, t, y=236, xs=(46, 92, 138, 184), moods=("sweat", "dazed", "sweat", "dazed")):
    for k, x in enumerate(xs): ant(d, x + shiver(t, k), y, t, moods[k % len(moods)], bob=False)

def app_phone(d, x, y, t, locked=0.0):
    """증권 앱 화면(로고 없음) · 매수 버튼이 잠김"""
    d.rounded_rectangle([x, y, x + 54, y + 92], radius=7, fill=(20, 24, 40), outline=GRAY)
    d.rectangle([x + 5, y + 10, x + 49, y + 80], fill=(10, 14, 30))
    d.text((x + 27, y + 13), "로빈후드", font=F9, fill=WHITE, anchor="ma")
    d.text((x + 27, y + 27), "GME", font=F12, fill=YEL, anchor="ma")
    col = tuple(int(lerp(a, b, locked)) for a, b in zip(CYAN, (70, 70, 80)))
    d.rounded_rectangle([x + 10, y + 52, x + 44, y + 68], radius=3, fill=col)
    d.text((x + 27, y + 55), "매수", font=F9, fill=WHITE if locked < 0.5 else GRAY, anchor="ma")
    if locked >= 0.5:
        lx, ly = x + 40, y + 44
        d.arc([lx - 4, ly - 6, lx + 4, ly + 2], 180, 360, fill=WHITE, width=2)
        d.rectangle([lx - 6, ly - 2, lx + 6, ly + 8], fill=GOLD, outline=dk(GOLD, 0.6))

def money_bag(d, x, y, lbl="$", col=GOLD):
    d.polygon([(x + 6, y), (x + 14, y), (x + 12, y + 5), (x + 8, y + 5)], fill=dk(col, 0.8))
    d.ellipse([x, y + 4, x + 20, y + 24], fill=col, outline=dk(col, 0.6))
    d.text((x + 10, y + 9), lbl, font=F9, fill=DARK, anchor="ma")

def row_box(d, t, t0, y, title, l1, l2, col=CYAN, ok=True):
    if t < t0: return
    vis, o = slam(t, t0, 0.2); y += o
    box(d, 32, y, 218, y + 42, col, (8, 14, 26))
    d.text((40, y + 4), title, font=F9, fill=col)
    d.text((40, y + 16), l1, font=F9, fill=WHITE); d.text((40, y + 28), l2, font=F9, fill=GRAY)
    if t > t0 + 0.35: (checkmark if ok else xmark)(d, 196, y + 4, GRN if ok else SRED)

# ================================================================ scenes
def punch_fx(t, t0, flash=False):
    fx = {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2))}
    if flash: fx["flash"] = 0.25
    return fx if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 덜덜 미스터리", "시타델 작품?", "이번 하락장도 혹시...", YEL)
    s1 = seg[1]
    rise = ease(prog(t, 0.3, 1.3))
    castle(d, 88, 128 + int((1 - rise) * 60), t, 1.0, prog(t, 1.2, 1.8))
    if t < s1:
        if t > 1.6: trembling_ants(d, t)
        if t > 2.0: deul(d, 96, 282, t)
    else:
        trembling_ants(d, t)
        vis, o = slam(t, s1 + 0.3, 0.2)
        if vis:
            box(d, 40, 278 + o, 210, 302 + o, YEL, (30, 26, 8))
            d.text((CX, 284 + o), "소문 말고 사실만 확인", font=F12, fill=WHITE, anchor="ma")
    return {}

def s_who(img, d, t, seg, dur):
    header(d, t, "01 · 시타델은 누구?", "두 개의 성", "헤지펀드 · 시타델 증권", CYAN)
    s1 = seg[1]
    if t < s1:
        castle(d, 88, 132, t)
        d.text((CX, 210), "시타델 · 1990년 켄 그리핀 설립", font=F9, fill=GRAY, anchor="ma")
        v = 770 * ease(prog(t, 0.6, 2.0))
        d.text((CX, 226), f"운용자산 약 {v:.0f}억 달러", font=F12, fill=YEL, anchor="ma")
        if t > 2.0: d.text((CX, 246), "= 한국 돈 약 102조 원", font=F12, fill=WHITE, anchor="ma")
        d.text((CX, 304), "로이터 8/21 · 1,325원/달러 환산", font=F9, fill=DIM, anchor="ma")
    else:
        u = ease(prog(t, s1, s1 + 0.5))
        castle(d, int(lerp(88, 40, u)), 140, t, 0.7)
        if t > s1 + 0.4:
            castle(d, int(lerp(88, 150, u)), 140, t + 1, 0.7, col=(90, 120, 140))
            d.text((66, 196), "시타델", font=F12, fill=WHITE, anchor="ma"); d.text((66, 212), "헤지펀드", font=F9, fill=GRAY, anchor="ma")
            d.text((176, 196), "시타델 증권", font=F12, fill=WHITE, anchor="ma"); d.text((176, 212), "주문 처리", font=F9, fill=GRAY, anchor="ma")
            for yy in range(140, 214, 6): d.line([(121, yy), (121, yy + 3)], fill=GRAY)
        if t > s1 + 1.2:
            vis, o = slam(t, s1 + 1.2, 0.2)
            box(d, 40, 240 + o, 210, 266 + o, CYAN, (8, 20, 28))
            d.text((CX, 247 + o), "같은 창업자 · 법적으로 다른 회사", font=F9, fill=WHITE, anchor="ma")
    return {}

def s_gme(img, d, t, seg, dur):
    header(d, t, "02 · 2021 게임스탑", "개미의 반란", "그리고 매수 버튼이 멈췄다", ORG)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        pts = gme_pts(40, 206, 132, 232); u = ease(prog(t, 0.3, 2.4))
        d.line([(40, 232), (206, 232)], fill=DIM)
        p = path_until(pts, u)
        if len(p) > 1: d.line(p, fill=YEL, width=2)
        if u >= 1:
            vis, o = slam(t, 2.4, 0.2)
            box(d, 92, 124 + o, 216, 152 + o, YEL, (30, 26, 8))
            d.text((154, 127 + o), "장중 483달러", font=F12, fill=WHITE, anchor="ma"); d.text((154, 141 + o), "약 64만 원", font=F9, fill=GRAY, anchor="ma")
        for k in range(4): ant(d, 46 + k * 44, 248, t + k, "happy")
        d.text((CX, 300), "2021년 1월 · SEC 보고서", font=F9, fill=DIM, anchor="ma")
    elif t < s2:
        suit(d, 44, 140, t)
        d.text((60, 192), "멜빈캐피털", font=F9, fill=WHITE, anchor="ma"); d.text((60, 204), "(공매도 펀드)", font=F9, fill=GRAY, anchor="ma")
        if t > s1 + 0.6: stamp_slam(img, 66, 228, "-53%", YEL, t, s1 + 0.6, "24", -8)
        castle(d, 150, 140, t, 0.7)
        if t > s1 + 1.4:
            u = ease(prog(t, s1 + 1.4, s1 + 2.2))
            money_bag(d, int(lerp(166, 86, u)), int(lerp(160, 150, u) - math.sin(u * math.pi) * 24), "$")
        if t > s1 + 2.2:
            d.text((176, 200), "20억 달러 투입", font=F9, fill=YEL, anchor="ma"); d.text((176, 212), "약 2.7조 원", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 300), "1월 수익률 · 1/25 투입(포인트72와 함께)", font=F9, fill=DIM, anchor="ma")
    else:
        app_phone(d, 40, 130, t, prog(t, s2 + 0.4, s2 + 0.7))
        if t > s2 + 0.8: d.text((67, 228), "1월 28일 매수 제한", font=F9, fill=YEL, anchor="ma")
        castle(d, 152, 140, t, 0.65)
        if t > s2 + 1.4:
            for k in range(5):
                xx = int(lerp(98, 148, (t * 0.8 + k / 5) % 1)); d.rectangle([xx, 172, xx + 4, 175], fill=GRAY)
            d.text((176, 194), "주문 처리", font=F9, fill=WHITE, anchor="ma"); d.text((176, 206), "시타델 증권", font=F9, fill=GRAY, anchor="ma")
        if t > s2 + 2.2:
            for k in range(3): qmark(d, 120 + k * 22, 226 + (k % 2) * 8, t + k * 0.4, ORG)
            vis, o = slam(t, s2 + 2.4, 0.2)
            box(d, 52, 256 + o, 198, 280 + o, ORG, (30, 18, 8))
            d.text((CX, 262 + o), "의혹 폭발!", font=F12, fill=WHITE, anchor="ma")
    return {}

def s_2022(img, d, t, seg, dur):
    header(d, t, "03 · 2022 하락장", "역대 최대 수익", "연준이 금리를 급하게 올린 해", GOLD)
    s1, s2 = seg[1], seg[2]
    if t < s2:
        pts = [(36, 132), (56, 142), (74, 138), (94, 160), (112, 168), (130, 158), (148, 182)]
        p = path_until(pts, ease(prog(t, 0.2, 1.6)))
        if len(p) > 1: d.line(p, fill=GRAY, width=2)
        d.text((40, 188), "시장", font=F9, fill=GRAY)
        castle(d, 150, 130, t, 0.6)
        v = 38.1 * ease(prog(t, 1.0, 2.4))
        d.text((CX, 210), "시타델 대표 펀드(웰링턴)", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 224), f"+{v:.1f}%", font=F24, fill=YEL, anchor="ma")
        if t > s1:
            for k in range(10):
                ts = s1 + 0.1 + k * 0.07
                if t > ts: coin(d, 162 + (k % 5) * 9, 196 - (k // 5) * 7, 5, "")
            vis, o = slam(t, s1 + 0.3, 0.2)
            box(d, 34, 256 + o, 216, 292 + o, GOLD, (30, 24, 6))
            d.text((CX, 261 + o), "한 해 160억 달러 · 약 21조 원", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 278 + o), "헤지펀드 역사상 최대 수익", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 304), "한국경제 7/31 · LCH 집계", font=F9, fill=DIM, anchor="ma")
    else:
        vis, o = slam(t, s2 + 0.2, 0.2)
        news_card(d, 34, 136, o, "2022.5 · 루나 폭락 배후설?", ORG)
        for k in range(3): qmark(d, 70 + k * 40, 176 + (k % 2) * 6, t + k * 0.5, ORG)
        castle(d, 98, 196, t, 0.55)
        if t > s2 + 1.2:
            speech(d, 40, 252, "시타델 증권: 관련 없다 (부인)", tail_left=True)
    return {}

def s_july(img, d, t, seg, dur):
    header(d, t, "04 · 2026 레오폴드 사태", "절묘한 타이밍", "AI 펀드 SA가 무너질 때", PURP)
    s1, s2, s3 = seg[1], seg[2], seg[3]
    if t < s1:
        suit(d, 60, 136, t)
        d.text((76, 188), "SA 펀드", font=F12, fill=WHITE, anchor="ma"); d.text((76, 204), "(AI 몰빵 · 레버리지)", font=F9, fill=GRAY, anchor="ma")
        if t > 1.0: stamp_slam(img, 168, 160, "7월 -67%", YEL, t, 1.0, "12", -8)
        if t > 1.8: warn_icon(d, 150, 214); d.text((176, 220), "마진콜", font=F12, fill=YEL)
        d.text((CX, 300), "레오폴드 아셴브레너 운용 · 투자자 서한", font=F9, fill=DIM, anchor="ma")
    elif t < s3:
        rows = [("7월 말 · 시타델 증권 '깜짝 금리 인상' 전망", s1 + 0.2), ("7/29 · 인수 협상 시작", s1 + 1.4), ("7/30 · 시타델이 통째로 인수", s1 + 2.6)]
        for i, (h, ts) in enumerate(rows):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); news_card(d, 34, 128 + i * 28, o, h, PURP)
        castle(d, 92, 214, t, 0.6)
        if t > s2:
            vis, o = slam(t, s2 + 0.2, 0.2)
            box(d, 34, 260 + o, 216, 300 + o, PURP, (20, 12, 32))
            d.text((CX, 265 + o), "약 160억 달러 규모 · 약 21조 원", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 281 + o), "그날 해당 종목 20~27% 반등", font=F12, fill=YEL, anchor="ma")
    else:
        castle(d, 40, 136, t, 0.7)
        for k in range(6):
            u = (t * 0.6 + k / 6) % 1
            d.rectangle([int(lerp(96, 210, u)), 150 + (k % 3) * 10, int(lerp(96, 210, u)) + 12, 156 + (k % 3) * 10], fill=GOLD)
        d.text((150, 186), "블록딜 약 100건", font=F9, fill=GRAY, anchor="ma")
        v = 40 * ease(prog(t, s3 + 0.3, s3 + 1.6))
        d.text((CX, 204), f"{v:.0f}억 달러 넘게 처분", font=F12, fill=YEL, anchor="ma")
        d.text((CX, 222), "= 약 5.3조 원 (8/21 서한)", font=F9, fill=WHITE, anchor="ma")
        if t > s3 + 2.0: d.text((CX, 240), "7월 대표 펀드 +5.94%", font=F12, fill=WHITE, anchor="ma")
        if t > s3 + 3.0:
            for k, x in enumerate((60, 150)): ant(d, x + shiver(t, k), 258, t, "sweat", bob=False)
            deul(d, 96, 270, t, "덜덜", YEL)
        d.text((CX, 304), "한국경제 7/31 · SpotGamma · 로이터", font=F9, fill=DIM, anchor="ma")
    return {}

def s_oct(img, d, t, seg, dur):
    header(d, t, "05 · 그리고 10월", "또 시타델?", "버블 발언 뒤 하락장", TEAL)
    s1 = seg[1]
    vis, o = slam(t, 0.2, 0.2)
    if vis: news_card(d, 34, 128, o, "10/20 그리핀: AI는 '거의 확실히' 버블", TEAL)
    if t > 1.6: vis, o = slam(t, 1.6, 0.2); news_card(d, 34, 156, o, "10/22 시장 다시 급락", GRAY)
    castle(d, 98, 186, t, 0.55)
    if t > s1:
        trembling_ants(d, t, 238)
        speech(d, 60, 280, "이번에도 시타델 작품?!", tail_left=True)
    return {}

def s_verdict(img, d, t, seg, dur):
    header(d, t, "06 · 사실 확인", "증거는?", "의혹 하나씩 체크", CYAN)
    s1, s2, s3 = seg[1], seg[2], seg[3]
    row_box(d, t, 0.3, 124, "게임스탑", "SEC(2021): 공모 증거 없음", "매수 제한은 청산소 증거금 때문")
    row_box(d, t, s1 + 0.2, 170, "7월 금리 인상 전망", "9월에 실제로 인상 · 적중", "전망 낸 곳 · 산 곳은 다른 회사")
    row_box(d, t, s2 + 0.2, 216, "10월 버블 발언", "다음 날 엔비디아 +2.5%", "SOXL +5.8% 오히려 상승")
    if t > s3 + 0.3: stamp_slam(img, CX, 284, "증거 없음", YEL, t, s3 + 0.3, "24", -8)
    return punch_fx(t, s3 + 0.3)

def s_end(img, d, t, seg, dur):
    header(d, t, "반전", "진짜 무서운 건", "시타델이 아니라...", YEL)
    s1 = seg[1]
    for i, (nm, yr) in enumerate([("멜빈", "2021"), ("SA", "2026")]):
        x = 36 + i * 52; sw = int(math.sin((t + i) * 2) * 2)
        suit(d, x + sw, 132, t + i)
        d.text((x + 16, 182), f"{nm} {yr}", font=F9, fill=WHITE, anchor="ma")
    castle(d, 150, 136, t, 0.6)
    for k in range(4):
        u = (t * 0.7 + k / 4) % 1
        coin(d, int(lerp(110, 168, u)), int(lerp(160, 176, u)), 4, "")
    if t > 1.2:
        vis, o = slam(t, 1.2, 0.2)
        box(d, 34, 200 + o, 216, 222 + o, GRAY, (12, 14, 28))
        d.text((CX, 205 + o), "무너질 때 싸게 줍는 큰손", font=F12, fill=WHITE, anchor="ma")
    if t > s1 + 0.2:
        d.text((CX, 232), "멜빈 · SA를 무너뜨린 건 빚 + 마진콜", font=F9, fill=GRAY, anchor="ma")
    if t > s1 + 1.6: stamp_slam(img, CX, 268, "레버리지 조심", YEL, t, s1 + 1.6, "24", -8)
    d.text((32, 306), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, s1 + 1.6, True)

SCRIPT = [
    (s_hook, [("이번 하락장\n혹시 시타델의 작품일까?", "이번 하락장, 혹시 시타델의 작품일까요?"),
              ("개미들 사이에 도는 소문\n사실만 모아서 확인해 볼게요", "개미들 사이에 도는 소문, 사실만 모아서 확인해 볼게요. 덜덜덜.")]),
    (with_card(s_who, "01", "시타델은 누구?", CARD), [
        ("1990년 켄 그리핀이 세운 헤지펀드\n운용자산 약 770억 달러, 약 102조 원", "시타델은 천구백구십 년, 켄 그리핀이 세운 헤지펀드예요. 굴리는 돈만 약 칠백칠십억 달러, 우리 돈 약 백이 조 원이에요."),
        ("형제 회사 시타델 증권은 개인 주문을 대량 처리\n둘은 법적으로 다른 회사예요", "형제 회사인 시타델 증권은, 개인 투자자 주문을 대량으로 처리하는 회사예요. 둘은 법적으로 다른 회사예요.")]),
    (with_card(s_gme, "02", "2021 게임스탑", CARD), [
        ("2021년 게임스탑, 개미들이 공매도에 맞서\n주가를 장중 483달러(약 64만 원)까지", "이천이십일 년 게임스탑 사태. 개미들이 공매도 세력에 맞서서, 주가를 장중 사백팔십삼 달러, 우리 돈 약 육십사만 원까지 끌어올렸어요."),
        ("공매도한 멜빈캐피털은 1월에만 −53%\n시타델이 20억 달러, 약 2.7조 원을 넣어줬죠", "공매도를 했던 멜빈캐피털은 일월에만 오십삼 퍼센트를 잃었고, 시타델이 이십억 달러, 우리 돈 약 이 점 칠 조 원을 넣어 줬어요."),
        ("1월 28일 로빈후드가 매수를 막았는데\n그 주문을 처리하던 곳이 시타델 증권", "그리고 일월 이십팔 일, 로빈후드가 게임스탑 매수를 막았는데요. 그 주문을 처리하던 곳이 바로 시타델 증권이라, 의혹이 폭발했어요.")]),
    (with_card(s_2022, "03", "2022 하락장", CARD), [
        ("2022년 금리 인상으로 시장이 무너질 때\n시타델 대표 펀드는 +38.1%", "이천이십이 년, 연준이 금리를 급하게 올리면서 시장이 무너질 때, 시타델 대표 펀드는 삼십팔 점 일 퍼센트를 벌었어요."),
        ("한 해 160억 달러, 약 21조 원\n헤지펀드 역사상 최대 수익", "한 해에 백육십억 달러, 우리 돈 약 이십일 조 원. 헤지펀드 역사상 최대 수익이었어요."),
        ("같은 해 루나 폭락 배후설도 돌았지만\n시타델 증권은 관련 없다며 부인", "같은 해 루나 폭락 배후설도 돌았지만, 시타델 증권은 관련 없다며 부인했어요.")]),
    (with_card(s_july, "04", "레오폴드 사태", CARD), [
        ("올해 7월, 레오폴드의 AI 펀드 SA가\n한 달 −67%, 마진콜에 몰렸어요", "그리고 올해 칠월. 레오폴드 아셴브레너의 에이아이 펀드, 에스에이가 한 달 만에 육십칠 퍼센트를 잃고, 마진콜에 몰렸어요."),
        ("7월 말 시타델 증권 '깜짝 금리 인상' 전망\n7/29 협상 → 7/30 시타델이 통째 인수", "칠월 말 시타델 증권이 깜짝 금리 인상 전망을 냈고, 칠월 이십구 일 협상, 삼십 일에는 시타델이 포트폴리오를 통째로 인수했어요."),
        ("약 160억 달러(약 21조 원) 규모\n그날 해당 종목들 20~27% 반등", "약 백육십억 달러, 우리 돈 약 이십일 조 원 규모였고, 그날 해당 종목들은 이십에서 이십칠 퍼센트 반등했어요."),
        ("8월엔 블록딜로 40억 달러(약 5.3조 원) 넘게 처분\n7월 대표 펀드 수익 +5.94%", "그리고 팔월, 블록딜 약 백 건으로 사십억 달러, 우리 돈 약 오 점 삼 조 원어치 넘게 정리했어요. 칠월 대표 펀드 수익은 오 점 구사 퍼센트. 절묘하죠? 덜덜.")]),
    (with_card(s_oct, "05", "그리고 10월", CARD), [
        ("10월 20일 그리핀 'AI는 거의 확실히 버블'\n이틀 뒤 시장이 다시 급락하자", "그리고 시월 이십 일, 그리핀이 에이아이는 거의 확실히 버블이라고 말했어요. 이틀 뒤 시장이 다시 크게 빠지자,"),
        ("개미들 사이에선\n'이번에도 시타델 작품?' 소문이", "개미들 사이에선, 이번에도 시타델 작품 아니냐는 소문이 돌았죠.")]),
    (with_card(s_verdict, "06", "사실 확인", CARD), [
        ("게임스탑: SEC 보고서(2021) '공모 증거 없음'\n매수 제한은 청산소 증거금 때문", "자, 하나씩 확인해 볼게요. 게임스탑은, 미국 증권거래위원회가 이천이십일 년 보고서에서 공모 증거가 없다고 했어요. 매수 제한은 청산소 증거금 요구 때문이었대요."),
        ("7월 금리 전망: 9월에 실제로 인상, 적중\n전망 낸 곳과 산 곳은 다른 회사", "칠월 금리 인상 전망은, 구월에 연준이 실제로 금리를 올려서 맞힌 셈이고, 전망을 낸 곳과 물량을 산 곳은 다른 회사예요."),
        ("10월 발언 다음 날 엔비디아 +2.5%\nSOXL은 +5.8% 오히려 상승", "시월 버블 발언 다음 날엔, 엔비디아가 이 점 오, 속슬은 오 점 팔 퍼센트, 오히려 올랐어요."),
        ("결론: 수상해 보여도\n작전이라는 증거는 없어요", "결론. 수상해 보여도, 작전이라는 증거는 없어요.")]),
    (s_end, [("시타델은 '개미 학살자'라기보다\n남이 무너질 때 싸게 줍는 큰손", "시타델은 개미 학살자라기보다, 남이 무너질 때 싸게 줍는 큰손에 가까워요."),
             ("멜빈도 SA도 무너뜨린 건 빚과 마진콜\n진짜 무서운 건 레버리지예요", "멜빈도, 에스에이도, 무너뜨린 건 결국 빚과 마진콜이었어요. 진짜 무서운 건, 레버리지예요.")]),
]
TITLES = ["", "두 개의 성", "개미의 반란", "역대 최대 수익", "절묘한 타이밍", "또 시타델?", "증거는?", "진짜 무서운 건"]
NCH = 6


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    MINLINE = {(0, 0): 3.2, (0, 1): 3.0, (1, 0): 3.0, (2, 0): 3.4, (2, 1): 3.4, (2, 2): 3.4, (3, 0): 3.0,
               (4, 0): 3.0, (4, 1): 4.2, (4, 3): 4.4, (5, 0): 3.2, (6, 0): 2.8, (6, 3): 2.6, (7, 1): 3.4}
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (CH + 0.5 if 1 <= k <= NCH else 0.3)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += max(L, MINLINE.get((k, i), 0)) + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.4, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    # 밝고 잔잔한 장조 칩튠 하나를 처음부터 끝까지 (G-D-Em-C, 94bpm, 드럼 아주 약하게)
    bpm = 94; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = [([67, 71, 74], 55), ([62, 66, 69], 50), ([64, 67, 71], 52), ([60, 64, 67], 48)]
    mel = [[79, None, 83, None, 81, None, 79, None], [78, None, 74, None, 76, None, 78, None], [79, None, 76, None, 74, None, 76, None], [72, None, 74, None, 76, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            m = mm[st]
            if m: tone(bgm, T, e * 1.6, mtof(m), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR); fi = int(1.0 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.07, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.06, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.05, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.05, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=0.8): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def lock(T): tone(sfx, T, 0.05, 2200, 0.06, "sq", 0.5, decay=0.03); tone(sfx, T + 0.06, 0.08, 900, 0.06, "sq", 0.5, decay=0.05)
    def brr(T, d=0.9):                                                          # 덜덜덜(살짝 떨리는 저음)
        for j in range(int(d / 0.07)): tone(sfx, T + j * 0.07, 0.05, 150 + (j % 2) * 30, 0.035, "sq", 0.5, decay=0.04)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    typing(S[0] + 0.1, "시타델작품"); rise(S[0] + 0.3, 1.0); brr(S[0] + 1.6, 1.2); brr(sg(0, 1) + 0.2, 0.8); ding(sg(0, 1) + 0.3)
    for k in range(1, len(scenes)):
        if 1 <= k <= NCH: chapter(S[k]); swoosh(S[k] + CH - 0.25); typing(S[k] + CH + 0.6, TITLES[k])
        else: swoosh(S[k]); typing(S[k] + 0.3, TITLES[k])
    C = lambda k: S[k] + CH
    rise(C(1) + 0.6, 1.4); ding(C(1) + 2.0); swoosh(sg(1, 1)); pop(sg(1, 1) + 0.4); thump(sg(1, 1) + 1.2)
    rise(C(2) + 0.3, 2.1); ding(C(2) + 2.4)
    stampfx(sg(2, 1) + 0.6); swoosh(sg(2, 1) + 1.4); coin_s(sg(2, 1) + 2.2)
    lock(sg(2, 2) + 0.5); pop(sg(2, 2) + 2.2); pop(sg(2, 2) + 2.5); thump(sg(2, 2) + 2.4)
    rise(C(3) + 1.0, 1.4)
    for k in range(10): coin_s(sg(3, 1) + 0.1 + k * 0.07)
    thump(sg(3, 1) + 0.3); pop(sg(3, 2) + 0.2); pop(sg(3, 2) + 1.2)
    stampfx(C(4) + 1.0); thump(C(4) + 1.8)
    for k in range(3): pop(sg(4, 1) + [0.2, 1.4, 2.6][k])
    thump(sg(4, 2) + 0.2)
    for k in range(6): coin_s(sg(4, 3) + 0.3 + k * 0.2)
    brr(sg(4, 3) + 3.0, 1.0)
    pop(C(5) + 0.2); thump(C(5) + 1.6); brr(sg(5, 1) + 0.1, 1.2)
    for i in range(3): pop(sg(6, i) + 0.2); ding(sg(6, i) + 0.55)
    stampfx(sg(6, 3) + 0.3)
    for k in range(4): coin_s(S[7] + 0.3 + k * 0.4)
    thump(S[7] + 1.2); stampfx(sg(7, 1) + 1.6); ding(sg(7, 1) + 2.0)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

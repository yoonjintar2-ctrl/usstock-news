#!/bin/bash
# 8비트 픽셀 쇼츠 제작 환경 (이 폴더 안에서 실행: bash setup.sh)
set -e
cd "$(dirname "$0")"
pip install --break-system-packages -q sherpa-onnx==1.13.8 pillow numpy
mkdir -p tts/official && cd tts/official
if [ ! -d sherpa-onnx-supertonic-3-tts-int8-2026-05-11 ]; then
  curl -sSL -o st3.tar.bz2 "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2"
  tar xjf st3.tar.bz2 && rm st3.tar.bz2
fi
cd ../..
which ffmpeg >/dev/null || echo "!! ffmpeg 필요"
fc-list | grep -q "Noto Sans CJK KR" || echo "!! 자막 폰트 Noto Sans CJK KR Bold 필요 (/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc)"
echo "준비 완료"

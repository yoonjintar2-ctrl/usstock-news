"""여러 후보 중 문장마다 가장 좋은 테이크 고르기
기준: ① 기준 음색(ref)과 화자 유사도 ② 굉음(저역 럼블·갑작스런 폭발음)·지글거림 없음 ③ 너무 작거나 긴 테이크 제외
python3 pick_takes.py <cand_dir> <ref.wav> [ref2.wav ...] → 표 출력 + 선택 결과 json"""
import sys, os, glob, json, re, numpy as np, soundfile as sf, librosa, warnings
warnings.filterwarnings('ignore')
from resemblyzer import VoiceEncoder, preprocess_wav

def noise_score(x, sr):
    """0이면 깨끗. 저역 럼블 비율·순간 폭발·고역 지글 프레임 수 합산"""
    hop = int(sr * 0.025)
    S = np.abs(librosa.stft(x, n_fft=2048, hop_length=hop)) + 1e-9
    f = librosa.fft_frequencies(sr=sr, n_fft=2048)
    tot = S.sum(0); loud = tot > np.percentile(tot, 40)
    low = S[f < 140].sum(0) / tot                      # 굉음(럼블)
    hi = S[f > 7000].sum(0) / tot                      # 지글/쉭
    rms = librosa.feature.rms(y=x, frame_length=2048, hop_length=hop)[0]
    med = np.median(rms[loud[:len(rms)]]) if loud.any() else 1e-3
    burst = (rms > 3.0 * med).sum()
    return float((low[loud] > 0.35).sum() + (hi[loud] > 0.45).sum() + 2 * burst)

def main(cdir, refs):
    enc = VoiceEncoder('cpu', verbose=False)
    ref = np.mean([enc.embed_utterance(preprocess_wav(r)) for r in refs], 0); ref /= np.linalg.norm(ref)
    rows = {}
    for p in sorted(glob.glob(os.path.join(cdir, '*.wav'))):
        m = re.match(r'(\w+?)_c(\d+)\.wav', os.path.basename(p))
        if not m: continue
        x, sr = sf.read(p, dtype='float32'); dur = len(x) / sr
        sim = float(np.dot(ref, enc.embed_utterance(preprocess_wav(p))))
        nz = noise_score(x, sr); peak = float(np.abs(x).max())
        score = sim - 0.01 * nz - (0.3 if peak < 0.25 else 0)
        rows.setdefault(m.group(1), []).append(dict(file=p, take=int(m.group(2)), dur=round(dur, 1), sim=round(sim, 3),
                                                   noise=nz, peak=round(peak, 2), score=round(score, 3)))
    pick = {}
    for line, rs in rows.items():
        md = np.median([r['dur'] for r in rs])
        for r in rs:
            if r['dur'] > 1.6 * md: r['score'] -= 0.5      # 혼자 너무 긴 테이크 = 헛소리/반복 의심
        rs.sort(key=lambda r: -r['score']); pick[line] = rs[0]['file']
        print(line, ' | '.join(f"c{r['take']} sim{r['sim']} nz{r['noise']:.0f} {r['dur']}s pk{r['peak']} → {r['score']:.3f}" for r in rs))
    return pick

if __name__ == '__main__':
    pick = main(sys.argv[1], sys.argv[2:])
    json.dump(pick, open(os.path.join(sys.argv[1], 'pick.json'), 'w'), ensure_ascii=False, indent=1)
    print('선택:', {k: os.path.basename(v) for k, v in pick.items()})

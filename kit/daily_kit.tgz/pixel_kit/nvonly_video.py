"""'반도체는 버텼는데 엔비디아만 -5%' (60초 이내) — 2026-11-11 제작 · 8비트 + 마스코트 풀샷 컷(30fps, 무대 조명)
사실 확인(11/10 미국장 종가, 2026-11-11 KST 확인):
 · 필라델피아 반도체지수 9,998.33(-0.36%) · 나스닥 -0.74% · S&P500 -0.38% (서울신문 데이터랩)
 · 엔비디아 $168.89(-5.47%) · 11/9 -4.27% → 이틀 약 -9.5% · 작년 말 종가 $186.50 → 올해 상승분 반납(연초 대비 약 -9%) · 최근 고점 $243.37 (Decrypt)
 · 브로드컴 +3.91% · TSMC ADR +2.02% · AMD +1.30% · SK하이닉스 ADR -3.51% · 마이크론 -1.10%
 · 미 하원 위원장들, 젠슨 황에 비공개 브리핑 요구(불응 시 소환장 경고 보도) · 주주 집단소송 제기 · 이사회 독립 조사 진행, 회사는 "기밀 손상 근거 없음", CEO직 유지
 · 구글 새 AI 칩 구성 공개, OpenAI의 구글 TPU 구매 검토 보도 (브로드컴 상승과의 연결은 해석 — 화면엔 사실만: 같은 날 올랐다)
 · 엔비디아 실적 발표 11/17 예정 · 환율 1,345원/달러(11/10 토스 1,344.6): $186.5≈25.1만 · $243.4≈32.7만 · $168.9≈22.7만
 · 정당명 언급 없음, 상대 인물 실명·의혹 세부 없음, 투자 권유 아님, 상승·하락 빨강/초록 구분 없음(▲▼ 모양 + 청록/흰색)
python3 nvonly_video.py [times|stills T,T|audio|full]"""
import os, sys, math, json, hashlib, wave
import numpy as np
from PIL import Image, ImageDraw

from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, CYAN, ORG, GRAY, DIM, BG, prog, ease, lerp, tone, mtof, SR, bg_img, typed, blink)
from sandisk_video import box, slam, CX, SX0, SX1, WHT2, chip
from nike_video import stamp_slam, debris, dk, DARK, render_low, shutter_mask, dissolve_mask, clamp, TR, warn_icon, put
from option_video import big_text
from semicrash_video import news_card

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "nvonly/out"); os.makedirs(OUT, exist_ok=True)
NDIR = os.path.join(BASE, "nvonly/narr"); os.makedirs(NDIR, exist_ok=True)
def clip_path(n): return os.path.join(NDIR, hashlib.md5(f"q|{n}".encode()).hexdigest() + ".npy")
GAP, TAIL = 0.32, 0.5
NEU = (200, 206, 220)          # 선 색(상승·하락 색 구분 없음)
BROWN = (150, 100, 60); HORN = (240, 232, 210)
SUIT = (34, 36, 52); CUFF = (230, 232, 240); SKINH = (232, 188, 146)
GOLD = (240, 190, 60)

# ================================================================ sprites
def bear(d, x, y, t):
    b = int(abs(math.sin(t * 4)) * 2); y -= b
    for ex in (x + 4, x + 30): d.ellipse([ex, y, ex + 10, y + 10], fill=BROWN, outline=dk(BROWN, 0.6))
    d.ellipse([x + 2, y + 4, x + 42, y + 34], fill=BROWN, outline=dk(BROWN, 0.6))
    d.ellipse([x + 14, y + 18, x + 30, y + 30], fill=(210, 170, 120))
    d.rectangle([x + 20, y + 19, x + 24, y + 22], fill=DARK)
    for ex in (x + 12, x + 28):
        d.rectangle([ex, y + 12, ex + 3, y + 15], fill=DARK)
        d.line([(ex - 2, y + 9 + (0 if ex < x + 20 else 3)), (ex + 5, y + 12 - (0 if ex < x + 20 else 3))], fill=DARK)

def money_bag(d, x, y, lbl="$", col=GOLD):
    d.polygon([(x + 6, y), (x + 14, y), (x + 12, y + 5), (x + 8, y + 5)], fill=dk(col, 0.8))
    d.ellipse([x, y + 4, x + 20, y + 24], fill=col, outline=dk(col, 0.6))
    d.text((x + 10, y + 9), lbl, font=F9, fill=DARK, anchor="ma")

def datacenter(d, x, y, t, col=CYAN, w=52):
    d.rectangle([x, y, x + w, y + 34], fill=(18, 22, 40), outline=col)
    d.rectangle([x + 3, y - 6, x + w - 3, y], fill=dk(col, 0.6))
    for r in range(2):
        for c in range(3):
            on = ((r * 3 + c + int(t * 5)) % 4) != 0
            d.rectangle([x + 5 + c * 16, y + 6 + r * 13, x + 16 + c * 16, y + 13 + r * 13], fill=(34, 40, 62))
            d.rectangle([x + 12 + c * 16, y + 9 + r * 13, x + 14 + c * 16, y + 10 + r * 13], fill=YEL if on else DIM)

def hand(img, cx, ybot, top):
    """위에서 내려오는 정체불명의 손(정장 소매 + '?' 단추). ybot = 손가락 끝, top 위로는 잘림(상자 안에서만 보임)"""
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); d.fontmode = "1"
    yb = int(ybot); fl = 9; hp = 22; yp = yb - fl - hp
    d.rectangle([cx - 26, yp - 120, cx + 26, yp - 6], fill=SUIT + (255,), outline=dk(SUIT, 0.6) + (255,))
    d.text((cx, yp - 24), "?", font=F12, fill=YEL + (255,), anchor="ma")
    d.rectangle([cx - 28, yp - 10, cx + 28, yp - 4], fill=CUFF + (255,))
    d.rounded_rectangle([cx - 24, yp - 4, cx + 24, yb - fl], radius=4, fill=SKINH + (255,), outline=dk(SKINH, 0.65) + (255,))
    for k in range(4):
        fx = cx - 22 + k * 12
        d.rounded_rectangle([fx, yb - fl - 3, fx + 9, yb], radius=3, fill=SKINH + (255,), outline=dk(SKINH, 0.65) + (255,))
    d.rounded_rectangle([cx + 20, yp + 2, cx + 30, yp + 18], radius=3, fill=SKINH + (255,), outline=dk(SKINH, 0.65) + (255,))
    d.rectangle([0, 0, W, top - 1], fill=(0, 0, 0, 0))
    img.paste(lay, (0, 0), lay)

def wig(x, seed):
    return math.sin(x * 0.31 + seed) * 3 + math.sin(x * 0.11 + seed * 2) * 4

def label_tag(d, x, y, s, col=CYAN, font=F9, anchor_r=False):
    w = int(d.textlength(s, font=font)) + 8
    x0 = x - w if anchor_r else x
    d.rectangle([x0, y, x0 + w, y + 14], fill=(10, 14, 30), outline=col)
    d.text((x0 + 4, y + 2), s, font=font, fill=col)

def head(d, t, small, big, col=YEL):
    d.text((CX, 52), small, font=F9, fill=GRAY, anchor="ma")
    s = typed(big, t, 0.1, 20)
    d.text((CX - d.textlength(big, font=F24) / 2, 64), s, font=F24, fill=col)

def punch_fx(t, t0, amp=4):
    u = t - t0
    return {"shake": (int(math.sin(u * 60) * amp * max(0, 1 - u / 0.3)), 0)} if 0 <= u < 0.3 else {}

# ================================================================ host stage (풀샷 컷 배경, 마스코트·말풍선은 compose에서)
STARS = [((i * 73) % 250 + 10, (i * 151) % 190 + 8, i % 3) for i in range(26)]
def stage(img, d, t, title, small, col=YEL):
    for (x, y, k) in STARS:
        if ((t * 1.3 + k * 0.4 + x * 0.01) % 1) < 0.75: d.point((x, y), fill=(120, 130, 170) if k else (200, 205, 230))
    # 계단식 스포트라이트(방사선 없음 — 위가 좁고 아래가 넓은 계단)
    for s in range(14):
        y0 = 150 + s * 22; hw = 22 + s * 9
        d.rectangle([W // 2 - hw, y0, W // 2 + hw, y0 + 22], fill=(26, 32, 62))
    d.rectangle([0, 452, W, H], fill=(18, 14, 18)); d.line([(0, 452), (W, 452)], fill=(220, 150, 50), width=1)
    tw = d.textlength(title, font=F24)
    d.text((W // 2 - tw / 2 + 1, 28 + 1), title, font=F24, fill=(0, 0, 0)); d.text((W // 2 - tw / 2, 28), title, font=F24, fill=col)
    if small: d.text((W // 2, 58), small, font=F12, fill=WHITE, anchor="ma")

def s_host_hook(img, d, t, seg, dur): stage(img, d, t, "엔비디아만 -5.5%", "브로드컴 +3.9% · TSMC +2.0%")
def s_host_mid(img, d, t, seg, dur): stage(img, d, t, "근데 말이죠", "왜 엔비디아만?")
def s_host_end(img, d, t, seg, dur):
    stage(img, d, t, "여러분 생각은?", "다음 주 엔비디아 실적")
    d.text((W // 2, 466), "※ 투자 권유 아님 · 11/10 종가 기준", font=F9, fill=GRAY, anchor="ma")

# ================================================================ ① 간밤 성적표: 반도체는 버텼다
ROWS = [("반도체지수", "-0.36%", 0, "버팀"), ("브로드컴", "+3.91%", 1, None), ("TSMC", "+2.02%", 1, None), ("AMD", "+1.30%", 1, None)]
def arrow(d, x, y, up, col):
    if up: d.polygon([(x, y + 9), (x + 10, y + 9), (x + 5, y)], fill=col)
    else: d.polygon([(x, y), (x + 10, y), (x + 5, y + 9)], fill=col)
def split_times(seg, dur):
    L = dur - TAIL - 0.15 - seg[0]
    return [seg[0] + 0.10 * L, seg[0] + 0.52 * L, seg[0] + 0.64 * L, seg[0] + 0.76 * L]
def s_split(img, d, t, seg, dur):
    head(d, t, "11/10 미국장 종가", "반도체 성적표")
    for k, ((nm, pct, up, tag), ta) in enumerate(zip(ROWS, split_times(seg, dur))):
        if t < ta: continue
        vis, o = slam(t, ta, 0.2)
        y0 = 100 + k * 50 + (o if k == 0 else -o)
        col = CYAN if up else WHITE
        box(d, 32, y0, 218, y0 + 42, YEL if (k == 0 and t < split_times(seg, dur)[1]) else DIM)
        chip(d, 40, y0 + 9, 24, col, t, k + 1, 1.0 if up else 0.5)
        d.text((74, y0 + 6), nm, font=F12, fill=WHITE)
        d.text((74, y0 + 23), "버텼다" if tag else "올랐다", font=F9, fill=GRAY)
        arrow(d, 142, y0 + 15, up, col)
        d.text((212, y0 + 12), pct, font=F12, fill=col, anchor="ra")
    return {}

# ================================================================ ② 엔비디아 올해 상승분 반납
def s_ytd(img, d, t, seg, dur):
    head(d, t, "엔비디아 주가(달러)", "올해 상승분 반납")
    L = dur - TAIL - 0.15 - seg[0]
    x0, x1, yb = 40, 208, 262
    box(d, 32, 100, 218, 272, DIM)
    def Y(p): return yb - (p - 150) * (150 / 110)
    base = Y(186.5)
    for x in range(x0, x1, 6): d.line([(x, base), (x + 3, base)], fill=GRAY)
    d.text((x0 + 2, base + 3), "작년 말 $186.5(약 25.1만원)", font=F9, fill=GRAY)
    KP = [(0.0, 186.5), (0.25, 205), (0.50, 228), (0.66, 243.4), (0.80, 215), (0.90, 187), (0.95, 178.7), (1.0, 168.9)]
    def P(u):
        for (a, pa), (b, pb) in zip(KP, KP[1:]):
            if u <= b: return pa + (pb - pa) * (u - a) / (b - a)
        return KP[-1][1]
    Td = seg[0] + 0.15 * L; Te = seg[0] + 0.72 * L
    ud = ease(prog(t, Td, Te)); pts = []
    for i in range(0, int(60 * ud) + 1):
        u = i / 60; pts.append((x0 + (x1 - x0) * u, Y(P(u)) + wig(i * 3, 2) * 0.35 * (0 < u < 1)))
    if len(pts) > 1: d.line(pts, fill=NEU, width=2)
    if pts: d.rectangle([pts[-1][0] - 2, pts[-1][1] - 2, pts[-1][0] + 2, pts[-1][1] + 2], fill=WHITE)
    if ud > 0.68:
        px_ = x0 + (x1 - x0) * 0.66
        d.text((px_, Y(243.4) - 24), "고점 $243.4", font=F9, fill=CYAN, anchor="ma"); d.text((px_, Y(243.4) - 13), "(약 32.7만원)", font=F9, fill=CYAN, anchor="ma")
    if t > Te:
        vis, o = slam(t, Te, 0.18)
        d.text((x1 + 6, Y(168.9) + 6 - o), "$168.9", font=F12, fill=YEL, anchor="ra"); d.text((x1 + 6, Y(168.9) + 20 - o), "(약 22.7만원)", font=F9, fill=YEL, anchor="ra")
        d.text((x0 + 2, yb - 2), "이틀 -9.5%", font=F9, fill=WHT2)
    Ts = Te + 0.35
    if t > Ts: stamp_slam(img, CX, 293, "올해 수익률 -9%", YEL, t, Ts, "12", -5)
    fx = punch_fx(t, Ts, 3)
    if Ts <= t < Ts + 0.08: fx["flash"] = 0.15
    return fx

# ================================================================ ③ 이유 1: 젠슨 황 리스크
def capitol(d, x, y):
    d.polygon([(x + 4, y + 10), (x + 22, y), (x + 40, y + 10)], fill=WHITE)
    d.rectangle([x + 2, y + 10, x + 42, y + 13], fill=WHITE)
    for c in range(5): d.rectangle([x + 5 + c * 8, y + 14, x + 8 + c * 8, y + 30], fill=WHITE)
    d.rectangle([x, y + 31, x + 44, y + 34], fill=WHITE)
def gavel(d, x, y, t, t0):
    sw = 0 if t < t0 else int(6 * max(0, 1 - (t - t0) / 0.25))
    d.rectangle([x + 4, y + 6 - sw, x + 26, y + 16 - sw], fill=(190, 140, 80), outline=dk((190, 140, 80), 0.6))
    d.line([(x + 15, y + 16 - sw), (x + 34, y + 30)], fill=(190, 140, 80), width=3)
    d.rectangle([x, y + 30, x + 30, y + 34], fill=GRAY)
def why1_times(seg, dur):
    L = dur - TAIL - 0.15 - seg[0]
    return seg[0] + 0.34 * L, seg[0] + 0.72 * L
def s_why1(img, d, t, seg, dur):
    head(d, t, "왜 엔비디아만? 1/2", "젠슨 황 리스크")
    ta, tb = why1_times(seg, dur)
    if t > 0.3: label_tag(d, 62, 96, "이사회 독립 조사 진행 중", GRAY)
    for k, (ta_, ttl, sub) in enumerate(((ta, "미 의회", "비공개 브리핑 요구"), (tb, "주주", "집단소송 제기"))):
        if t < ta_: continue
        vis, o = slam(t, ta_, 0.2)
        y0 = 118 + k * 88 + (o if k == 0 else -o)
        on = (k == 0 and t < tb) or k == 1
        box(d, 32, y0, 218, y0 + 78, YEL if on else DIM)
        if k == 0: capitol(d, 46, y0 + 20)
        else: gavel(d, 50, y0 + 22, t, ta_ + 0.25)
        d.text((104, y0 + 16), ttl, font=F12, fill=YEL if on else WHITE)
        d.text((104, y0 + 36), sub, font=F12, fill=WHITE)
        if k == 0: d.text((104, y0 + 56), "불응 시 소환장 경고", font=F9, fill=GRAY)
        else: d.text((104, y0 + 56), "위험 미공개 주장", font=F9, fill=GRAY)
    return punch_fx(t, tb + 0.25, 2)

# ================================================================ ④ 이유 2: 대안이 보인다
def s_why2(img, d, t, seg, dur):
    head(d, t, "왜 엔비디아만? 2/2", "대안이 보인다")
    L = dur - TAIL - 0.15 - seg[0]
    Tn = seg[0] + 0.42 * L; Tb = seg[0] + 0.80 * L
    box(d, 32, 150, 104, 250, DIM); d.text((68, 156), "엔비디아", font=F12, fill=GRAY, anchor="ma")
    chip(d, 48, 180, 40, GRAY, t, 9, 0.35)
    d.text((68, 230), "-5.47%", font=F12, fill=WHITE, anchor="ma")
    if t > Tn - 0.1:
        vis, o = slam(t, Tn - 0.1, 0.18)
        d.rectangle([30, 100 - o // 2, 220, 138 - o // 2], fill=(14, 16, 32), outline=YEL); d.rectangle([30, 100 - o // 2, 35, 138 - o // 2], fill=YEL)
        d.text((41, 104 - o // 2), "구글, 새 AI 칩 구성 공개", font=F12, fill=WHITE)
        d.text((41, 123 - o // 2), "OpenAI도 구글 칩 구매 검토 보도", font=F9, fill=GRAY)
        ua = ease(prog(t, Tn + 0.2, Tn + 0.9))
        for i in range(int(5 * ua)):
            xx = 110 + i * 7; d.rectangle([xx, 198, xx + 4, 201], fill=YEL)
        if ua > 0.95: d.polygon([(144, 193), (144, 207), (152, 200)], fill=YEL)
        vis2, o2 = slam(t, Tn + 0.5, 0.2)
        if vis2:
            lit = t > Tb
            box(d, 156, 150 + o2, 218, 250 + o2, YEL if lit else DIM); d.text((187, 156 + o2), "브로드컴", font=F12, fill=YEL if lit else WHITE, anchor="ma")
            chip(d, 167, 180 + o2, 40, CYAN, t, 4, 1.0)
            if lit:
                d.text((187, 230), "+3.91%", font=F12, fill=CYAN, anchor="ma")
    if t > Tb + 0.3: d.text((CX, 262), "구글 맞춤형 AI 칩의 협력사", font=F9, fill=WHT2, anchor="ma")
    if Tb <= t < Tb + 0.5: debris(d, 187, 200, t, Tb, 10, (WHITE, YEL, CYAN), 40, 0.5, 5, 2)
    return punch_fx(t, Tb, 2)

# ================================================================ ⑤ 반론: 아직 조사 중
def s_counter(img, d, t, seg, dur):
    head(d, t, "다만, 아직은", "조사 진행 중", CYAN)
    L = dur - TAIL - 0.15 - seg[0]
    Tp = seg[0] + 0.55 * L
    box(d, 40, 104, 210, 236, WHITE, fill=(236, 232, 220))
    d.text((CX, 110), "회사 입장", font=F12, fill=DARK, anchor="ma"); d.line([(52, 128), (198, 128)], fill=(120, 116, 104))
    lines = ["· 기밀 손상 근거 없음", "· 독립 조사 진행", "· CEO직 유지"]
    for i, s in enumerate(lines):
        s2 = typed(s, t, 0.5 + i * 0.7, 18); d.text((54, 138 + i * 22), s2, font=F12, fill=DARK)
    if t > Tp - 0.6:
        u = prog(t, Tp - 0.6, Tp + 1.6); mx = lerp(60, 176, (math.sin(u * math.pi * 2 - math.pi / 2) + 1) / 2); my = 216 + math.sin(u * 9) * 3
        d.ellipse([mx - 11, my - 11, mx + 11, my + 11], outline=CYAN, width=3); d.line([(mx + 8, my + 8), (mx + 17, my + 17)], fill=CYAN, width=3)
    if t > Tp:
        vis, o = slam(t, Tp, 0.2)
        if blink(t, 2.2) or t < Tp + 0.4: label_tag(d, 82, 248 + o, "결론은 아직", YEL, F12)
    return {}

# ================================================================ script
HOST = {"s_host_hook", "s_host_mid", "s_host_end"}
SCRIPT = [
    (s_host_hook, [("엔비디아 하루 {-5.5%}\n브로드컴은 {+3.9%}?", "엔비디아 하루 마이너스 오 점 오 퍼센트. 그런데 브로드컴은 플러스 사 퍼센트?", "h1"),
                   ("같은 반도체인데\n{왜 엔비디아만?}", "같은 반도체인데, 왜 엔비디아만 빠질까요?", "h2")]),
    (s_split, [("반도체지수는 {-0.4%}로 버텼어요\n브로드컴·TSMC·AMD는 올랐고요", "간밤 반도체지수는 마이너스 영 점 사 퍼센트로 버텼어요. 브로드컴, 티에스엠씨, 에이엠디는 오히려 올랐고요.", "a1")]),
    (s_ytd, [("엔비디아는 이틀간 {-9.5%}\n올해 오른 걸 {전부 반납}", "엔비디아는 이틀 동안 십 퍼센트 가까이 빠져서, 올해 오른 걸 전부 반납했어요.", "a2")]),
    (s_host_mid, [("근데 말이죠\n{왜 엔비디아만}일까요?", "근데 말이죠. 왜 엔비디아만일까요?", "t1")]),
    (s_why1, [("첫째, {젠슨 황 리스크}\n의회 브리핑 요구에 주주 소송까지", "첫째. 젠슨 황 리스크예요. 미국 의회가 비공개 브리핑을 요구했고, 주주 소송까지 나왔어요.", "b1")]),
    (s_why2, [("둘째, {대안이 보이기 시작}\n구글 새 AI 칩 소식에 브로드컴 상승", "둘째. 대안이 보이기 시작했어요. 구글의 새 에이아이 칩 소식이 나온 날, 브로드컴이 올랐죠.", "b2")]),
    (s_counter, [("다만 회사는 {기밀 손상 없다}는 입장\n조사는 아직 진행 중", "다만 회사는 기밀이 새지 않았다고 밝혔고, 조사는 아직 진행 중이에요.", "c1")]),
    (s_host_end, [("다음 주 실적이 {진짜 시험대}\n어떻게 보세요?", "다음 주 엔비디아 실적이 진짜 시험대예요. 여러분은 어떻게 보세요?", "e1")]),
]

def placeholder_narration():
    """TTS 도착 전 레이아웃용 임시 무음(초당 6.3음절 추정) — 실제 테이크가 오면 덮어씀"""
    for _, lines in SCRIPT:
        for _, n, _ in lines:
            p = clip_path(n)
            if not os.path.exists(p):
                syl = len([c for c in n if '가' <= c <= '힣'])
                np.save(p.replace(".npy", ".ph.npy") if False else p, np.zeros(int(syl / 6.3 * SR), np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.12 if k == 0 else TR + 0.12
        seg, lens = [], []
        for sub, n, _ in lines:
            L = len(np.load(clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        host = fn.__name__ in HOST
        dur = t - GAP + (TAIL + (0.25 if host else 0.15))
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=dur, host=host, subs=[s for s, _, _ in lines], narr=[n for _, n, _ in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def spec(scenes, starts, total):
    hosts, bubbles, subs = [], [], []
    for k, sc in enumerate(scenes):
        S = starts[k]
        if sc["host"]:
            hosts.append(dict(k=k, t0=S, t1=S + sc["dur"], fade_in=(k > 0)))
            for i, s in enumerate(sc["subs"]):
                t0 = S + sc["seg"][i]; t1 = S + (sc["seg"][i + 1] if i + 1 < len(sc["subs"]) else sc["seg"][i] + sc["lens"][i] + 0.35)
                bubbles.append(dict(t0=t0, t1=t1, text=s, first=(i == 0), last=(i == len(sc["subs"]) - 1)))
        else:
            for i, s in enumerate(sc["subs"]):
                t0 = S + sc["seg"][i]; t1 = S + (sc["seg"][i + 1] - 0.05 if i + 1 < len(sc["subs"]) else min(sc["dur"] - 0.05, sc["seg"][i] + sc["lens"][i] + 0.45))
                subs.append(dict(t0=t0, t1=t1, text=s))
    return dict(total=total, hosts=hosts, bubbles=bubbles, subs=subs)

# ================================================================ audio
def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(clip_path(n)).astype(np.float64)
            if np.abs(x).max() > 0:
                x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
                if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    # 잔잔하지만 살짝 수상한 분위기: A단조 (Am - F - Dm - E), 느린 템포, 부드러운 사인·삼각파
    bpm = 88; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = [([57, 60, 64], 45), ([53, 57, 60], 41), ([50, 53, 57], 38), ([52, 56, 59], 40)]
    mel = [[76, None, None, 72, None, None, 71, None], [72, None, None, 69, None, None, None, None],
           [74, None, None, 72, None, 69, None, None], [71, None, None, 68, None, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for nn in notes: tone(bgm, t0, bar * 0.98, mtof(nn), 0.014, "sin", decay=bar * 0.9, att=0.08, rel=0.3)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st in (0, 3, 6): tone(bgm, T, e * 1.4, mtof(root - 12), 0.10, "tri", decay=0.35)
            tone(bgm, T, e * 0.5, mtof(notes[st % 3] + 12), 0.008, "sq", 0.25, decay=0.08)
            if mm[st] and b % 2 == 1: tone(bgm, T, e * 2.2, mtof(mm[st]), 0.020, "sin", decay=0.6, att=0.01)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt in (0, 2): tone(bgm, T, 0.12, 110, 0.10, "sin", f1=45, decay=0.07)
            tone(bgm, T + e, 0.02, 0, 0.012, "noise", decay=0.008)
    ie = int(total * SR); fo = int(1.6 * SR); fi = int(0.2 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.05, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.03, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def pop(T): tone(sfx, T, 0.06, 600, 0.04, "sq", 0.5, f1=1300, decay=0.04)
    def bpop(T): tone(sfx, T, 0.07, 500, 0.03, "sin", f1=1100, decay=0.05)
    def tick(T): tone(sfx, T, 0.03, 1500, 0.025, "sq", 0.5, decay=0.015)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.12, "noise", decay=0.05)
    def creep(T): tone(sfx, T, 0.5, 400, 0.025, "sin", f1=180, decay=0.45)
    for k in range(1, len(scenes)): swoosh(S[k] - 0.05)
    for k, sc in enumerate(scenes):
        if sc["host"]:
            for i in range(len(sc["subs"])): bpop(S[k] + sc["seg"][i] - 0.04)
        fn = sc["fn"].__name__
        if fn == "s_split":
            for ta in split_times(sc["seg"], sc["dur"]): pop(S[k] + ta)
        if fn == "s_ytd":
            L = sc["dur"] - TAIL - 0.15 - sc["seg"][0]; Te = sc["seg"][0] + 0.72 * L
            creep(S[k] + sc["seg"][0] + 0.45 * L); pop(S[k] + Te); stampfx(S[k] + Te + 0.35)
        if fn == "s_why1":
            ta, tb = why1_times(sc["seg"], sc["dur"]); pop(S[k] + ta); pop(S[k] + tb); thump(S[k] + tb + 0.25)
        if fn == "s_why2":
            L = sc["dur"] - TAIL - 0.15 - sc["seg"][0]; pop(S[k] + sc["seg"][0] + 0.42 * L - 0.1); pop(S[k] + sc["seg"][0] + 0.42 * L + 0.5); thump(S[k] + sc["seg"][0] + 0.80 * L)
        if fn == "s_counter":
            L = sc["dur"] - TAIL - 0.15 - sc["seg"][0]
            for i in range(3): tick(S[k] + 0.5 + i * 0.7)
            pop(S[k] + sc["seg"][0] + 0.55 * L)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.58 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    g = 0.89 / max(1e-6, np.abs(mix).max()); mix = mix * g
    for p, a, ch in ((path, mix, 2), (path.replace(".wav", "_narr.wav"), nv * g, 1)):
        pcm = (np.clip(a, -1, 1) * 32767).astype(np.int16)
        with wave.open(p, "wb") as w:
            w.setnchannels(ch); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes() if ch == 1 else np.repeat(pcm[:, None], 2, axis=1).tobytes())

def render_px(T, scenes, starts, total):
    k = min(max(i for i in range(len(scenes)) if starts[i] <= T + 1e-9), len(scenes) - 1)
    t = T - starts[k]; sc = scenes[k]
    low = render_low(sc, t)
    if k > 0 and t < TR:
        prev = render_low(scenes[k - 1], scenes[k - 1]["dur"] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T > total - 0.8: a = (a * clamp((total - T) / 0.8)).astype(np.uint8)
    return Image.fromarray(a)

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    placeholder_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    json.dump(spec(scenes, starts, total), open(f"{OUT}/spec.json", "w"), ensure_ascii=False, indent=1)
    if mode == "times":
        for k, s in enumerate(scenes): print(k, s["fn"].__name__, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_px(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    if mode == "audio": sys.exit()
    n = int(total * FPS); os.makedirs(f"{OUT}/px", exist_ok=True)
    for i in range(n):
        render_px(i / FPS, scenes, starts, total).save(f"{OUT}/px/{i:05d}.png", compress_level=1)
        if i % 300 == 0: print(i, "/", n, flush=True)
    print("done", total)

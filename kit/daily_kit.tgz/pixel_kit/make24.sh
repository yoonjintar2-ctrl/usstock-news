#!/bin/bash
# make24.sh <vid>  → audio, full, compose, loudnorm
set -e; V=$1; cd /home/claude/pixel_kit; O=d1124_$V/out
rm -rf $O/px
VID=$V python3 d1124_video.py full
python3 host_compose.py $O/spec.json $O/px $O/m $O/mix.wav /home/claude/vid/${V}b-raw.mp4
ffmpeg -y -loglevel error -i /home/claude/vid/${V}b-raw.mp4 -c:v copy -af loudnorm=I=-16:TP=-1.5:LRA=11 -c:a aac -b:a 192k -ar 48000 -movflags +faststart /home/claude/vid/${V}b.mp4
echo FINISHED $V

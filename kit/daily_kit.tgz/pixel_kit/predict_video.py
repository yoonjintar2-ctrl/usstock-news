"""특별편 · 전문가도 주가는 못 맞힌다 + 유튜브 의견에 휩쓸리지 않는 법 (squeeze_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-24 기준):
 · 비즈워치 2025/12/31: 증권사 7곳 2026 코스피 전망 상단 NH 5,500 · KB 5,000 · 신한 5,000 · 삼성 4,900 · 하나 4,650 · 한투 4,600 · 키움 4,500
 · 서울신문 2026/6/18: 코스피 사상 첫 9,000 돌파 9,063.84 마감 · 7월 한 달 -22.19%(전국시민의소리 정리)
 · Yahoo Finance(2022/11 기준 정리, AOL 'Morning Brief'): 2022년 S&P500 전략가 12명 목표 중간값 4,825(최저 4,400) → 실제 2022 종가 3,839.50
   · 2023 목표 중간값 4,000(17명, 최고 4,500) → 실제 2023 종가 4,769.83(+24.2%)
 · CXO Advisory 'Guru Grades': 전문가 68명 · 미국 주식시장 예측 6,582개(1998~2012) · 전체 적중률 46.9%
 · S&P SPIVA U.S. Year-End 2025: 미국 대형주 액티브 펀드 2025년 79%가 S&P500에 못 미침 · 20년 92.89%
상승·하락을 빨강/초록으로 구분하지 않음(사용자 지시): 전망=노랑, 실제=하늘색, 하락 수치는 흰색 글자 + 말로.
실존 인물·특정 유튜버 등장 없음.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, glitch_text, coin, F36, GOLD
from ackman_video import tower, money_bag
from semicrash_video import news_card, qmark, TEAL
from aibubble_video import play_btn
from survive_video import ant, speech, checkmark, xmark, cloud, PINK, MINT
from squeeze_video import CH, chapter_card, with_card, ring

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "predict/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
FC, AC = YEL, CYAN                                                             # 전망 = 노랑, 실제 = 하늘색 (상승/하락 색 아님)

# ================================================================ drawings
def crystal_ball(d, cx, cy, t, r=34, cracked=0.0):
    d.polygon([(cx - 26, cy + r + 14), (cx + 26, cy + r + 14), (cx + 18, cy + r - 2), (cx - 18, cy + r - 2)], fill=dk(GOLD, 0.7), outline=GOLD)
    d.rectangle([cx - 30, cy + r + 14, cx + 30, cy + r + 19], fill=GOLD)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(36, 26, 74), outline=PURP, width=2)
    for k in range(4):                                                          # 안에서 도는 안개
        a = t * 1.6 + k * 1.57; rx = int(r * 0.55 * math.cos(a)); ry = int(r * 0.4 * math.sin(a * 1.3))
        d.ellipse([cx + rx - 6, cy + ry - 4, cx + rx + 6, cy + ry + 4], fill=(90, 70, 160))
    pts = [(cx - 22 + j * 4, cy + int(8 * math.sin(t * 7 + j * 1.9) * math.cos(j * 0.7))) for j in range(12)]   # 제멋대로 흔들리는 차트
    d.line(pts, fill=WHT2, width=1)
    d.ellipse([cx - r + 8, cy - r + 7, cx - r + 16, cy - r + 13], fill=(200, 200, 255))
    if cracked > 0:
        n = int(6 * cracked)
        p = [(cx - 4, cy - r + 2), (cx + 4, cy - 14), (cx - 6, cy - 2), (cx + 6, cy + 8), (cx - 2, cy + 18), (cx + 8, cy + r - 4), (cx + 2, cy + r)]
        d.line(p[:n + 1], fill=WHITE, width=2)

def flip_coin(d, x, y, t, r=16):
    w = max(1, int(r * abs(math.cos(t * 9))))
    face = math.cos(t * 9) > 0
    d.ellipse([x - w, y - r, x + w, y + r], fill=GOLD if face else dk(GOLD, 0.75), outline=dk(GOLD, 0.5))
    if w > 8: d.text((x, y - 6), "앞" if face else "뒤", font=F9, fill=DARK, anchor="ma")

def hbar(d, x, y, v, vmax, wmax, col, h=10, u=1.0):
    w = int(v / vmax * wmax * u)
    d.rectangle([x, y, x + max(1, w), y + h], fill=col)
    return x + w

def monitor(d, x, y, col=CYAN):
    d.rectangle([x, y, x + 40, y + 28], fill=(14, 18, 36), outline=col)
    d.rectangle([x + 16, y + 28, x + 24, y + 33], fill=GRAY); d.rectangle([x + 10, y + 33, x + 30, y + 35], fill=GRAY)

# ================================================================ scenes
def punch_fx(t, t0):
    return {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2)), "flash": 0.3} if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 주가 예측", "내일 주가는?", "누가 맞힐 수 있을까", YEL)
    s1, s2 = seg[1], seg[2]
    if t < s2:
        crystal_ball(d, CX, 186, t, 36, ease(prog(t, s1 + 0.6, s1 + 1.0)) if t > s1 else 0)
        for k in range(3): qmark(d, 60 + k * 65, 132 + (k % 2) * 10, t + k * 0.4)
        if t < s1:
            for k, (x, lb) in enumerate([(50, "전문가"), (176, "유튜버")]):
                if t > 0.6 + k * 0.4:
                    mini_person(d, x, 252, (BLUE, ORG)[k], t, k); d.text((x + 3, 270), lb, font=F9, fill=GRAY, anchor="ma")
                    speech(d, x - 14, 226, ("오른다!", "폭락!")[k], tail_left=True)
        if t > s1 + 1.0:
            stamp_slam(img, CX, 270, "아무도 못 맞힘", WHITE, t, s1 + 1.0, "12", -6)
            debris(d, CX, 200, t, s1 + 0.6, 12, (WHT2, PURP, YEL), 46, 0.7, 5)
    else:
        for k in range(4):
            ts = s2 + 0.2 + k * 0.25
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); x = 36 + k * 46
            d.rectangle([x, 150 + o, x + 40, 200 + o], fill=(14, 18, 36), outline=(CYAN, ORG, PURP, TEAL)[k])
            d.text((x + 20, 156 + o), f"0{k + 1}", font=F24, fill=(CYAN, ORG, PURP, TEAL)[k], anchor="ma")
            d.text((x + 20, 186 + o), "증거", font=F9, fill=WHITE, anchor="ma")
        if t > s2 + 1.3: ant(d, 112, 236, t, "ok")
    fx = {}
    if t > s1: fx.update(punch_fx(t, s1 + 1.0))
    return fx

BROK = [("NH", 5500), ("KB", 5000), ("신한", 5000), ("삼성", 4900), ("하나", 4650), ("한투", 4600), ("키움", 4500)]

def s_kospi(img, d, t, seg, dur):
    header(d, t, "01 · 작년 12월 전망", "코스피 전망 상단", "2026년 · 증권사 7곳", CYAN)
    s1, s2, s3 = seg[1], seg[2], seg[3]
    vmax, x0, wmax = 9500, 64, 146
    d.text((34, 120), "전망 상단", font=F9, fill=FC); d.rectangle([28, 122, 32, 126], fill=FC)
    for i, (nm, v) in enumerate(BROK):
        ts = 0.3 + i * 0.18
        if t < ts: continue
        y = 136 + i * 15
        d.text((34, y), nm, font=F9, fill=WHITE)
        xe = hbar(d, x0, y + 1, v, vmax, wmax, FC, 9, ease(prog(t, ts, ts + 0.4)))
        if t > ts + 0.4: d.text((xe + 3, y), f"{v:,}", font=F9, fill=GRAY)
    if s1 <= t < s2: ring(d, x0 + int(5500 / vmax * wmax), 141, t, s1 + 0.2, YEL)
    if t > s2:
        y = 248
        d.text((34, y - 12), "실제", font=F9, fill=AC); d.rectangle([28, y - 10, 32, y - 6], fill=AC)
        if t < s3:
            u = ease(prog(t, s2 + 0.2, s2 + 1.4)); v = 9064 * u
            xe = hbar(d, x0, y, v, vmax, wmax, AC, 14, 1)
            d.text((34, y + 2), "6/18", font=F9, fill=WHITE)
            d.text((min(xe - 2, 214), y - 13), f"{v:,.0f}", font=F12, fill=AC, anchor="ra")
            d.line([(x0 + int(5500 / vmax * wmax), 132), (x0 + int(5500 / vmax * wmax), y + 16)], fill=YEL)
            if u >= 1: stamp_slam(img, 150, 286, "상단보다 +65%", YEL, t, s2 + 1.5, "12", -6)
        else:
            u = ease(prog(t, s3 + 0.3, s3 + 1.1)); v = lerp(8476, 6595, u)
            xe = hbar(d, x0, y, v, vmax, wmax, WHT2, 14, 1)
            d.text((34, y + 2), "7월", font=F9, fill=WHITE)
            d.text((min(xe - 2, 214), y - 13), f"{v:,.0f}", font=F12, fill=WHITE, anchor="ra")
            if u >= 1: glitch_text(img, 150, 282, "7월 한 달 -22%", F12, WHITE, t, 4 if t < s3 + 1.5 else 0)
    d.text((CX, 304), "비즈워치 2025.12.31 · 서울신문 6.18", font=F9, fill=DIM, anchor="ma")
    return punch_fx(t, s2 + 1.5) if s2 < t < s3 else ({"shake": (int(math.sin(t * 80) * 2), 0)} if s3 + 1.1 < t < s3 + 1.4 else {})

def s_wall(img, d, t, seg, dur):
    header(d, t, "02 · 월가도", "S&P500 연말 전망", "전략가 중간값 vs 실제", ORG)
    s1, s2, s3 = seg[1], seg[2], seg[3]
    if t < s1:
        for k in range(3): tower(d, 40 + k * 56, 150 + (k % 2) * 14, 40, 110 - (k % 2) * 14, (80, 90, 140), None, 0.5)
        for k in range(4):
            if t > 0.4 + k * 0.2: mini_person(d, 56 + k * 42, 272, (BLUE, ORG, PURP, CYAN)[k], t, k)
        if t > 1.2: speech(d, 60, 236, "올해는 4,825!", tail_left=True)
    else:
        def pair(xc, yr, fv, av, ts, lab_a):
            base = 270; sc = 130 / 5200
            if t < ts: return
            u = ease(prog(t, ts, ts + 0.6)); hf = int(fv * sc * u)
            d.rectangle([xc - 30, base - hf, xc - 4, base], fill=FC)
            if u >= 1: d.text((xc - 17, base - hf - 11), f"{fv:,}", font=F9, fill=FC, anchor="ma")
            if t > ts + 0.8:
                u2 = ease(prog(t, ts + 0.8, ts + 1.4)); ha = int(av * sc * u2)
                d.rectangle([xc + 4, base - ha, xc + 30, base], fill=AC)
                if u2 >= 1: d.text((xc + 17, base - ha - 11), f"{av:,}", font=F9, fill=AC, anchor="ma")
            d.text((xc, base + 4), yr, font=F12, fill=WHITE, anchor="ma")
            if t > ts + 1.6: d.text((xc, base + 20), lab_a, font=F9, fill=GRAY, anchor="ma")
        d.rectangle([40, 122, 46, 128], fill=FC); d.text((50, 120), "전망 중간값", font=F9, fill=FC)
        d.rectangle([130, 122, 136, 128], fill=AC); d.text((140, 120), "실제 종가", font=F9, fill=AC)
        d.line([(34, 270), (216, 270)], fill=GRAY)
        pair(80, "2022", 4825, 3839, s1 + 0.2, "예상보다 -20%")
        if t > s2: pair(170, "2023", 4000, 4770, s2 + 0.2, "예상보다 +19%")
        if t > s3:
            xmark(d, 80, 140, WHITE, 14); xmark(d, 170, 140, WHITE, 14)
            if t > s3 + 0.5: ant(d, 112, 140, t, "dazed")
    d.text((CX, 304), "야후파이낸스 정리 · 2021·2022년 말 전망", font=F9, fill=DIM, anchor="ma")
    return {}

def s_guru(img, d, t, seg, dur):
    header(d, t, "03 · 유명 전문가", "적중률 46.9%", "68명 · 예측 6,582개", PURP)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        n = int(68 * ease(prog(t, 0.2, 1.8)))
        for k in range(n):
            x = 38 + (k % 17) * 10; y = 126 + (k // 17) * 18
            mini_person(d, x, y, (BLUE, ORG, PURP, CYAN, TEAL)[k % 5], t, k)
        v = int(6582 * ease(prog(t, 0.4, 2.2)))
        d.text((CX, 210), "공개 예측", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 222), f"{v:,}개", font=F24, fill=WHITE, anchor="ma")
        d.text((CX, 254), "1998 ~ 2012 · 맞았는지 채점", font=F9, fill=GRAY, anchor="ma")
    elif t < s2:
        v = 46.9 * ease(prog(t, s1 + 0.1, s1 + 1.2))
        big_text(img, CX, 140, f"{v:.1f}%", PURP if v < 46.8 else YEL, 2)
        d.rectangle([40, 214, 210, 228], outline=WHT2)
        d.rectangle([42, 216, 42 + int(166 * v / 100), 226], fill=PURP)
        d.line([(125, 210), (125, 232)], fill=WHITE); d.text((125, 234), "50%", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 252), "평균 적중률", font=F12, fill=WHITE, anchor="ma")
    else:
        flip_coin(d, 80, 190, t, 22)
        d.text((80, 220), "동전 50%", font=F12, fill=GOLD, anchor="ma")
        d.text((170, 176), "전문가", font=F12, fill=PURP, anchor="ma"); d.text((170, 192), "46.9%", font=F24, fill=YEL, anchor="ma")
        if t > s2 + 1.0: stamp_slam(img, CX, 262, "동전보다 못함", WHITE, t, s2 + 1.0, "12", -6)
    d.text((CX, 304), "CXO Advisory 'Guru Grades'", font=F9, fill=DIM, anchor="ma")
    return punch_fx(t, s2 + 1.0) if t > s2 else {}

def s_fund(img, d, t, seg, dur):
    header(d, t, "04 · 펀드매니저", "지수를 못 이긴다", "미국 대형주 액티브 펀드", TEAL)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        monitor(d, 72, 150, TEAL); monitor(d, 128, 150, TEAL)
        d.line([(76, 170), (84, 162), (92, 168), (100, 158), (108, 164)], fill=WHT2); d.line([(132, 160), (140, 168), (148, 158), (156, 166), (164, 160)], fill=WHT2)
        mini_person(d, 120, 196, BLUE, t * 3, 1)
        d.rectangle([60, 210, 190, 214], fill=GRAY)
        for k in range(3): qmark(d, 70 + k * 55, 236, t + k * 0.4)
    else:
        frac = 79 if t < s2 else 93
        lab = "2025년 1년" if t < s2 else "20년"
        u = ease(prog(t, (s1 if t < s2 else s2) + 0.1, (s1 if t < s2 else s2) + 1.4))
        nfill = int(frac * u) if t < s2 else int(lerp(79, 93, u))
        for k in range(100):
            x = 62 + (k % 10) * 13; y = 124 + (k // 10) * 13
            d.rectangle([x, y, x + 10, y + 10], fill=GRAY if k < nfill else YEL)
        d.text((CX, 260), lab, font=F12, fill=WHITE, anchor="ma")
        pct = "79%" if t < s2 else "92.89%"
        if u >= 1:
            d.text((CX, 276), f"{pct}가 S&P500보다 못함", font=F12, fill=YEL, anchor="ma")
        d.rectangle([40, 124, 50, 134], fill=GRAY); d.rectangle([40, 140, 50, 150], fill=YEL)
        d.text((36, 154), "짐", font=F9, fill=GRAY); d.text((38, 166), "", font=F9)
        d.text((196, 124), "회색", font=F9, fill=GRAY); d.text((196, 134), "=짐", font=F9, fill=GRAY)
        d.text((196, 148), "노랑", font=F9, fill=YEL); d.text((196, 158), "=이김", font=F9, fill=YEL)
    d.text((CX, 304), "S&P SPIVA · 2025년 말 기준", font=F9, fill=DIM, anchor="ma")
    return {}

def s_why(img, d, t, seg, dur):
    header(d, t, "05 · 왜 못 맞힐까", "미래 뉴스는 모른다", "", CYAN)
    s1, s2 = seg[1], seg[2]
    if t < s2:
        heads = [("내일 속보", "??????"), ("전쟁", "??????"), ("금리", "??????"), ("실적", "??????")]
        for i, (a, b) in enumerate(heads):
            ts = 0.3 + i * 0.3 if i == 0 else s1 + 0.1 + (i - 1) * 0.3
            if t < ts: continue
            vis, o = slam(t, ts, 0.2)
            news_card(d, 34, 122 + i * 26, o, f"{a} : {b}", (CYAN, ORG, PURP, TEAL)[i])
        if t > s1 + 1.2:
            cloud(d, 60, 236); cloud(d, 150, 230)
            d.text((CX, 262), "미리 아는 사람 = 0명", font=F12, fill=WHITE, anchor="ma")
    else:
        mini_person(d, 70, 196, PURP, t, 2)
        money_bag(d, 92, 196, "$")
        speech(d, 40, 160, "쉿!", tail_left=True)
        if t > s2 + 0.6:
            for k in range(3): coin(d, 150 + k * 16, 230 - int(abs(math.sin(t * 4 + k)) * 6), 7, "$")
        if t > s2 + 1.2:
            vis, o = slam(t, s2 + 1.2, 0.2)
            box(d, 34, 250 + o, 216, 286 + o, YEL, (30, 26, 8))
            d.text((CX, 254 + o), "진짜 맞힌다면", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 266 + o), "조용히 혼자 돈 범", font=F12, fill=WHITE, anchor="ma")
    return {}

def s_check(img, d, t, seg, dur):
    header(d, t, "06 · 체크리스트", "휩쓸리지 않는 법", "", YEL)
    rows = [("'무조건·확실' = 경고", "warn", ORG), ("지난 예측 성적표 확인", "chk", CYAN),
            ("조회수·리딩방으로 돈 버나?", "play", PURP), ("남 예측 대신 내 계획·분산", "chk", TEAL)]
    for i, (s, ic, col) in enumerate(rows):
        ts = seg[i] + 0.1 if i < len(seg) else 99
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 122 + i * 40 + o
        d.rectangle([34, y, 216, y + 32], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y, 40, y + 32], fill=col)
        d.text((48, y + 9), s, font=F12 if d.textlength(s, font=F12) < 140 else F9, fill=WHITE)
        if ic == "warn": warn_icon(d, 192, y + 9, YEL)
        elif ic == "play": play_btn(d, 182, y + 6, PURP)
        else: checkmark(d, 194, y + 10, col)
    if t > seg[2] + 1.2: d.text((150, 288), "(이 채널 포함!)", font=F9, fill=YEL, anchor="ma"); ant(d, 52, 270, t, "happy")
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "정리", "예측 말고 대응", "", YEL)
    crystal_ball(d, 70, 176, t, 26, 1.0)
    d.text((70, 222), "예측", font=F12, fill=GRAY, anchor="ma"); xmark(d, 70, 136, WHITE, 12)
    ant(d, 150, 160, t, "happy")
    if t > 0.8:
        vis, o = slam(t, 0.8, 0.2)
        d.rectangle([126, 196 + o, 196, 220 + o], fill=(10, 30, 40), outline=CYAN); d.text((161, 201 + o), "내 계획", font=F12, fill=CYAN, anchor="ma")
    if t > 1.6: stamp_slam(img, CX, 262, "대응은 할 수 있다", YEL, t, 1.6, "12", -6)
    d.text((32, 306), "※ 교육용 콘텐츠 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.6)

SCRIPT = [
    (s_hook, [("내일 주가, 누가 맞힐 수 있을까?", "내일 주가, 누가 맞힐 수 있을까요?"),
              ("정답: 아무도 못 맞혀요\n아무리 유능한 전문가라도요", "정답은, 아무도 못 맞힌다예요. 아무리 유능한 전문가라도요."),
              ("증거 4개, 바로 보여드릴게요", "증거 네 개를 바로 보여드릴게요.")]),
    (with_card(s_kospi, "01", "증권사 전망", CYAN), [
        ("작년 12월 증권사 7곳이 낸\n2026년 코스피 전망 상단이에요", "작년 십이월, 증권사 일곱 곳이 낸 올해 코스피 전망 상단이에요."),
        ("가장 높게 본 곳도 5,500이었는데", "가장 높게 본 곳도 오천오백이었는데,"),
        ("6월 18일 실제 코스피는 9,063!\n상단보다 65%나 더 올랐어요", "유월 십팔 일, 실제 코스피는 구천육십삼. 상단보다 육십오 퍼센트나 더 올랐죠."),
        ("그리고 7월 한 달에만 22% 빠졌죠", "그리고 칠월 한 달에만, 이십이 퍼센트 빠졌어요.")]),
    (with_card(s_wall, "02", "월가 전망", ORG), [
        ("월가 전략가들도 마찬가지예요", "월가의 전략가들도 마찬가지예요."),
        ("2022년 S&P500 전망 중간값 4,825\n실제로는 3,839로 끝났어요", "이천이십이 년, 에스앤피 오백 전망 중간값은 사천팔백이십오. 실제로는 삼천팔백삼십구로 끝났어요."),
        ("2023년엔 4,000을 예상했는데\n실제로는 4,770, 1년에 +24%", "이천이십삼 년엔 사천을 예상했는데, 실제로는 사천칠백칠십. 한 해에 이십사 퍼센트나 올랐죠."),
        ("한 해는 너무 낙관, 다음 해는 너무 비관", "한 해는 너무 낙관했고, 다음 해는 너무 비관했어요.")]),
    (with_card(s_guru, "03", "전문가 적중률", PURP), [
        ("유명 시장 전문가 68명이 공개한\n예측 6,582개를 채점한 연구", "유명 시장 전문가 육십팔 명이 공개적으로 한 예측, 육천오백팔십이 개를 채점한 연구가 있어요."),
        ("평균 적중률은 46.9%", "평균 적중률은, 사십육 점 구 퍼센트."),
        ("동전 던지기(50%)보다도 낮아요", "동전 던지기보다도 낮은 수준이에요.")]),
    (with_card(s_fund, "04", "펀드매니저", TEAL), [
        ("매일 시장만 보는 펀드매니저는?", "그럼 매일 시장만 보는 펀드매니저는 어떨까요?"),
        ("2025년 미국 대형주 액티브 펀드의\n79%가 S&P500보다 못했어요", "작년 한 해, 미국 대형주 액티브 펀드의 칠십구 퍼센트가, 에스앤피 오백보다 못했어요."),
        ("20년으로 넓히면 92.89%가 졌어요", "이십 년으로 넓히면, 구십이 점 팔구 퍼센트가 졌어요.")]),
    (with_card(s_why, "05", "왜 못 맞힐까", CYAN), [
        ("주가는 아직 안 나온 뉴스로 움직여요", "주가는 아직 나오지 않은 뉴스로 움직이기 때문이에요."),
        ("전쟁·금리·실적, 미리 아는 사람은 없어요", "전쟁, 금리, 실적 발표를, 미리 아는 사람은 없죠."),
        ("진짜 맞힐 수 있다면?\n알려주지 않고 조용히 혼자 벌겠죠", "진짜로 맞힐 수 있는 사람이 있다면, 굳이 알려주지 않고, 조용히 혼자 돈을 벌겠죠.")]),
    (with_card(s_check, "06", "휩쓸리지 않기", YEL), [
        ("'무조건·확실·100%'가 나오면 경고!", "무조건, 확실하다, 백 퍼센트라는 말이 나오면, 경고 신호예요."),
        ("예전 예측이 맞았는지 성적표 확인", "그 사람이 예전에 한 예측이 맞았는지, 성적표를 찾아보세요."),
        ("조회수·리딩방·강의로 돈을 번다면\n한 번 더 의심 (이 채널 포함!)", "조회수나 유료 리딩방, 강의 판매로 돈을 번다면, 한 번 더 의심하세요. 이 채널도 포함해서요!"),
        ("남의 예측 대신, 내 계획과 분산으로", "그리고 남의 예측 대신, 나만의 계획과 분산 투자로 대응하세요.")]),
    (s_end, [("주가는 아무도 몰라요\n하지만 대응은 우리가 할 수 있어요", "주가는 아무도 모릅니다. 하지만 대응은, 우리가 할 수 있어요.")]),
]
TITLES = ["", "코스피 전망 상단", "S&P500 연말 전망", "적중률 46.9%", "지수를 못 이긴다", "미래 뉴스는 모른다", "휩쓸리지 않는 법", "예측 말고 대응"]


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    MINLINE = {(0, 1): 2.6, (1, 2): 3.2, (1, 3): 2.4, (2, 1): 3.0, (2, 2): 3.0, (3, 0): 2.6, (3, 2): 2.6, (4, 1): 2.6, (4, 2): 2.6, (5, 2): 2.8, (7, 0): 3.4}
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (CH + 0.5 if k < len(SCRIPT) - 1 else 0.3)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += max(L, MINLINE.get((k, i), 0)) + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.4, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    # 탐정풍 D단조 칩튠(120bpm) → 체크리스트부터 F장조
    bpm = 120; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([62, 65, 69], 50), ([58, 62, 65], 46), ([60, 64, 67], 48), ([57, 61, 64], 45)]   # Dm Bb C A
    prog_major = [([65, 69, 72], 53), ([60, 64, 67], 48), ([62, 65, 69], 50), ([58, 62, 65], 46)]   # F C Dm Bb
    mel_m = [[74, None, 77, 76, 74, None, 69, None], [70, None, 74, None, 77, 76, 74, None], [72, None, 76, 79, 76, None, 72, None], [73, None, 69, None, 76, None, None, None]]
    mel_M = [[77, None, 81, 84, 81, None, 77, None], [76, None, 79, None, 84, 83, 79, None], [74, None, 77, 81, 77, None, 74, None], [74, 72, 70, None, 69, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = t0 >= S[6]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.15, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and T > 2.0: tone(bgm, T, e * 0.8, mtof(m), 0.028, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.28, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.08, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def glass(T):
        for j in range(5): tone(sfx, T + j * 0.04, 0.2, 2400 + j * 330, 0.04, "sin", decay=0.15)
        tone(sfx, T, 0.25, 0, 0.09, "noise", decay=0.1)
    def mystic(T, d=1.6):
        for j in range(6): tone(sfx, T + j * 0.18, 0.4, mtof(74 + (j * 5) % 12), 0.025, "sin", decay=0.35)
    def flipfx(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.1, 0.03, 2200 if j % 2 else 1800, 0.035, "sq", 0.5, decay=0.02)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.06, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.03, "sin", decay=0.2)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    # hook
    typing(S[0] + 0.1, "내일주가는"); mystic(S[0] + 0.3)
    pop(S[0] + 0.6); pop(S[0] + 1.0)
    glass(sg(0, 1) + 0.6); stampfx(sg(0, 1) + 1.0)
    for k in range(4): pop(sg(0, 2) + 0.2 + k * 0.25)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k]); swoosh(S[k] + CH - 0.25); typing(S[k] + CH + 0.6, TITLES[k])
        else: swoosh(S[k]); typing(S[k] + 0.3, TITLES[k])
    # 01 kospi
    for i in range(7): pop(S[1] + CH + 0.3 + i * 0.18)
    lock(sg(1, 1) + 0.2)
    rise(sg(1, 2) + 0.2, 1.2); stampfx(sg(1, 2) + 1.5)
    fall(sg(1, 3) + 0.3, 0.8); glitch(sg(1, 3) + 1.1, 6)
    # 02 wall
    for k in range(4): pop(S[2] + CH + 0.4 + k * 0.2)
    for k in (1, 2):
        pop(sg(2, k) + 0.2); ding(sg(2, k) + 1.0); thump(sg(2, k) + 1.4)
    tone(sfx, sg(2, 3) + 0.2, 0.45, 180, 0.08, "sq", 0.5, f1=900, decay=0.4)
    # 03 guru
    for k in range(12): blip(S[3] + CH + 0.2 + k * 0.13, 1200 + k * 40)
    rise(sg(3, 1) + 0.1, 1.1); ding(sg(3, 1) + 1.2)
    flipfx(sg(3, 2), 10); stampfx(sg(3, 2) + 1.0)
    # 04 fund
    for k in range(6): blip(S[4] + CH + 0.3 + k * 0.3, 900)
    for k in range(10): blip(sg(4, 1) + 0.1 + k * 0.13, 700)
    for k in range(6): blip(sg(4, 2) + 0.1 + k * 0.2, 600); ding(sg(4, 2) + 1.5)
    # 05 why
    pop(S[5] + CH + 0.3); pop(sg(5, 1) + 0.1); pop(sg(5, 1) + 0.4); pop(sg(5, 1) + 0.7)
    tone(sfx, sg(5, 2), 0.5, 0, 0.05, "noise", decay=0.4)
    for k in range(3): coin_s(sg(5, 2) + 0.6 + k * 0.2)
    thump(sg(5, 2) + 1.2)
    # 06 check
    for i in range(4): pop(sg(6, i) + 0.1); ding(sg(6, i) + 0.3)
    # end
    glass(S[7] + 0.2); pop(S[7] + 0.8); stampfx(S[7] + 1.6)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "scan":
        from nike_video import render_low
        for k, s in enumerate(scenes):
            for i in range(int(s["dur"] * FPS) + 1): render_low(s, i / FPS)
        print("scan ok"); sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

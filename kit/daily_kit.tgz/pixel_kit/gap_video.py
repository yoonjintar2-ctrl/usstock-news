import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, person, warn_icon, render_frame, dk, SKIN, DARK)
from mid_video import eout

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "gap/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
BROWN = (200, 130, 50); NAVY = (14, 20, 52); SKY = (90, 150, 220)

# ================================================================ drawings
def candle(d, x, o, c, hi, lo, up=True, w=14):
    col = SRED if up else BLUE        # Korean convention: up = red, down = blue
    d.line([(x + w // 2, hi), (x + w // 2, lo)], fill=col, width=2)
    top, bot = min(o, c), max(o, c)
    d.rectangle([x, top, x + w, max(bot, top + 2)], fill=col)

def moon(d, x, y, r=9):
    d.ellipse([x - r, y - r, x + r, y + r], fill=(250, 240, 180))
    d.ellipse([x - r + 6, y - r - 2, x + r + 6, y + r - 2], fill=NAVY)

def stars(d, x0, y0, x1, y1, t, n=7):
    for k in range(n):
        x = x0 + (k * 37) % (x1 - x0); y = y0 + (k * 23) % (y1 - y0)
        if (t * 2 + k * 0.7) % 2 < 1.4: d.point((x, y), fill=WHITE); d.point((x + 1, y), fill=(200, 200, 255))

def sun(d, x, y, r=10, t=0):
    d.ellipse([x - r, y - r, x + r, y + r], fill=YEL)
    d.ellipse([x - r + 3, y - r + 3, x + r - 3, y + r - 3], fill=(255, 230, 120))

def newspaper(d, x, y, s="실적 대박!"):
    d.rectangle([x, y, x + 56, y + 32], fill=WHITE, outline=GRAY)
    d.rectangle([x + 3, y + 3, x + 53, y + 13], fill=SRED)
    d.text((x + 28, y + 4), s, font=F9, fill=WHITE, anchor="ma")
    for i in range(3): d.line([(x + 4, y + 17 + i * 5), (x + 52 - (i % 2) * 14, y + 17 + i * 5)], fill=GRAY)

def phone(d, x, y, t, buzz=True):
    dx = int(math.sin(t * 40) * 1) if buzz else 0
    d.rounded_rectangle([x + dx, y, x + 16 + dx, y + 28], radius=3, fill=DARK, outline=WHT2)
    d.rectangle([x + 2 + dx, y + 3, x + 14 + dx, y + 22], fill=(40, 90, 160))
    d.text((x + 8 + dx, y + 7), "!", font=F12, fill=YEL, anchor="ma")
    if buzz:
        d.line([(x - 4, y + 6), (x - 2, y + 10)], fill=YEL); d.line([(x + 20, y + 6), (x + 18, y + 10)], fill=YEL)

def shopdoor(d, x, y, t):
    d.rectangle([x, y, x + 34, y + 46], fill=(70, 40, 30), outline=WHT2)
    d.rectangle([x + 4, y + 6, x + 30, y + 40], fill=(40, 60, 90))
    d.rectangle([x + 6, y + 14, x + 28, y + 22], fill=YEL)
    d.text((x + 17, y + 14), "OPEN", font=F9, fill=DARK, anchor="ma")

def mini_person(d, x, y, col, t=0, k=0):
    b = int(abs(math.sin(t * 6 + k)) * 2)
    d.rectangle([x + 1, y - b, x + 5, y + 4 - b], fill=SKIN)
    d.rectangle([x, y + 5 - b, x + 6, y + 13 - b], fill=col)
    d.line([(x + 1, y + 14), (x + 1, y + 17)], fill=GRAY); d.line([(x + 5, y + 14), (x + 5, y + 17)], fill=GRAY)

def bungeo(d, x, y, s=1.0, col=BROWN):
    """붕어빵 (fish-shaped pastry), facing left"""
    w, h = int(40 * s), int(22 * s)
    d.ellipse([x, y, x + w, y + h], fill=col, outline=dk(col, 0.6))
    d.polygon([(x + w - 4, y + h // 2), (x + w + int(12 * s), y), (x + w + int(12 * s), y + h)], fill=col, outline=dk(col, 0.6))
    d.ellipse([x + int(6 * s), y + int(6 * s), x + int(10 * s), y + int(10 * s)], fill=DARK)
    for i in range(3):
        cx = x + int((16 + i * 7) * s)
        d.arc([cx - 4, y + int(5 * s), cx + 4, y + int(15 * s)], 270, 90, fill=dk(col, 0.7))
    d.line([(x + int(3 * s), y + int(14 * s)), (x + int(8 * s), y + int(16 * s))], fill=dk(col, 0.55))

def tv(d, x, y, t, on=True):
    d.rectangle([x, y, x + 52, y + 38], fill=(40, 40, 50), outline=WHT2)
    d.rectangle([x + 4, y + 4, x + 48, y + 30], fill=(30, 80, 140) if on else DARK)
    d.line([(x + 18, y - 8), (x + 24, y)], fill=GRAY); d.line([(x + 34, y - 8), (x + 28, y)], fill=GRAY)
    d.rectangle([x + 20, y + 38, x + 32, y + 41], fill=GRAY)
    if on:
        bungeo(d, x + 8, y + 9, 0.55)
        if blink(t, 2): d.rectangle([x + 4, y + 24, x + 48, y + 30], fill=SRED)
        d.text((x + 26, y + 24), "맛집 방송", font=F9, fill=WHITE, anchor="ma")

def gap_box(d, x0, y0, x1, y1, t, col=YEL, label="GAP"):
    c = col if blink(t, 3) else dk(col, 0.6)
    for x in range(int(x0), int(x1), 4): d.point((x, y0), fill=c); d.point((x, y1), fill=c)
    for y in range(int(y0), int(y1), 4): d.point((x0, y), fill=c); d.point((x1, y), fill=c)
    if label: d.text(((x0 + x1) / 2, (y0 + y1) / 2 - 5), label, font=F9, fill=col, anchor="ma")

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "주식 용어 1분 사전", "갭상승", "GAP UP", YEL)
    box(d, SX0 + 2, 128, SX1 - 4, 300, DIM)
    # yesterday candle
    candle(d, 60, 236, 210, 204, 246, True, 16)
    d.text((68, 252), "어제", font=F9, fill=GRAY, anchor="ma")
    # today candle jumps over
    u = prog(t, 0.6, 1.4)
    tx = lerp(60, 150, ease(u)); hop = math.sin(math.pi * u) * 50
    ty_off = lerp(0, -70, ease(u)) - hop
    if u > 0:
        candle(d, tx, 236 + ty_off, 210 + ty_off, 204 + ty_off, 246 + ty_off, True, 16)
    if u >= 1:
        d.text((172, 150), "오늘", font=F9, fill=GRAY)
        gap_box(d, 46, 177, 204, 202, t)
    if 0.55 < t < 0.9:
        for k in range(4): square(d, 58 + k * 6, 244 + (k % 2) * 2, GRAY, 2)
    debris(d, 158, 178, t, 1.4, 12, (YEL, WHITE, SRED), 40, 0.6, 3)
    if t > 1.6: d.text((CX, 140), "점프!", font=F12, fill=YEL, anchor="ma")
    if t > seg[1]:
        stamp_slam(img, CX, 274, "이게 갭상승!", SRED, t, seg[1] + 0.3, "12", -6)
        debris(d, CX, 274, t, seg[1] + 0.3, 14, (YEL, SRED, WHITE), 50, 0.8, 5)
    fx = {}
    if 1.4 < t < 1.6: fx["shake"] = (0, int(math.sin(t * 80) * 2))
    if seg[1] + 0.3 < t < seg[1] + 0.42: fx["flash"] = 0.35
    return fx

def s_what(img, d, t, seg, dur):
    header(d, t, "WHAT", "빈칸이 생긴다", "어제 마지막 vs 오늘 처음", CYAN)
    bx0, by0, bx1, by1 = SX0 + 2, 128, SX1 - 4, 300
    box(d, bx0, by0, bx1, by1, DIM)
    # night band between candles
    nb0, nb1 = 92, 146
    nu = prog(t, 0.6, 1.2)
    if nu > 0:
        d.rectangle([nb0, by0 + 2, nb1, by1 - 2], fill=NAVY)
        moon(d, 119, 150); stars(d, nb0 + 4, by0 + 30, nb1 - 4, by1 - 20, t)
        d.text((119, 280), "장 마감", font=F9, fill=GRAY, anchor="ma")
    candle(d, 52, 262, 226, 220, 272, True, 16)
    if t > 0.3:
        d.line([(70, 226), (90, 226)], fill=WHITE)
        d.text((60, 210), "어제 마지막", font=F9, fill=WHITE, anchor="ma")
    if t > 1.4:
        vis, o = slam(t, 1.4, 0.2)
        candle(d, 160, 176 + o, 146 + o, 140 + o, 184 + o, True, 16)
        d.line([(146, 176), (158, 176)], fill=WHITE)
        d.text((182, 131), "오늘 처음", font=F9, fill=WHITE, anchor="ra")
    if t > seg[1]:
        gap_box(d, 52, 186, 206, 218, t, YEL, "")
        vis, o = slam(t, seg[1] + 0.3, 0.2)
        if vis:
            d.rectangle([60, 194 + o, 190, 210 + o], fill=(30, 26, 8), outline=YEL)
            d.text((CX, 197 + o), "빈칸 = 갭(GAP)", font=F12, fill=YEL, anchor="ma")
    d.text((CX, 304), "※ 엄밀히는 전날 고가 위에서 시작할 때", font=F9, fill=DIM, anchor="ma")
    fx = {}
    if seg[1] + 0.3 < t < seg[1] + 0.42: fx["flash"] = 0.3
    return fx

def s_why(img, d, t, seg, dur):
    header(d, t, "WHY", "밤사이 호재", "자는 동안 무슨 일이?", PURP)
    x0, y0, x1, y1 = SX0 + 2, 128, SX1 - 4, 300
    day = ease(prog(t, seg[1], seg[1] + 1.0))
    bg = tuple(int(lerp(a, b, day)) for a, b in zip(NAVY, SKY))
    d.rectangle([x0, y0, x1, y1], fill=bg, outline=DIM)
    d.rectangle([x0 + 1, 262, x1 - 1, y1 - 1], fill=tuple(int(lerp(a, b, day)) for a, b in zip((20, 30, 30), (60, 120, 60))))
    if day < 1:
        my = lerp(150, 230, day); moon(d, 60, int(my))
        if day < 0.5: stars(d, x0 + 4, y0 + 6, x1 - 4, 220, t, 10)
    if day > 0:
        sy = lerp(270, 150, day); sun(d, 190, int(sy))
    if t < seg[1] + 0.4:
        # news flying in, phones buzzing
        u = ease(prog(t, 0.4, 1.0))
        newspaper(d, int(lerp(230, 110, u)), 160)
        if t > 1.2:
            phone(d, 70, 214, t); phone(d, 100, 222, t + 0.3); phone(d, 160, 216, t + 0.6)
        if t > 1.6:
            d.text((CX, 206), "실적 발표 · 신제품 · 인수합병", font=F9, fill=WHITE, anchor="ma")
    else:
        shopdoor(d, 170, 216, t)
        cols = [CYAN, GRN, YEL, PURP, ORG, WHT2, SRED]
        for k in range(7):
            ts = seg[1] + 0.6 + k * 0.15
            if t < ts: continue
            x = lerp(x0 - 10, 150 - k * 15, ease(prog(t, ts, ts + 0.5)))
            mini_person(d, x, 244, cols[k], t, k)
        if t > seg[1] + 1.5:
            vis, o = slam(t, seg[1] + 1.5)
            d.rectangle([44, 140 + o, 150, 168 + o], fill=WHITE, outline=SRED)
            d.text((97, 144 + o), "시작가부터", font=F9, fill=DARK, anchor="ma")
            d.text((97, 155 + o), "비싸게!", font=F12, fill=SRED, anchor="ma")
    return {}

def s_example(img, d, t, seg, dur):
    header(d, t, "EXAMPLE", "붕어빵 주식회사", "※ 가상의 예시예요", ORG)
    # top row: yesterday card | TV | today card
    if t > 0.3:
        vis, o = slam(t, 0.3, 0.2)
        d.rectangle([32, 130 + o, 92, 196 + o], fill=(10, 14, 30), outline=GRAY)
        d.text((62, 134 + o), "어제 종가", font=F9, fill=GRAY, anchor="ma")
        bungeo(d, 40, 150 + o, 0.85)
        d.text((62, 180 + o), "10,000원", font=F9, fill=WHITE, anchor="ma")
    if t > seg[1]:
        tv(d, 99, 148, t, True)
        d.text((125, 192), "밤사이", font=F9, fill=PURP, anchor="ma")
        for k in range(5):
            ph = ((t - seg[1]) * 1.4 + k * 0.2) % 1
            square(d, 104 + k * 9, 144 - ph * 14, YEL, 2)
    if t > seg[1] + 1.4:
        vis, o = slam(t, seg[1] + 1.4, 0.2)
        d.rectangle([158, 130 + o, 218, 196 + o], fill=(30, 10, 14), outline=SRED)
        d.text((188, 134 + o), "오늘 시가", font=F9, fill=GRAY, anchor="ma")
        bungeo(d, 166, 150 + o, 0.85)
        d.text((188, 180 + o), "12,000원", font=F9, fill=YEL, anchor="ma")
        for k in range(3):
            ph = ((t - seg[1]) * 2 + k * 0.33) % 1
            d.text((172 + k * 12, 150 - ph * 10), "~", font=F9, fill=WHT2)
    # bottom mini chart
    if t > seg[1] + 1.8:
        box(d, 32, 206, 218, 300, DIM)
        candle(d, 70, 284, 262, 258, 290, True, 14)
        candle(d, 150, 238, 220, 214, 242, True, 14)
        gap_box(d, 62, 244, 172, 256, t, YEL, "")
        d.text((77, 292), "1만", font=F9, fill=GRAY, anchor="ma"); d.text((157, 244), "1만2천", font=F9, fill=GRAY, anchor="ma")
        st = seg[2] if len(seg) > 2 else seg[1] + 2.2
        stamp_slam(img, 112, 226, "+20% 갭상승", SRED, t, st, "12", -6)
        debris(d, 112, 226, t, st, 16, (YEL, SRED, WHITE), 55, 0.9, 8)
        confetti(d, t, st + 0.2, 10, (YEL, ORG, SRED), 206, 298)
    fx = {}
    st = seg[2] if len(seg) > 2 else seg[1] + 2.2
    if st < t < st + 0.12: fx["flash"] = 0.35
    if st < t < st + 0.3: fx["zoom"] = 1 + 0.05 * (1 - prog(t, st, st + 0.3))
    return fx

def s_caution(img, d, t, seg, dur):
    header(d, t, "CAUTION", "갭 메우기", "들뜬 기대가 식으면", SRED)
    bx0, by0, bx1, by1 = SX0 + 2, 128, SX1 - 4, 270
    box(d, bx0, by0, bx1, by1, DIM)
    candle(d, 44, 250, 226, 220, 258, True, 12)
    candle(d, 66, 182, 160, 154, 188, True, 12)
    gx0, gy0, gx1, gy1 = 40, 190, 214, 218
    seq = [(88, 168, 186, False), (110, 184, 198, False), (132, 196, 208, False), (154, 206, 220, False), (176, 214, 226, False)]
    n = int(prog(t, 0.5, seg[1] + 1.0) * len(seq))
    fill_to = gy0
    for i in range(n):
        x, o_, c_, up = seq[i]
        candle(d, x, o_, c_, o_ - 4, c_ + 5, up, 12)
        fill_to = max(fill_to, min(c_, gy1))
    if fill_to > gy0:
        for yy in range(gy0 + 1, int(fill_to), 2): d.line([(gx0 + 1, yy), (gx1 - 1, yy)], fill=(80, 30, 40))
    gap_box(d, gx0, gy0, gx1, gy1, t, YEL, "" if n else "GAP")
    if n >= len(seq):
        d.text((CX, 232), "빈칸이 다시 채워짐", font=F9, fill=YEL, anchor="ma")
    if t > seg[1]:
        stamp_slam(img, CX, 290, "추격매수 주의", SRED, t, seg[1] + 1.2, "12", -6)
        debris(d, CX, 290, t, seg[1] + 1.2, 12, (SRED, WHITE), 50, 0.8, 4)
        warn_icon(d, 36, 280); warn_icon(d, 198, 280)
    fx = {}
    if seg[1] + 1.2 < t < seg[1] + 1.4: fx["shake"] = (int(math.sin(t * 70) * 2), 0)
    return fx

def s_outro(img, d, t, seg, dur):
    header(d, t, "SUMMARY", "오늘의 용어", "갭상승 · 갭하락 · 갭 메우기", YEL)
    rows = [("갭상승", "어제보다 높게 출발", SRED, "▲"), ("갭하락", "어제보다 낮게 출발", BLUE, "▼"), ("갭 메우기", "빈칸을 다시 채움", YEL, "■")]
    for i, (a, b, c, ic) in enumerate(rows):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 132 + i * 34
        d.rectangle([34, y + o, 216, y + 28 + o], fill=(10, 14, 30), outline=c)
        d.text((42, y + 7 + o), ic, font=F12, fill=c)
        d.text((58, y + 7 + o), a, font=F12, fill=c)
        d.text((210, y + 9 + o), b, font=F9, fill=WHITE, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([60, 244 + o, 190, 274 + o], fill=(8, 24, 14), outline=GRN if blink(t, 2) else YEL)
            d.text((CX, 249 + o), "다음 용어는?", font=F12, fill=GRN, anchor="ma")
            d.text((CX, 263 + o), "NEXT EPISODE", font=F9, fill=GRAY, anchor="ma")
        for k in range(3):
            if blink(t + k * 0.3, 2): d.text((44 + k * 70, 282), "?", font=F24, fill=WHT2)
    d.text((CX, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM, anchor="ma")
    return {}

SCRIPT = [
    (s_hook, [("아침에 주식 앱을 켰더니\n시작부터 훌쩍 올라 있다?", "아침에 주식 앱을 켰더니, 시작부터 훌쩍 올라 있다?"),
              ("이게 바로 갭상승이에요", "이게 바로, 갭상승이에요.")]),
    (s_what, [("어제 마지막 가격보다\n오늘 첫 가격이 훨씬 높으면", "어제 마지막 가격보다, 오늘 첫 가격이 훨씬 높게 시작하면,"),
              ("차트에 빈칸이 생겨요\n이 빈칸이 바로 '갭'이죠", "차트에 빈칸이 생겨요. 이 빈칸이 바로 갭이죠.")]),
    (s_why, [("장이 닫힌 밤사이\n실적 발표 같은 호재가 나오면", "장이 닫힌 밤사이, 실적 발표 같은 큰 호재가 나오면,"),
             ("아침에 사려는 사람이 몰려서\n처음부터 비싸게 거래되는 거예요", "아침에 사려는 사람이 몰려서, 처음부터 비싸게 거래되는 거예요.")]),
    (s_example, [("예를 들어 어제 1만 원에 끝난\n붕어빵 주식회사가", "예를 들어, 어제 만 원에 끝난 붕어빵 주식회사가,"),
                 ("밤새 맛집 방송을 타고\n오늘 1만 2천 원에 시작하면", "밤새 맛집 방송을 타고, 오늘 만 이천 원에 시작하면,"),
                 ("20% 갭상승이에요!", "이십 퍼센트 갭상승이에요!")]),
    (s_caution, [("다만 들뜬 기대가 식으면\n가격이 내려와 빈칸을 채우기도 해요", "다만 들뜬 기대가 식으면, 가격이 내려와 빈칸을 채우기도 해요."),
                 ("이걸 갭 메우기라고 해요\n무작정 따라 사는 건 조심!", "이걸 갭 메우기라고 해요. 무작정 따라 사는 건 조심!")]),
    (s_outro, [("반대로 낮게 시작하면\n갭하락이에요", "반대로 낮게 시작하면, 갭하락이에요."),
               ("다음 주식 용어도\n쉽게 알려드릴게요!", "다음 주식 용어도, 쉽게 알려드릴게요!")]),
]
TITLES = ["", "빈칸이 생긴다", "밤사이 호재", "붕어빵 주식회사", "갭 메우기", "오늘의 용어"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # playful bouncy BGM: G major, 128 bpm, staccato
    bpm = 128; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    major = [([67, 71, 74], 43), ([64, 67, 71], 40), ([60, 64, 67], 48), ([62, 66, 69], 50)]   # G Em C D
    minor = [([64, 67, 71], 40), ([60, 64, 67], 48), ([57, 60, 64], 45), ([59, 62, 66], 47)]
    mel = [[79, None, 83, 81, 79, None, 76, 74], [76, None, 79, None, 74, 76, 71, None],
           [72, None, 76, 79, 76, None, 72, 74], [74, 76, 78, None, 81, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        caution = S[4] <= t0 < S[5]
        notes, root = (minor if caution else major)[b % 4]
        for st in range(16):
            T = t0 + st * s16
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, s16 * 0.7, mtof(notes[(st // 2) % 3] + 12), 0.045, "sq", 0.25, decay=0.05)
            if st % 2 == 0: tone(bgm, T, 0.03, 0, 0.028 if st % 4 else 0.016, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0 or caution: tone(bgm, T, e * 0.6, mtof(root - 12 + (7 if st % 4 == 2 else 0)), 0.17, "tri")
            m = mel[b % 4][st]
            if m and not caution and T > S[1]: tone(bgm, T, e * 0.8, mtof(m - 12), 0.04, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2): tone(bgm, T, 0.16, 150, 0.32, "sin", f1=45, decay=0.07)
            if bt in (1, 3) and not caution:
                tone(bgm, T, 0.1, 0, 0.1, "noise", decay=0.035); tone(bgm, T, 0.06, 220, 0.06, "tri", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def boing(T): tone(sfx, T, 0.5, 180, 0.08, "sq", 0.5, f1=900, decay=0.3)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def buzz(T): tone(sfx, T, 0.25, 140, 0.04, "sq", 0.5, decay=0.2)
    def rooster(T):
        for j, (f0, f1) in enumerate([(700, 1100), (1100, 900), (900, 1400)]): tone(sfx, T + j * 0.14, 0.14, f0, 0.05, "sq", 0.5, f1=f1)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    typing(S[0] + 0.1, "갭상승GAPUP"); boing(S[0] + 0.6); thump(S[0] + 1.4); ding(S[0] + 1.45)
    stampfx(sg(0, 1) + 0.3)
    for k in range(1, len(scenes)): swoosh(S[k]); typing(S[k] + 0.1, TITLES[k])
    pop(S[1] + 0.6); thump(S[1] + 1.4); ding(sg(1, 1) + 0.3)
    swoosh(S[2] + 0.4); pop(S[2] + 1.0)
    for j in range(3): buzz(S[2] + 1.2 + j * 0.3)
    rooster(sg(2, 1) + 0.3)
    for k in range(7): pop(sg(2, 1) + 0.6 + k * 0.15)
    thump(sg(2, 1) + 1.5)
    thump(S[3] + 0.3); pop(sg(3, 1)); thump(sg(3, 1) + 1.4); stampfx(sg(3, 2)); ding(sg(3, 2) + 0.05)
    for k in range(5): tone(sfx, S[4] + 0.5 + k * (scenes[4]["seg"][1] + 0.5) / 5, 0.12, 700 - k * 80, 0.04, "sq", 0.5, f1=500 - k * 60)
    stampfx(sg(4, 1) + 1.2)
    for i in range(3): thump(S[5] + 0.3 + i * 0.45)
    ding(sg(5, 1) + 0.25)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

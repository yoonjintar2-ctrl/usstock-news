import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "juseok/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
GOLD = (240, 190, 60); JEAN = (70, 110, 200)

# ================================================================ drawings
def medal(d, cx, cy, r=12, label="주석", col=GOLD):
    d.polygon([(cx - 8, cy - r - 12), (cx - 2, cy - r - 12), (cx + 2, cy - r + 2), (cx - 4, cy - r + 2)], fill=SRED)
    d.polygon([(cx + 2, cy - r - 12), (cx + 8, cy - r - 12), (cx + 4, cy - r + 2), (cx - 2, cy - r + 2)], fill=dk(SRED, 0.7))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col, outline=dk(col, 0.6))
    d.ellipse([cx - r + 3, cy - r + 3, cx + r - 3, cy + r - 3], outline=dk(col, 0.75))
    if label: d.text((cx, cy - 5), label, font=F9, fill=DARK, anchor="ma")

def phone_app(d, x, y, t, rows):
    d.rounded_rectangle([x, y, x + 110, y + 150], radius=8, fill=(20, 22, 34), outline=WHT2)
    d.rectangle([x + 6, y + 12, x + 104, y + 138], fill=(12, 14, 26))
    d.text((x + 55, y + 16), "내 계좌", font=F9, fill=GRAY, anchor="ma")
    for i, (name, pct, col) in enumerate(rows):
        yy = y + 34 + i * 24
        d.text((x + 12, yy), name, font=F9, fill=WHITE)
        d.text((x + 98, yy), pct, font=F12, fill=col, anchor="ra")
        d.line([(x + 10, yy + 17), (x + 100, yy + 17)], fill=(40, 44, 64))

def carpet(d, x0, y, x1, u):
    xe = int(lerp(x0, x1, ease(u)))
    if xe > x0:
        d.rectangle([x0, y, xe, y + 8], fill=SRED); d.line([(x0, y + 1), (xe, y + 1)], fill=GOLD); d.line([(x0, y + 7), (xe, y + 7)], fill=GOLD)
        d.ellipse([xe - 6, y - 2, xe + 6, y + 10], fill=dk(SRED, 0.8), outline=GOLD)

def elevator(d, x, y, t, floor):
    # shaft
    d.rectangle([x, y, x + 60, y + 150], fill=(16, 18, 30), outline=GRAY)
    for k in range(5):
        yy = y + 10 + k * 30
        d.line([(x + 2, yy), (x + 58, yy)], fill=(40, 44, 64))
    # car position floor: 1 (=역주석, top), 0 (ground), -1, -2
    ypos = {1: y + 12, 0: y + 42, -1: y + 72, -2: y + 102}
    cy = ypos.get(floor, y + 42)
    d.rectangle([x + 8, cy, x + 52, cy + 26], fill=(150, 150, 170), outline=WHITE)
    d.line([(x + 30, cy + 2), (x + 30, cy + 24)], fill=GRAY)
    d.line([(x + 30, y), (x + 30, cy)], fill=GRAY)

def floor_panel(d, x, y, label, col):
    d.rectangle([x, y, x + 84, y + 26], fill=DARK, outline=col)
    d.text((x + 42, y + 6), label, font=F12, fill=col, anchor="ma")

def stock_card(d, x, y, name, pct, n_medal, t, ts):
    d.rectangle([x, y, x + 86, y + 92], fill=(10, 14, 30), outline=SRED)
    d.text((x + 43, y + 5), name, font=F9, fill=WHITE, anchor="ma")
    d.text((x + 43, y + 18), pct, font=F12, fill=BLUE, anchor="ma")
    shown = min(n_medal, int(max(0, t - ts) / 0.3) + 1) if t > ts else 0
    for i in range(int(math.ceil(n_medal))):
        if i >= shown: break
        mx = x + 14 + (i % 4) * 19; my = y + 58
        frac = 1 if i + 1 <= n_medal else n_medal - i
        if frac >= 1: medal(d, mx, my, 8, "")
        else:
            medal(d, mx, my, 8, "", (120, 100, 60))
    d.text((x + 43, y + 76), f"{n_medal:g}주석" if n_medal >= 1 and n_medal == int(n_medal) else "거의 4주석", font=F9, fill=GOLD, anchor="ma")

def flare_pants(d, x, y):
    d.rectangle([x + 4, y, x + 30, y + 6], fill=dk(JEAN, 0.7))
    d.polygon([(x + 4, y + 6), (x + 16, y + 6), (x + 14, y + 30), (x + 18, y + 44), (x - 2, y + 44), (x + 4, y + 30)], fill=JEAN)
    d.polygon([(x + 18, y + 6), (x + 30, y + 6), (x + 30, y + 30), (x + 36, y + 44), (x + 16, y + 44), (x + 20, y + 30)], fill=JEAN)
    d.line([(x + 17, y + 6), (x + 17, y + 14)], fill=dk(JEAN, 0.6))

def baseball(d, x, y, t):
    a = math.sin(t * 4) * 0.5
    bx, by = x + 22, y + 8
    d.line([(x, y + 40), (x + int(24 + a * 8), y + int(6 - a * 4))], fill=(190, 140, 80), width=4)
    d.ellipse([bx + 8, by + 14, bx + 22, by + 28], fill=WHITE, outline=GRAY)
    d.arc([bx + 6, by + 14, bx + 14, by + 28], -60, 60, fill=SRED); d.arc([bx + 16, by + 14, bx + 24, by + 28], 120, 240, fill=SRED)

def letter_block(d, cx, y, s, col, font=F12, pad=5):
    w = int(d.textlength(s, font=font)) + pad * 2
    d.rectangle([cx - w // 2, y, cx + w // 2, y + font.size + 6], fill=(10, 14, 30), outline=col)
    d.text((cx, y + 3), s, font=font, fill=col, anchor="ma")

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "주식 용어 1분 사전", "주석", "오늘 계좌에 주석님이?", GOLD)
    phone_app(d, 38, 130, t, [("A전자", "-5.1%" if t > 0.6 else "-0.3%", BLUE if t > 0.6 else GRAY),
                              ("B화학", "+0.8%", SRED), ("C바이오", "-1.2%", BLUE), ("D금융", "+0.2%", SRED)])
    if 0.6 < t < 0.9:
        d.rectangle([44, 162, 142, 180], outline=YEL)
    carpet(d, 150, 268, 216, prog(t, 1.0, 1.8))
    u = ease(prog(t, 1.4, 2.2))
    my = lerp(110, 220, u)
    if t > 1.4:
        medal(d, 184, int(my), 16)
        if u >= 1:
            for k in range(6):
                ph = ((t * 1.3 + k * 0.17) % 1)
                square(d, 166 + (k * 7) % 36, 200 + ph * 50, YEL, 2)
    if t > seg[1]:
        stamp_slam(img, CX, 300, "주석 = 하루 -5%", SRED, t, seg[1] + 0.4, "12", -5)
        debris(d, CX, 300, t, seg[1] + 0.4, 14, (GOLD, SRED, WHITE), 50, 0.8, 3)
    fx = {}
    if seg[1] + 0.4 < t < seg[1] + 0.52: fx["flash"] = 0.35
    return fx

def s_why(img, d, t, seg, dur):
    header(d, t, "WHY", "말장난의 법칙", "숫자가 이름이 되기까지", PURP)
    steps = [(0.2, "-5%", BLUE, F24), (0.9, "마이너스 오", WHITE, F12), (seg[0] + 1.8, "마 + 오", YEL, F12),
             (seg[1] + 0.1, "마오", GOLD, F24), (seg[1] + 1.4, "마오쩌둥 '주석'", SRED, F12)]
    for i, (ts, s, c, f) in enumerate(steps):
        if t < ts: continue
        vis, o = slam(t, ts, 0.18)
        y = 128 + i * 34 + o
        letter_block(d, CX, y, s, c, f)
        if i > 0:
            d.polygon([(CX - 4, y - 8), (CX + 4, y - 8), (CX, y - 3)], fill=GRAY)
        if i == 2:
            # highlight first syllables flying
            for k, ch in enumerate(["마", "오"]):
                ph = prog(t, ts - 0.4, ts)
                if ph < 1: d.text((lerp(CX - 30 + k * 40, CX - 10 + k * 20, ph), lerp(170, y, ph)), ch, font=F12, fill=YEL)
        if i == 4 and t > ts + 0.2:
            medal(d, 200, y + 10, 10, "")
    if t > seg[1] + 2.2:
        d.text((CX, 300), "※ 실제 인물과 무관한 말장난이에요", font=F9, fill=GRAY, anchor="ma")
    return {}

def s_levels(img, d, t, seg, dur):
    header(d, t, "LEVEL", "몇 주석?", "엘리베이터로 이해하기", CYAN)
    floor = 0
    if t > 0.6: floor = -1
    if t > 1.8: floor = -2
    if t > seg[1] + 0.3: floor = 1
    elevator(d, 36, 132, t, floor)
    panels = [(1, "역주석", "+5% ↑", SRED), (-1, "1주석", "-5%", BLUE), (-2, "2주석", "-10%", BLUE)]
    for i, (fl, a, b, c) in enumerate(panels):
        show = (fl == -1 and t > 0.6) or (fl == -2 and t > 1.8) or (fl == 1 and t > seg[1] + 0.3)
        if not show: continue
        y = {1: 140, -1: 200, -2: 236}[fl]
        vis, o = slam(t, {1: seg[1] + 0.3, -1: 0.6, -2: 1.8}[fl], 0.2)
        d.rectangle([104, y + o, 214, y + 28 + o], fill=(10, 14, 30), outline=c)
        if fl < 0:
            for m in range(-fl): medal(d, 116 + m * 16, y + 16 + o, 6, "")
        else:
            d.text((112, y + 7 + o), "↑", font=F12, fill=SRED)
        d.text((150 if fl < 0 else 126, y + 7 + o), a, font=F12, fill=GOLD if fl < 0 else SRED)
        d.text((208, y + 9 + o), b, font=F9, fill=c, anchor="ra")
    if floor == -2 and t < seg[1] + 0.3:
        for k in range(3): d.text((48 + k * 14, 290), "▼", font=F9, fill=BLUE)
    if floor == 1:
        confetti(d, t, seg[1] + 0.4, 10, (SRED, YEL, WHITE), 124, 196)
    d.text((CX, 304), "※ 하루 등락률 기준", font=F9, fill=DIM, anchor="ma")
    fx = {}
    if 0.6 < t < 0.8 or 1.8 < t < 2.0: fx["shake"] = (0, int(math.sin(t * 80) * 2))
    return fx

def s_example(img, d, t, seg, dur):
    header(d, t, "EXAMPLE", "실제 주석 사례", "2026년 3월 26일", ORG)
    if t > 0.3:
        stock_card(d, 34, 134, "SK하이닉스", "-6.23%", 1, t, 0.6)
    if t > seg[1]:
        stock_card(d, 130, 134, "한화솔루션", "-18.22%", 3.64, t, seg[1] + 0.3)
    if t > seg[1] + 1.8:
        vis, o = slam(t, seg[1] + 1.8)
        if vis:
            d.rectangle([44, 240 + o, 206, 272 + o], fill=(30, 14, 8), outline=ORG)
            d.text((CX, 245 + o), "미·이란 전쟁·유가 급등으로", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 257 + o), "주석이 자주 출몰한 날들", font=F9, fill=GOLD, anchor="ma")
    d.text((CX, 290), "자료: 문화일보 (2026.3.27)", font=F9, fill=DIM, anchor="ma")
    return {}

def s_bonus(img, d, t, seg, dur):
    header(d, t, "BONUS", "말장난 시리즈", "개미들의 웃픈 유머", GRN)
    if t > 0.3:
        vis, o = slam(t, 0.3, 0.2)
        d.rectangle([34, 132 + o, 120, 230 + o], fill=(10, 14, 30), outline=JEAN)
        d.text((77, 136 + o), "-8%", font=F12, fill=BLUE, anchor="ma")
        d.text((77, 150 + o), "마팔 → 마팔바지", font=F9, fill=WHITE, anchor="ma")
        flare_pants(d, 60, 168 + o)
    if t > seg[0] + 1.6:
        vis, o = slam(t, seg[0] + 1.6, 0.2)
        d.rectangle([130, 132 + o, 216, 230 + o], fill=(10, 14, 30), outline=SRED)
        d.text((173, 136 + o), "-9%", font=F12, fill=BLUE, anchor="ma")
        d.text((173, 150 + o), "마구 → 마구마구", font=F9, fill=WHITE, anchor="ma")
        baseball(d, 148, 168 + o, t)
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.3)
        if vis:
            d.rectangle([44, 244 + o, 206, 274 + o], fill=(8, 24, 14), outline=GRN)
            d.text((CX, 250 + o), "숫자는 무서워도 웃으며 버티기", font=F9, fill=GRN, anchor="ma")
            d.text((CX, 262 + o), "ㅋㅋㅋ", font=F9, fill=YEL, anchor="ma")
    return {}

def s_outro(img, d, t, seg, dur):
    header(d, t, "SUMMARY", "오늘의 용어", "주석 · 2주석 · 역주석", GOLD)
    rows = [("1주석", "하루 -5% 이상", BLUE, 1), ("2주석", "하루 -10% 이상", BLUE, 2), ("역주석", "하루 +5% 이상", SRED, 0)]
    for i, (a, b, c, n) in enumerate(rows):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 132 + i * 34
        d.rectangle([34, y + o, 216, y + 28 + o], fill=(10, 14, 30), outline=c)
        for m in range(n): medal(d, 46 + m * 14, y + 16 + o, 5, "")
        if n == 0: d.text((42, y + 7 + o), "↑", font=F12, fill=SRED)
        d.text((80, y + 7 + o), a, font=F12, fill=GOLD if n else SRED)
        d.text((210, y + 9 + o), b, font=F9, fill=WHITE, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([44, 244 + o, 206, 278 + o], fill=(30, 12, 16), outline=SRED if blink(t, 2) else GOLD)
            d.text((CX, 250 + o), "여러분 계좌엔", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 262 + o), "역주석만 오길!", font=F12, fill=SRED, anchor="ma")
        confetti(d, t, seg[1] + 0.4, 14, (SRED, GOLD, WHITE), 124, 240)
    d.text((CX, 300), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM, anchor="ma")
    return {}

SCRIPT = [
    (s_hook, [("\"오늘 주석 맞았다\"\n이 말, 들어보셨나요?", "주식 커뮤니티에서, 오늘 주석 맞았다는 말, 들어보셨나요?"),
              ("여기서 주석은\n하루에 5% 떨어졌다는 뜻이에요", "여기서 주석은, 하루에 오 퍼센트 떨어졌다는 뜻이에요.")]),
    (s_why, [("마이너스 오(-5)에서\n앞글자만 따면 '마오'", "마이너스 오에서 앞글자만 따면, 마오."),
             ("마오쩌둥의 직함 '주석'으로\n변신한 말장난이에요", "그래서 마오쩌둥의 직함인 주석으로 변신한, 말장난이에요.")]),
    (s_levels, [("하루 10% 빠지면 2주석", "하루 십 퍼센트 빠지면, 이 주석."),
                ("반대로 5% 넘게 오르면\n역주석이라고 불러요", "반대로 오 퍼센트 넘게 오르면, 역주석이라고 불러요.")]),
    (s_example, [("올해 3월 26일 SK하이닉스는\n6% 넘게 빠지며 1주석", "올해 삼월 이십육 일, 에스케이하이닉스는 육 퍼센트 넘게 빠지며 일 주석."),
                 ("18% 넘게 빠진 한화솔루션은\n거의 4주석을 맞았죠", "십팔 퍼센트 넘게 빠진 한화솔루션은, 거의 사 주석을 맞았죠.")]),
    (s_bonus, [("비슷한 말장난도 있어요\n-8%는 마팔바지, -9%는 마구마구", "비슷한 말장난도 있어요. 마이너스 팔은 마팔바지, 마이너스 구는 마구마구."),
               ("숫자는 무섭지만 웃으며 버티자는\n개미들의 유머죠", "숫자는 무섭지만, 웃으며 버티자는 개미들의 유머죠.")]),
    (s_outro, [("오늘의 용어, 주석!", "오늘의 용어, 주석!"),
               ("여러분 계좌엔\n역주석만 오길 바랄게요", "여러분 계좌엔, 역주석만 오길 바랄게요.")]),
]
TITLES = ["", "말장난의 법칙", "몇 주석?", "실제 주석 사례", "말장난 시리즈", "오늘의 용어"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # comic BGM: F major oom-pah, 124 bpm
    bpm = 124; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    chords = [([65, 69, 72], 41), ([58, 62, 65], 46), ([60, 64, 67], 48), ([65, 69, 72], 41)]
    mel = [[77, 76, 77, None, 72, None, 69, None], [70, 69, 70, None, 74, None, 70, None],
           [72, 71, 72, None, 76, None, 79, None], [77, None, 72, None, 65, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = chords[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, e * 0.5, mtof(root - 12 + (7 if st % 4 == 2 else 0)), 0.17, "tri")
            else:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.022, "sq", 0.25, decay=0.05)
            m = mel[b % 4][st]
            if m and T > S[1]: tone(bgm, T, e * 0.8, mtof(m), 0.035, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.08, 0, 0.08, "noise", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def wahwah(T):
        for j, m in enumerate([67, 66, 65, 64]): tone(sfx, T + j * 0.25, 0.28 if j < 3 else 0.6, mtof(m), 0.07, "sq", 0.5, f1=mtof(m) * 0.98, decay=0.3)
    def elev(T): tone(sfx, T, 0.12, 1319, 0.06, "sin", decay=0.2)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    typing(S[0] + 0.1, "주석오늘계좌에"); thump(S[0] + 0.6); tone(sfx, S[0] + 1.0, 0.8, 200, 0.03, "noise", decay=0.4)
    fanfare(S[0] + 1.4); thump(S[0] + 2.2); stampfx(sg(0, 1) + 0.4)
    for k in range(1, len(scenes)): swoosh(S[k]); typing(S[k] + 0.1, TITLES[k])
    for ts in (0.2, 0.9, scenes[1]["seg"][0] + 1.8, scenes[1]["seg"][1] + 0.1, scenes[1]["seg"][1] + 1.4): pop(S[1] + ts)
    ding(S[1] + scenes[1]["seg"][1] + 1.4)
    elev(S[2] + 0.6); thump(S[2] + 0.6); elev(S[2] + 1.8); thump(S[2] + 1.8); fanfare(sg(2, 1) + 0.3)
    wahwah(S[3] + 0.6); thump(sg(3, 1) + 0.3)
    for j in range(4): pop(sg(3, 1) + 0.3 + j * 0.3)
    pop(S[4] + 0.3); pop(S[4] + scenes[4]["seg"][0] + 1.6); ding(sg(4, 1) + 0.3)
    for i in range(3): thump(S[5] + 0.3 + i * 0.45)
    fanfare(sg(5, 1) + 0.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

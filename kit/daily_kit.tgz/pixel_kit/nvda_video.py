"""시황 특별편 · '이 하락장, 끝내러 왔다!' 엔비디아 실적(11/17 미국 · 한국 11/18 07:00) 기대 포인트 (60초 이내)
10/30 새 기준: 진행자 = 3D USB 마스코트(원형 인서트, mascot3d) · 자막 대신 마스코트에서 뻗는 말풍선(bubble_fx) · 보이스 6번
사실 확인(2026-10-30 KST 기준):
 · 실적 발표: 미국 11/17(화) 장 마감 후, 컨퍼런스콜 5pm ET = 한국 11/18(수) 07:00 (엔비디아 10/28 공지, StockTitan)
 · 2분기(FY27, 7/26 마감) 매출 962억$(+106%, 작년 467억$) · 데이터센터 890억$ · 매출총이익률 75.0% · 3분기 가이던스 1,080억$±2%, 중국 데이터센터 매출 0 가정 (엔비디아 8/26 실적 발표문)
 · 젠슨 황: Vera Rubin 'now in full production' (같은 발표문)
 · 메타: 10/21 올해 설비투자 1,350~1,450억$로 하단 상향 · 아마존: 10/29 올해 약 2,200억$ 계획 유지, AWS +39% · MS CFO: 수요가 공급을 계속 초과 (24/7 Wall St. 10/29, Motley Fool 10/29)
 · 10/29 알파벳 -12.64%(역대 최악의 하루) · 나스닥 -1.38% · 인텔 실적 후 시간외 -20% 넘게 (뉴스핌 10/30, CNBC 10/29)
 · 리스크: 알파벳·MS 분기 설비투자가 예상 밑돎(빅테크 투자 속도 논란), 가이던스에 중국 제외
 · 환율 1,325원/달러: 962억$≈127.5조 · 1,080억$≈143.1조 · 1,450억$≈192.1조 · 2,200억$≈291.5조
 · 상승·하락을 빨강/초록으로 구분하지 않음, 회사는 로봇·칩 캐릭터(로고 없음), 실존 인물 대사 없음(발언은 사실 요약)
"""
import os, sys, math, subprocess, wave, hashlib, json
import numpy as np
from PIL import Image, ImageDraw

import sandisk_video as sv
from sandisk_video import header, box, slam, CX, PURP, WHT2, chip, BLUE, SRED
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, lerp, prog, ease, tone, mtof, SR)
import mid_video as mv
import nike_video as nk
from nike_video import stamp_slam, dk, DARK, confetti, warn_icon, render_low, shutter_mask, dissolve_mask, clamp, TR
from option_video import big_text, GOLD
from squeeze_video import CH, with_card
from monday_video import bear, bull, gauge
from claude_video import robot, vbar, flare
from citadel_video import money_bag
from aibubble_video import datacenter
from memneck_video import gpu_card, factory
from fomc_video import person
from intel_video import down_arrow, tag, arrow_r

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "nvda/out"); os.makedirs(OUT, exist_ok=True)
NDIR = os.path.join(BASE, "narr_v6"); os.makedirs(NDIR, exist_ok=True)
mv.clip_path = lambda n: os.path.join(NDIR, hashlib.md5(f"v6s|{n}".encode()).hexdigest() + ".npy")   # v6s: 문장 쉼 적용본
GAP, TAIL = 0.42, 0.75
CARD = CYAN
NEU = (200, 206, 220)

# ================================================================ drawings
def big_cal(d, x, y, top, day, sub, col=YEL):
    """큰 달력 (약 70x74)"""
    d.rectangle([x, y, x + 70, y + 74], fill=(232, 230, 216), outline=GRAY)
    d.rectangle([x, y, x + 70, y + 16], fill=col)
    for k in range(4): d.rectangle([x + 10 + k * 16, y - 4, x + 13 + k * 16, y + 4], fill=GRAY)
    d.text((x + 35, y + 3), top, font=F9, fill=DARK, anchor="ma")
    d.text((x + 35, y + 20), day, font=F24, fill=DARK, anchor="ma")
    d.text((x + 35, y + 56), sub, font=F9, fill=(90, 90, 100), anchor="ma")

def gpu_bot(d, x, y, t, mood="happy", glow=1.0):
    """GPU 칩 캐릭터(엔비디아 의인화, 로고 없음) 약 60x60"""
    b = int(abs(math.sin(t * 4)) * 2); y -= b
    d.rectangle([x - 6, y + 8, x + 66, y + 52], fill=(24, 30, 48), outline=GRAY)       # 보드
    for k in range(7): d.line([(x - 2 + k * 10, y + 52), (x - 2 + k * 10, y + 57)], fill=GOLD)
    c = (90, 200, 120) if glow > 0.5 else (60, 120, 90)
    d.rectangle([x + 10, y, x + 50, y + 40], fill=(36, 46, 64), outline=c)
    d.rectangle([x + 14, y + 4, x + 46, y + 36], fill=(46, 58, 80))
    if mood == "happy":
        for ex in (x + 20, x + 34): d.arc([ex, y + 12, ex + 7, y + 19], 200, 340, fill=CYAN, width=2)
        d.arc([x + 22, y + 20, x + 38, y + 30], 20, 160, fill=CYAN, width=2)
    elif mood == "fire":
        for ex in (x + 20, x + 34): d.rectangle([ex, y + 13, ex + 5, y + 18], fill=YEL)
        d.rectangle([x + 23, y + 25, x + 37, y + 28], fill=YEL)
    else:
        for ex in (x + 21, x + 35): d.rectangle([ex, y + 13, ex + 3, y + 17], fill=CYAN)
        d.line([(x + 24, y + 27), (x + 36, y + 27)], fill=CYAN, width=2)
    d.text((x + 30, y + 41), "GPU", font=F9, fill=WHITE, anchor="ma")

def chart_down(d, x0, y0, x1, y1, u, col=NEU):
    pts = [(x0, y0), (x0 + (x1 - x0) * .2, y0 + 10), (x0 + (x1 - x0) * .35, y0 + 4), (x0 + (x1 - x0) * .55, y0 + 26),
           (x0 + (x1 - x0) * .7, y0 + 20), (x0 + (x1 - x0) * .85, y0 + 40), (x1, y1)]
    n = max(2, int(len(pts) * u + 0.999)); pp = pts[:n]
    d.line([(int(a), int(b)) for a, b in pp], fill=col, width=2)

def queue(d, x, y, n, t, col=WHT2):
    for k in range(n):
        person(d, x + k * 12, y + int(abs(math.sin(t * 5 + k)) * 2), [CYAN, YEL, ORG, PURP, WHT2][k % 5])

def conveyor(d, x, y, w, t, col=GRAY):
    d.rectangle([x, y, x + w, y + 6], fill=(50, 56, 76), outline=col)
    for k in range(w // 10 + 1):
        xx = x + (k * 10 + int(t * 30)) % w
        d.line([(xx, y + 1), (xx, y + 5)], fill=DIM)

def pie75(d, cx, cy, r, u, col=CYAN):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(30, 36, 56), outline=GRAY)
    if u > 0: d.pieslice([cx - r, cy - r, cx + r, cy + r], -90, -90 + 360 * 0.75 * u, fill=col)
    d.ellipse([cx - r // 2, cy - r // 2, cx + r // 2, cy + r // 2], fill=BG)

# ================================================================ scenes  (그림은 y 60~232 안 · 아래는 원형 마스코트·말풍선 자리)
def punch_fx(t, t0, amp=3):
    u = t - t0
    return {"shake": (int(math.sin(u * 60) * amp * max(0, 1 - u / 0.3)), 0)} if 0 <= u < 0.3 else {}

def s_hook(img, d, t, seg, dur):
    d.text((CX, 62), "AI 공포에 흔들린 한 주", font=F9, fill=GRAY, anchor="ma")         # 첫 프레임부터 완성
    big_text(img, CX, 72, "하락장 끝?", YEL, 3, F12)
    s1 = seg[1]
    if t < s1:
        # 곰이 차트 위에서 버티다 GPU 로켓에 밀려남
        chart_down(d, 30, 150, 120, 200, 1.0)
        u = prog(t, 0.6, 1.6)
        bx = 140 + int(ease(u) * 80); by = 150 - int(math.sin(u * math.pi) * 30)
        if u < 1: bear(d, bx, by, t, angry=True)
        gx = 70; gy = 230 - int(ease(prog(t, 0.2, 0.9)) * 70)
        gpu_bot(d, gx, gy, t, "fire")
        for k in range(4): d.rectangle([gx + 18 + k * 6, gy + 58 + (int(t * 20) + k) % 3, gx + 22 + k * 6, gy + 64 + (int(t * 20) + k) % 3], fill=ORG if k % 2 else YEL)
        fx = punch_fx(t, 0.9, 4)
    else:
        u = t - s1
        for k, (who, v, t0) in enumerate((("알파벳 하루", "-12.6%", 0.15), ("인텔 시간외", "-20%↓" if False else "-20%", 1.6))):
            vis, o = slam(t, s1 + t0, 0.18)
            if vis:
                yy = 128 + k * 50 + o
                box(d, 34, yy, 214, yy + 38, NEU, (12, 16, 30))
                d.text((48, yy + 6), who, font=F12, fill=WHITE); d.text((200, yy + 4), v, font=F24, fill=WHITE, anchor="ra")
                down_arrow(d, 170 - 40, yy + 8, 12, NEU) if False else None
        if u > 3.0: bear(d, 170, 196, t, angry=True)
        fx = {}
    return fx

def s_when(img, d, t, seg, dur):
    header(d, t, "분위기 반전 카드", "한 방은?", "", CYAN)
    s1 = seg[1]
    if t < s1:
        for k in range(3):
            q = int(abs(math.sin(t * 3 + k)) * 4)
            d.text((70 + k * 55, 150 - q), "?", font=F24, fill=[CYAN, YEL, WHT2][k], anchor="ma")
        bear(d, 30, 186, t, angry=False); bull(d, 180, 186, t)
        d.text((CX, 206), "VS", font=F12, fill=GRAY, anchor="ma")
        return {}
    u = t - s1
    gpu_bot(d, 36, 140, t, "happy")
    vis, o = slam(t, s1 + 0.3, 0.2)
    if vis: big_cal(d, 140, 128 + o, "11월 · 한국", "18", "오전 7시")
    if u > 1.3: tag(d, t, s1 + 1.3, 34, 212, "엔비디아 실적 발표", YEL)
    return punch_fx(t, s1 + 0.3) if u > 0.3 else {}

def s_rev(img, d, t, seg, dur):
    header(d, t, "체력 점검", "숫자가 증명", "", CYAN)
    s1 = seg[1]
    data = [("작년 2분기", 467, GRAY, 0.2), ("올해 2분기", 962, CYAN, 0.7)]
    if t >= s1: data.append(("이번 목표", 1080, YEL, s1 + 0.2))
    sc_ = 96 / 1080
    for k, (lbl, v, col, t0) in enumerate(data):
        x = 36 + k * 64; u = prog(t, t0, t0 + 0.6)
        h = int(v * sc_)
        if col == YEL:
            hh = int(h * ease(u))
            if hh > 0:
                d.rectangle([x, 222 - hh, x + 42, 222], fill=dk(YEL, 0.35))
                for yy in range(222 - hh, 222, 6): d.line([(x, yy), (x + 42, yy)], fill=dk(YEL, 0.7))
                d.rectangle([x, 222 - hh, x + 42, 222], outline=YEL)
        else:
            vbar(d, x, 222, 42, h, col, u)
        d.text((x + 21, 225), lbl, font=F9, fill=WHITE, anchor="ma")
        if u >= 1: d.text((x + 21, 222 - h - 12), f"{v:,}억$", font=F9, fill=WHITE, anchor="ma")
    if 1.5 < t < s1 + 0.6:
        vis, o = slam(t, 1.5, 0.2)
        if vis: d.text((70, 118 + o), "x2", font=F24, fill=YEL, anchor="ma")
    return {}

def s_wallet(img, d, t, seg, dur):
    header(d, t, "큰손 고객들", "지갑은 열려 있다", "", CYAN)
    s1 = seg[1]
    if t < s1:
        for k, (who, v, t0) in enumerate((("메타", "최대 1,450억$", 0.3),)):
            vis, o = slam(t, t0, 0.2)
            if vis:
                for j in range(3): money_bag(d, 44 + j * 24, 150 + o - (j % 2) * 6, "$", GOLD)
                d.text((150, 140 + o), who, font=F12, fill=WHITE, anchor="ma"); d.text((150, 158 + o), v, font=F12, fill=YEL, anchor="ma")
                d.text((150, 176 + o), "올해 투자 계획", font=F9, fill=GRAY, anchor="ma")
        datacenter(d, 92, 196, t, CYAN) if False else None
        return {}
    u = t - s1
    vis, o = slam(t, s1 + 0.15, 0.2)
    if vis:
        for j in range(4): money_bag(d, 34 + j * 20, 132 + o - (j % 2) * 5, "$", GOLD)
        d.text((180, 128 + o), "아마존", font=F12, fill=WHITE, anchor="ma"); d.text((180, 144 + o), "2,200억$", font=F12, fill=YEL, anchor="ma")
    if u > 2.2:
        datacenter(d, 130, 180, t, CYAN)
        queue(d, 34, 194, 7, t)
        d.text((80, 216), "MS: 수요 > 공급", font=F9, fill=WHITE, anchor="ma")
    return {}

def s_rubin(img, d, t, seg, dur):
    header(d, t, "다음 무기", "차세대 칩 루빈", "", CYAN)
    conveyor(d, 30, 206, 120, t)
    factory(d, 26, 160, GRAY)
    for k in range(3):
        xx = 80 + ((int(t * 30) + k * 40) % 80)
        chip(d, xx, 192, 14, CYAN, t, seed=k)
    d.text((90, 216), "양산 돌입", font=F9, fill=WHITE, anchor="ma")
    u = prog(t, 1.4, 2.4)
    pie75(d, 186, 172, 24, ease(u), CYAN)
    if u >= 1: d.text((186, 165), "75%", font=F12, fill=WHITE, anchor="ma"); d.text((186, 200), "이익률", font=F9, fill=GRAY, anchor="ma")
    return {}

def s_check(img, d, t, seg, dur):
    header(d, t, "그래도 체크", "변수 두 가지", "", YEL)
    for k, (title, l1, t0) in enumerate((("중국 매출", "전망에서 0으로 가정", 0.3), ("투자 속도", "알파벳·MS 투자 예상 밑돎", 1.4))):
        vis, o = slam(t, t0, 0.2)
        if vis:
            yy = 128 + k * 50 + o
            box(d, 30, yy, 220, yy + 40, YEL, (12, 16, 30)); warn_icon(d, 38, yy + 12, YEL)
            d.text((62, yy + 5), title, font=F12, fill=WHITE); d.text((62, yy + 23), l1, font=F9, fill=GRAY)
    return {}

def s_end(img, d, t, seg, dur):
    d.text((CX, 62), "한국 시간 11월 18일 오전 7시", font=F9, fill=GRAY, anchor="ma")
    big_text(img, CX, 74, "D-DAY", YEL, 3, F12)
    gpu_bot(d, 40, 150, t, "fire")
    u = prog(t, 0.6, 1.6)
    bear(d, 150 + int(u * 30), 166 - int(math.sin(u * math.pi) * 18), t, angry=False) if u < 1 else bull(d, 160, 170, t)
    if u >= 1: confetti(d, t, 1.6)
    d.text((32, 226), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.6) if u >= 1 else {}

# ---------------- 대본: (말풍선 문구, 내레이션, 말풍선 종류 n 보통 · s 외침 · t 생각) — 말풍선 {강조}
SCRIPT = [
    (s_hook, [("이 하락장,\n{끝내러 왔다!}", "이 하락장, 내가 끝내러 왔다!", "s"),
              ("알파벳 하루 {-12.6%}\n인텔 시간외 {-20%}\nAI 공포에 흔들", "알파벳은 하루 만에 십이 퍼센트 넘게 빠지고, 인텔은 이십 퍼센트 넘게 급락했죠.", "n")]),
    (with_card(s_when, "01", "반전 카드", CARD), [
        ("분위기 뒤집을\n한 방은?", "그럼, 분위기를 뒤집을 한 방은 뭘까요?", "t"),
        ("{엔비디아 실적!}\n11월 18일 오전 7시\n(한국 시간)", "바로 엔비디아 실적 발표! 한국 시간으로 십일월 십팔 일 아침 일곱 시예요.", "s")]),
    (with_card(s_rev, "02", "숫자 체력", CARD), [
        ("지난 분기 매출\n{962억$}(약 127조 원)\n1년 새 {2배}", "하나. 지난 분기 매출은 구백육십이억 달러, 약 백이십칠조 원. 일 년 만에 두 배가 넘었어요.", "n"),
        ("이번 분기 목표\n{1,080억$}\n(약 143조 원)", "둘. 이번 분기 목표는 천팔십억 달러, 약 백사십삼조 원이에요.", "n")]),
    (with_card(s_wallet, "03", "큰손 지갑", CARD), [
        ("메타 올해 투자\n최대 {1,450억$}\n(약 192조 원)", "셋. 큰손 고객들 지갑도 열려 있어요. 메타는 올해 투자를 최대 천사백오십억 달러까지 잡았고요.", "n"),
        ("아마존 {2,200억$}\n(약 291조 원) 그대로\nMS \"수요가 공급보다 많다\"", "아마존도 이천이백억 달러 계획을 지켰어요. 마이크로소프트는 수요가 공급보다 많다고 했죠.", "n")]),
    (with_card(s_rubin, "04", "다음 무기", CARD), [
        ("차세대 칩 {루빈}\n양산 돌입\n이익률 {75%}", "넷. 차세대 칩 루빈이 양산에 들어갔고, 이익률도 칠십오 퍼센트로 높아요.", "n")]),
    (s_check, [("체크할 점\n중국 매출은 전망 제외\n빅테크 투자 속도 논란", "다만, 전망에 중국 매출은 빠져 있고, 빅테크 투자 속도를 걱정하는 목소리도 있어요.", "t")]),
    (s_end, [("11월 18일 아침,\n{같이 지켜봐요!}", "십일월 십팔 일 아침, 하락장을 끝낼지 같이 지켜봐요!", "s")]),
]
NCH0, NCH = 1, 4

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n, _ in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts
    from sandy_voice import voice_line
    tts = make_tts()
    for n in todo:
        x, sr = voice_line(tts, n); assert sr == SR
        np.save(mv.clip_path(n), x); print(f"{len(x)/sr:.2f}s", n, flush=True)

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.05 if k == 0 else (CH + 0.25 if NCH0 <= k <= NCH else 0.25)
        seg, lens = [], []
        for i, (sub, n, st) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.15, subs=[], bubbles=[(s, st) for s, _, st in lines], narr=[n for _, n, _ in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def bubble_track(scenes, starts):
    """말풍선 타임라인: [{t0,t1,text,style}] (전체 시간)"""
    out = []
    for k, sc in enumerate(scenes):
        for i, (txt, st) in enumerate(sc["bubbles"]):
            t0 = starts[k] + sc["seg"][i]; out.append(dict(t0=t0, t1=t0 + sc["lens"][i], text=txt, style=st))
    return out

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts); sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    bpm = 100; beat = 60 / bpm; e = beat / 2; bar = beat * 4                 # 밝고 잔잔한 장조 하나 (F-C-Dm-Bb)
    prog_ = [([65, 69, 72], 53), ([60, 64, 67], 48), ([62, 65, 69], 50), ([58, 62, 65], 46)]
    mel = [[81, None, 79, None, 77, None, 79, None], [76, None, 72, None, 76, None, 79, None], [77, None, 74, None, 77, None, 81, None], [79, None, 77, None, 74, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.016, "sq", 0.25, decay=0.12)
            if mm[st]: tone(bgm, T, e * 1.6, mtof(mm[st] - 12), 0.022, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.11, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.025, "noise", decay=0.03)
    ie = int(total * SR); fo = int(1.5 * SR); fi = int(0.3 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def bubble_pop(T): tone(sfx, T, 0.07, 500, 0.035, "sin", f1=1100, decay=0.05)
    def shout_fx(T): thump(T); tone(sfx, T, 0.16, 300, 0.05, "sq", 0.5, f1=900, decay=0.08)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    for b in bubble_track(scenes, starts):
        (shout_fx if b["style"] == "s" else bubble_pop)(b["t0"] - 0.04)
    for k in range(NCH0, NCH + 1): bell3(S[k]); swoosh(S[k] + CH - 0.25)
    thump(S[0] + 0.9); pop(sg(0, 1) + 0.15); pop(sg(0, 1) + 1.6)
    thump(sg(1, 1) + 0.3); pop(sg(2, 0) + 0.8); pop(sg(2, 1) + 0.6)
    pop(sg(3, 0) + 0.3); pop(sg(3, 1) + 0.15); pop(S[5] + 0.55); pop(S[5] + 1.65); thump(S[6] + 1.6)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    g = 0.89 / max(1e-6, np.abs(mix).max()); mix = mix * g
    for p, a in ((path, mix), (path.replace(".wav", "_narr.wav"), nv * g)):
        pcm = (np.clip(a, -1, 1) * 32767).astype(np.int16)
        with wave.open(p, "wb") as w:
            w.setnchannels(1 if a is not mix else 2); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes() if a is not mix else np.repeat(pcm[:, None], 2, axis=1).tobytes())

def render_px(T, scenes, starts, total):
    """자막 없이 픽셀 프레임만 (말풍선은 bubble_fx에서 합성)"""
    k = min(max(i for i in range(len(scenes)) if starts[i] <= T + 1e-9), len(scenes) - 1)
    t = T - starts[k]; sc = scenes[k]
    low = render_low(sc, t)
    if k > 0 and t < TR:
        prev = render_low(scenes[k - 1], scenes[k - 1]["dur"] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T > total - 0.8: a = (a * clamp((total - T) / 0.8)).astype(np.uint8)
    return Image.fromarray(a)

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    json.dump(dict(total=total, bubbles=bubble_track(scenes, starts)), open(f"{OUT}/bubbles.json", "w"), ensure_ascii=False, indent=1)
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_px(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    if mode == "audio": sys.exit()
    n = int(total * FPS); os.makedirs(f"{OUT}/px", exist_ok=True)
    for i in range(n):
        render_px(i / FPS, scenes, starts, total).save(f"{OUT}/px/{i:05d}.png", compress_level=1)
        if i % 300 == 0: print(i, "/", n, flush=True)
    open(f"{OUT}/total.txt", "w").write(f"{total:.3f}")
    print("done", total)

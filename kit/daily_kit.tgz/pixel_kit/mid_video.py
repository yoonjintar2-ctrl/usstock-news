import os, sys, json, math, hashlib, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, tag, stamp, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, shutter_mask
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR, dissolve_mask)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "mid/out"); os.makedirs(OUT, exist_ok=True)
NDIR = os.path.join(BASE, "narr2"); os.makedirs(NDIR, exist_ok=True)
FD = os.path.join(BASE, "fonts/galmuri-2.40.3/package/dist")
F36 = ImageFont.truetype(f"{FD}/Galmuri11-Bold.ttf", 36)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
DATA = json.load(open(os.path.join(BASE, "mid/data/analysis.json")))
AVG = DATA["avg"]                         # 24 months: Jan(Y) .. Dec(Y+1), Dec(Y-1)=100
Y26 = DATA["y2026"]                       # Jan..Sep 2026
STATS = DATA["stats"]
MON = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]

def eout(u): return 1 - (1 - u) ** 3

def dome(d, cx, y, s=1.0, col=WHT2):
    w = int(44 * s)
    d.pieslice([cx - w // 2, y, cx + w // 2, y + int(40 * s)], 180, 360, fill=col)
    d.rectangle([cx - 2, y - int(8 * s), cx + 2, y], fill=col)
    d.rectangle([cx - int(32 * s), y + int(20 * s), cx + int(32 * s), y + int(24 * s)], fill=col)
    for i in range(7):
        x = cx - int(28 * s) + i * int(9.3 * s)
        d.rectangle([x, y + int(26 * s), x + 3, y + int(44 * s)], fill=col)
    d.rectangle([cx - int(38 * s), y + int(46 * s), cx + int(38 * s), y + int(50 * s)], fill=col)

def term_blocks(d, y, t, hi=1, labels=("1년 차", "2년 차", "3년 차", "4년 차"), appear=0.3):
    for i, lb in enumerate(labels):
        if t < appear + i * 0.15: continue
        x0 = 34 + i * 47; x1 = x0 + 42
        on = i == hi
        d.rectangle([x0, y, x1, y + 24], fill=(60, 40, 16) if on else (18, 22, 40), outline=YEL if on else DIM)
        d.text(((x0 + x1) // 2, y + 6), lb, font=F9, fill=YEL if on else GRAY, anchor="ma")

def line_chart(d, bx, series, n, ymin, ymax, col, width=2, dashed=False, xcount=24):
    bx0, by0, bx1, by1 = bx
    def mp(i, v):
        return bx0 + 8 + i / (xcount - 1) * (bx1 - bx0 - 16), by1 - 8 - (v - ymin) / (ymax - ymin) * (by1 - by0 - 20)
    m = n * (len(series) - 1)
    pts = []
    for i in range(int(m) + 1): pts.append(mp(i, series[i]))
    if m > int(m) and int(m) + 1 < len(series):
        f = m - int(m); a, b = series[int(m)], series[int(m) + 1]
        pts.append(mp(int(m) + f, lerp(a, b, f)))
    if len(pts) > 1:
        if dashed:
            for j in range(0, len(pts) - 1, 2): d.line([pts[j], pts[j + 1]], fill=col, width=width)
        else:
            d.line(pts, fill=col, width=width)
    return mp, pts

# ------------------------------------------------------------------ scenes
def s_hook(img, d, t, seg, dur):
    ctext(d, 62, "미국 중간선거의 해 · S&P 500", F9, GRAY)
    # stylised V : drop then rally
    bx = (SX0 + 2, 150, SX1 - 4, 300)
    box(d, *bx, DIM)
    V = [100, 99, 96, 93, 90, 86, 83, 85, 89, 94, 99, 104, 108, 110]
    def mp(i, v):
        return bx[0] + 8 + i / (len(V) - 1) * (bx[2] - bx[0] - 16), bx[3] - 10 - (v - 80) / (112 - 80) * (bx[3] - bx[1] - 22)
    def part(i0, i1, u, col):
        m = i0 + (i1 - i0) * u
        pts = [mp(i, V[i]) for i in range(i0, int(m) + 1)]
        if m > int(m) and int(m) + 1 <= i1:
            f = m - int(m); pts.append(mp(m, lerp(V[int(m)], V[int(m) + 1], f)))
        if len(pts) > 1: d.line(pts, fill=col, width=2)
        return pts
    u1 = eout(prog(t, 0.05, 1.2))
    if t < seg[1]:
        val = int(round(-17 * u1))
        ctext(d, 76, f"{val}%", F36, SRED, full="-17%")
        ctext(d, 122, "중간선거 해 평균 최대 낙폭", F9, WHITE)
        pts = part(0, 6, u1, SRED)
    else:
        u2 = eout(prog(t, seg[1], seg[1] + 1.1))
        val = int(round(32 * u2))
        col = GRN if t < seg[1] + 1.1 or blink(t, 3) else YEL
        ctext(d, 76, f"+{val}%", F36, col, full="+32%")
        ctext(d, 122, "바닥에서 1년 뒤 평균", F9, WHITE)
        part(0, 6, 1, SRED)
        pts = part(6, 13, u2, GRN)
        x, y = mp(6, 83); d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=YEL)
        d.text((x, y + 6), "바닥", font=F9, fill=YEL, anchor="ma")
    if len(pts) > 1:
        x, y = pts[-1]; d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=WHITE)
    sh = 2 if (1.2 < t < 1.45) or (len(seg) > 1 and seg[1] + 1.1 < t < seg[1] + 1.35) else 0
    return (int(math.sin(t * 60) * sh), int(math.cos(t * 47) * sh))

def s_what(img, d, t, seg, dur):
    header(d, t, "WHAT", "MIDTERMS", "대통령 임기 한가운데 선거", CYAN)
    dome(d, CX, 136, 1.0, WHT2 if t > 0.3 else DIM)
    term_blocks(d, 204, t, hi=1, appear=0.6)
    if t > 1.4:
        x = 34 + 47 + 42
        d.line([(x, 198), (x, 232)], fill=YEL, width=1)
        d.polygon([(x, 196), (x + 10, 199), (x, 202)], fill=YEL)
        d.text((x - 2, 234), "중간선거", font=F9, fill=YEL, anchor="ma")
        x4 = 34 + 47 * 3 + 42
        d.line([(x4, 198), (x4, 232)], fill=GRAY); d.text((x4 - 6, 234), "대선", font=F9, fill=GRAY, anchor="ma")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([56, 252 + o, 194, 294 + o], fill=(10, 14, 30), outline=YEL)
            d.text((CX, 256 + o), "2026 MIDTERM", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 268 + o), "11월 3일", font=F24, fill=YEL, anchor="ma")
    return (0, 0)

def s_why1(img, d, t, seg, dur):
    header(d, t, "WHY 1", "UNCERTAINTY", "결과 발표 전 긴장", ORG)
    dome(d, CX, 132, 0.8)
    # seat bar wobbling
    share = 0.5 + 0.12 * math.sin(t * 2.6) + 0.05 * math.sin(t * 6.1)
    x0, x1 = 40, 210; xm = int(lerp(x0, x1, share))
    d.rectangle([x0, 182, xm, 194], fill=CYAN); d.rectangle([xm, 182, x1, 194], fill=ORG)
    d.rectangle([x0, 182, x1, 194], outline=WHITE)
    d.text((x0, 198), "여당", font=F9, fill=CYAN); d.text((x1, 198), "야당", font=F9, fill=ORG, anchor="ra")
    d.text((CX, 198), "의석은?", font=F9, fill=WHITE, anchor="ma")
    qs = [("세금?", 42, 218, 0.6), ("규제?", 102, 232, 1.1), ("예산?", 160, 218, 1.6)]
    for s, x, y, ts in qs:
        if t > ts:
            vis, o = slam(t, ts, 0.18)
            d.rectangle([x, y + o, x + 44, y + 16 + o], fill=WHITE)
            d.text((x + 22, y + 2 + o), s, font=F12, fill=(10, 10, 20), anchor="ma")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([40, 258 + o, 210, 292 + o], fill=(30, 14, 8), outline=ORG if blink(t, 3) else SRED)
            d.text((CX, 263 + o), "시장은 '모르는 것'이", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 276 + o), "제일 싫다", font=F12, fill=ORG, anchor="ma")
    return (0, 0)

def s_why2(img, d, t, seg, dur):
    header(d, t, "WHY 2", "4-YEAR CYCLE", "쓴 약은 임기 초반에", PURP)
    term_blocks(d, 134, t, hi=1, appear=0.3)
    if t > 1.0:
        # pill over years 1-2, up-arrow over 3-4
        for i in range(2):
            x = 34 + i * 47 + 12
            d.rounded_rectangle([x, 164, x + 18, 172], radius=4, fill=SRED, outline=WHITE)
            d.line([(x + 9, 164), (x + 9, 172)], fill=WHITE)
        d.text((80, 176), "인기 없는 정책", font=F9, fill=SRED, anchor="ma")
        for i in range(2, 4):
            x = 34 + i * 47 + 21
            d.polygon([(x, 162), (x + 7, 170), (x - 7, 170)], fill=GRN)
        d.text((174, 176), "경기 부양", font=F9, fill=GRN, anchor="ma")
    if t > seg[1]:
        base = 286
        u = ease(prog(t, seg[1] + 0.3, seg[1] + 1.3)); u2 = ease(prog(t, seg[1] + 1.4, seg[1] + 2.4))
        h2 = int(5 * 5.4 * u); h3 = int(14.5 * 5.4 * u2)
        d.line([(44, base + 1), (206, base + 1)], fill=GRAY)
        d.rectangle([62, base - h2, 100, base], fill=SRED)
        d.rectangle([150, base - h3, 188, base], fill=GRN)
        if u > 0: d.text((81, base - h2 - 14), "약 5%", font=F12, fill=WHITE, anchor="ma")
        if u2 > 0: d.text((169, base - h3 - 14), "14.5%", font=F12, fill=YEL, anchor="ma")
        d.text((81, base + 4), "2년 차", font=F9, fill=SRED, anchor="ma")
        d.text((169, base + 4), "3년 차", font=F9, fill=GRN, anchor="ma")
    return (0, 0)

def s_when(img, d, t, seg, dur):
    header(d, t, "WHEN", "THE BOTTOM", "바닥은 보통 8~9월", YEL)
    bx = (SX0 + 2, 128, SX1 - 4, 284)
    box(d, *bx, DIM)
    mp0 = lambda i, v: (bx[0] + 8 + i / 23 * (bx[2] - bx[0] - 16), bx[3] - 8 - (v - 94) / (124 - 94) * (bx[3] - bx[1] - 20))
    # bottom zone Aug-Sep (idx 7-8)
    if t > seg[0] + 1.2:
        xa = mp0(6.6, 100)[0]; xb = mp0(8.4, 100)[0]
        for y in range(bx[1] + 2, bx[3] - 1, 3): d.line([(xa, y), (xb, y)], fill=(60, 50, 16))
        d.text(((xa + xb) / 2, bx[1] + 4), "바닥", font=F9, fill=YEL, anchor="ma")
    # election flag Nov (idx 10)
    xe = mp0(10, 100)[0]
    d.line([(xe, bx[1] + 18), (xe, bx[3] - 2)], fill=CYAN)
    d.text((xe + 2, bx[1] + 16), "선거", font=F9, fill=CYAN)
    n = prog(t, 0.3, seg[1] + 1.8)
    mp, pts = line_chart(d, bx, AVG, n, 94, 124, GRN)
    if len(pts) > 1:
        x, y = pts[-1]; d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=YEL)
    # month labels
    for i, lb in [(0, "1월"), (11, "12월"), (23, "이듬해 12월")]:
        x = mp0(i, 100)[0]
        d.text((x, bx[3] + 3), lb, font=F9, fill=GRAY, anchor="ma" if 0 < i < 23 else ("la" if i == 0 else "ra"))
    if n >= 1: d.text((bx[2] - 6, pts[-1][1] - 14), f"+{AVG[-1]-100:.0f}%", font=F12, fill=GRN, anchor="ra")
    d.text((CX, 300), "※ 1950~2022 중간선거 19회 평균 · 월평균", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

def s_after(img, d, t, seg, dur):
    header(d, t, "AFTER", "19 FOR 19", "1950년 이후 19번 모두 상승", GRN)
    base = 262; bw = 8
    d.line([(SX0 + 2, base + 1), (SX1 - 4, base + 1)], fill=GRAY)
    for i, s in enumerate(STATS):
        ts = 0.3 + i * 0.12
        if t < ts: continue
        u = ease(prog(t, ts, ts + 0.35))
        h = int(s["r12"] * 100 * 3.4 * u)
        x = SX0 + 4 + i * 10
        d.rectangle([x, base - h, x + bw - 1, base], fill=GRN if s["y"] != 1954 else YEL)
    for i, lb in [(0, "'50"), (9, "'86"), (18, "'22")]:
        d.text((SX0 + 8 + i * 10, base + 4), lb, font=F9, fill=GRAY, anchor="ma")
    if t > 0.3 + 1 * 0.12 + 0.35:
        x = SX0 + 4 + 10 + 4; d.text((x, base - int(30.9 * 3.4) - 12), "+31%", font=F9, fill=YEL, anchor="ma")
    cnt = min(19, int(max(0, t - 0.3) / 0.12) + 1) if t > 0.3 else 0
    d.text((SX1 - 6, 132), f"{cnt}/19", font=F12, fill=GRN, anchor="ra")
    d.text((SX0 + 6, 132), "선거 후 1년", font=F9, fill=WHITE)
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([36, 278 + o, 214, 298 + o], fill=(8, 24, 14), outline=GRN)
            d.text((CX, 282 + o), "평균 약 +15% · 10월말~4월 19전 19승", font=F9, fill=GRN, anchor="ma")
    d.text((CX, 304), "※ 막대: 선거 전 10월 → 이듬해 10월 (월평균)", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

def s_2026(img, d, t, seg, dur):
    header(d, t, "2026", "THIS YEAR", "올해는 조금 달랐다", YEL)
    bx = (SX0 + 2, 128, SX1 - 4, 284)
    box(d, *bx, DIM)
    mpf = lambda i, v: (bx[0] + 8 + i / 11 * (bx[2] - bx[0] - 16), bx[3] - 8 - (v - 94) / (116 - 94) * (bx[3] - bx[1] - 20))
    avg12 = AVG[:12]
    pa = [mpf(i, v) for i, v in enumerate(avg12)]
    for j in range(0, len(pa) - 1):
        if j % 2 == 0: d.line([pa[j], pa[j + 1]], fill=GRAY)
    d.text((pa[-1][0], pa[-1][1] + 4), "평균", font=F9, fill=GRAY, anchor="ra")
    n = prog(t, 0.3, seg[0] + 2.6)
    k = n * (len(Y26) - 1)
    pts = [mpf(i, Y26[i]) for i in range(int(k) + 1)]
    if k > int(k): f = k - int(k); pts.append(mpf(int(k) + f, lerp(Y26[int(k)], Y26[int(k) + 1], f)))
    if len(pts) > 1:
        d.line(pts, fill=YEL, width=2)
        x, y = pts[-1]; d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=WHITE)
    if k >= 2.2:
        x, y = mpf(2, Y26[2]); d.text((x - 8, y + 6), "3월 말 저점 -9%", font=F9, fill=SRED, anchor="la")
    if n >= 1:
        x, y = mpf(8, Y26[8]); d.line([(x + 4, y), (186, y)], fill=YEL); d.text((190, y - 5), "+20%↑", font=F9, fill=YEL)
    xe = mpf(10.1, 100)[0]
    d.line([(xe, bx[1] + 18), (xe, bx[3] - 2)], fill=CYAN); d.text((xe, bx[1] + 6), "11/3", font=F9, fill=CYAN, anchor="ma")
    for i, lb in [(0, "1월"), (11, "12월")]:
        d.text((mpf(i, 100)[0], bx[3] + 3), lb, font=F9, fill=GRAY, anchor="la" if i == 0 else "ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([38, 136 + o, 134, 156 + o], fill=(10, 14, 30), outline=YEL)
            d.text((86, 140 + o), "얕고 빠른 조정", font=F12, fill=YEL, anchor="ma")
    return (0, 0)

def s_outro(img, d, t, seg, dur):
    header(d, t, "SUMMARY", "PATTERN", "흔들리고, 회복한다", CYAN)
    rows = [("선거 전", "불확실성에 흔들림", ORG), ("바닥", "평균 8~9월", YEL), ("선거 후 1년", "19전 19승", GRN)]
    for i, (a, b, c) in enumerate(rows):
        ts = 0.3 + i * 0.5
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 134 + i * 34
        d.rectangle([36, y + o, 214, y + 26 + o], fill=(10, 14, 30), outline=c)
        d.text((44, y + 7 + o), a, font=F12, fill=c)
        d.text((206, y + 8 + o), b, font=F9, fill=WHITE, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.1)
        d.rectangle([44, 246 + o, 206, 276 + o], fill=(30, 10, 14), outline=SRED if blink(t, 2) else ORG)
        d.text((CX, 250 + o), "과거 패턴은 참고만!", font=F12, fill=WHITE, anchor="ma")
    d.text((CX, 284), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 296), "자료: LPL·Fidelity·Motley Fool 외", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

SCRIPT = [
    (s_hook, [("중간선거 해, 주가는\n평균 17% 빠졌다가", "중간선거가 있는 해, 주가는 평균 십칠 퍼센트 빠졌다가,"),
              ("바닥에서 1년 뒤엔\n평균 32% 올랐습니다", "바닥에서 일 년 뒤엔, 평균 삼십이 퍼센트 올랐습니다.")]),
    (s_what, [("중간선거는 미국 대통령 임기 중간에\n의회를 새로 뽑는 선거예요", "중간선거는 미국 대통령 임기 한가운데, 의회를 새로 뽑는 선거예요."),
              ("올해는 11월 3일이\n바로 그날이죠", "올해는 십일월 삼 일이 바로 그날이죠.")]),
    (s_why1, [("누가 의회를 가져가느냐에 따라\n세금·규제·예산 방향이 바뀌어요", "누가 의회를 가져가느냐에 따라, 세금, 규제, 예산 방향이 바뀌어요."),
              ("그런데 시장은\n모르는 걸 제일 싫어하거든요", "그런데 시장은, 모르는 걸 제일 싫어하거든요.")]),
    (s_why2, [("흔히 대통령은 인기 없는 정책을\n임기 초반에 몰아서 한다고 하죠", "흔히 대통령은, 인기 없는 정책을 임기 초반에 몰아서 한다고 하죠."),
              ("실제로 임기 2년 차 평균은 약 5%\n3년 차는 14.5%였어요", "실제로 임기 이 년 차 평균 수익률은 약 오 퍼센트, 삼 년 차는 십사 점 오 퍼센트였어요.")]),
    (s_when, [("역대 중간선거 해의 바닥은\n평균 8월 중순, 중간값은 9월 초", "역대 중간선거 해의 바닥은, 평균 팔월 중순, 중간값은 구월 초였어요."),
              ("그리고 선거 직전 10월부터\n반등이 시작된 경우가 많았죠", "그리고 선거 직전인 시월부터, 반등이 시작된 경우가 많았죠.")]),
    (s_after, [("1950년 이후 중간선거 19번,\n1년 뒤엔 한 번도 빠짐없이 올랐어요", "천구백오십 년 이후 중간선거 열아홉 번, 일 년 뒤 주가는 한 번도 빠짐없이 올랐어요."),
               ("평균 상승률은 약 15%,\n10월 말~이듬해 4월도 19전 19승", "평균 상승률은 약 십오 퍼센트. 시월 말부터 이듬해 사월까지도 열아홉 번 모두 플러스였죠.")]),
    (s_2026, [("올해는 3월 말까지 9% 빠진 뒤\n벌써 20% 넘게 반등했어요", "올해는 삼월 말까지 구 퍼센트 빠진 뒤, 벌써 이십 퍼센트 넘게 반등했어요."),
              ("평균보다 얕고 빠른 조정,\n역사대로 갈지가 관전 포인트죠", "평균보다 얕고 빠른 조정. 이번에도 역사대로 갈지가 관전 포인트죠.")]),
    (s_outro, [("정리하면, 선거 전엔 흔들리고\n선거 후엔 회복하는 패턴", "정리하면, 선거 전엔 흔들리고, 선거 후엔 회복하는 패턴."),
               ("다만 과거가 미래를 보장하진 않으니\n흐름만 참고하세요", "다만 과거가 미래를 보장하진 않으니, 흐름만 참고하세요.")]),
]
TITLES = ["", "MIDTERMS", "UNCERTAINTY", "4-YEAR CYCLE", "THE BOTTOM", "19 FOR 19", "THIS YEAR", "PATTERN"]

def clip_path(text_): return os.path.join(NDIR, hashlib.md5(f"{VOICE_SID}|{SPEED}|{text_}".encode()).hexdigest() + ".npy")

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        dur = t - GAP + TAIL
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=dur, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    starts = np.cumsum([0] + [s["dur"] for s in scenes]).tolist()
    return scenes, starts

TR = 0.4
def render_low(sc, t):
    img = bg_img("grid").copy(); d = ImageDraw.Draw(img); d.fontmode = "1"
    dx, dy = sc["fn"](img, d, t, sc["seg"], sc["dur"]) or (0, 0)
    if dx or dy:
        out = bg_img("grid").copy(); out.paste(img, (dx, dy)); img = out
    return img

def render_frame(T, scenes, starts, total):
    k = min(max(i for i in range(len(scenes)) if starts[i] <= T + 1e-9), len(scenes) - 1)
    t = T - starts[k]; sc = scenes[k]
    low = render_low(sc, t)
    if k > 0 and t < TR:
        prev = render_low(scenes[k - 1], scenes[k - 1]["dur"] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T > total - 0.8: a = (a * clamp((total - T) / 0.8)).astype(np.uint8)
    big = Image.fromarray(a)
    segs = sc["seg"] + [sc["dur"]]
    for i, s in enumerate(sc["subs"]):
        if segs[i] <= t < segs[i + 1] and T < total - 0.5:
            si = sub_img(s); big.paste(si, (0, sv.SUB_Y), si)
    return big

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # BGM: D minor -> F major release. 116 bpm
    bpm = 116; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    minor = [([62, 65, 69], 50), ([58, 62, 65], 46), ([60, 64, 67], 48), ([57, 61, 64], 45)]   # Dm Bb C A
    major = [([65, 69, 72], 41), ([60, 64, 67], 48), ([62, 65, 69], 50), ([58, 62, 65], 46)]   # F C Dm Bb
    mel = [[77, None, 76, 72, 74, None, 72, 69], [72, None, 74, 76, 79, None, 76, None],
           [74, None, 72, 69, 72, 74, 77, None], [74, None, 72, 70, 69, None, None, None]]
    def sec(T):
        if T < S[1]: return "hook"
        if T < S[2]: return "light"
        if T < S[4]: return "tense"
        if T < S[5]: return "build"
        if T < S[7]: return "full"
        return "outro"
    for b in range(int(total / bar) + 1):
        t0 = b * bar; name = sec(t0)
        notes, root = (minor if name in ("hook", "tense", "light") else major)[b % 4]
        drums = name in ("hook", "build", "full")
        for st in range(16):
            T = t0 + st * s16
            if T >= total: break
            tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + 12), 0.045, "sq", 0.125, decay=0.08)
            if st % 2 == 0 and drums: tone(bgm, T, 0.03, 0, 0.03 if st % 4 else 0.018, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.9, mtof(root - 12 + (12 if st % 2 else 0)), 0.16, "tri")
            m = mel[b % 4][st]
            if m and name in ("full", "outro"): tone(bgm, T, e * 0.95, mtof(m - 12), 0.04, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2) and name != "light": tone(bgm, T, 0.16, 150, 0.33, "sin", f1=45, decay=0.07)
            if bt in (1, 3) and drums:
                tone(bgm, T, 0.12, 0, 0.11, "noise", decay=0.04); tone(bgm, T, 0.08, 190, 0.07, "tri", decay=0.04)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def pop(T): tone(sfx, T, 0.06, 600, 0.06, "sq", 0.5, f1=1200, decay=0.04)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    tone(sfx, S[0] + 0.05, 1.15, 1400, 0.05, "sq", 0.5, f1=200); thump(S[0] + 1.2)
    tone(sfx, sg(0, 1), 1.1, 200, 0.05, "sq", 0.5, f1=1600); thump(sg(0, 1) + 1.1); ding(sg(0, 1) + 1.12)
    for k in range(1, len(scenes)): swoosh(S[k]); typing(S[k] + 0.1, TITLES[k])
    for i in range(4): blip(S[1] + 0.6 + i * 0.15, 800, 0.04)
    thump(sg(1, 1) + 0.2)
    for ts in (0.6, 1.1, 1.6): pop(S[2] + ts)
    thump(sg(2, 1) + 0.2)
    for i in range(2): pop(S[3] + 1.0 + i * 0.1)
    tone(sfx, sg(3, 1) + 0.3, 1.0, 300, 0.04, "sq", 0.5, f1=500); tone(sfx, sg(3, 1) + 1.4, 1.0, 300, 0.05, "sq", 0.5, f1=1300); ding(sg(3, 1) + 2.4)
    tone(sfx, S[4] + 0.3, scenes[4]["seg"][1] + 1.5, 220, 0.03, "tri", f1=900)
    for i in range(19): blip(S[5] + 0.3 + i * 0.12, 700 + i * 50, 0.04)
    ding(S[5] + 0.3 + 19 * 0.12); thump(sg(5, 1) + 0.2)
    tone(sfx, S[6] + 0.3, 2.4, 300, 0.035, "sq", 0.5, f1=900); thump(sg(6, 1) + 0.2)
    for i in range(3): thump(S[7] + 0.3 + i * 0.5)
    thump(sg(7, 1) + 0.1)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

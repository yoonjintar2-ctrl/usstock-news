"""11/21 8비트 쇼츠 썸네일 2종 (1080×1920) — nvda: 신문 호외 1면 / avgo: 경고 테이프
python3 thumb_d1121.py <mascot_rgba.png> <out_dir>"""
import sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter
W, H = 1080, 1920
def nf(size, w='Black'):
    p = f'/usr/share/fonts/opentype/noto/NotoSansCJK-{w}.ttc'
    for i in range(10):
        f = ImageFont.truetype(p, size, index=i)
        if 'KR' in f.getname()[0]: return f
    return ImageFont.truetype(p, size)
def serif(size):
    p = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Black.ttc'
    for i in range(10):
        f = ImageFont.truetype(p, size, index=i)
        if 'KR' in f.getname()[0]: return f
def ctext(d, y, s, f, fill, stroke=0, sc=None, cx=W // 2):
    d.text((cx, y), s, font=f, fill=fill, anchor='ma', stroke_width=stroke, stroke_fill=sc)
def fit(d, s, f_fn, size, maxw):
    while size > 40 and d.textlength(s, font=f_fn(size)) > maxw: size -= 4
    return f_fn(size)

masc = Image.open(sys.argv[1]).convert('RGBA'); out = sys.argv[2]
bb = masc.getbbox(); masc = masc.crop(bb)

# ---------- NVDA: 호외 신문 1면
im = Image.new('RGB', (W, H), (236, 230, 214)); d = ImageDraw.Draw(im)
for y in range(0, H, 6): d.line([(0, y), (W, y)], fill=(230, 224, 207))
INK = (24, 22, 20)
d.rectangle([70, 150, 1010, 162], fill=INK)
ctext(d, 178, '호 외', serif(150), INK)
d.rectangle([70, 350, 1010, 356], fill=INK)
d.text((80, 368), '2026년 11월 21일(토)', font=nf(40, 'Bold'), fill=INK)
d.text((1000, 368), '미국주식 늬우스', font=nf(40, 'Bold'), fill=INK, anchor='ra')
d.rectangle([70, 428, 1010, 432], fill=INK)
ctext(d, 470, '엔비디아', fit(d, '엔비디아', nf, 230, 900), INK)
ctext(d, 740, '-14%', nf(330), (196, 30, 30))
ctext(d, 1150, "'회계 조사' 보도에", nf(76, 'Bold'), INK)
ctext(d, 1250, '하루 661조 원 증발', nf(84), INK)
for i, y in enumerate(range(1400, 1540, 34)):
    d.rectangle([80, y, 80 + (360 if i % 2 else 420), y + 14], fill=(160, 154, 140))
m = masc.resize((int(masc.width * 520 / masc.height), 520), Image.LANCZOS)
sh = Image.new('RGBA', (W, H), (0, 0, 0, 0)); ImageDraw.Draw(sh).ellipse([560, 1880, 1000, 1925], fill=(0, 0, 0, 90))
im.paste(sh.filter(ImageFilter.GaussianBlur(10)), (0, 0), sh.filter(ImageFilter.GaussianBlur(10)))
im.paste(m, (W - m.width - 60, H - m.height - 20), m)
d.text((80, 1560), '11.21', font=nf(150), fill=INK)
im.save(f'{out}/thumb_nvda.jpg', quality=92)

# ---------- AVGO: 경고 테이프
im = Image.new('RGB', (W, H), (18, 20, 30)); d = ImageDraw.Draw(im)
def tape(y, ang_up=True):
    t = Image.new('RGBA', (1500, 120), (250, 200, 30, 255)); g = ImageDraw.Draw(t)
    for x in range(-200, 1600, 90): g.polygon([(x, 0), (x + 45, 0), (x - 75, 120), (x - 120, 120)], fill=(20, 20, 20, 255))
    t = t.rotate(8 if ang_up else -8, expand=True, resample=Image.BICUBIC)
    im.paste(t, (-200, y), t)
tape(110, True); tape(1420, False)
ctext(d, 330, '11.21', nf(150), (250, 200, 30))
ctext(d, 520, '브로드컴', fit(d, '브로드컴', nf, 240, 920), (245, 245, 240))
ctext(d, 790, '-12%', nf(330), (250, 200, 30), 6, (18, 20, 30))
ctext(d, 1160, '설문 한 장에', nf(110), (245, 245, 240))
ctext(d, 1300, '257조 원 증발?', nf(96), (245, 245, 240))
m = masc.resize((int(masc.width * 360 / masc.height), 360), Image.LANCZOS).transpose(Image.FLIP_LEFT_RIGHT)
im.paste(m, (W // 2 - m.width // 2 - 60, H - m.height - 40), m)
im.save(f'{out}/thumb_avgo.jpg', quality=92)
print('ok')

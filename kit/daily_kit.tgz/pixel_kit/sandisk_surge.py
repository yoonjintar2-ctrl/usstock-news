import os, sys, json, math, hashlib, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import (ctext, header, box, slam, tag, stamp, building, roof, chip, CX, SX0, SX1,
                           BLUE, SRED, PURP, WHT2, sub_img, shutter_mask)
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR, dissolve_mask)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "out4"); os.makedirs(OUT, exist_ok=True)
NDIR = os.path.join(BASE, "narr2"); os.makedirs(NDIR, exist_ok=True)
FD = os.path.join(BASE, "fonts/galmuri-2.40.3/package/dist")
F48 = ImageFont.truetype(f"{FD}/Galmuri11-Bold.ttf", 36)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6

def eout(u): return 1 - (1 - u) ** 3

def pips(d, idx):
    for i in range(4):
        x = CX - 27 + i * 14
        c = YEL if i == idx else (GRAY if i < idx else DIM)
        d.rectangle([x, 122, x + 8, 126], fill=c)

PATH = [(0, 48.6), (0.1, 37), (0.25, 48), (0.4, 116), (0.5, 220), (0.65, 603), (0.75, 1300), (0.82, 2300),
        (0.88, 1700), (0.95, 1890), (1.0, 1600)]

def price_at(f):
    for j in range(len(PATH) - 1):
        (f0, p0), (f1, p1) = PATH[j], PATH[j + 1]
        if f0 <= f <= f1:
            return 10 ** lerp(math.log10(p0), math.log10(p1), (f - f0) / (f1 - f0))
    return PATH[-1][1]

def draw_price(d, bx, n, col=GRN):
    bx0, by0, bx1, by1 = bx
    box(d, bx0, by0, bx1, by1, DIM)
    def mp(f, p):
        x = bx0 + 8 + f * (bx1 - bx0 - 16)
        y = by1 - 10 - (math.log10(p) - math.log10(30)) / (math.log10(3000) - math.log10(30)) * (by1 - by0 - 26)
        return x, y
    for p in (100, 1000):
        y = int(mp(0, p)[1])
        for x in range(bx0 + 2, bx1 - 1, 4): d.point((x, y), fill=(34, 42, 70))
    pts = [mp(i / 120, price_at(i / 120)) for i in range(int(n * 120) + 1)]
    if len(pts) > 1:
        d.line(pts, fill=col, width=2)
    return mp, pts

def product(d, x, y, kind):
    if kind == 0:
        d.polygon([(x, y), (x + 14, y), (x + 20, y + 6), (x + 20, y + 28), (x, y + 28)], fill=SRED, outline=WHITE)
        d.rectangle([x + 3, y + 12, x + 17, y + 24], fill=WHITE)
    elif kind == 1:
        d.rectangle([x, y + 8, x + 26, y + 20], fill=SRED, outline=WHITE)
        d.rectangle([x + 26, y + 10, x + 34, y + 18], fill=GRAY)
    else:
        d.rectangle([x - 4, y + 2, x + 30, y + 26], fill=(40, 44, 62), outline=WHITE)
        d.rectangle([x, y + 8, x + 16, y + 18], fill=SRED)

# ------------------------------------------------------------------ scenes  f(img, d, t, seg, dur)
def s_hook(img, d, t, seg, dur):
    ctext(d, 62, "SANDISK (SNDK) 주가", F9, GRAY)
    u = eout(prog(t, 0.05, 1.3))
    val = int(round(3000 * u / 10) * 10)
    col = GRN if t < 1.3 else (YEL if blink(t, 3) else GRN)
    ctext(d, 78, f"+{val:,}%", F48, col, full="+3,000%")
    ctext(d, 128, "상장 첫날 $48.6 → 지금 $1,600 안팎", F9, WHITE)
    mp, pts = draw_price(d, (SX0 + 2, 146, SX1 - 4, 300), u)
    if len(pts) > 1:
        x, y = pts[-1]
        d.polygon([(x + 5, y - 5), (x - 2, y - 3), (x + 3, y + 2)], fill=WHITE)
        for k in range(3):
            if (t * 10 + k) % 2 < 1.2: square(d, x - 4 - k * 3, y + 2 + k * 3, [YEL, ORG, SRED][k], 2)
    if len(seg) > 1 and t > seg[1]:
        vis, o = slam(t, seg[1])
        d.rectangle([CX - 48, 196 + o, CX + 48, 240 + o], fill=(10, 14, 30), outline=YEL if blink(t, 3) else ORG)
        ctext(d, 206 + o, "WHY?", F24, YEL)
    sh = 2 if 1.3 < t < 1.6 else 0
    return (int(math.sin(t * 60) * sh), int(math.cos(t * 47) * sh))

def s_who(img, d, t, seg, dur):
    header(d, t, "WHO", "SANDISK", "플래시 메모리 회사", SRED)
    if t < seg[1]:
        chip(d, 102, 136, 46, SRED, t, 2)
        for i, name in enumerate(["메모리카드", "USB", "SSD"]):
            ts = 0.6 + i * 0.35
            if t < ts: continue
            x = 48 + i * 58; y = 204 + int((1 - ease(prog(t, ts, ts + 0.3))) * 10)
            product(d, x, y, i)
            d.text((x + 12, y + 32), name, font=F9, fill=WHITE, anchor="ma")
    else:
        tt = t - seg[1]
        sp = ease(prog(tt, 0.5, 1.4)) * 22
        if tt < 0.5:
            d.rectangle([58, 136, 192, 214], fill=(40, 30, 70), outline=PURP)
            d.text((CX, 168), "WD + SANDISK", font=F12, fill=WHITE, anchor="ma")
        else:
            building(d, int(58 - sp), 136, int(122 - sp), 214, BLUE, "웨스턴디지털", 1, t)
            building(d, int(128 + sp), 136, int(192 + sp), 214, SRED, "SANDISK", 3, t)
            roof(d, int(58 - sp), int(122 - sp), 134, 14, BLUE)
            roof(d, int(128 + sp), int(192 + sp), 134, 14, SRED)
        if tt > 1.5:
            vis, o = slam(t, seg[1] + 1.5)
            d.rectangle([44, 230 + o, 206, 292 + o], fill=(8, 24, 14), outline=GRN)
            d.text((CX, 235 + o), "2025.02.24 NASDAQ", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 248 + o), "SNDK", font=F24, fill=GRN, anchor="ma")
            d.text((CX, 278 + o), "첫날 종가 $48.6", font=F9, fill=WHITE, anchor="ma")
    return (0, 0)

def s_ai(img, d, t, seg, dur):
    header(d, t, "REASON 1", "AI BOOM", "데이터가 폭증했다", GRN); pips(d, 0)
    for i in range(3):
        x = 38 + i * 24
        d.rectangle([x, 136, x + 18, 214], fill=(18, 22, 36), outline=GRAY)
        for r in range(7):
            yy = 142 + r * 10
            d.rectangle([x + 3, yy, x + 15, yy + 6], fill=(30, 36, 56))
            on = ((r + i * 3 + int(t * 6)) % 4) != 0
            d.point((x + 13, yy + 3), fill=GRN if on else DIM)
    d.text((65, 218), "AI 서버", font=F9, fill=GRAY, anchor="ma")
    chip(d, 160, 154, 40, SRED, t, 2)
    d.text((180, 218), "플래시", font=F9, fill=SRED, anchor="ma")
    rate = 0.12 if t > seg[1] else 0.3
    for k in range(int(dur / 0.12)):
        ts = 0.4 + k * 0.12
        if t > seg[1] or k % 3 == 0:
            fly(d, (110, 144 + (k * 13) % 60), (160, 164 + (k * 7) % 30), (t - ts) / 0.6, [CYAN, GRN, YEL][k % 3], arc=8)
    if t > seg[2]:
        vis, o = slam(t, seg[2])
        d.rectangle([40, 234 + o, 210, 296 + o], fill=(10, 14, 30), outline=GRN)
        d.text((CX, 238 + o), "데이터센터 매출 (1년 전 대비)", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 252 + o), "+645%", font=F24, fill=GRN, anchor="ma")
        d.text((CX, 282 + o), "2026년 1~3월 분기 · 7배 넘게", font=F9, fill=GRAY, anchor="ma")
    return (0, 0)

def person(d, x, y, col):
    d.rectangle([x + 1, y, x + 5, y + 4], fill=(240, 200, 160))
    d.rectangle([x, y + 5, x + 6, y + 13], fill=col)
    d.line([(x + 1, y + 14), (x + 1, y + 17)], fill=GRAY); d.line([(x + 5, y + 14), (x + 5, y + 17)], fill=GRAY)

def s_supply(img, d, t, seg, dur):
    header(d, t, "REASON 2", "SHORTAGE", "물건이 모자라다", ORG); pips(d, 1)
    box(d, 30, 140, 86, 206, ORG, (24, 16, 10))
    d.text((58, 144), "재고", font=F9, fill=ORG, anchor="ma")
    left = 3 - int(prog(t, seg[1] + 0.3, seg[1] + 1.6) * 3)
    for i in range(left): d.rectangle([40 + i * 13, 186, 49 + i * 13, 199], fill=SRED, outline=WHITE)
    if left == 0 and blink(t, 3): stamp(d, 58, 166, "품절", RED)
    cols = [CYAN, GRN, YEL, PURP, CYAN, WHT2, GRN, YEL, ORG]
    for i in range(9):
        ts = 0.3 + i * 0.22
        tx = 94 + i * 13
        x = lerp(W + 10, tx, ease(prog(t, ts, ts + 0.7)))
        if t > ts: person(d, x, 188, cols[i])
    if t > seg[1] + 0.6 and blink(t, 2): d.text((150, 172), "주세요!", font=F9, fill=WHITE)
    if t > seg[2]:
        n = int(prog(t, seg[2], seg[2] + 1.6) * 7)
        for k in range(n):
            d.rectangle([44 + k * 22, 278 - k * 8, 62 + k * 22, 288 - k * 8], fill=SRED)
        if n >= 7: d.polygon([(196, 222), (214, 232), (198, 240)], fill=SRED)
        d.text((44, 226), "NAND 가격", font=F12, fill=SRED)
        d.text((44, 242), "▲ 치솟는 중", font=F9, fill=WHITE)
    return (0, 0)

def coins(d, x0, x1, base, h, col=YEL):
    y = base
    while y > base - h:
        d.ellipse([x0, y - 6, x1, y], fill=col, outline=(180, 130, 30))
        y -= 5

def s_margin(img, d, t, seg, dur):
    header(d, t, "REASON 3", "MARGIN 78%", "남는 돈이 달라졌다", YEL); pips(d, 2)
    ctext(d, 130, "₩100 팔면 원가 빼고 남는 돈", F9, GRAY)
    base = 252
    h1 = 24 * ease(prog(t, seg[1] + 0.1, seg[1] + 0.8))
    h2 = 82 * ease(prog(t, seg[1] + 1.4, seg[1] + 2.6))
    d.line([(40, base + 1), (210, base + 1)], fill=GRAY)
    if h1 > 0:
        coins(d, 58, 96, base, h1, (170, 150, 90))
        d.text((77, base - h1 - 26), "₩23", font=F12, fill=WHITE, anchor="ma")
        d.text((77, base - h1 - 12), "22.7%", font=F9, fill=GRAY, anchor="ma")
    if h2 > 0:
        coins(d, 150, 192, base, h2)
        d.text((171, base - h2 - 26), "₩78", font=F12, fill=YEL, anchor="ma")
        d.text((171, base - h2 - 12), "78.4%", font=F9, fill=YEL, anchor="ma")
    d.text((77, base + 4), "1년 전", font=F9, fill=GRAY, anchor="ma")
    d.text((171, base + 4), "지금", font=F9, fill=YEL, anchor="ma")
    if t > seg[2]:
        vis, o = slam(t, seg[2])
        d.rectangle([52, 272 + o, 198, 296 + o], fill=(10, 14, 30), outline=YEL)
        d.text((CX, 277 + o), "분기 매출 3.5배 ▲", font=F12, fill=YEL, anchor="ma")
    d.text((CX, 302), "※ 조정 매출총이익률 기준", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

def s_book(img, d, t, seg, dur):
    header(d, t, "REASON 4", "BOOKED", "미리 받아둔 예약", CYAN); pips(d, 3)
    box(d, 36, 136, 214, 228, CYAN)
    d.rectangle([36, 136, 214, 148], fill=CYAN)
    d.text((40, 137), "FY2027 공급 물량", font=F9, fill=(8, 11, 24))
    cells = 7 * 4; booked = 11
    for k in range(cells):
        c, r = k % 7, k // 7
        x = 42 + c * 24; y = 154 + r * 18
        on = k < booked and t > 0.5 + k * 0.12
        d.rectangle([x, y, x + 20, y + 14], fill=(30, 90, 130) if on else (20, 24, 40), outline=CYAN if on else DIM)
        if on: d.line([(x + 5, y + 7), (x + 9, y + 11), (x + 16, y + 3)], fill=WHITE)
    if t > 1.9: d.text((210, 230), "1/3 이상 계약 완료", font=F9, fill=CYAN, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.3)
        if vis:
            tag(d, 70, 246 + o, "$42B+", YEL, F24)
            d.text((CX, 280 + o), "고객 5곳 장기계약 · 최소 매출", font=F9, fill=WHITE, anchor="ma")
    return (0, 0)

def s_risk(img, d, t, seg, dur):
    header(d, t, "BUT", "WILD RIDE", "롤러코스터 주의", SRED)
    n = prog(t, 0.2, seg[1] + 0.2)
    mp, pts = draw_price(d, (SX0 + 2, 128, SX1 - 4, 296), n)
    if len(pts) > 1:
        x, y = pts[-1]; d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=YEL)
    if n > 0.83:
        x, y = mp(0.82, 2300); d.text((x - 34, y - 12), "$2,300대", font=F9, fill=YEL)
    if n >= 1:
        x2, y2 = mp(1.0, 1600); d.text((x2 - 2, y2 + 6), "$1,600", font=F9, fill=WHITE, anchor="ra")
        if t > seg[1] + 0.6:
            x1, y1 = mp(0.82, 2300)
            d.line([(x1 + 4, y1), (x2 + 2, y1)], fill=SRED); d.line([(x2 + 2, y1), (x2 + 2, y2 - 3)], fill=SRED)
            if blink(t, 2.5):
                d.rectangle([SX0 + 10, 138, SX0 + 96, 154], fill=(30, 10, 14), outline=SRED)
                d.text((SX0 + 53, 141), "고점 대비 -30%대", font=F9, fill=SRED, anchor="ma")
    return (0, 0)

def s_outro(img, d, t, seg, dur):
    header(d, t, "SUMMARY", "4 REASONS", "네 박자가 만든 결과", GRN)
    items = [("AI 수요", GRN), ("공급 부족", ORG), ("마진 폭발", YEL), ("장기 계약", CYAN)]
    for i, (s, c) in enumerate(items):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 130 + i * 26
        d.rectangle([64, y + o, 186, y + 20 + o], fill=(10, 14, 30), outline=c)
        d.text((CX, y + 4 + o), s, font=F12, fill=c, anchor="ma")
        if i > 0: d.text((52, y + 4 + o), "+", font=F12, fill=WHITE, anchor="ma")
    if t > 2.3:
        vis, o = slam(t, 2.3)
        col = GRN if blink(t, 2) else YEL
        d.rectangle([44, 236 + o, 206, 270 + o], fill=(8, 24, 14), outline=col)
        ctext(d, 241 + o, "= +3,000%", F24, col)
    d.text((CX, 284), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 296), "주가는 2026.10.9 기준", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

# ------------------------------------------------------------------ script: (scene, [(subtitle, narration)])
SCRIPT = [
    (s_hook, [("2년도 안 돼 주가 3,000%", "이 년도 안 돼서, 주가 삼천 퍼센트."),
              ("샌디스크, 대체 왜 이렇게\n올랐을까요?", "샌디스크, 대체 왜 이렇게 올랐을까요?")]),
    (s_who, [("샌디스크는 USB, SSD에 들어가는\n플래시 메모리 회사예요", "샌디스크는 유에스비, 에스에스디에 들어가는 플래시 메모리 회사예요."),
             ("웨스턴디지털 안에 있다가\n2025년 2월 독립해 상장했죠", "웨스턴디지털 안에 있다가, 이천이십오 년 이월 독립해 상장했죠.")]),
    (s_ai, [("첫째, AI.", "첫째, 에이아이."),
            ("AI는 엄청난 데이터를\n빠르게 저장하고 꺼내 써야 해요", "에이아이는 엄청난 데이터를 빠르게 저장하고 꺼내 써야 해요."),
            ("그래서 데이터센터 매출이\n1년 새 7배 넘게 늘었죠", "그래서 데이터센터 매출이, 일 년 새 일곱 배 넘게 늘었죠.")]),
    (s_supply, [("둘째, 공급 부족.", "둘째, 공급 부족."),
                ("사려는 곳은 줄을 섰는데\n물건이 모자라요", "사려는 곳은 줄을 섰는데, 물건이 모자라요."),
                ("인기 맛집에 재료가 떨어진 셈.\n가격이 치솟을 수밖에요", "인기 맛집에 재료가 떨어진 셈. 가격이 치솟을 수밖에요.")]),
    (s_margin, [("셋째, 남는 돈이 확 늘었어요.", "셋째, 남는 돈이 확 늘었어요."),
                ("100원 팔면 23원 남던 회사가\n이제 78원을 남겨요", "백 원 팔면 이십삼 원 남던 회사가, 이제 칠십팔 원을 남겨요."),
                ("분기 매출도 1년 전의\n3.5배로 뛰었고요", "분기 매출도, 일 년 전의 삼 점 오 배로 뛰었고요.")]),
    (s_book, [("넷째, 미리 예약까지 받아뒀어요.", "넷째, 미리 예약까지 받아뒀어요."),
              ("고객 5곳과 장기계약을 맺어\n최소 420억 달러 매출을 확보했죠", "고객 다섯 곳과 장기계약을 맺어, 최소 사백이십억 달러 매출을 확보했죠.")]),
    (s_risk, [("다만 메모리는 원래\n오르내림이 큰 업종이에요", "다만 메모리는 원래, 오르내림이 큰 업종이에요."),
              ("한때 2,300달러대까지 갔다가\n지금은 1,600달러 안팎이죠", "한때 이천삼백 달러대까지 갔다가, 지금은 천육백 달러 안팎이죠.")]),
    (s_outro, [("AI, 공급 부족, 마진, 장기계약.\n네 박자가 만든 3,000%", "에이아이, 공급 부족, 마진, 장기계약. 네 박자가 만든 삼천 퍼센트."),
               ("이 흐름이 계속될지,\n같이 지켜보시죠", "이 흐름이 계속될지, 같이 지켜보시죠.")]),
]

def clip_path(text_): return os.path.join(NDIR, hashlib.md5(f"{VOICE_SID}|{SPEED}|{text_}".encode()).hexdigest() + ".npy")

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        dur = t - GAP + TAIL
        if k == 0: dur = max(dur, 1.9)
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=dur, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    starts = np.cumsum([0] + [s["dur"] for s in scenes]).tolist()
    return scenes, starts

TR = 0.4
def render_low(sc, t):
    img = bg_img("grid").copy(); d = ImageDraw.Draw(img); d.fontmode = "1"
    dx, dy = sc["fn"](img, d, t, sc["seg"], sc["dur"]) or (0, 0)
    if dx or dy:
        out = bg_img("grid").copy(); out.paste(img, (dx, dy)); img = out
    return img

def render_frame(T, scenes, starts, total):
    k = min(max(i for i in range(len(scenes)) if starts[i] <= T + 1e-9), len(scenes) - 1)
    t = T - starts[k]; sc = scenes[k]
    low = render_low(sc, t)
    if k > 0 and t < TR:
        prev = render_low(scenes[k - 1], scenes[k - 1]["dur"] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T > total - 0.8: a = (a * clamp((total - T) / 0.8)).astype(np.uint8)
    big = Image.fromarray(a)
    segs = sc["seg"] + [sc["dur"]]
    for i, s in enumerate(sc["subs"]):
        if segs[i] <= t < segs[i + 1] and T < total - 0.5:
            si = sub_img(s); big.paste(si, (0, sv.SUB_Y), si)
    return big

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    # narration
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    # BGM: A minor drive, 124 bpm
    bpm = 124; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    chords = [([57, 60, 64], 45), ([53, 57, 60], 41), ([55, 60, 64], 48), ([55, 59, 62], 43)]
    mel = [[69, None, 72, 76, 74, 72, 71, 72], [69, None, 72, 77, 76, 74, 72, None],
           [67, None, 72, 76, 79, 76, 74, 72], [71, None, 74, 79, 74, 71, 67, None]]
    risk0, risk1 = starts[6], starts[7]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = chords[b % 4]
        tense = risk0 <= t0 < risk1
        for st in range(16):
            T = t0 + st * s16
            if T >= total: break
            tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + 12), 0.045, "sq", 0.125, decay=0.08)
            if st % 2 == 0 and not tense: tone(bgm, T, 0.03, 0, 0.03 if st % 4 else 0.018, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.9, mtof(root + (12 if st % 2 else 0)), 0.16, "tri")
            m = mel[b % 4][st]
            if m and not tense and T > starts[2]: tone(bgm, T, e * 0.95, mtof(m), 0.04, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2) or tense: tone(bgm, T, 0.16, 150, 0.33, "sin", f1=45, decay=0.07)
            if bt in (1, 3) and not tense:
                tone(bgm, T, 0.12, 0, 0.11, "noise", decay=0.04); tone(bgm, T, 0.08, 190, 0.07, "tri", decay=0.04)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    # SFX
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin(T): tone(sfx, T, 0.05, 988, 0.06, "sq", 0.5); tone(sfx, T + 0.05, 0.12, 1319, 0.06, "sq", 0.5, decay=0.06)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    S = starts; sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    for j in range(26): blip(S[0] + 0.05 + 1.25 * (1 - (1 - j / 26) ** 0.5), 900 + j * 40, 0.035)   # counter ticks
    tone(sfx, S[0] + 0.05, 1.25, 200, 0.05, "sq", 0.5, f1=1600)
    thump(S[0] + 1.3); ding(S[0] + 1.32); thump(sg(0, 1))
    for k, title in enumerate(["", "SANDISK", "AI BOOM", "SHORTAGE", "MARGIN 78%", "BOOKED", "WILD RIDE", "4 REASONS"]):
        if k > 0: swoosh(S[k]); typing(S[k] + 0.1, title)
    for i in range(3): blip(S[1] + 0.6 + i * 0.35, 900, 0.05)
    tone(sfx, sg(1, 1) + 0.5, 0.2, 0, 0.1, "noise", decay=0.03); thump(sg(1, 1) + 1.5)
    ding(sg(2, 2))
    for i in range(9): blip(S[3] + 0.3 + i * 0.22 + 0.6, 600, 0.03)
    tone(sfx, sg(3, 2), 1.6, 220, 0.05, "sq", 0.5, f1=1200)
    for j in range(6): coin(sg(4, 1) + 0.1 + j * 0.12)
    for j in range(16): coin(sg(4, 1) + 1.4 + j * 0.075)
    thump(sg(4, 2)); ding(sg(4, 2) + 0.02)
    for kk in range(11): blip(S[5] + 0.5 + kk * 0.12, 1200, 0.03)
    thump(sg(5, 1) + 0.3); coin(sg(5, 1) + 0.35)
    tone(sfx, sg(6, 1) + 0.6, 0.8, 700, 0.06, "sq", 0.5, f1=120)
    for i in range(4): thump(S[7] + 0.3 + i * 0.45)
    thump(S[7] + 2.3)
    for j, m in enumerate([72, 76, 79, 84]): tone(sfx, S[7] + 2.3 + j * 0.1, 0.18, mtof(m), 0.07, "sq", 0.25, decay=0.12)
    # duck under narration
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]])
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

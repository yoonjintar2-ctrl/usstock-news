import math, sys, os, subprocess, wave
import numpy as np
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, ImageOps

BASE = os.path.dirname(os.path.abspath(__file__))
FD = os.path.join(BASE, "fonts/galmuri-2.40.3/package/dist")
W, H, S = 270, 480, 4
FW, FH = W * S, H * S
FPS = 30

F24 = ImageFont.truetype(f"{FD}/Galmuri11-Bold.ttf", 24)
F12 = ImageFont.truetype(f"{FD}/Galmuri11-Bold.ttf", 12)
F12R = ImageFont.truetype(f"{FD}/Galmuri11.ttf", 12)
F9 = ImageFont.truetype(f"{FD}/Galmuri9.ttf", 10)

def noto_kr(size):
    p = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
    for i in range(12):
        f = ImageFont.truetype(p, size, index=i)
        if f.getname()[0] == "Noto Sans CJK KR":
            return f
    return ImageFont.truetype(p, size)

SUBF = noto_kr(56)

BG = (10, 14, 30); GRID = (20, 28, 52); SHADOW = (0, 0, 0)
WHITE = (236, 238, 244); YEL = (255, 204, 64); RED = (240, 72, 72)
GRN = (86, 222, 112); CYAN = (96, 190, 255); ORG = (255, 128, 60)
GRAY = (128, 138, 168); DIM = (52, 62, 96)

# ------------------------------------------------------------ helpers
def lerp(a, b, u): return a + (b - a) * u
def clamp(u, a=0.0, b=1.0): return max(a, min(b, u))
def prog(t, t0, t1): return clamp((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def ease(u): return u * u * (3 - 2 * u)
def blink(t, hz=2.5): return (t * hz) % 1 < 0.6

@lru_cache(None)
def bg_img(kind="grid"):
    im = Image.new("RGB", (W, H), BG if kind == "grid" else (16, 8, 12))
    d = ImageDraw.Draw(im)
    g = GRID if kind == "grid" else (40, 16, 22)
    for x in range(0, W, 10): d.line([(x, 0), (x, H)], fill=g)
    for y in range(0, H, 10): d.line([(0, y), (W, y)], fill=g)
    return im

def text(d, xy, s, font, fill, anchor="la", shadow=True):
    x, y = xy
    if shadow:
        d.text((x + 1, y + 1), s, font=font, fill=SHADOW, anchor=anchor)
    d.text((x, y), s, font=font, fill=fill, anchor=anchor)

def ctext(d, y, s, font, fill, full=None, cx=W // 2, shadow=True):
    """centered text that stays put while typing (aligned by full string width)"""
    full = full if full is not None else s
    w = d.textlength(full, font=font)
    text(d, (int(cx - w / 2), y), s, font, fill, shadow=shadow)

def typed(s, t, t0, cps=20):
    n = int(max(0.0, t - t0) * cps)
    return s[:n]

def fit_font(d, s, maxw=250):
    return F24 if d.textlength(s, font=F24) <= maxw else F12

def header(d, t, small, big, sub, col=YEL):
    if small:
        ctext(d, 14, small, F9, GRAY)
    f = fit_font(d, big)
    ctext(d, 28, typed(big, t, 0.1, 22), f, col, full=big)
    if sub:
        t0 = 0.1 + len(big) / 22 + 0.1
        ctext(d, 62, typed(sub, t, t0, 26), F12, WHITE, full=sub)

def bubble(d, x, y, s, col=WHITE, tcol=(10, 10, 20)):
    w = int(d.textlength(s, font=F9)) + 6
    d.rectangle([x, y, x + w, y + 12], fill=col)
    d.polygon([(x + 4, y + 12), (x + 8, y + 12), (x + 4, y + 16)], fill=col)
    d.text((x + 3, y + 1), s, font=F9, fill=tcol)

def gauge(d, x, y, w, frac, col, label):
    d.text((x, y), label, font=F9, fill=GRAY)
    pct = f"{int(round(frac * 100))}%"
    d.text((x + w, y), pct, font=F9, fill=col, anchor="ra")
    d.rectangle([x, y + 11, x + w, y + 17], outline=GRAY)
    fw = int((w - 4) * frac)
    if fw > 0:
        d.rectangle([x + 2, y + 13, x + 2 + fw, y + 15], fill=col)

def square(d, x, y, col, s=3):
    d.rectangle([int(x), int(y), int(x) + s - 1, int(y) + s - 1], fill=col)

def fly(d, p0, p1, u, col, arc=14):
    if 0 <= u <= 1:
        x = lerp(p0[0], p1[0], u); y = lerp(p0[1], p1[1], u) - math.sin(math.pi * u) * arc
        square(d, x, y, col)

# ------------------------------------------------------------ sprites
@lru_cache(None)
def whale_sprite(scale=1, flip=False):
    im = Image.new("RGBA", (46, 28), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    body = (44, 112, 206); dark = (18, 56, 128); belly = (164, 212, 246)
    d.polygon([(13, 15), (5, 8), (1, 2), (6, 4), (9, 0), (10, 7), (16, 13)], fill=body)
    d.ellipse([9, 8, 45, 27], fill=body)
    d.ellipse([17, 18, 42, 27], fill=belly)
    d.ellipse([9, 8, 45, 27], outline=dark)
    d.line([(35, 20), (44, 19)], fill=dark)
    d.rectangle([35, 13, 37, 15], fill=(255, 255, 255)); d.point((36, 14), fill=(10, 10, 20))
    d.line([(29, 11), (31, 10)], fill=(120, 180, 240))
    if scale > 1: im = im.resize((46 * scale, 28 * scale), Image.NEAREST)
    if flip: im = ImageOps.mirror(im)
    return im

@lru_cache(None)
def ant_sprite(frame=0, scale=1, flip=False, col=ORG):
    im = Image.new("RGBA", (15, 11), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    dk = tuple(int(c * 0.6) for c in col)
    legs = [[(3, 7), (2, 10)], [(7, 6), (7, 10)], [(9, 6), (10, 10)]] if frame == 0 else \
           [[(3, 7), (4, 10)], [(7, 6), (6, 10)], [(9, 6), (8, 10)]]
    for l in legs: d.line(l, fill=dk)
    d.ellipse([0, 2, 6, 8], fill=col)
    d.ellipse([6, 4, 8, 6], fill=col)
    d.ellipse([8, 2, 13, 7], fill=col)
    d.point((11, 4), fill=(255, 255, 255)); d.point((12, 4), fill=(10, 10, 20))
    d.line([(11, 2), (13, 0)], fill=dk); d.point((14, 0), fill=dk)
    if scale > 1: im = im.resize((15 * scale, 11 * scale), Image.NEAREST)
    if flip: im = ImageOps.mirror(im)
    return im

def put(img, spr, x, y):
    img.paste(spr, (int(x), int(y)), spr)

def ant(img, x, y, t, flip=True, walking=False, scale=1, col=ORG):
    fr = int(t * (8 if walking else 2)) % 2
    put(img, ant_sprite(fr, scale, flip, col), x, y)

def whale(img, x, y, t, scale=1, flip=False):
    put(img, whale_sprite(scale, flip), x, y + round(math.sin(t * 2.2) * 1.5))

# ------------------------------------------------------------ chart data
def gen_candles():
    rng = np.random.default_rng(11)
    segs = [(15, 100, 'flat'), (10, 66, 'drop'), (15, 226, 'pump'), (10, 218, 'top'), (10, 86, 'crash')]
    out = []; p = 100.0
    for n, target, kind in segs:
        start = p
        for i in range(n):
            u = (i + 1) / n
            if kind == 'flat':
                base = 100 + math.sin(i * 1.3) * 2.5; noise = 2.0; vol = 8 + i * 0.5
            elif kind == 'drop':
                base = lerp(start, target, ease(u)); noise = 3.5; vol = 30 + 10 * math.sin(u * 3)
            elif kind == 'pump':
                base = lerp(start, target, u ** 1.6); noise = 5; vol = 40 + 60 * u
            elif kind == 'top':
                base = target + math.sin(i * 1.9) * 9; noise = 6; vol = 110 - i * 3
            else:
                base = lerp(start, target, 1 - (1 - u) ** 2); noise = 5; vol = 70 - i * 3
            c = base + rng.uniform(-noise, noise)
            o = p
            h = max(o, c) + rng.uniform(1, 5); l = min(o, c) - rng.uniform(1, 5)
            out.append((o, c, h, l, max(4, vol)))
            p = c
    return out

CANDLES = gen_candles()
CB = (12, 96, 258, 278)          # chart box
PY0, PY1 = 106, 248              # price area
VY1 = 276                        # volume bottom
CX0 = 16
PHASES = [(0, 15, '매집', CYAN), (15, 25, '흔들기', RED), (25, 40, '띄우기', GRN), (40, 50, '설거지', YEL), (50, 60, '폭락', RED)]

def py(p): return int(PY1 - (p - 50) / 200 * (PY1 - PY0))

def draw_chart(d, nvis, avg_line=None):
    d.rectangle(CB, fill=(8, 11, 24), outline=DIM)
    for p in (100, 150, 200):
        y = py(p)
        for x in range(CB[0] + 2, CB[2] - 1, 4): d.point((x, y), fill=(34, 42, 70))
    last = None
    for i in range(int(math.ceil(nvis))):
        if i >= len(CANDLES): break
        fr = clamp(nvis - i)
        o, c, h, l, v = CANDLES[i]
        cc = o + (c - o) * fr
        x = CX0 + i * 4
        col = GRN if cc >= o else RED
        hh = max(o, cc) + (h - max(o, c)) * fr; ll = min(o, cc) - (min(o, c) - l) * fr
        d.line([(x + 1, py(hh)), (x + 1, py(ll))], fill=col)
        d.rectangle([x, py(max(o, cc)), x + 2, py(min(o, cc))], fill=col)
        vh = int(v / 120 * 20 * fr)
        if vh > 0:
            vc = tuple(int(k * 0.45) for k in col)
            d.rectangle([x, VY1 - vh, x + 2, VY1], fill=vc)
        last = cc
    if avg_line is not None:
        y = py(avg_line)
        for x in range(CB[0] + 2, CB[2] - 1, 6): d.line([(x, y), (x + 2, y)], fill=YEL)
        d.text((CB[0] + 4, y - 11), "개미 평단", font=F9, fill=YEL)
    if last is not None:
        chg = (last - 100) / 100 * 100
        col = GRN if chg >= 0 else RED
        d.text((CB[0] + 4, CB[1] + 3), f"PRICE {int(last * 100):,}", font=F9, fill=WHITE)
        d.text((CB[2] - 4, CB[1] + 3), f"{chg:+.1f}%", font=F9, fill=col, anchor="ra")
    for a, b, name, col in PHASES:
        if nvis >= a + 1:
            x0 = CX0 + a * 4; x1 = CX0 + b * 4 - 2
            d.line([(x0, 281), (x1, 281)], fill=col)
            d.text(((x0 + x1) // 2, 283), name, font=F9, fill=col, anchor="ma")

# ------------------------------------------------------------ scenes
# each scene: f(img, d, t) -> (dx, dy) shake
WHALE_POS = (12, 308)
ANT_SLOTS = [(118 + (i % 7) * 20, 320 + (i // 7) * 20) for i in range(14)]

def s_intro(img, d, t):
    # ticker
    tick = "  A주 ▲3.2%   B주 ▼1.4%   C주 ▲8.9%   D주 ▼5.1%   E주 ▲0.7%  " * 3
    off = int(t * 30) % int(d.textlength(tick[:len(tick) // 3], font=F9))
    d.rectangle([0, 6, W, 18], fill=(6, 9, 20))
    d.text((-off, 7), tick, font=F9, fill=GRAY)
    ctext(d, 84, typed("THE MARKET WAR", t, 0.2, 18), F12, YEL, full="THE MARKET WAR")
    if t > 1.0:
        a, vs, b = "세력", " VS ", "개미"
        wa, wv, wb = (d.textlength(s, font=F24) for s in (a, vs, b))
        x = int(W / 2 - (wa + wv + wb) / 2); y = 104
        text(d, (x, y), a, F24, CYAN)
        if blink(t, 2): text(d, (x + wa, y), vs, F24, YEL)
        if t > 1.5: text(d, (x + wa + wv, y), b, F24, ORG)
    if t > 2.0:
        ctext(d, 140, typed("보이지 않는 전쟁", t, 2.0, 14), F12, WHITE, full="보이지 않는 전쟁")
    wx = lerp(-100, 14, ease(prog(t, 0.4, 1.6)))
    whale(img, wx, 220, t, scale=2)
    for i in range(8):
        tx = 136 + (i % 4) * 32; ty = 232 + (i // 4) * 30
        ax = lerp(290 + i * 10, tx, ease(prog(t, 0.8 + i * 0.1, 2.0 + i * 0.1)))
        ant(img, ax, ty, t + i * 0.3, flip=True, walking=ax > tx + 1, scale=2)
    if t > 2.4:
        for k in range(6):
            ph = (t * 3 + k * 0.37) % 1
            if ph < 0.5:
                x = 116 + (k * 13) % 18; y = 234 + (k * 7) % 40
                square(d, x, y, YEL if k % 2 else WHITE, 2)
    return (0, 0)

def s_whale(img, d, t):
    header(d, t, "세력의 정체", "WHO IS THE WHALE", "큰손 = 기관 · 대형 자금 · 작전 세력", CYAN)
    whale(img, 89, 86, t, scale=2)
    # bars
    d.text((14, 160), "세력 자금", font=F12, fill=CYAN)
    u1 = ease(prog(t, 1.4, 3.0))
    d.text((256, 162), "1,000억", font=F9, fill=CYAN, anchor="ra")
    d.rectangle([14, 176, 256, 186], outline=DIM)
    if u1 > 0: d.rectangle([16, 178, 16 + int(238 * u1), 184], fill=CYAN)
    d.text((14, 202), "개미 1명", font=F12, fill=ORG)
    d.text((256, 204), "1,000만", font=F9, fill=ORG, anchor="ra")
    d.rectangle([14, 218, 256, 228], outline=DIM)
    if t > 2.6: d.rectangle([16, 220, 17, 226], fill=ORG)
    if t > 4.6:
        d.text((14, 244), "개미 1,000명 합쳐도", font=F12, fill=ORG)
        d.text((256, 246), "100억", font=F9, fill=ORG, anchor="ra")
        u2 = ease(prog(t, 5.0, 6.6))
        d.rectangle([14, 260, 256, 270], outline=DIM)
        if u2 > 0: d.rectangle([16, 262, 16 + int(23.8 * u2), 268], fill=ORG)
    if t > 7.0 and blink(t, 2):
        ctext(d, 280, "= 세력의 10%", F12, RED)
    n = int(clamp((t - 4.8) / 2.0) * 16)
    for i in range(n):
        ant(img, 6 + i * 16, 302 + (i % 2) * 2, t + i * 0.2, flip=False)
    return (0, 0)

def chart_n(t, a, b, t0, t1):
    return lerp(a, b, prog(t, t0, t1))

def s_accum(img, d, t):
    header(d, t, "STEP 1", "ACCUMULATE", "매집 : 조용히 사 모으기", CYAN)
    draw_chart(d, chart_n(t, 0, 15, 0.6, 8.6))
    whale(img, *WHALE_POS, t)
    leavers = [1, 3, 4, 6]
    held = 0.10
    for i in range(7):
        sx, sy = 118 + i * 20, 322
        if i in leavers:
            k = leavers.index(i); ts = 1.2 + k * 1.8
            fly(d, (sx + 2, sy), (WHALE_POS[0] + 30, WHALE_POS[1] + 6), (t - ts) / 0.6, GRN)
            if t > ts + 0.6: held += 0.0625
            if ts - 0.9 < t < ts and k in (0, 2): bubble(d, sx - 4, sy - 18, "지루해…")
            if t > ts + 0.8:
                x = sx + (t - ts - 0.8) * 40
                if x < W + 5: ant(img, x, sy, t, flip=False, walking=True)
                continue
        ant(img, sx, sy, t + i * 0.4, flip=True)
    gauge(d, WHALE_POS[0], 340, 74, held, CYAN, "세력 보유")
    return (0, 0)

STAY3 = [0, 2, 5]
def s_shake(img, d, t):
    header(d, t, "STEP 2", "SHAKE OUT", "흔들기 : 겁줘서 털어내기", RED)
    draw_chart(d, 15 if t < 1.4 else chart_n(t, 15, 25, 1.4, 3.6))
    whale(img, *WHALE_POS, t)
    held = 0.35
    for j, i in enumerate(STAY3):
        sx, sy = 118 + i * 20, 322
        ts = 2.2 + j * 0.7
        fly(d, (sx + 2, sy), (WHALE_POS[0] + 30, WHALE_POS[1] + 6), (t - ts) / 0.5, GRN)
        if t > ts + 0.5: held += 0.04
        jump = -abs(math.sin(t * 12 + j)) * 4 if 1.6 < t < 4.2 else 0
        if j < 2 and t > 4.4:
            x = sx + (t - 4.4) * 60
            if x < W + 5: ant(img, x, sy, t, flip=False, walking=True)
            continue
        ant(img, sx, sy + jump, t, flip=True)
        if 1.6 < t < 4.4 and blink(t + j * 0.2, 4):
            d.text((sx + 6, sy - 12 + jump), "!", font=F12, fill=RED)
    if 1.6 < t < 5.0 and blink(t, 3):
        ctext(d, 170, "PANIC SELL!", F24, RED, cx=180)
    if t > 5.5:
        bubble(d, WHALE_POS[0] + 50, WHALE_POS[1] - 4, "싸게 잘 샀다", YEL)
    gauge(d, WHALE_POS[0], 340, 74, held, CYAN, "세력 보유")
    sh = 2 if 1.6 < t < 3.4 else 0
    return (int(math.sin(t * 60) * sh), int(math.cos(t * 47) * sh))

NEWS = [(1.8, "[속보] 신사업 진출!"), (3.4, "거래량 폭발!"), (5.0, "목표주가 상향!")]
def s_pump(img, d, t):
    header(d, t, "STEP 3", "PUMP IT UP", "띄우기 : 관심 끌어모으기", GRN)
    draw_chart(d, chart_n(t, 25, 40, 1.0, 7.6))
    for k, (ts, s) in enumerate(NEWS):
        if t > ts:
            y = 120 + k * 22
            w = int(d.textlength(s, font=F12)) + 10
            bc = YEL if (t - ts) < 0.6 and blink(t, 6) else WHITE
            d.rectangle([20, y, 20 + w, y + 16], fill=(20, 24, 44), outline=bc)
            d.text((25, y + 2), s, font=F12, fill=bc)
    whale(img, *WHALE_POS, t)
    gauge(d, WHALE_POS[0], 340, 74, 0.47, CYAN, "세력 보유")
    if t > 6.6: bubble(d, WHALE_POS[0] + 50, WHALE_POS[1] - 4, "때가 됐군", YEL)
    # stubborn ant from previous scene in slot 0, others arrive
    for k in range(14):
        sx, sy = ANT_SLOTS[k]
        if k == 0:
            ant(img, sx, sy, t, flip=True); continue
        ta = 1.4 + k * 0.4
        x = lerp(W + 20, sx, prog(t, ta, ta + 1.0))
        if t > ta:
            ant(img, x, sy, t + k * 0.3, flip=True, walking=x > sx + 1)
            if k in (3, 8, 11) and t > ta + 1.0 and blink(t + k, 3):
                d.text((sx + 4, sy - 11), "!!", font=F9, fill=GRN)
    cnt = int(lerp(1, 248, prog(t, 1.4, 7.6)))
    d.text((256, 362), f"개미 {cnt}명 매수", font=F9, fill=ORG, anchor="ra")
    return (0, 0)

def s_dump(img, d, t):
    header(d, t, "STEP 4", "DISTRIBUTION", "설거지 : 고점에서 떠넘기기", YEL)
    draw_chart(d, chart_n(t, 40, 50, 0.8, 8.4))
    whale(img, *WHALE_POS, t)
    for k in range(14):
        sx, sy = ANT_SLOTS[k]
        ant(img, sx, sy, t + k * 0.3, flip=True)
    n_sp = 30
    for s in range(n_sp):
        ts = 1.0 + s * 0.25
        k = (s * 5) % 14
        tx, ty = ANT_SLOTS[k]
        fly(d, (WHALE_POS[0] + 30, WHALE_POS[1] + 6), (tx + 4, ty - 2), (t - ts) / 0.7, RED, arc=20)
    u = prog(t, 1.0, 8.6)
    if blink(t, 2.5):
        d.text((WHALE_POS[0] + 50, WHALE_POS[1] + 8), "SELL▼", font=F9, fill=RED)
        d.text((120, 360), "BUY▲", font=F9, fill=GRN)
    gauge(d, WHALE_POS[0], 340, 74, lerp(0.47, 0.05, u), CYAN, "세력 보유")
    gauge(d, 154, 358, 100, lerp(0.08, 0.46, u), ORG, "개미 보유")
    return (0, 0)

def s_crash(img, d, t):
    header(d, t, "RESULT", "BAG HOLDERS", "결과 : 고점에 물린 개미", RED)
    draw_chart(d, chart_n(t, 50, 60, 0.6, 3.8), avg_line=220)
    if t > 4.0 and blink(t, 2):
        last = CANDLES[-1][1]
        ctext(d, 150, f"{(last - 220) / 220 * 100:.0f}%", F24, RED, cx=64)
    wx = lerp(WHALE_POS[0], -70, ease(prog(t, 1.2, 3.4)))
    whale(img, wx, WHALE_POS[1], t, flip=True)
    if 1.2 < t < 3.8:
        d.text((int(wx) + 50, WHALE_POS[1] - 4), "+수익 ₩₩₩", font=F9, fill=YEL)
    sad = (170, 92, 58)
    for k in range(14):
        sx, sy = ANT_SLOTS[k]
        ant(img, sx, sy, 0, flip=True, col=sad)
        if t > 2.0 and k % 3 == 0:
            dy = int((t * 4 + k) % 3)
            d.point((sx + 1, sy - 1 + dy), fill=CYAN); d.point((sx + 1, sy + dy), fill=CYAN)
    if t > 4.6:
        bubble(d, ANT_SLOTS[2][0], ANT_SLOTS[2][1] - 18, "물렸다…")
    if t > 5.6:
        bubble(d, ANT_SLOTS[10][0] - 30, ANT_SLOTS[10][1] - 18, "본전만…")
    sh = 2 if 0.8 < t < 2.4 else 0
    return (int(math.sin(t * 61) * sh), int(math.cos(t * 43) * sh))

def s_warn(img, d, t):
    header(d, t, "NOTICE", "WARNING", "", RED)
    # alert triangle
    if blink(t, 1.6):
        d.polygon([(135, 72), (165, 124), (105, 124)], outline=RED)
        d.polygon([(135, 78), (160, 121), (110, 121)], outline=RED)
        d.rectangle([133, 92, 137, 110], fill=RED); d.rectangle([133, 114, 137, 117], fill=RED)
    d.rectangle([16, 150, 254, 270], fill=(12, 6, 10), outline=RED)
    d.rectangle([16, 150, 254, 163], fill=RED)
    d.text((20, 151), "market_alert.log", font=F9, fill=(16, 8, 12))
    lines = [(0.6, "> 시세조종 · 주가조작", WHITE), (1.8, "> 자본시장법 위반 = 불법", RED),
             (4.4, "> 그러나 패턴은 반복된다", YEL)]
    for k, (ts, s, c) in enumerate(lines):
        d.text((24, 176 + k * 28), typed(s, t, ts, 18), font=F12, fill=c)
    if blink(t, 2): d.rectangle([24, 256, 30, 262], fill=WHITE)
    return (0, 0)

ITEMS = [("이유 없는 급등은 의심", "재료 없이 오르면 누가 사는지 보라"),
         ("뉴스+거래량 폭발 = 경계", "관심이 몰릴 때 누군가는 판다"),
         ("고점 추격매수 금지", "이미 오른 차트에 올라타지 말 것"),
         ("분할매수 · 손절선 먼저", "한 번에 다 걸지 않기")]
ITEM_T0 = 2.5; ITEM_DT = 2.8
def s_survive(img, d, t):
    header(d, t, "개미 생존 수칙", "HOW TO SURVIVE", "", GRN)
    d.rectangle([12, 70, 258, 286], fill=(6, 14, 10), outline=GRN)
    d.rectangle([12, 70, 258, 83], fill=GRN)
    d.text((16, 71), "survival.exe", font=F9, fill=(6, 14, 10))
    for i, (a, b) in enumerate(ITEMS):
        ts = ITEM_T0 + i * ITEM_DT
        if t < ts - 0.2: continue
        y = 96 + i * 46
        done = t > ts + 2.2
        d.text((20, y), "[V]" if done else "[ ]", font=F12, fill=GRN if done else GRAY)
        d.text((46, y), typed(a, t, ts, 16), font=F12, fill=YEL if done else WHITE)
        if t > ts + 1.2:
            d.text((46, y + 16), typed(b, t, ts + 1.2, 30), font=F9, fill=GRAY)
    # ant with shield
    ay = 304 + int(-abs(math.sin(t * 3)) * 3)
    ant(img, 104, ay, t, flip=False, scale=2)
    d.rectangle([138, ay - 2, 148, ay + 20], fill=CYAN, outline=WHITE)
    d.line([(143, ay + 1), (143, ay + 17)], fill=WHITE)
    return (0, 0)

def s_outro(img, d, t):
    whale(img, 206, 40, t, flip=True)
    if t < 2.6:
        if blink(t, 2): ctext(d, 120, "GAME OVER?", F24, RED)
    else:
        if blink(t, 2): ctext(d, 120, "CONTINUE ▶", F24, YEL)
        ctext(d, 152, "YES", F12, GRN)
    ay = 196 + int(-abs(math.sin(t * 4)) * 6 if t > 2.6 else 0)
    ant(img, 113, ay, t, flip=False, scale=3, col=ORG if t > 2.6 else (150, 84, 54))
    if t > 3.2:
        ctext(d, 252, typed("패턴을 알면", t, 3.2, 14), F12, WHITE, full="패턴을 알면")
        ctext(d, 270, typed("개미도 당하지 않는다", t, 4.0, 14), F12, YEL, full="개미도 당하지 않는다")
    ctext(d, 364, "※ 교육용 콘텐츠이며 투자 권유가 아닙니다", F9, GRAY, shadow=False)
    return (0, 0)

SCENES = [
    (8, s_intro, "grid", [(0.3, 4.0, "주식시장에는\n보이지 않는 전쟁이 있습니다"),
                          (4.0, 7.8, "큰돈을 가진 '세력'과\n개인 투자자 '개미'의 싸움이죠")]),
    (9, s_whale, "grid", [(0.3, 4.5, "세력은 주가를 움직일 만큼\n큰 자금을 가진 쪽입니다"),
                          (4.5, 8.8, "개미 수천 명이 힘을 합쳐도\n상대가 안 될 때가 많죠")]),
    (10, s_accum, "grid", [(0.3, 5.0, "1단계는 매집.\n관심 없는 주식을 조용히 사 모읍니다"),
                           (5.0, 9.8, "주가는 지루하게 옆으로 기고\n지친 개미들은 팔고 떠나죠")]),
    (10, s_shake, "grid", [(0.3, 5.0, "2단계는 흔들기.\n일부러 주가를 크게 떨어뜨립니다"),
                           (5.0, 9.8, "겁먹은 개미가 던진 물량은\n세력이 싸게 주워 담습니다")]),
    (10, s_pump, "grid", [(0.3, 5.0, "3단계는 띄우기.\n급등과 호재 뉴스로 시선을 모읍니다"),
                          (5.0, 9.8, "놓칠까 봐 불안해진 개미들이\n뒤늦게 몰려들기 시작하죠")]),
    (10, s_dump, "grid", [(0.3, 5.0, "4단계는 설거지.\n고점에서 개미에게 물량을 넘깁니다"),
                          (5.0, 9.8, "개미가 사고 있을 때\n세력은 팔고 있었던 겁니다")]),
    (9, s_crash, "grid", [(0.3, 4.6, "세력이 빠져나가면\n주가는 다시 제자리로 돌아오고"),
                          (4.6, 8.8, "고점에 물린 개미만\n남게 됩니다")]),
    (8, s_warn, "warn", [(0.3, 4.2, "물론 이런 시세조종은\n자본시장법 위반, 명백한 불법입니다"),
                         (4.2, 7.8, "하지만 비슷한 패턴은\n시장에서 계속 반복되죠")]),
    (14, s_survive, "grid", [(0.3, 2.5, "그래서, 개미 생존 수칙")] +
        [(ITEM_T0 + i * ITEM_DT, ITEM_T0 + (i + 1) * ITEM_DT - 0.05, s) for i, s in enumerate([
            "첫째, 이유 없는 급등은\n의심부터 하세요",
            "둘째, 뉴스와 거래량이\n동시에 터지면 경계하세요",
            "셋째, 이미 오른 주식을\n추격 매수하지 마세요",
            "넷째, 나눠서 사고\n손절 기준은 미리 정하세요"])]),
    (8, s_outro, "grid", [(0.3, 3.4, "세력의 패턴을 알면"),
                          (3.4, 7.2, "개미도 더 이상\n당하지 않습니다")]),
]
STARTS = np.cumsum([0] + [s[0] for s in SCENES]).tolist()
TOTAL = STARTS[-1]
TR = 0.4

@lru_cache(None)
def sub_img(s):
    lines = s.split("\n")
    f = SUBF
    tmp = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while max(tmp.textlength(l, font=f) for l in lines) > 980:
        f = ImageFont.truetype(f.path, f.size - 2, index=f.index)
    lh = int(f.size * 1.32)
    im = Image.new("RGBA", (FW, lh * len(lines) + 20), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for i, l in enumerate(lines):
        d.text((FW // 2, 8 + i * lh), l, font=f, fill=(255, 255, 255), anchor="ma",
               stroke_width=6, stroke_fill=(0, 0, 0))
    return im

def render_low(k, t):
    dur, fn, kind, _ = SCENES[k]
    img = bg_img(kind).copy()
    d = ImageDraw.Draw(img); d.fontmode = "1"
    dx, dy = fn(img, d, t) or (0, 0)
    if dx or dy:
        out = bg_img(kind).copy(); out.paste(img, (dx, dy)); img = out
    return img

PERMS = {}
def dissolve_mask(k, p):
    if k not in PERMS:
        PERMS[k] = np.random.default_rng(k).permutation(27 * 48).reshape(48, 27)
    m = (PERMS[k] < p * 27 * 48).astype(np.uint8) * 255
    return Image.fromarray(m, "L").resize((W, H), Image.NEAREST)

def render_frame(T):
    k = max(i for i in range(len(SCENES)) if STARTS[i] <= T + 1e-9)
    k = min(k, len(SCENES) - 1)
    t = T - STARTS[k]
    low = render_low(k, t)
    if k > 0 and t < TR:
        prev = render_low(k - 1, SCENES[k - 1][0] + t)
        low = Image.composite(low, prev, dissolve_mask(k, t / TR))
    big = low.resize((FW, FH), Image.NEAREST)
    a = np.asarray(big).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    # outro fade
    if T > TOTAL - 1.0:
        a = (a * clamp(TOTAL - T)).astype(np.uint8)
    big = Image.fromarray(a)
    for s0, s1, s in SCENES[k][3]:
        if s0 <= t < s1 and T < TOTAL - 0.6:
            si = sub_img(s); big.paste(si, (0, 1520), si)
    return big

# ------------------------------------------------------------ audio
SR = 44100
def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)

def tone(buf, start, dur, f0, vol, kind="sq", duty=0.5, f1=None, decay=None, att=0.004, rel=0.02):
    i0 = int(start * SR); n = int(dur * SR)
    if i0 >= len(buf) or n <= 0: return
    n = min(n, len(buf) - i0)
    tt = np.arange(n) / SR
    if f1:
        f = f0 * (f1 / f0) ** (tt / dur); ph = np.cumsum(f) / SR
    else:
        ph = f0 * tt
    if kind == "sq": w = np.where((ph % 1) < duty, 1.0, -1.0)
    elif kind == "tri": w = 2 * np.abs(2 * (ph % 1) - 1) - 1
    elif kind == "sin": w = np.sin(2 * np.pi * ph)
    else: w = np.random.default_rng(int(start * 1000)).uniform(-1, 1, n)
    env = np.ones(n)
    a = min(n, int(att * SR)); r = min(n, int(rel * SR))
    if a: env[:a] = np.linspace(0, 1, a)
    if r: env[-r:] *= np.linspace(1, 0, r)
    if decay: env *= np.exp(-tt / decay)
    buf[i0:i0 + n] += w * env * vol

def make_audio(path):
    N = int((TOTAL + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N)
    bpm = 112; beat = 60 / bpm; e = beat / 2; s16 = beat / 4
    chords = [([57, 60, 64], 45), ([53, 57, 60], 41), ([55, 60, 64], 48), ([55, 59, 62], 43)]
    mel = [[69, None, 72, 76, 74, 72, 71, 72], [69, None, 72, 77, 76, 74, 72, None],
           [67, None, 72, 76, 79, 76, 74, 72], [71, None, 74, 79, 74, 71, 67, None]]
    S_ = STARTS
    def section(T):
        if T < S_[2]: return dict(arp=1, bass=1, kick=0, hat=0, snare=0, lead=0)
        if T < S_[4]: return dict(arp=1, bass=1, kick=1, hat=1, snare=0, lead=0)
        if T < S_[7]: return dict(arp=1, bass=1, kick=1, hat=1, snare=1, lead=1)
        if T < S_[8]: return dict(arp=0, bass=1, kick=0, hat=0, snare=0, lead=0)
        if T < S_[9]: return dict(arp=1, bass=1, kick=1, hat=1, snare=1, lead=1)
        return dict(arp=1, bass=1, kick=0, hat=0, snare=0, lead=0)
    bar = beat * 4; nbars = int(TOTAL / bar) + 1
    for b in range(nbars):
        t0 = b * bar
        notes, root = chords[b % 4]
        sec = section(t0)
        for st in range(16):
            T = t0 + st * s16
            if T >= TOTAL: break
            if sec["arp"]:
                tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + 12), 0.05, "sq", 0.125, decay=0.08)
            if sec["hat"] and st % 2 == 0:
                tone(bgm, T, 0.03, 0, 0.035 if st % 4 else 0.02, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= TOTAL: break
            if sec["bass"]:
                tone(bgm, T, e * 0.9, mtof(root + (12 if st % 2 else 0)), 0.16, "tri")
            if sec["lead"]:
                m = mel[b % 4][st]
                if m: tone(bgm, T, e * 0.95, mtof(m), 0.05, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= TOTAL: break
            if sec["kick"] and bt in (0, 2):
                tone(bgm, T, 0.16, 150, 0.35, "sin", f1=45, decay=0.07)
            if sec["snare"] and bt in (1, 3):
                tone(bgm, T, 0.12, 0, 0.12, "noise", decay=0.04)
                tone(bgm, T, 0.08, 190, 0.08, "tri", decay=0.04)
    # fade bgm at end
    fo = int(3.0 * SR); ie = int(TOTAL * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    bgm[:int(0.5 * SR)] *= np.linspace(0, 1, int(0.5 * SR))

    def blip(T, f=1200, v=0.05): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.09, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.08, "sq", 0.5, decay=0.1)
    def coin(T): tone(sfx, T, 0.05, 988, 0.07, "sq", 0.5); tone(sfx, T + 0.05, 0.15, 1319, 0.07, "sq", 0.5, decay=0.07)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.08, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.05, "sq", 0.5, f1=200)
    def drop(T, dur=0.9): tone(sfx, T, dur, 800, 0.12, "sq", 0.5, f1=80); tone(sfx, T, 0.5, 0, 0.18, "noise", decay=0.2)
    def alarm(T): tone(sfx, T, 0.12, 880, 0.07, "sq", 0.5); tone(sfx, T + 0.13, 0.12, 660, 0.07, "sq", 0.5)
    def rise(T, dur=1.5): tone(sfx, T, dur, 200, 0.06, "sq", 0.5, f1=1400)
    def typing(T0, s, cps):
        n = len(s)
        for c in range(0, n, 2): blip(T0 + c / cps, 1500 + (c % 3) * 150, 0.03)

    for k, (dur, fn, kind, subs) in enumerate(SCENES):
        T0 = STARTS[k]
        if k > 0: swoosh(T0)
    titles = {2: "ACCUMULATE", 3: "SHAKE OUT", 4: "PUMP IT UP", 5: "DISTRIBUTION", 6: "BAG HOLDERS",
              7: "WARNING", 8: "HOW TO SURVIVE", 1: "WHO IS THE WHALE"}
    for k, s in titles.items(): typing(STARTS[k] + 0.1, s, 22)
    typing(STARTS[0] + 0.2, "THE MARKET WAR", 18)
    tone(sfx, STARTS[0] + 1.0, 0.25, 220, 0.12, "sq", 0.5, f1=110, decay=0.15)  # 세력 VS
    tone(sfx, STARTS[0] + 1.5, 0.25, 330, 0.12, "sq", 0.5, f1=165, decay=0.15)
    # whale scene bars
    rise(STARTS[1] + 1.4, 1.6); blip(STARTS[1] + 2.6, 600, 0.08); rise(STARTS[1] + 5.0, 1.6)
    for j in range(3): alarm(STARTS[1] + 7.0 + j * 0.5) if j == 0 else None
    # accumulate coins
    for kk in range(4): coin(STARTS[2] + 1.2 + kk * 1.8 + 0.6)
    # shake out
    drop(STARTS[3] + 1.5, 1.2)
    for j in range(3): alarm(STARTS[3] + 1.8 + j * 0.6)
    for j in range(3): coin(STARTS[3] + 2.2 + j * 0.7 + 0.5)
    # pump
    rise(STARTS[4] + 1.0, 6.0)
    for ts, _ in NEWS: ding(STARTS[4] + ts)
    # dump
    for s in range(30): coin(STARTS[5] + 1.0 + s * 0.25 + 0.7) if s % 2 == 0 else None
    # crash
    drop(STARTS[6] + 0.8, 1.8)
    tone(sfx, STARTS[6] + 0.8, 0.6, 60, 0.3, "sin", f1=30, decay=0.3)
    # warn
    for j in range(3): alarm(STARTS[7] + 0.2 + j * 0.45)
    for ts, s in [(0.6, "> 시세조종 · 주가조작"), (1.8, "> 자본시장법 위반 = 불법"), (4.4, "> 그러나 패턴은 반복된다")]:
        typing(STARTS[7] + ts, s, 18)
    # survive
    for i, (a, b) in enumerate(ITEMS):
        ts = STARTS[8] + ITEM_T0 + i * ITEM_DT
        typing(ts, a, 16); ding(ts + 2.2)
    # outro
    for j, m in enumerate([72, 67, 64, 60]): tone(sfx, STARTS[9] + 0.3 + j * 0.22, 0.2, mtof(m), 0.08, "sq", 0.5, decay=0.15)
    for j, m in enumerate([60, 64, 67, 72, 76]): tone(sfx, STARTS[9] + 2.6 + j * 0.09, 0.12, mtof(m), 0.08, "sq", 0.25, decay=0.1)

    mix = bgm * 0.9 + sfx
    mix = np.tanh(mix * 1.2) / np.tanh(1.2)
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    st = np.repeat(pcm[:, None], 2, axis=1)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(st.tobytes())

# ------------------------------------------------------------ main
if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    out = os.path.join(BASE, "out"); os.makedirs(out, exist_ok=True)
    if mode == "stills":
        times = [float(x) for x in sys.argv[2].split(",")]
        for T in times:
            render_frame(T).resize((540, 960), Image.LANCZOS).save(f"{out}/still_{T:05.1f}.png")
    elif mode == "audio":
        make_audio(f"{out}/audio.wav")
    else:
        make_audio(f"{out}/audio.wav")
        nfr = int(TOTAL * FPS)
        p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
                              "-s", f"{FW}x{FH}", "-r", str(FPS), "-i", "-", "-i", f"{out}/audio.wav",
                              "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                              "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
                              f"{out}/video.mp4"], stdin=subprocess.PIPE)
        for i in range(nfr):
            p.stdin.write(render_frame(i / FPS).tobytes())
            if i % 300 == 0: print(i, "/", nfr, flush=True)
        p.stdin.close(); p.wait()
        print("done", TOTAL)

"""'엔비디아만 -5%' 썸네일 — 새 스타일: 성적표(공책 종이 + 표 + 형광펜 동그라미 + 클립) · python3 thumb_report.py <mascot.png> <out.jpg>"""
import sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
W, H = 1080, 1920
FB = '/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc'; FM = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def f(sz, black=True): return ImageFont.truetype(FB if black else FM, sz, index=1)
INK = (26, 28, 40); YEL = (255, 214, 64); NAVY = (18, 24, 52)
rng = np.random.default_rng(7)
bg = np.zeros((H, W, 3), np.float32) + np.array(NAVY, np.float32)
yy, xx = np.mgrid[0:H, 0:W]
bg *= (1.15 - 0.5 * (((xx - W / 2) / W) ** 2 + ((yy - H * 0.4) / H) ** 2))[..., None]
im = Image.fromarray(bg.clip(0, 255).astype(np.uint8)).convert('RGBA'); d = ImageDraw.Draw(im)
for x in range(0, W, 60): d.line([(x, 0), (x, H)], fill=(30, 38, 74))
for y in range(0, H, 60): d.line([(0, y), (W, y)], fill=(30, 38, 74))
# 종이
PW, PH = 860, 1000
paper = Image.new('RGBA', (PW + 80, PH + 80), (0, 0, 0, 0)); g = ImageDraw.Draw(paper)
sh = Image.new('RGBA', paper.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rectangle([52, 60, 52 + PW, 60 + PH], fill=(0, 0, 0, 170))
paper = Image.alpha_composite(sh.filter(ImageFilter.GaussianBlur(16)), paper); g = ImageDraw.Draw(paper)
g.rectangle([40, 40, 40 + PW, 40 + PH], fill=(250, 246, 234))
g.text((40 + PW // 2, 70), "11/10 반도체 성적표", font=f(64), fill=INK, anchor='ma')
g.line([(80, 160), (PW, 160)], fill=INK, width=5)
rows = [("브로드컴", "+3.9%"), ("TSMC", "+2.0%"), ("AMD", "+1.3%"), ("반도체지수", "-0.4%"), ("엔비디아", "-5.5%")]
for i, (nm, v) in enumerate(rows):
    y = 190 + i * 158; last = i == len(rows) - 1
    g.text((100, y + 28), nm, font=f(76 if last else 64, last), fill=INK)
    g.text((PW - 10, y + 20 if last else y + 28), v, font=f(96 if last else 70), fill=INK, anchor='ra')
    if not last: g.line([(80, y + 150), (PW, y + 150)], fill=(170, 166, 150), width=3)
# 형광펜 + 손그림 동그라미(엔비디아 줄)
y = 190 + 4 * 158
hl = Image.new('RGBA', paper.size, (0, 0, 0, 0)); hd = ImageDraw.Draw(hl)
hd.rounded_rectangle([70, y + 14, PW + 10, y + 150], radius=24, fill=YEL + (150,))
paper = Image.alpha_composite(paper, hl); g = ImageDraw.Draw(paper)
g.text((100, y + 28), "엔비디아", font=f(76), fill=INK); g.text((PW - 10, y + 20), "-5.5%", font=f(96), fill=INK, anchor='ra')
for k in range(3):
    pts = [(PW - 190 + math.cos(a) * (210 + k * 4) + math.sin(a * 3) * 5, y + 82 + math.sin(a) * (84 + k * 3)) for a in np.linspace(0.3 + k * 0.2, 6.6 + k * 0.2, 80)]
    g.line(pts, fill=INK, width=7, joint='curve')
paper = paper.rotate(-3, resample=Image.BICUBIC, expand=True)
im.alpha_composite(paper, (W // 2 - paper.width // 2, 520))
d = ImageDraw.Draw(im)
# 집게
d.rounded_rectangle([430, 500, 650, 610], radius=18, fill=(60, 64, 80), outline=(20, 22, 30), width=6); d.rounded_rectangle([490, 470, 590, 540], radius=30, outline=(180, 184, 196), width=12)
# 마스코트
m = Image.open(sys.argv[1]).convert('RGBA'); m = m.crop(m.getbbox()); s = 620 / m.height
m = m.resize((int(m.width * s), int(m.height * s)), Image.LANCZOS)
im.alpha_composite(m, (W - m.width + 10, H - m.height + 330))
d = ImageDraw.Draw(im)
d.text((W // 2, 120), "반도체는 버텼는데…", font=f(80, False), fill=(240, 238, 230), anchor='ma')
d.text((W // 2, 230), "엔비디아만 -5%", font=f(140), fill=YEL, anchor='ma', stroke_width=6, stroke_fill=(10, 12, 24))
im.convert('RGB').save(sys.argv[2], quality=92); print('ok')

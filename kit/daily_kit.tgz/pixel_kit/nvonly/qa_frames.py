"""host_compose로 특정 시각 프레임만 합성해 PNG로 (QA용)"""
import sys, os, json
sys.argv_saved = list(sys.argv)
sys.path.insert(0, '/home/claude/pixel_kit')
import numpy as np
from PIL import Image
import host_compose as HC
S = json.load(open('nvonly/out/spec.json')); total = S['total']; FPS = 30
def frame(t, step=2):
    i = int(round(t * FPS)); fr = np.asarray(Image.open(f'nvonly/out/px/{i:05d}.png').convert('RGB'), dtype=np.float32).copy()
    gfade = min(1.0, max(0.0, (total - t) / 0.8))
    for h in S['hosts']:
        if not (h['t0'] <= t < h['t1']): continue
        a = HC.host_alpha(h, t, total) * gfade
        loc = int(round((t - h['t0']) * FPS)) // step * step
        mp = f"nvonly/out/m/host_{h['k']}/{loc:05d}.png"
        if not os.path.exists(mp): mp = '/home/claude/mascot3d/ev/host_A.png'
        HC.paste(fr, HC.shadow(), HC.M_CX - 260, HC.M_FOOT - 55, a * 0.9)
        HC.paste(fr, HC.mascot(mp), HC.M_CX - 301 * HC.M_SCALE, HC.M_FOOT - 790 * HC.M_SCALE, a)
    B = S['bubbles']
    for j, b in enumerate(B):
        a, sc = HC.bubble_state(b, t, B[j + 1] if j + 1 < len(B) else None)
        if a <= 0: continue
        im, tx, ty = HC.bubble_img(b['text']); ax, ay = HC.M_CX, HC.BUB_CY + im.height / 2 - 8
        HC.paste(fr, im, ax - tx * sc, ay - ty * sc, a * gfade, sc)
    for s in S['subs']:
        if s['t0'] <= t < s['t1']:
            a = HC.ease((t - s['t0']) / 0.08) * (1 - HC.ease((t - s['t1'] + 0.08) / 0.08)) * gfade
            HC.paste(fr, HC.sub_img(s["text"]), 0, HC.SUB_TOP, a)
    return Image.fromarray(np.clip(fr, 0, 255).astype(np.uint8))
ts = [float(x) for x in sys.argv[1].split(',')]
ims = [frame(t).resize((360, 640)) for t in ts]
cols = min(6, len(ims)); rows = (len(ims) + cols - 1) // cols
sheet = Image.new('RGB', (360 * cols, 640 * rows))
for k, im in enumerate(ims): sheet.paste(im, ((k % cols) * 360, (k // cols) * 640))
sheet.save(sys.argv[2], quality=85)

import math, sys, os, subprocess, wave
import numpy as np
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont

from make_video import (W, H, S, FW, FH, FPS, F24, F12, F12R, F9, SUBF, BG, GRID, SHADOW, WHITE, YEL, RED,
                        GRN, CYAN, ORG, GRAY, DIM, lerp, clamp, prog, ease, blink, bg_img, text, typed,
                        square, fly, tone, mtof, SR, dissolve_mask)

BASE = os.path.dirname(os.path.abspath(__file__))
# ---- YouTube Shorts safe zone (low-res coords, x4 = 1080x1920)
CX = 125                     # visual centre of safe zone (right side reserved for buttons)
SX0, SX1 = 30, 220           # safe horizontal range
SY0, SY1 = 60, 318           # safe vertical range for graphics
SUB_Y = 1296                 # subtitle top (full-res)
SUB_CX = 500
SUB_MAXW = 740

BLUE = (60, 130, 230); SRED = (232, 64, 72); PURP = (170, 110, 240); WHT2 = (210, 214, 226)

def ctext(d, y, s, font, fill, full=None, cx=CX, shadow=True):
    full = full if full is not None else s
    w = d.textlength(full, font=font)
    text(d, (int(cx - w / 2), y), s, font, fill, shadow=shadow)

def fit(d, s, maxw=188):
    return F24 if d.textlength(s, font=F24) <= maxw else F12

def header(d, t, small, big, sub, col=YEL):
    if small: ctext(d, 62, small, F9, GRAY)
    f = fit(d, big)
    ctext(d, 75, typed(big, t, 0.1, 22), f, col, full=big)
    if sub:
        t0 = 0.1 + len(big) / 22 + 0.1
        ctext(d, 104, typed(sub, t, t0, 26), F12, WHITE, full=sub)

def box(d, x0, y0, x1, y1, col, fill=(8, 11, 24)):
    d.rectangle([x0, y0, x1, y1], fill=fill, outline=col)

def slam(t, t0, dur=0.25):
    """returns (visible, offset) for slam-in text: drops from above with a bounce"""
    if t < t0: return False, 0
    u = prog(t, t0, t0 + dur)
    return True, int((1 - ease(u)) * -14)

TL = [(1988, 36), (2016, 80), (2023, 124), (2025, 168), (2026, 210)]
def timeline(d, idx, t):
    y = 302
    d.line([(SX0 + 4, y), (SX1 - 6, y)], fill=DIM)
    for i, (yr, x) in enumerate(TL):
        on = i == idx
        c = YEL if on else (GRAY if i < idx else DIM)
        if on and blink(t, 2): d.rectangle([x - 3, y - 3, x + 3, y + 3], outline=YEL)
        d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=c)
        d.text((x, y + 5), f"'{str(yr)[2:]}", font=F9, fill=c, anchor="ma")

def building(d, x0, y0, x1, y1, col, label, lit_seed=0, t=0):
    d.rectangle([x0, y0, x1, y1], fill=tuple(int(c * 0.35) for c in col), outline=col)
    k = 0
    for wy in range(y0 + 6, y1 - 14, 9):
        for wx in range(x0 + 5, x1 - 6, 9):
            on = ((k * 7 + lit_seed + int(t * 1.5)) % 5) != 0
            d.rectangle([wx, wy, wx + 4, wy + 4], fill=col if on else tuple(int(c * 0.5) for c in col))
            k += 1
    d.text(((x0 + x1) // 2, y1 - 12), label, font=F9, fill=WHITE, anchor="ma")

def roof(d, x0, x1, ybase, h, col):
    cx = (x0 + x1) // 2
    d.polygon([(x0, ybase), (cx, ybase - h), (x1, ybase)], outline=col)
    d.polygon([(x0 + 3, ybase - 1), (cx, ybase - h + 3), (x1 - 3, ybase - 1)], outline=tuple(int(c * 0.5) for c in col))

def chip(d, x0, y0, sz, col, t, seed=0, lit=1.0):
    # pins
    for i in range(4):
        p = x0 + 6 + i * (sz - 12) // 3
        d.line([(p, y0 - 4), (p, y0)], fill=GRAY); d.line([(p, y0 + sz), (p, y0 + sz + 4)], fill=GRAY)
        q = y0 + 6 + i * (sz - 12) // 3
        d.line([(x0 - 4, q), (x0, q)], fill=GRAY); d.line([(x0 + sz, q), (x0 + sz + 4, q)], fill=GRAY)
    d.rectangle([x0, y0, x0 + sz, y0 + sz], fill=(24, 28, 44), outline=col)
    n = 5; cs = (sz - 8) // n
    for r in range(n):
        for c in range(n):
            on = ((r * 3 + c * 5 + seed + int(t * 4)) % 7) < 5 * lit
            d.rectangle([x0 + 4 + c * cs, y0 + 4 + r * cs, x0 + 2 + (c + 1) * cs, y0 + 2 + (r + 1) * cs],
                        fill=col if on else (44, 50, 74))

def tag(d, x, y, s, col, font=F12):
    w = int(d.textlength(s, font=font)) + 14
    h = 16 if font is F12 else 28
    d.polygon([(x, y + h // 2), (x + 6, y), (x + w, y), (x + w, y + h), (x + 6, y + h)], fill=(20, 22, 36), outline=col)
    d.rectangle([x + 5, y + h // 2 - 1, x + 6, y + h // 2], fill=col)
    d.text((x + 10, y + (2 if font is F12 else 2)), s, font=font, fill=col)
    return w

def stamp(d, cx, y, s, col):
    w = int(d.textlength(s, font=F12)) + 10
    d.rectangle([cx - w // 2, y, cx + w // 2, y + 16], outline=col)
    d.rectangle([cx - w // 2 + 2, y + 2, cx + w // 2 - 2, y + 14], outline=col)
    d.text((cx, y + 2), s, font=F12, fill=col, anchor="ma")

# ----------------------------------------------------------------- scenes
def s1(img, d, t):
    header(d, t, "SANDISK × WESTERN DIGITAL", "한 지붕 두 가족", "", YEL)
    sp = ease(prog(t, 4.2, 5.4)) * 16
    building(d, int(52 - sp), 176, int(110 - sp), 282, BLUE, "웨스턴디지털", 1, t)
    building(d, int(140 + sp), 176, int(198 + sp), 282, SRED, "샌디스크", 4, t)
    if t < 4.2:
        u = ease(prog(t, 0.6, 1.6))
        if u > 0: roof(d, 42, 208, 172, int(44 * u), YEL)
    else:
        # roof breaks in two halves
        roof(d, int(42 - sp), int(125 - sp), 172, 30, YEL)
        roof(d, int(125 + sp), int(208 + sp), 172, 30, YEL)
        vis, off = slam(t, 5.0)
        if vis: ctext(d, 122 + off, "SPLIT!", F24, SRED)
    if 1.6 < t < 4.2:
        ctext(d, 142, "ONE ROOF", F12, YEL if blink(t, 2) else GRAY)
    return (0, 0)

def s2(img, d, t):
    header(d, t, "1988", "THE PIONEER", "플래시 메모리 개척자", SRED)
    timeline(d, 0, t)
    off = t > 2.0
    lit = 1.0
    chip(d, 100, 134, 50, SRED, t if not off else 2.0, 3, lit)
    if t > 1.6:
        pw = "전원 OFF" if t > 2.0 else "전원 ON"
        d.text((160, 140), pw, font=F9, fill=GRAY if off else GRN)
    if t > 2.8:
        vis, o = slam(t, 2.8)
        d.text((160, 156 + o), "기억 유지!", font=F12, fill=YEL)
    # products
    items = [("메모리카드", 0), ("USB", 1), ("SSD", 2)]
    for i, (name, kind) in enumerate(items):
        ts = 5.6 + i * 0.6
        if t < ts: continue
        x = 48 + i * 58; y = 206 + int((1 - ease(prog(t, ts, ts + 0.3))) * 10)
        if kind == 0:
            d.polygon([(x, y), (x + 14, y), (x + 20, y + 6), (x + 20, y + 28), (x, y + 28)], fill=SRED, outline=WHITE)
            d.rectangle([x + 3, y + 12, x + 17, y + 24], fill=WHITE)
        elif kind == 1:
            d.rectangle([x, y + 8, x + 26, y + 20], fill=SRED, outline=WHITE)
            d.rectangle([x + 26, y + 10, x + 34, y + 18], fill=GRAY)
        else:
            d.rectangle([x - 4, y + 2, x + 30, y + 26], fill=(40, 44, 62), outline=WHITE)
            d.rectangle([x, y + 8, x + 16, y + 18], fill=SRED)
        d.text((x + 12, y + 32), name, font=F9, fill=WHITE, anchor="ma")
    if t > 8.4:
        box(d, SX0 + 6, 254, SX1 - 8, 290, YEL)
        d.text((SX0 + 12, 258), typed("공동창업자 산제이 메로트라", t, 8.5, 24), font=F9, fill=WHITE)
        d.text((SX0 + 12, 274), typed("→ 현 마이크론 CEO", t, 9.4, 24), font=F12, fill=YEL)
    return (0, 0)

def s3(img, d, t):
    header(d, t, "WD vs SANDISK", "DISK vs CHIP", "대형 창고 vs 편의점", CYAN)
    timeline(d, 0, t)
    # left HDD
    if t > 0.6:
        box(d, 32, 128, 120, 200, BLUE, (14, 20, 40))
        cx, cy, r = 70, 164, 28
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(120, 128, 150), outline=WHT2)
        d.ellipse([cx - 18, cy - 18, cx + 18, cy + 18], outline=(150, 158, 178))
        d.ellipse([cx - 4, cy - 4, cx + 4, cy + 4], fill=(60, 64, 80))
        a = t * 7
        square(d, cx + math.cos(a) * 23 - 1, cy + math.sin(a) * 23 - 1, WHITE, 3)
        ang = math.sin(t * 2) * 0.25
        ex, ey = 112 - 40 * math.cos(0.9 + ang), 134 + 40 * math.sin(0.9 + ang)
        d.line([(112, 136), (int(ex), int(ey))], fill=YEL, width=2)
        d.text((76, 206), "HDD", font=F12, fill=CYAN, anchor="ma")
        d.text((76, 222), "돌아가는 원판", font=F9, fill=GRAY, anchor="ma")
    if t > 4.6:
        box(d, 130, 128, 218, 200, SRED, (30, 12, 18))
        chip(d, 152, 142, 44, SRED, t, 1)
        d.text((174, 206), "FLASH", font=F12, fill=SRED, anchor="ma")
        d.text((174, 222), "전기로 저장", font=F9, fill=GRAY, anchor="ma")
    if t > 8.6:
        for i, (x, a, b, c) in enumerate([(76, "대형 창고", "크고 싸다", "대신 느림"), (174, "편의점", "빠르다", "대신 비쌈")]):
            vis, o = slam(t, 8.6 + i * 0.5)
            if not vis: continue
            col = CYAN if i == 0 else SRED
            d.rectangle([x - 40, 240 + o, x + 40, 288 + o], fill=(10, 14, 30), outline=col)
            d.text((x, 244 + o), a, font=F12, fill=YEL, anchor="ma")
            d.text((x, 262 + o), b, font=F9, fill=WHITE, anchor="ma")
            d.text((x, 274 + o), c, font=F9, fill=GRAY, anchor="ma")
    return (0, 0)

def s4(img, d, t):
    header(d, t, "2015 – 2016", "THE BIG DEAL", "창고가 편의점을 품다", YEL)
    timeline(d, 1, t)
    u = ease(prog(t, 4.6, 6.0))
    rx = lerp(150, 92, u)
    if u < 1:
        building(d, 40, 140, 100, 214, BLUE, "WD", 1, t)
        building(d, int(rx), 150, int(rx + 50), 214, SRED, "SANDISK", 3, t)
    else:
        building(d, 40, 140, 142, 214, PURP if blink(t, 4) and t < 6.6 else BLUE, "WD + SANDISK", 2, t)
    # price tag
    if t > 0.8:
        tag(d, 150 if u < 1 else 152, 128 if u < 1 else 150, "$19B", GRAY if t > 4.6 else YEL)
        if t > 4.6:
            d.line([(158, (128 if u < 1 else 150) + 8), (196, (128 if u < 1 else 150) + 8)], fill=SRED)
    if t > 5.0:
        vis, o = slam(t, 5.0)
        tag(d, 150, 176 + o, "$16B", YEL, F24)
        d.text((150, 208 + o), "최종 약 160억$", font=F9, fill=GRAY)
    if t > 9.0:
        vis, o = slam(t, 9.0)
        d.rectangle([62, 236 + o, 188, 288 + o], fill=(10, 14, 30), outline=GRAY)
        d.text((CX, 242 + o), "TICKER: SNDK", font=F12, fill=GRAY, anchor="ma")
        if t > 9.8:
            stamp(d, CX, 262 + o, "DELISTED", SRED)
    return (0, 0)

def s5(img, d, t):
    header(d, t, "PROBLEM", "BUNDLE TRAP", "묶음 할인의 함정", ORG)
    timeline(d, 1, t)
    box(d, SX0 + 2, 126, SX1 - 4, 214, DIM)
    n = clamp(prog(t, 0.6, 4.6))
    x0, x1 = SX0 + 8, SX1 - 10
    pts_h, pts_n = [], []
    for i in range(int(n * 60) + 1):
        x = x0 + (x1 - x0) * i / 60
        pts_h.append((x, 176 + math.sin(i * 0.3) * 1.5))
        pts_n.append((x, 170 - math.sin(i * 0.33) * 30 - math.sin(i * 0.11) * 6))
    if len(pts_h) > 1:
        d.line(pts_h, fill=BLUE, width=1); d.line(pts_n, fill=SRED, width=1)
        cx_, cy_ = pts_n[-1]
        d.rectangle([cx_ - 3, cy_ - 4, cx_ + 3, cy_], fill=YEL)  # coaster cart
    d.text((x0, 130), "NAND 가격", font=F9, fill=SRED)
    d.text((x0 + 70, 130), "HDD", font=F9, fill=BLUE)
    if t > 8.6:
        vis, o = slam(t, 8.6)
        d.text((SX0 + 6, 224 + o), "따로 팔면", font=F9, fill=GRAY)
        tag(d, SX0 + 6, 238 + o, "창고 ₩₩₩", CYAN)
        tag(d, SX0 + 6, 260 + o, "편의점 ₩₩₩", SRED)
    if t > 9.8:
        vis, o = slam(t, 9.8)
        d.text((136, 224 + o), "세트로 묶으면", font=F9, fill=GRAY)
        tag(d, 136, 238 + o, "세트 ₩₩", YEL)
        if blink(t, 3): d.text((140, 262 + o), "할인 중…", font=F12, fill=SRED)
    elif 4.4 < t <= 8.6:
        if blink(t, 2.5): ctext(d, 236, "같이 흔들린다!", F12, SRED)
        ctext(d, 256, "HDD 평가도 덩달아 ▼", F9, GRAY)
    return (0, 0)

def s6(img, d, t):
    header(d, t, "2022 – 2023", "BREAK UP?", "쪼개라 → 합치자? → 무산", SRED)
    timeline(d, 2, t)
    if t < 4.6:
        # megaphone + sound arcs (arcs, not rays)
        x, y = 50, 150
        d.polygon([(x, y + 6), (x + 10, y + 6), (x + 28, y - 4), (x + 28, y + 26), (x + 10, y + 16), (x, y + 16)], fill=YEL)
        for k in range(3):
            if (t * 3 - k * 0.3) % 1 < 0.7:
                r = 8 + k * 7
                d.arc([x + 28 - r, y + 11 - r, x + 28 + r, y + 11 + r], -40, 40, fill=YEL)
        d.text((x + 14, y + 34), "ELLIOTT", font=F9, fill=YEL, anchor="ma")
        d.text((x + 14, y + 46), "행동주의 펀드", font=F9, fill=GRAY, anchor="ma")
        if t > 1.0:
            vis, o = slam(t, 1.0)
            d.rectangle([118, 140 + o, 214, 170 + o], fill=WHITE)
            d.polygon([(118, 150 + o), (110, 156 + o), (118, 160 + o)], fill=WHITE)
            d.text((166, 148 + o), "쪼개라!", font=F12, fill=(10, 10, 20), anchor="ma")
    else:
        u = ease(prog(t, 4.8, 7.4))
        back = ease(prog(t, 8.0, 8.8)) * 18
        lx = lerp(36, 66, u) - back; rx = lerp(160, 132, u) + back
        d.rectangle([int(lx), 150, int(lx) + 56, 196], fill=(60, 20, 26), outline=SRED)
        d.text((int(lx) + 28, 160), "WD", font=F12, fill=SRED, anchor="ma")
        d.text((int(lx) + 28, 178), "플래시", font=F9, fill=WHITE, anchor="ma")
        d.rectangle([int(rx), 150, int(rx) + 56, 196], fill=(40, 44, 60), outline=WHT2)
        d.text((int(rx) + 28, 160), "KIOXIA", font=F12, fill=WHT2, anchor="ma")
        d.text((int(rx) + 28, 178), "옛 도시바", font=F9, fill=GRAY, anchor="ma")
        if 6.0 < t < 7.6: ctext(d, 134, "합병?", F12, YEL)
        if t > 7.6:
            vis, o = slam(t, 7.6, 0.15)
            c = SRED
            d.line([(CX - 14, 158 + o), (CX + 14, 188 + o)], fill=c, width=4)
            d.line([(CX + 14, 158 + o), (CX - 14, 188 + o)], fill=c, width=4)
            d.text((CX, 204), "SK하이닉스 반대", font=F12, fill=ORG, anchor="ma")
            d.text((CX, 220), "(키오시아 투자자)", font=F9, fill=GRAY, anchor="ma")
        if t > 10.6:
            vis, o = slam(t, 10.6)
            d.rectangle([48, 240 + o, 202, 286 + o], fill=(10, 14, 30), outline=YEL)
            d.text((CX, 246 + o), "2023.10", font=F12, fill=YEL, anchor="ma")
            d.text((CX, 264 + o), "회사 분리 결정", font=F12, fill=WHITE, anchor="ma")
    sh = 2 if 7.6 < t < 8.2 else 0
    return (int(math.sin(t * 60) * sh), 0)

def s7(img, d, t):
    header(d, t, "2025.02.24", "INDEPENDENCE", "9년 만에 돌아온 SNDK", GRN)
    timeline(d, 3, t)
    sp = ease(prog(t, 3.0, 4.4)) * 22
    if t < 3.0:
        d.rectangle([58, 136, 192, 216], fill=(40, 30, 70), outline=PURP)
        d.text((CX, 170), "WD + SANDISK", font=F12, fill=WHITE, anchor="ma")
        n = prog(t, 1.4, 2.8)
        pts = [(CX + (4 if i % 2 else -4), 136 + i * 8) for i in range(11)]
        k = int(n * len(pts))
        if k > 1: d.line(pts[:k], fill=YEL, width=2)
    else:
        building(d, int(58 - sp), 136, int(122 - sp), 216, BLUE, "WD", 1, t)
        building(d, int(128 + sp), 136, int(192 + sp), 216, SRED, "SANDISK", 3, t)
        roof(d, int(58 - sp), int(122 - sp), 134, 14, BLUE)
        roof(d, int(128 + sp), int(192 + sp), 134, 14, SRED)
    if t > 5.0:
        vis, o = slam(t, 5.0)
        d.rectangle([44, 232 + o, 206, 286 + o], fill=(8, 24, 14), outline=GRN)
        d.text((CX, 238 + o), "NASDAQ", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 252 + o), "SNDK", font=F24, fill=GRN, anchor="ma")
        # confetti falling (vertical, not radial)
        for k in range(16):
            ph = (t * 0.6 + k * 0.137) % 1
            x = SX0 + (k * 37) % (SX1 - SX0); y = 120 + ph * 180
            square(d, x, y, [YEL, GRN, SRED, CYAN][k % 4], 2)
    sh = 2 if 5.0 < t < 5.4 else 0
    return (0, int(math.cos(t * 50) * sh))

def s8(img, d, t):
    header(d, t, "2025 – 2026", "AI BOOM", "편의점에 손님이 몰렸다", GRN)
    timeline(d, 4, t)
    if t < 7.4:
        for i in range(3):
            x = 38 + i * 24
            d.rectangle([x, 132, x + 18, 210], fill=(18, 22, 36), outline=GRAY)
            for r in range(7):
                yy = 138 + r * 10
                d.rectangle([x + 3, yy, x + 15, yy + 6], fill=(30, 36, 56))
                on = ((r + i * 3 + int(t * 6)) % 4) != 0
                d.point((x + 13, yy + 3), fill=GRN if on else DIM)
        d.text((65, 216), "AI 서버", font=F9, fill=GRAY, anchor="ma")
        chip(d, 160, 150, 40, SRED, t, 2)
        d.text((180, 216), "플래시", font=F9, fill=SRED, anchor="ma")
        for k in range(24):
            ts = 0.8 + k * 0.22
            fly(d, (110, 140 + (k * 13) % 60), (160, 160 + (k * 7) % 30), (t - ts) / 0.6, [CYAN, GRN, YEL][k % 3], arc=8)
        if t > 3.8:
            ctext(d, 236, "데이터 폭증", F12, YEL)
            ctext(d, 254, "빠른 저장장치가 필요해!", F9, WHITE)
    else:
        # supply / demand bars
        u = ease(prog(t, 7.6, 9.4))
        base = 214
        d.line([(40, base), (210, base)], fill=GRAY)
        dh = int(70 * u); sh_ = int(26 * u)
        d.rectangle([52, base - dh, 80, base], fill=GRN); d.text((66, base + 4), "수요", font=F9, fill=GRN, anchor="ma")
        d.rectangle([92, base - sh_, 120, base], fill=GRAY); d.text((106, base + 4), "공급", font=F9, fill=GRAY, anchor="ma")
        # stepped price arrow
        if t > 8.6:
            n = int(prog(t, 8.6, 10.4) * 6)
            for k in range(n):
                d.rectangle([140 + k * 10, 200 - k * 12, 149 + k * 10, 210 - k * 12], fill=SRED)
            if n >= 6: d.polygon([(196, 130), (212, 146), (196, 146)], fill=SRED)
            d.text((150, 216), "NAND 가격", font=F9, fill=SRED)
        if t > 11.0:
            vis, o = slam(t, 11.0)
            d.rectangle([40, 232 + o, 210, 290 + o], fill=(10, 14, 30), outline=YEL)
            d.text((CX, 236 + o), "분기 매출 (1년 전 대비)", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 250 + o), "3.5배", font=F24, fill=YEL, anchor="ma")
            d.text((CX, 276 + o), "2026년 1~3월 분기 · +251%", font=F9, fill=GRAY, anchor="ma")
    return (0, 0)

# stylised SNDK price path (fraction of Feb-2025 → Oct-2026, price $)
PATH = [(0, 50), (0.1, 34), (0.25, 48), (0.4, 116), (0.5, 220), (0.65, 603), (0.75, 1300), (0.82, 2300),
        (0.88, 1700), (0.95, 1890), (1.0, 1600)]
def s9(img, d, t):
    header(d, t, "SNDK STOCK", "WILD RIDE", "수십 달러 → 2,000달러+", YEL)
    timeline(d, 4, t)
    bx0, by0, bx1, by1 = SX0 + 2, 126, SX1 - 4, 282
    box(d, bx0, by0, bx1, by1, DIM)
    def mp(f, p):
        x = bx0 + 8 + f * (bx1 - bx0 - 16)
        y = by1 - 10 - (math.log10(p) - math.log10(25)) / (math.log10(3200) - math.log10(25)) * (by1 - by0 - 30)
        return x, y
    for p in (100, 1000):
        y = mp(0, p)[1]
        for x in range(bx0 + 2, bx1 - 1, 4): d.point((x, int(y)), fill=(34, 42, 70))
    n = prog(t, 0.6, 5.6)
    pts = []
    steps = 120
    for i in range(int(n * steps) + 1):
        f = i / steps
        for j in range(len(PATH) - 1):
            if PATH[j][0] <= f <= PATH[j + 1][0]:
                (f0, p0), (f1, p1) = PATH[j], PATH[j + 1]
                u = (f - f0) / (f1 - f0)
                p = 10 ** lerp(math.log10(p0), math.log10(p1), u)
                break
        pts.append(mp(f, p))
    if len(pts) > 1:
        d.line(pts, fill=GRN, width=2)
        x, y = pts[-1]; d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=YEL)
    if n > 0.02:
        x, y = mp(0, 50); d.text((x, y + 4), "$50", font=F9, fill=WHITE)
    if n > 0.83:
        x, y = mp(0.82, 2300); d.text((x - 30, y - 12), "$2,300대", font=F9, fill=YEL)
    if n > 0.72:
        x, y = mp(0.71, 900)
        d.line([(x, y), (x, by1 - 4)], fill=CYAN)
        d.text((x - 4, by1 - 26), "나스닥100", font=F9, fill=CYAN, anchor="ra")
        d.text((x - 4, by1 - 15), "재편입", font=F9, fill=CYAN, anchor="ra")
    if n >= 1:
        x, y = mp(1, 1600); d.text((x - 2, y + 6), "$1,600", font=F9, fill=WHITE, anchor="ra")
    if t > 8.6:
        vis, o = slam(t, 8.6)
        d.rectangle([60, 146 + o, 150, 184 + o], fill=(10, 14, 30), outline=YEL)
        d.text((105, 150 + o), "약 30배", font=F24, fill=YEL, anchor="ma")
    return (0, 0)

def s10(img, d, t):
    header(d, t, "ENDING", "TWO HOUSES", "따로 서니 제값을 받다", CYAN)
    building(d, 44, 150, 108, 236, BLUE, "WD", 1, t)
    building(d, 142, 150, 206, 236, SRED, "SANDISK", 3, t)
    roof(d, 44, 108, 148, 16, BLUE); roof(d, 142, 206, 148, 16, SRED)
    d.text((76, 240), "대형 창고", font=F9, fill=CYAN, anchor="ma")
    d.text((174, 240), "편의점", font=F9, fill=SRED, anchor="ma")
    if t > 1.0:
        k = int(t * 4) % 4
        for i in range(3):
            y = 136 - ((i * 6 + k * 2) % 14)
            d.polygon([(174, y - 6), (180, y), (168, y)], fill=GRN if i == 0 else (40, 120, 60))
    d.text((CX, 266), "※ 투자 권유가 아닌", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 278), "정보 제공용 콘텐츠입니다", font=F9, fill=GRAY, anchor="ma")
    return (0, 0)

SCENES = [
    (8, s1, [(0.3, 4.0, "샌디스크와 웨스턴디지털,\n원래 한 회사였다는 거 아세요?"),
             (4.0, 7.8, "합쳤다가 갈라선\n10년짜리 드라마, 풀어볼게요")]),
    (12, s2, [(0.3, 4.2, "1988년, 엘리 하라리 등 3명이\n샌디스크를 세웁니다"),
              (4.2, 8.2, "전원이 꺼져도 기억하는 칩,\n플래시 메모리의 개척자죠"),
              (8.2, 11.8, "공동창업자 산제이 메로트라는\n지금 마이크론의 CEO랍니다")]),
    (13, s3, [(0.3, 4.4, "웨스턴디지털은 하드디스크 회사.\n돌아가는 원판에 기록하고"),
              (4.4, 8.4, "샌디스크는 플래시.\n칩에 전기로 저장해요"),
              (8.4, 12.8, "쉽게 말해 크고 싼 '대형 창고'와\n빠르고 비싼 '편의점'의 차이죠")]),
    (13, s4, [(0.3, 4.4, "2015년 웨스턴디지털이\n샌디스크 인수를 발표하고"),
              (4.4, 8.6, "2016년, 약 160억 달러에\n통째로 품습니다"),
              (8.6, 12.8, "창고 회사가 편의점 체인을 산 셈.\nSNDK라는 이름표는 사라지죠")]),
    (13, s5, [(0.3, 4.4, "문제는 플래시 가격이\n롤러코스터처럼 오르내린다는 것"),
              (4.4, 8.6, "안정적인 하드디스크 사업까지\n덩달아 저평가를 받게 됩니다"),
              (8.6, 12.8, "따로 팔면 더 비쌀 메뉴가\n세트로 묶여 싸게 팔린 셈이죠")]),
    (14, s6, [(0.3, 4.6, "2022년, 행동주의 펀드 엘리엇이\n사업을 쪼개라고 압박합니다"),
              (4.6, 7.6, "플래시 사업을 오랜 공장 파트너\n키오시아와 합치려 했지만"),
              (7.6, 10.4, "키오시아에 투자한 SK하이닉스가\n반대하며 무산되죠"),
              (10.4, 13.8, "결국 2023년 10월,\n회사를 둘로 나누기로 합니다")]),
    (11, s7, [(0.3, 5.4, "2025년 2월 24일, 샌디스크는\n독립해 나스닥에 다시 상장합니다"),
              (5.4, 10.8, "9년 만에 SNDK라는\n옛 이름표를 되찾은 거죠")]),
    (15, s8, [(0.3, 3.6, "그런데 AI가 판을 바꿉니다"),
              (3.6, 7.4, "AI 데이터센터는 엄청난 데이터를\n빠르게 꺼낼 저장장치가 필요하거든요"),
              (7.4, 11.0, "수요는 폭발하는데 공급은 빠듯하니\n플래시 가격이 치솟고"),
              (11.0, 14.8, "2026년 초 분기 매출은\n1년 전의 3.5배가 됩니다")]),
    (12, s9, [(0.3, 4.4, "분사 직후 50달러 안팎이던 주가는\n2026년 한때 2,300달러대까지"),
              (4.4, 8.4, "다만 메모리는 원래 사이클 산업.\n지금은 1,600달러 안팎으로 조정 중"),
              (8.4, 11.8, "그래도 분사 때보다는\n약 30배 오른 셈이죠")]),
    (9, s10, [(0.3, 4.4, "한 지붕 아래 저평가받던 샌디스크,\n독립하자 제값을 받기 시작했죠"),
              (4.4, 8.4, "다음 메모리 사이클에서도 웃을지,\n계속 지켜볼 포인트입니다")]),
]
STARTS = np.cumsum([0] + [s[0] for s in SCENES]).tolist()
TOTAL = STARTS[-1]
SCALE = [1.0] * len(SCENES)   # per-scene time stretch (set by narrated build)
TR = 0.45

@lru_cache(None)
def sub_img(s):
    lines = s.split("\n")
    f = ImageFont.truetype(SUBF.path, 52, index=SUBF.index)
    tmp = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while max(tmp.textlength(l, font=f) for l in lines) > SUB_MAXW:
        f = ImageFont.truetype(f.path, f.size - 2, index=f.index)
    lh = int(52 * 1.3)
    im = Image.new("RGBA", (FW, lh * len(lines) + 20), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for i, l in enumerate(lines):
        d.text((SUB_CX, 8 + i * lh), l, font=f, fill=(255, 255, 255), anchor="ma", stroke_width=6, stroke_fill=(0, 0, 0))
    return im

def render_low(k, t):
    img = bg_img("grid").copy()
    d = ImageDraw.Draw(img); d.fontmode = "1"
    dx, dy = SCENES[k][1](img, d, t) or (0, 0)
    if dx or dy:
        out = bg_img("grid").copy(); out.paste(img, (dx, dy)); img = out
    return img

def shutter_mask(p):
    m = np.zeros((H, W), np.uint8)
    for r in range(0, H, 12):
        frac = clamp(p * 1.7 - (r / H) * 0.7)
        m[r:r + 12, :int(W * frac)] = 255
    return Image.fromarray(m, "L")

def render_frame(T, guide=False):
    k = min(max(i for i in range(len(SCENES)) if STARTS[i] <= T + 1e-9), len(SCENES) - 1)
    t = T - STARTS[k]
    low = render_low(k, t)
    if k > 0 and t < TR:
        prev = render_low(k - 1, SCENES[k - 1][0] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T < 0.4: a = (a * clamp(T / 0.4)).astype(np.uint8)
    if T > TOTAL - 1.0: a = (a * clamp(TOTAL - T)).astype(np.uint8)
    big = Image.fromarray(a)
    for s0, s1_, s in SCENES[k][2]:
        if s0 <= t < s1_ and T < TOTAL - 0.6:
            si = sub_img(s); big.paste(si, (0, SUB_Y), si)
    if guide:
        ov = Image.new("RGBA", (FW, FH), (0, 0, 0, 0)); g = ImageDraw.Draw(ov)
        z = (255, 0, 80, 90)
        g.rectangle([0, 0, FW, 225], fill=z)                # status bar + top icons
        g.rectangle([890, 1000, FW, 1760], fill=z)          # right action buttons
        g.rectangle([0, 1490, FW, FH], fill=z)              # channel name / desc / nav
        g.rectangle([0, 0, 48, FH], fill=z); g.rectangle([FW - 48, 0, FW, FH], fill=z)  # side crop
        big = Image.alpha_composite(big.convert("RGBA"), ov).convert("RGB")
    return big

# ----------------------------------------------------------------- audio
def make_audio(path, narr=None):
    N = int((TOTAL + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N)
    bpm = 118; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    # F - C - Dm - Bb (bright, story-telling)
    chords = [([65, 69, 72], 41), ([60, 64, 67], 48), ([62, 65, 69], 50), ([58, 62, 65], 46)]
    minor = [([57, 60, 64], 45), ([53, 57, 60], 41), ([52, 55, 59], 40), ([52, 56, 59], 40)]
    mel = [[77, None, 76, 72, 74, None, 72, 69], [72, None, 74, 76, 79, None, 76, None],
           [74, None, 72, 69, 72, 74, 77, None], [74, None, 72, 70, 69, None, None, None]]
    St = STARTS
    def sec(T):
        if T < St[2]: return "intro"
        if T < St[5]: return "build"
        if T < St[6]: return "full"
        if T < St[7]: return "tense"
        if T < St[9]: return "full"
        return "outro"
    L = {"intro": dict(arp=1, bass=1, kick=0, hat=0, snare=0, lead=0),
         "build": dict(arp=1, bass=1, kick=1, hat=1, snare=0, lead=0),
         "full": dict(arp=1, bass=1, kick=1, hat=1, snare=1, lead=1),
         "tense": dict(arp=1, bass=1, kick=1, hat=0, snare=0, lead=0),
         "outro": dict(arp=1, bass=1, kick=0, hat=1, snare=0, lead=1)}
    nb = int(TOTAL / bar) + 1
    for b in range(nb):
        t0 = b * bar
        name = sec(t0); lay = L[name]
        notes, root = (minor if name == "tense" else chords)[b % 4]
        for st in range(16):
            T = t0 + st * s16
            if T >= TOTAL: break
            if lay["arp"]: tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + (0 if name == "tense" else 12) - 12 + 12), 0.045, "sq", 0.125, decay=0.08)
            if lay["hat"] and st % 2 == 0: tone(bgm, T, 0.03, 0, 0.03 if st % 4 else 0.018, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= TOTAL: break
            if lay["bass"]: tone(bgm, T, e * 0.9, mtof(root - 12 + (12 if st % 2 else 0)), 0.17, "tri")
            if lay["lead"]:
                m = mel[b % 4][st]
                if m: tone(bgm, T, e * 0.95, mtof(m - 12), 0.045, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= TOTAL: break
            if lay["kick"] and (bt in (0, 2) or name == "tense"): tone(bgm, T, 0.16, 150, 0.33, "sin", f1=45, decay=0.07)
            if lay["snare"] and bt in (1, 3):
                tone(bgm, T, 0.12, 0, 0.11, "noise", decay=0.04); tone(bgm, T, 0.08, 190, 0.07, "tri", decay=0.04)
    ie = int(TOTAL * SR); fo = int(3.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    bgm[:int(0.6 * SR)] *= np.linspace(0, 1, int(0.6 * SR))

    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    A = lambda k, t: St[k] + t * SCALE[k]
    def typing(k, t0, s, cps):
        for c in range(0, len(s), 2): blip(A(k, t0 + c / cps), 1500 + (c % 3) * 150)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin(T): tone(sfx, T, 0.05, 988, 0.07, "sq", 0.5); tone(sfx, T + 0.05, 0.15, 1319, 0.07, "sq", 0.5, decay=0.07)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def alarm(T): tone(sfx, T, 0.12, 880, 0.06, "sq", 0.5); tone(sfx, T + 0.13, 0.12, 660, 0.06, "sq", 0.5)
    def rise(T, dur): tone(sfx, T, dur, 200, 0.05, "sq", 0.5, f1=1400)
    def crack(T):
        for j in range(5): tone(sfx, T + j * 0.06, 0.05, 0, 0.12, "noise", decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.18, mtof(m), 0.07, "sq", 0.25, decay=0.12)
    titles = ["한 지붕 두 가족", "THE PIONEER", "DISK vs CHIP", "THE BIG DEAL", "BUNDLE TRAP", "BREAK UP?",
              "INDEPENDENCE", "AI BOOM", "WILD RIDE", "TWO HOUSES"]
    for k, s in enumerate(titles):
        T0 = St[k]
        if k > 0: swoosh(T0)
        typing(k, 0.1, s, 22)
    crack(A(0, 4.2)); thump(A(0, 5.0))
    tone(sfx, A(1, 2.0), 0.4, 600, 0.06, "sq", 0.5, f1=150); ding(A(1, 2.8))
    for i in range(3): blip(A(1, 5.6 + i * 0.6), 900, 0.06)
    typing(1, 8.5, "공동창업자 산제이 메로트라", 24)
    blip(A(2, 0.6), 700, 0.06); blip(A(2, 4.6), 1000, 0.06); thump(A(2, 8.6)); thump(A(2, 9.1))
    coin(A(3, 0.8)); tone(sfx, A(3, 4.6), 0.3, 500, 0.06, "sq", 0.5, f1=180); thump(A(3, 5.0)); coin(A(3, 5.2))
    thump(A(3, 9.0)); alarm(A(3, 9.8))
    tone(sfx, A(4, 0.6), 4.0, 300, 0.025, "tri", f1=300)
    thump(A(4, 8.6)); thump(A(4, 9.8)); coin(A(4, 9.9))
    for j in range(3): alarm(A(5, 1.0 + j * 0.5)) if j == 0 else blip(A(5, 1.0 + j * 0.5), 700, 0.06)
    rise(A(5, 4.8), 2.6 * SCALE[5]); thump(A(5, 7.6)); alarm(A(5, 7.8)); thump(A(5, 10.6))
    crack(A(6, 1.4)); thump(A(6, 3.0)); thump(A(6, 5.0)); fanfare(A(6, 5.1))
    rise(A(7, 0.8), 5.0 * SCALE[7]); rise(A(7, 8.6), 1.8 * SCALE[7]); thump(A(7, 11.0)); ding(A(7, 11.1))
    rise(A(8, 0.6), 5.0 * SCALE[8]); thump(A(8, 8.6)); ding(A(8, 8.7))
    fanfare(A(9, 1.0))
    if narr is not None:
        nv = np.zeros(N); nv[:min(N, len(narr))] = narr[:N]
        # ducking envelope: windowed peak of narration, smoothed (attack/release ~120 ms)
        win = int(0.12 * SR)
        a = np.abs(nv)
        pk = np.maximum.reduceat(a, np.arange(0, N, win))
        env = np.repeat(pk, win)[:N]
        k = np.ones(win) / win
        env = np.convolve(env, k, mode="same")
        act = np.clip(env / 0.04, 0, 1)
        bgm = bgm * (1 - 0.62 * act)          # about -8.4 dB under voice
        sfx = sfx * (1 - 0.35 * act)
        mix = bgm * 0.9 + sfx
        mix = np.tanh(mix * 1.2) / np.tanh(1.2) * 0.55 + nv
    else:
        mix = bgm * 0.9 + sfx
    mix = np.tanh(mix * 1.2) / np.tanh(1.2)
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    out = os.path.join(BASE, "out2"); os.makedirs(out, exist_ok=True)
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, guide=True).resize((360, 640), Image.LANCZOS).save(f"{out}/g_{T:06.1f}.png")
    else:
        make_audio(f"{out}/audio.wav")
        p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                              "-r", str(FPS), "-i", "-", "-i", f"{out}/audio.wav", "-c:v", "libx264", "-preset", "veryfast",
                              "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-shortest",
                              "-movflags", "+faststart", f"{out}/video.mp4"], stdin=subprocess.PIPE)
        n = int(TOTAL * FPS)
        for i in range(n):
            p.stdin.write(render_frame(i / FPS).tobytes())
            if i % 600 == 0: print(i, "/", n, flush=True)
        p.stdin.close(); p.wait(); print("done", TOTAL)

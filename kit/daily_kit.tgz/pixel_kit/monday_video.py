"""특별편 14 · 월요일도 갭하락? 이번 주 악재 3 · 호재 3 (60초 이내 · 10/25 새 기준 첫 적용: 첫 프레임에 결론, 하루 2~4편)
사실 확인(2026-10-25 기준):
 · VKOSPI 약 52, 코스피 지난주 -2.08% 5,550.30, 코스닥 -5.42% (시티타임스 10/25)
 · FOMC 10/27~28(미국) → 결정 10/29 03:00 KST, 9월 0.25%p 인상(3.75~4%), 이번엔 동결 확률 85% 이상(CME FedWatch, 시티타임스 10/25)
 · WTI 10/23 103.27$(+3.8%, Yahoo CL=F) · 원화 약 13.7만 원(1,325원/달러)
 · 메타 잉여현금흐름 마이너스 전환 → AI 투자 부담 우려, 코어위브 채권 불안 (헤럴드경제·한국경제 10/23~25)
 · SK하이닉스 3Q 10/28: 영업이익 컨센서스 76.964조(+576.11% YoY), 매출 98.2257조 (한국경제 10/23) · 삼성전자 10/29
 · 삼성전자 최대 110조 추가 주주환원 발표, 하닉 추가 환원 30조+ 추정(NH투자증권) (한국경제 10/23)
 · EWY 10/23 151.26$ (+1.5%, Yahoo) — 미국 상장 한국 ETF
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image

from sandisk_video import header, box, slam, CX, PURP, WHT2, chip
from make_video import (FW, FH, FPS, F24, F12, F9, WHITE, YEL, CYAN, ORG, GRAY, DIM, lerp, prog, ease, tone, mtof, SR)
import mid_video as mv
from nike_video import stamp_slam, warn_icon, render_frame, dk, DARK
from option_video import big_text, coin, GOLD
from semicrash_video import hbm_stack, TEAL
from survive_video import ant, speech
from squeeze_video import CH, with_card
from citadel_video import shiver, deul, punch_fx

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "monday/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
GAP, TAIL = 0.22, 0.5
CARD = YEL
BROWN = (150, 100, 60); HORN = (240, 232, 210); BULLC = (190, 120, 60)

# ================================================================ drawings
def bear(d, x, y, t, angry=True):
    """곰(하락장 상징, 직접 그린 캐릭터) 약 44x46"""
    b = int(abs(math.sin(t * 4)) * 2); y -= b
    for ex in (x + 4, x + 30): d.ellipse([ex, y, ex + 10, y + 10], fill=BROWN, outline=dk(BROWN, 0.6))
    d.ellipse([x + 2, y + 4, x + 42, y + 34], fill=BROWN, outline=dk(BROWN, 0.6))
    d.ellipse([x + 14, y + 18, x + 30, y + 30], fill=(210, 170, 120))
    d.rectangle([x + 20, y + 19, x + 24, y + 22], fill=DARK)
    for ex in (x + 12, x + 28):
        d.rectangle([ex, y + 12, ex + 3, y + 15], fill=DARK)
        if angry: d.line([(ex - 2, y + 9 + (0 if ex < x + 20 else 3)), (ex + 5, y + 12 - (0 if ex < x + 20 else 3))], fill=DARK)
    d.rounded_rectangle([x + 6, y + 32, x + 38, y + 50], radius=6, fill=BROWN, outline=dk(BROWN, 0.6))
    d.text((x + 22, y + 36), "곰", font=F9, fill=HORN, anchor="ma")

def bull(d, x, y, t):
    """황소(상승장 상징, 직접 그린 캐릭터) 약 48x46"""
    b = int(abs(math.sin(t * 4 + 1)) * 2); y -= b
    d.polygon([(x + 6, y + 8), (x - 2, y - 2), (x + 2, y + 10)], fill=HORN)
    d.polygon([(x + 42, y + 8), (x + 50, y - 2), (x + 46, y + 10)], fill=HORN)
    d.ellipse([x + 4, y + 2, x + 44, y + 32], fill=BULLC, outline=dk(BULLC, 0.6))
    d.ellipse([x + 12, y + 18, x + 36, y + 31], fill=(225, 170, 130))
    for nx in (x + 18, x + 28): d.rectangle([nx, y + 23, nx + 2, y + 25], fill=DARK)
    d.arc([x + 19, y + 27, x + 29, y + 34], 0, 180, fill=GOLD, width=2)
    for ex in (x + 13, x + 31): d.rectangle([ex, y + 10, ex + 3, y + 13], fill=DARK)
    d.rounded_rectangle([x + 8, y + 32, x + 40, y + 50], radius=6, fill=BULLC, outline=dk(BULLC, 0.6))
    d.text((x + 24, y + 36), "소", font=F9, fill=HORN, anchor="ma")

def gauge(d, cx, cy, r, val, vmax, u=1.0, lbl="공포지수"):
    """반원 게이지(왼쪽 차분 → 오른쪽 공포), 눈금은 중립색"""
    cols = [CYAN, TEAL, YEL, ORG, (230, 120, 60)]
    for k, c in enumerate(cols):
        a0 = 180 + k * 36; d.arc([cx - r, cy - r, cx + r, cy + r], a0, a0 + 34, fill=c, width=6)
    v = val * u; ang = math.pi * (1 - v / vmax)
    d.line([(cx, cy), (cx + int(math.cos(ang) * (r - 8)), cy - int(math.sin(ang) * (r - 8)))], fill=WHITE, width=3)
    d.ellipse([cx - 4, cy - 4, cx + 4, cy + 4], fill=WHITE)
    d.text((cx, cy + 8), f"{v:.0f}", font=F24, fill=WHITE, anchor="ma")
    d.text((cx, cy + 36), lbl, font=F9, fill=GRAY, anchor="ma")

def barrel(d, x, y, col=(70, 80, 100)):
    d.rounded_rectangle([x, y, x + 30, y + 40], radius=4, fill=col, outline=dk(col, 0.6))
    for yy in (y + 8, y + 30): d.rectangle([x, yy, x + 30, yy + 2], fill=dk(col, 0.6))
    d.text((x + 15, y + 15), "WTI", font=F9, fill=WHITE, anchor="ma")

def cal(d, x, y, day, lbl, col=YEL):
    d.rectangle([x, y, x + 40, y + 42], fill=(230, 228, 214), outline=GRAY)
    d.rectangle([x, y, x + 40, y + 10], fill=col)
    d.text((x + 20, y + 1), lbl, font=F9, fill=DARK, anchor="ma")
    d.text((x + 20, y + 16), day, font=F12, fill=DARK, anchor="ma")

def item(d, t, t0, y, title, l1, l2, col):
    vis, o = slam(t, t0, 0.18)
    if not vis: return
    y += o
    box(d, 30, y, 220, y + 40, col, (10, 14, 28))
    d.text((38, y + 4), title, font=F12, fill=col)
    d.text((38, y + 20), l1, font=F9, fill=WHITE); d.text((38, y + 30), l2, font=F9, fill=GRAY)

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t + 9, "10/26(월) 장 열리기 전", "월요일도 갭하락?", "악재 3 · 호재 3만 보세요", YEL)   # t+9: 첫 프레임부터 제목 완성
    s1 = seg[1]
    gauge(d, CX, 186, 46, 52, 80, ease(prog(t, 0.0, 0.8)), "변동성 지수 VKOSPI")
    if t < s1:
        for k, x in enumerate((44, 176)): ant(d, x + shiver(t, k), 248, t, "sweat", bob=False)
        deul(d, 96, 286, t, "덜덜덜", WHITE)
    else:
        bear(d, 40, 236, t); bull(d, 160, 236, t)
        vis, o = slam(t, s1 + 0.2, 0.18)
        if vis:
            d.text((62, 290 + o), "악재 3", font=F12, fill=WHITE, anchor="ma"); d.text((184, 290 + o), "호재 3", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 262), "VS", font=F24, fill=YEL, anchor="ma")
    return {}

def s_bear(img, d, t, seg, dur):
    header(d, t, "이번 주 악재", "곰이 노린다", "먼저 나쁜 소식부터", ORG)
    s1, s2 = seg[1], seg[2]
    bear(d, 172, 122, t)
    if t < s1:
        cal(d, 40, 124, "29일", "새벽 3시")
        d.text((92, 128), "미국 금리 결정", font=F12, fill=WHITE)
        d.text((92, 146), "9월에 이미 +0.25%p", font=F9, fill=GRAY)
    elif t < s2:
        barrel(d, 44, 124)
        d.text((86, 126), "유가 103달러", font=F12, fill=WHITE)
        d.text((86, 144), "약 13.7만 원 · 금 +3.8%", font=F9, fill=GRAY)
    else:
        d.rectangle([40, 124, 80, 152], fill=(14, 18, 36), outline=CYAN)
        d.line([(44, 132), (56, 138), (64, 134), (76, 148)], fill=CYAN, width=2)
        d.text((92, 126), "메타 현금흐름 -", font=F12, fill=WHITE)
        d.text((92, 144), "AI 투자 버틸 수 있나?", font=F9, fill=GRAY)
    item(d, t, 0.15, 182, "① FOMC 10/29 새벽", "또 올리면 반등이 막혀요", "9월 인상 3.75~4%", ORG)
    item(d, t, s1 + 0.1, 226, "② 유가 103달러", "물가 부담 → 금리 부담", "WTI 10/23 +3.8%", ORG)
    item(d, t, s2 + 0.1, 270, "③ AI 투자 의심", "메타 현금흐름 마이너스", "코어위브 채권 불안", ORG)
    return {}

def s_bull(img, d, t, seg, dur):
    header(d, t, "이번 주 호재", "황소의 반격", "이번엔 좋은 소식", CYAN)
    s1, s2 = seg[1], seg[2]
    bull(d, 168, 122, t)
    if t < s1:
        hbm_stack(d, 44, 122)
        v = 77 * ease(prog(t, 0.2, 1.4))
        d.text((92, 124), f"하닉 {v:.0f}조", font=F12, fill=YEL)
        d.text((92, 142), "3분기 영업익 예상", font=F9, fill=GRAY)
    elif t < s2:
        for k in range(8):
            if t > s1 + 0.1 + k * 0.06: coin(d, 48 + (k % 4) * 10, 150 - (k // 4) * 8, 5, "")
        d.text((92, 124), "주주환원 폭탄", font=F12, fill=YEL)
        d.text((92, 142), "삼전 최대 110조", font=F9, fill=GRAY)
    else:
        gauge(d, 62, 150, 22, 85, 100, ease(prog(t, s2, s2 + 0.8)), "")
        d.text((92, 124), "동결 85%+", font=F12, fill=YEL)
        d.text((92, 142), "CME 페드워치", font=F9, fill=GRAY)
    item(d, t, 0.15, 182, "① 10/28 하닉 실적", "영업이익 약 77조 예상", "작년보다 +576% · 삼전 29일", CYAN)
    item(d, t, s1 + 0.1, 226, "② 주주환원", "삼전 최대 110조 추가", "하닉 30조+ 예상 (NH)", CYAN)
    item(d, t, s2 + 0.1, 270, "③ 이번엔 금리 동결 쪽", "동결 확률 85% 이상", "12월 인상 여지는 남음", CYAN)
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "결론", "승부는 28·29일", "월요일 갭보다 중요한 것", YEL)
    s1 = seg[1]
    bear(d, 36, 126, t, False); bull(d, 166, 126, t)
    d.text((CX, 140), "VS", font=F24, fill=YEL, anchor="ma")
    vis, o = slam(t, 0.2, 0.18)
    if vis:
        box(d, 34, 186 + o, 216, 214 + o, GRAY, (12, 14, 28))
        d.text((CX, 190 + o), "금요일 밤 미국의 한국 ETF", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 201 + o), "EWY +1.5%", font=F12, fill=WHITE, anchor="ma")
    if t > 1.4: stamp_slam(img, CX, 240, "28·29일", YEL, t, 1.4, "24", -8)
    if t > s1 + 0.1: speech(d, 52, 268, "월요일, 사요? 기다려요?", tail_left=True)
    d.text((32, 306), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.4)

SCRIPT = [
    (s_hook, [("월요일도 갭하락일까?\n공포지수 52", "월요일도 갭하락일까요? 공포지수가 오십이예요."),
              ("이번 주 악재 3개 · 호재 3개\n이것만 보세요", "이번 주 악재 셋, 호재 셋만 보세요.")]),
    (with_card(s_bear, "악재", "먼저 나쁜 소식", CARD), [
        ("① 10/29 새벽 미국 금리 결정\n9월에 이미 올렸는데 또?", "하나. 이십구 일 새벽 미국 금리 결정. 구월에 이미 올렸는데, 또 올리면 반등이 막혀요."),
        ("② 유가 103달러(약 13.7만 원)\n금요일에만 +3.8%", "둘. 유가 백삼 달러, 우리 돈 약 십삼만 칠천 원. 금요일에만 삼 점 팔 퍼센트 뛰었어요."),
        ("③ 메타 현금흐름 마이너스\nAI 투자, 버틸 수 있나?", "셋. 메타 현금흐름이 마이너스로 돌아서서, 에이아이 투자 버틸 수 있냐는 걱정이에요.")]),
    (with_card(s_bull, "호재", "이번엔 좋은 소식", CARD), [
        ("① 10/28 하닉 실적\n영업이익 약 77조 예상 (+576%)", "하나. 이십팔 일 하이닉스 실적. 영업이익 약 칠십칠 조 원이 예상돼요."),
        ("② 주주환원\n삼전 최대 110조 · 하닉 30조+ 예상", "둘. 주주환원. 삼성전자 최대 백십 조, 하이닉스도 삼십 조 넘게 기대돼요."),
        ("③ 이번 FOMC는 동결 쪽\n동결 확률 85% 이상", "셋. 이번 금리 결정은 동결 쪽. 동결 확률이 팔십오 퍼센트를 넘어요.")]),
    (s_end, [("금요일 밤 미국의 한국 ETF는 +1.5%\n진짜 승부는 28·29일", "금요일 밤, 미국의 한국 이티에프는 일 점 오 퍼센트 올랐어요. 진짜 승부는 이십팔, 이십구 일이에요."),
             ("여러분은 월요일에 사요, 기다려요?\n댓글로 알려주세요", "여러분은 월요일에 사요, 기다려요? 댓글로 알려주세요.")]),
]
TITLES = ["", "곰이 노린다", "황소의 반격", "승부는 28·29일"]
NCH = 2


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.05 if k == 0 else (CH + 0.3 if 1 <= k <= NCH else 0.25)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.3, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts); sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    bpm = 96; beat = 60 / bpm; e = beat / 2; bar = beat * 4                  # 밝고 잔잔한 장조 하나 (C-G-Am-F)
    prog_ = [([60, 64, 67], 48), ([67, 71, 74], 55), ([69, 72, 76], 57), ([65, 69, 72], 53)]
    mel = [[76, None, 79, None, 77, None, 76, None], [74, None, 71, None, 74, None, 79, None], [76, None, 72, None, 74, None, 76, None], [77, None, 76, None, 72, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            if mm[st]: tone(bgm, T, e * 1.6, mtof(mm[st]), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(1.5 * SR); fi = int(0.3 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.07, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.06, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=0.8): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def growl(T): tone(sfx, T, 0.35, 110, 0.06, "sq", 0.5, f1=80, decay=0.3)
    def moo(T): tone(sfx, T, 0.4, 180, 0.05, "tri", f1=260, decay=0.3)
    def brr(T, d=0.9):
        for j in range(int(d / 0.07)): tone(sfx, T + j * 0.07, 0.05, 150 + (j % 2) * 30, 0.035, "sq", 0.5, decay=0.04)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    thump(S[0] + 0.02); rise(S[0] + 0.05, 0.7); brr(S[0] + 0.9, 1.0)
    growl(sg(0, 1) + 0.1); moo(sg(0, 1) + 0.25); pop(sg(0, 1) + 0.3)
    for k in (1, 2):
        bell3(S[k]); thump(S[k] + 0.12); swoosh(S[k] + CH - 0.25)
        for i in range(3): pop(sg(k, i) + 0.15)
    growl(S[1] + CH + 0.2); moo(S[2] + CH + 0.2); rise(sg(2, 0) + 0.2, 1.2)
    for j in range(8): tone(sfx, sg(2, 1) + 0.1 + j * 0.06, 0.06, 1976, 0.04, "sq", 0.5, decay=0.04)
    swoosh(S[3]); pop(sg(3, 0) + 0.2); stampfx(S[3] + 1.4); ding(sg(3, 1) + 0.15)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

"""특별편 · 역대급 숏이 쌓였다, 숏스퀴즈 터지면 대박? (aibubble_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-23 기준):
 · EPFR(Investing.com 10/15, Yahoo 10/18): NYSE 상장주식 공매도 잔고 9월 하순 210억 주 첫 돌파(사상 최대), 직전 집계 대비 +2.7%.
   EPFR은 '역발상 관점에선 긍정적 신호'라고 해석, 실제 매수로 이어질지·언제일지는 데이터로 알 수 없음
 · Bloomberg 10/22(IBTimes·PANews 정리), 골드만삭스 프라임 브로커리지 자료:
   이번 달 전 세계 주식 공매도:매수 약 5:1 · 숏 레버리지 최근 5년 중 99번째 백분위(상위 1%) · 약세 베팅 5년 최고 근접
   · 펀더멘털 롱숏 펀드 순노출 약 3년 최저, 총노출은 증가 · 10/15까지 1주일 -2.9%(매일 손실) · 아시아 종목 펀드 10월 상반월 -6.8%
   · 기술주가 핵심 격전지 · 상당수는 보유 주식을 지키는 헤지 목적 · 숏이 많아도 반등 시점은 알 수 없음
   · 골드만 마크 윌슨: 금리·에너지 가격 변동성으로 헤지펀드 주식 순노출이 역사적으로 낮음
 · 게임스톱(분할 전 종가): 2020/12/31 18.84$ → 2021/1/27 347.51$(+1,745%) → 2021/2/19 40.59$(-88%)
   멜빈캐피털 2021년 1월 -53%(시타델·포인트72가 27.5억$ 투입)
실존 인물은 등장시키지 않음(회사명 글자만). 마지막 장면 전망은 제작자 의견.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from ackman_video import up_arrow, money_bag, tower
from semicrash_video import alert_card, crash_line, qmark, news_card, shield, TEAL
from aibubble_video import path_until
from survive_video import ant, speech, checkmark, xmark, PINK, MINT

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "squeeze/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6

# ================================================================ drawings
def spring(d, cx, ybot, h, col=GRN, w=34, coils=7):
    """눌린 용수철(h = 현재 높이). 위에 누르는 판"""
    top = ybot - h
    pts = []
    for k in range(coils * 2 + 1):
        y = ybot - h * k / (coils * 2)
        x = cx - w // 2 if k % 2 == 0 else cx + w // 2
        pts.append((x, y))
    d.line(pts, fill=col, width=3)
    d.rectangle([cx - w // 2 - 6, ybot, cx + w // 2 + 6, ybot + 5], fill=GRAY)
    return top

def weight(d, cx, y, lbl, col=SRED, w=70):
    d.rectangle([cx - w // 2, y - 18, cx + w // 2, y], fill=dk(col, 0.6), outline=col)
    d.text((cx, y - 15), lbl, font=F9, fill=WHITE, anchor="ma")

def share_card(d, x, y, lbl, col=CYAN, o=0):
    d.rectangle([x, y + o, x + 30, y + 20 + o], fill=(14, 18, 36), outline=col)
    d.rectangle([x + 3, y + 3 + o, x + 9, y + 9 + o], fill=col)
    d.text((x + 15, y + 11 + o), lbl, font=F9, fill=WHITE, anchor="ma")

def arrow_r(d, x0, x1, y, col=WHT2):
    d.line([(x0, y), (x1, y)], fill=col, width=2); d.polygon([(x1, y - 4), (x1 + 6, y), (x1, y + 4)], fill=col)

def gme_pts(x0, x1, ytop, ybot):
    """게임스톱 2020.12.31~2021.2.19 (분할 전 종가, 주요 지점)"""
    ks = [(0, 18.84), (4, 17.69), (8, 31.40), (11, 39.36), (14, 65.01), (15, 76.79), (16, 147.98), (17, 347.51),
          (18, 193.60), (19, 325.00), (20, 225.00), (22, 90.00), (24, 53.50), (27, 51.10), (31, 40.59)]
    X = lambda i: x0 + i / 31 * (x1 - x0); Y = lambda v: ybot - v / 360 * (ybot - ytop)
    return [(X(a), Y(b)) for a, b in ks]

# ================================================================ scenes
def punch_fx(t, t0):
    return {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2)), "flash": 0.3} if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 숏스퀴즈", "역대급 숏 쌓였다", "뉴욕증시 공매도 사상 최대", SRED)
    s1 = seg[1]
    if t < s1:
        u = ease(prog(t, 0.3, 2.2))
        h = int(lerp(110, 34, u))
        top = spring(d, 78, 262, h, GRN)
        weight(d, 78, top, "공매도", SRED)
        for k in range(int(u * 5)):                                          # 계속 쌓이는 숏 벽돌
            d.rectangle([52 + (k % 2) * 8, top - 30 - k * 9, 104 + (k % 2) * 8, top - 22 - k * 9], fill=dk(SRED, 0.5), outline=SRED)
        v = 210 * ease(prog(t, 0.6, 2.2))
        d.text((170, 150), "NYSE 공매도", font=F9, fill=GRAY, anchor="ma")
        d.text((170, 164), f"{v:.0f}억 주", font=F24, fill=SRED if v >= 209.5 else WHITE, anchor="ma")
        if t > 2.3:
            vis, o = slam(t, 2.3, 0.2)
            d.rectangle([130, 200 + o, 212, 220 + o], fill=(40, 10, 16), outline=YEL if blink(t, 3) else SRED)
            d.text((171, 204 + o), "사상 처음!", font=F12, fill=YEL, anchor="ma")
        d.text((170, 232), "2026년 9월 하순 · EPFR", font=F9, fill=DIM, anchor="ma")
    else:
        h = int(34 + 4 * math.sin(t * 30)) if t < s1 + 0.8 else 34
        top = spring(d, CX, 262, h, GRN)
        weight(d, CX, top, "공매도 210억 주", SRED, 110)
        for k in range(3): qmark(d, CX - 50 + k * 50, 150, t + k * 0.3)
        if t > s1 + 0.8:
            stamp_slam(img, CX, 176, "터지면 대박?", YEL, t, s1 + 0.8, "24", -8)
            debris(d, CX, 250, t, s1 + 0.8, 12, (YEL, GRN, WHITE), 50, 0.7, 5)
    fx = {}
    if 2.3 < t < 2.4: fx["flash"] = 0.25
    if t > s1: fx.update(punch_fx(t, s1 + 0.8))
    return fx

def s_what(img, d, t, seg, dur):
    header(d, t, "01 · 먼저 기초", "공매도란?", "빌려서 팔고, 사서 갚기", CYAN)
    s1 = seg[1]
    if t < s1:
        steps = [(0.5, "① 빌리기", "주식 1주", CYAN), (1.3, "② 먼저 팔기", "100$에", ORG), (2.1, "③ 싸게 사서 갚기", "70$에", GRN)]
        for i, (ts, a, b, col) in enumerate(steps):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 124 + i * 46 + o
            d.rectangle([34, y, 216, y + 38], fill=(10, 14, 30), outline=col)
            share_card(d, 42, y + 9, "1주", col)
            d.text((84, y + 6), a, font=F12, fill=WHITE); d.text((84, y + 22), b, font=F9, fill=col)
        if t > 2.8:
            vis, o = slam(t, 2.8, 0.2)
            d.text((CX, 270 + o), "차익 +30$", font=F24, fill=GRN, anchor="ma")
            coin(d, 72, 282 + o, 7, "$"); coin(d, 178, 282 + o, 7, "$")
    else:
        box(d, 34, 124, 216, 214, DIM)
        d.text((40, 127), "그런데 주가가 오르면?", font=F9, fill=WHITE)
        u = ease(prog(t, s1 + 0.2, s1 + 1.6))
        pts = [(46 + j * 8, 200 - int((j / 20) ** 1.8 * 60 * u) + int(2 * math.sin(j * 1.7))) for j in range(int(20 * u) + 1)]
        if len(pts) > 1: d.line(pts, fill=SRED, width=2)
        d.line([(42, 186), (210, 186)], fill=GRAY); d.text((212, 188), "100$", font=F9, fill=GRAY, anchor="ra")
        if u >= 1: d.text((206, 132), "150$", font=F12, fill=SRED, anchor="ra")
        if t > s1 + 1.7:
            d.text((CX, 222), "손실 -50$, 더 오르면 끝없이", font=F9, fill=SRED, anchor="ma")
        if t > s1 + 2.3:
            for k in range(5):
                ts = s1 + 2.3 + k * 0.12
                if t > ts: mini_person(d, 56 + k * 22, 262, (BLUE, ORG, GRN, PURP, CYAN)[k], t * 2, k)
            vis, o = slam(t, s1 + 2.6, 0.2)
            d.rectangle([34, 286 + o, 216, 306 + o], fill=(40, 10, 16), outline=SRED)
            d.text((CX, 290 + o), "급히 사서 갚기 → 더 급등", font=F12, fill=WHITE, anchor="ma")
            up_arrow(d, 196, 250, SRED, 24)
    chapter_flash(img, d, t, "01", "공매도란?", CYAN)
    return punch_fx(t, s1 + 2.6) if t > s1 else {}

def s_who(img, d, t, seg, dur):
    header(d, t, "02 · 누가 걸었나", "주인공은 헤지펀드", "골드만삭스 프라임 브로커리지 자료", ORG)
    s1 = seg[1]
    if t < s1:
        tower(d, 40, 140, 44, 110, (90, 100, 150), "헤지펀드", 0.6)
        d.text((150, 128), "10월 전 세계 주식", font=F9, fill=GRAY, anchor="ma")
        base = 250
        for i, (nm, v, col, ts) in enumerate([("매수", 1, GRN, 0.6), ("공매도", 5, SRED, 1.1)]):
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.5)); h = int(v * 20 * u); x = 106 + i * 54
            d.rectangle([x, base - h, x + 36, base], fill=col)
            d.text((x + 18, base + 3), nm, font=F9, fill=col, anchor="ma")
            if u >= 1: d.text((x + 18, base - h - 13), str(v), font=F12, fill=WHITE, anchor="ma")
        d.line([(100, base + 1), (214, base + 1)], fill=GRAY)
        if t > 1.9: glitch_text(img, 150, 266, "5 : 1", F24, SRED, t, 5 if t < 2.4 else 1)
    else:
        d.text((CX, 126), "숏 레버리지 · 최근 5년 중 위치", font=F9, fill=WHITE, anchor="ma")
        u = ease(prog(t, s1 + 0.2, s1 + 1.3))
        d.rectangle([40, 144, 210, 160], outline=WHT2)
        for k in range(20):
            if k / 20 < u * 0.99:
                d.rectangle([42 + k * 8, 146, 48 + k * 8, 158], fill=SRED if k >= 17 else ORG)
        d.text((40, 164), "0%", font=F9, fill=GRAY); d.text((210, 164), "100%", font=F9, fill=GRAY, anchor="ra")
        if u >= 1: target_lock(d, 202, 152, t, s1 + 1.3, "99%", SRED, "상위 1%")
        if t > s1 + 2.0:
            vis, o = slam(t, s1 + 2.0, 0.2)
            box(d, 34, 196 + o, 216, 236 + o, ORG, (30, 18, 6))
            chip(d, 42, 204 + o, 22, CYAN, t, 2)
            d.text((136, 202 + o), "핵심 격전지", font=F9, fill=GRAY, anchor="ma"); d.text((136, 216 + o), "기술주", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 248), "약세 베팅 5년 최고 근접", font=F9, fill=ORG, anchor="ma")
    chapter_flash(img, d, t, "02", "누가 걸었나", ORG)
    return {"flash": 0.2} if t < s1 and 1.9 < t < 2.0 else {}

def s_why(img, d, t, seg, dur):
    header(d, t, "03 · 왜 걸었나", "하락 베팅 + 보험", "전부 '망한다'에 건 건 아니다", PURP)
    s1 = seg[1]
    if t < s1:
        items = [(0.4, "금리 불안", SRED), (0.8, "유가·에너지 변동", ORG), (1.2, "AI 수익성 의구심", PURP)]
        for i, (ts, s, col) in enumerate(items):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 126 + i * 30 + o
            d.rectangle([34, y, 160, y + 22], fill=(10, 14, 30), outline=col)
            warn_icon(d, 40, y + 5, col); d.text((62, y + 5), s, font=F12 if len(s) < 7 else F9, fill=WHITE)
        ant(d, 186, 160, t, "sweat", (120, 130, 170))
        if t > 1.8:
            vis, o = slam(t, 1.8, 0.2)
            d.text((CX, 232 + o), "\"떨어질 거야\"", font=F12, fill=SRED, anchor="ma")
            d.polygon([(118, 254 + o), (132, 254 + o), (125, 266 + o)], fill=SRED)
    else:
        share_card(d, 50, 150, "보유", GRN); d.text((65, 174), "산 주식", font=F9, fill=GRN, anchor="ma")
        if t > s1 + 0.5:
            shield(d, 102, 150, CYAN); d.text((110, 174), "보험", font=F9, fill=CYAN, anchor="ma")
        if t > s1 + 0.9:
            share_card(d, 146, 150, "숏", SRED); d.text((161, 174), "공매도", font=F9, fill=SRED, anchor="ma")
        if t > s1 + 1.4:
            vis, o = slam(t, s1 + 1.4, 0.2)
            box(d, 34, 196 + o, 216, 244 + o, PURP, (24, 12, 34))
            d.text((CX, 201 + o), "롱숏 펀드 순노출", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 216 + o), "약 3년 만에 최저", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 256), "사면서 동시에 숏으로 방어 중", font=F9, fill=PURP, anchor="ma")
    chapter_flash(img, d, t, "03", "왜 걸었나", PURP)
    return {}

def s_pain(img, d, t, seg, dur):
    header(d, t, "04 · 그런데", "펀드도 아프다", "버티기 힘들면 숏을 덮는다", SRED)
    s1 = seg[1]
    if t < s1:
        cal = [("10/9", "월"), ("10/12", "화"), ("10/13", "수"), ("10/14", "목"), ("10/15", "금")]
        d.text((CX, 124), "롱숏 펀드 · 10/15까지 1주일", font=F9, fill=GRAY, anchor="ma")
        for k in range(5):
            ts = 0.4 + k * 0.3
            if t < ts: continue
            vis, o = slam(t, ts, 0.18); x = 40 + k * 36
            d.rectangle([x, 142 + o, x + 30, 176 + o], fill=WHITE, outline=GRAY); d.rectangle([x, 142 + o, x + 30, 152 + o], fill=SRED)
            d.text((x + 15, 143 + o), "손실", font=F9, fill=WHITE, anchor="ma")
            d.polygon([(x + 9, 158 + o), (x + 21, 158 + o), (x + 15, 170 + o)], fill=BLUE)
        if t > 2.0:
            glitch_text(img, CX, 192, "-2.9%", F24, SRED, t, 6 if t < 2.5 else 1)
            d.text((CX, 222), "5일 내내 손실", font=F12, fill=WHITE, anchor="ma")
        ant(d, 100, 252, t, "dazed", (120, 130, 170)) if t > 2.4 else None
    else:
        d.text((CX, 124), "아시아 종목 펀드 · 10월 상반월", font=F9, fill=GRAY, anchor="ma")
        v = 6.8 * ease(prog(t, s1 + 0.2, s1 + 1.0))
        d.text((CX, 138), f"-{v:.1f}%", font=F24, fill=SRED, anchor="ma")
        if t > s1 + 1.2:                                                     # 숏 덮기 = 사서 갚기
            for k in range(6):
                ts = s1 + 1.2 + k * 0.15
                u = prog(t, ts, ts + 0.5)
                if u > 0: share_card(d, int(lerp(220, 50 + (k % 3) * 34, ease(u))), 178 + (k // 3) * 26, "매수", GRN)
            d.text((180, 190), "숏 덮기", font=F12, fill=GRN, anchor="ma") if t > s1 + 2.1 else None
        if t > s1 + 2.3:
            vis, o = slam(t, s1 + 2.3, 0.2)
            box(d, 34, 240 + o, 216, 280 + o, GRN, (10, 30, 16))
            d.text((CX, 245 + o), "공매도를 갚으려면", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 259 + o), "결국 '사야' 한다", font=F12, fill=GRN, anchor="ma")
    chapter_flash(img, d, t, "04", "펀드도 아프다", SRED)
    return punch_fx(t, 2.0) if t < s1 else {}

def s_gme(img, d, t, seg, dur):
    header(d, t, "05 · 터지면 대박?", "게임스톱의 교훈", "2021년 1~2월 · 분할 전 종가", GOLD)
    s1 = seg[1]
    box(d, 34, 122, 216, 252, DIM)
    d.text((40, 125), "게임스톱 주가($)", font=F9, fill=WHITE)
    pts = gme_pts(44, 208, 142, 244)
    ip = 7
    a0, a1 = s1 + 0.1, s1 + 1.1                                            # 경보 먼저 → 폭락
    p1 = path_until(pts[:ip + 1], ease(prog(t, 0.3, 2.4)))
    if len(p1) > 1: d.line(p1, fill=GRN, width=2)
    if t > 0.4: d.text((pts[0][0] + 2, pts[0][1] - 12), "18.84", font=F9, fill=WHT2)
    if t > 2.4:
        px, py = pts[ip]; d.text((px, py - 12), "347.51", font=F9, fill=YEL, anchor="ma")
        if t < s1: stamp_slam(img, 160, 196, "+1,745%", GRN, t, 2.5, "12", -8)
    if t > s1:
        alert_card(img, d, t, a0, a1, CX, 196, "폭락 경보", "숏스퀴즈 끝")
        if t >= a1:
            p2 = path_until(pts[ip:], ease(prog(t, a1, a1 + 1.2)))
            if len(p2) > 1: d.line(p2, fill=SRED, width=2)
        if t > a1 + 1.2:
            px, py = pts[-1]; d.text((px, py - 12), "40.59", font=F9, fill=SRED, anchor="ra")
            target_lock(d, int(px) - 6, int(py) - 2, t, a1 + 1.2, "-88%", SRED, "3주 만에")
    if t < s1 and t > 1.4:
        vis, o = slam(t, 1.4, 0.2)
        d.rectangle([34, 262 + o, 216, 284 + o], fill=(40, 10, 16), outline=SRED)
        d.text((CX, 266 + o), "숏 건 헤지펀드 한 달 -53%", font=F12, fill=WHITE, anchor="ma")
    if t > s1 + 2.6:
        vis, o = slam(t, s1 + 2.6, 0.2)
        d.rectangle([34, 262 + o, 216, 284 + o], fill=(30, 22, 6), outline=GOLD)
        d.text((CX, 266 + o), "꼭대기 추격 매수는 크게 물림", font=F9, fill=WHITE, anchor="ma")
        ant(d, 196, 286, t, "dazed")
    chapter_flash(img, d, t, "05", "게임스톱", GOLD)
    fx = {}
    if t > s1 and a1 < t < a1 + 0.4: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
    return fx

def s_predict(img, d, t, seg, dur):
    header(d, t, "PREDICTION · 제작자 의견", "대박? 반짝?", "", YEL)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        rows = [(0.4, "숏 많다 = 바로 터진다?", "타이밍은 아무도 몰라요"), (1.3, "전부 사서 갚아야 한다?", "상당수는 보험, 버티기도")]
        for i, (ts, a, b) in enumerate(rows):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 116 + i * 56 + o
            d.rectangle([34, y, 216, y + 46], fill=(10, 14, 30), outline=GRAY)
            d.text((42, y + 5), a, font=F12, fill=WHITE)
            d.text((42, y + 25), b, font=F9, fill=CYAN)
            if t > ts + 0.6: xmark(d, 196, y + 26, SRED, 12)
        if t > 2.4:
            h = int(34 + 3 * math.sin(t * 12)); top = spring(d, CX, 296, h, GRN, 30, 6)
            weight(d, CX, top, "숏", SRED, 50)
    elif t < s2:
        u = prog(t, s1 + 0.3, s1 + 0.9)
        h = int(lerp(30, 120, ease(u)))
        top = spring(d, 80, 280, h, GRN)
        wy = top - int(60 * ease(prog(t, s1 + 0.5, s1 + 1.2)))
        weight(d, 80, wy, "숏커버", SRED)
        if t > s1 + 0.6: up_arrow(d, 74, 120, GRN, 18)
        if t > s1 + 1.0:
            vis, o = slam(t, s1 + 1.0, 0.2)
            d.text((170, 140 + o), "반등 오면", font=F12, fill=WHITE, anchor="ma")
            d.text((170, 158 + o), "빠르고 세게", font=F12, fill=GRN, anchor="ma")
        if t > s1 + 2.0:
            vis, o = slam(t, s1 + 2.0, 0.2)
            d.text((170, 196 + o), "하지만", font=F9, fill=GRAY, anchor="ma")
            d.text((170, 212 + o), "대박 X", font=F12, fill=GRAY, anchor="ma")
            d.line([(150, 218 + o), (190, 218 + o)], fill=SRED, width=2)
            stamp_slam(img, 170, 250, "반짝!", YEL, t, s1 + 2.4, "24", -8)
    else:
        rows = [("올라탄다면 짧게", GRN), ("꼭대기 추격은 조심", SRED), ("공매도 잔고 발표 체크", CYAN)]
        for i, (s, col) in enumerate(rows):
            ts = s2 + 0.2 + i * 0.35
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 120 + i * 34 + o
            d.rectangle([34, y, 216, y + 26], fill=(10, 14, 30), outline=col)
            d.rectangle([34, y, 40, y + 26], fill=col)
            d.text((50, y + 7), s, font=F12, fill=WHITE)
            if col != SRED: checkmark(d, 194, y + 8, col)
            else: warn_icon(d, 194, y + 6, YEL)
        d.text((CX, 228), "미국 공매도 잔고: 한 달에 2번 발표", font=F9, fill=GRAY, anchor="ma") if t > s2 + 1.4 else None
        ant(d, 110, 252, t, "happy")
    d.text((32, 306), "※ 제작자 의견 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, s1 + 2.4) if s1 < t < s2 else {}

SCRIPT = [
    (s_hook, [("뉴욕증권거래소 공매도 잔고 210억 주,\n사상 처음으로 넘었어요", "뉴욕증권거래소 공매도 잔고가 이백십억 주를 넘었어요. 사상 처음이에요."),
              ("숏스퀴즈 터지면 진짜 대박일까?\n누가, 왜 걸었는지부터 볼게요", "이게 터지면 진짜 대박일까요? 누가, 왜 걸었는지부터 볼게요.")]),
    (s_what, [("공매도는 주식을 빌려서 먼저 팔고,\n나중에 싸게 사서 갚는 거예요", "공매도는 주식을 빌려서 먼저 팔고, 나중에 싸게 사서 갚는 거예요."),
              ("주가가 오르면 손실이 끝없이 커져서\n급히 사서 갚다가 더 튀는 게 숏스퀴즈", "그런데 주가가 오르면 손실이 끝없이 커지죠. 급하게 사서 갚다가 주가가 더 튀는 게, 숏스퀴즈예요.")]),
    (s_who, [("주인공은 헤지펀드, 골드만삭스 집계로\n이번 달 공매도가 매수보다 5배 많아요", "주인공은 헤지펀드예요. 골드만삭스 집계로, 이번 달엔 공매도가 매수보다 다섯 배 많았어요."),
             ("숏 레버리지는 최근 5년 중 상위 1%,\n특히 기술주가 격전지예요", "숏 비중은 최근 오 년 중 상위 일 퍼센트 수준이고, 특히 기술주가 격전지예요.")]),
    (s_why, [("금리·유가 불안, AI 수익성 걱정에\n하락에 베팅하기도 하고", "금리와 유가 불안, 에이아이 수익성 걱정에, 하락에 베팅하기도 하고,"),
             ("들고 있는 주식을 지키는 '보험'으로\n공매도를 같이 거는 경우도 많아요", "들고 있는 주식을 지키는 보험으로, 공매도를 같이 거는 경우도 많아요.")]),
    (s_pain, [("그런데 이 펀드들도 아파요\n10월 15일까지 1주일 -2.9%, 매일 손실", "그런데 이 펀드들도 지금 아파요. 십월 십오 일까지 일주일 동안, 매일 잃어서 이 점 구 퍼센트."),
              ("아시아 종목 펀드는 10월 상반월 -6.8%,\n버티기 힘들면 숏을 덮으려 사야 해요", "아시아 종목 펀드는 십월 상반월에 육 점 팔 퍼센트. 버티기 힘들어지면, 숏을 덮으려고 주식을 사야 하죠.")]),
    (s_gme, [("2021년 게임스톱은 한 달 만에 +1,745%,\n숏 건 헤지펀드는 한 달에 -53%", "이천이십일 년 게임스톱은 한 달도 안 돼 열여덟 배가 됐고, 숏을 건 헤지펀드는 한 달에 반 토막 넘게 잃었어요."),
             ("하지만 3주 뒤엔 꼭대기 대비 -88%,\n꼭대기에서 따라 산 사람은 크게 물렸어요", "하지만 삼 주 뒤엔 꼭대기에서 팔십팔 퍼센트 폭락. 꼭대기에서 따라 산 사람은 크게 물렸죠.")]),
    (s_predict, [("숏이 많다고 바로 터지진 않아요\n상당수는 보험이라 버티기도 해요", "숏이 많다고 바로 터지진 않아요. 상당수는 보험이라, 끝까지 버티기도 하고요."),
                 ("제 예측: 반등이 오면 숏커버로 빠르고 세게,\n하지만 '대박'보다는 '반짝'", "제 예측은요, 반등이 오면 숏 커버 때문에 빠르고 세게 오르겠지만, 대박보다는 반짝에 가까울 거예요."),
                 ("올라탄다면 짧게, 꼭대기 추격은 조심!\n공매도 잔고 발표도 같이 확인해요", "올라탄다면 짧게, 꼭대기 추격은 조심하세요. 공매도 잔고 발표도 같이 확인하고요!")]),
]
TITLES = ["", "공매도란?", "주인공은 헤지펀드", "하락 베팅 + 보험", "펀드도 아프다", "게임스톱의 교훈", "대박? 반짝?"]


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    MINLINE = {(0, 0): 2.9, (5, 0): 2.9}                                      # 카운터·상승선이 다 그려질 때까지
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else 0.75
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += max(L, MINLINE.get((k, i), 0)) + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.4, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # A minor tense-driving chiptune (128 bpm) → C major lift on the prediction
    bpm = 128; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([57, 60, 64], 45), ([53, 57, 60], 41), ([55, 59, 62], 43), ([52, 56, 59], 40)]   # Am F G E
    prog_major = [([60, 64, 67], 48), ([55, 59, 62], 43), ([57, 60, 64], 45), ([53, 57, 60], 41)]   # C G Am F
    mel_m = [[69, None, 72, 69, 76, None, 74, 72], [72, None, 69, None, 77, 76, 74, None], [74, None, 71, 67, 74, None, 76, 74], [76, None, 71, None, 68, None, None, None]]
    mel_M = [[72, None, 76, 79, 84, None, 79, 76], [74, None, 79, None, 83, 81, 79, None], [76, None, 72, 69, 76, None, 79, None], [77, 76, 74, None, 72, None, None, None]]
    gk = 5; a1 = sg(5, 1) + 1.1
    mutes = [(sg(5, 1) + 0.1, a1)]
    muted = lambda T: any(a <= T < b for a, b in mutes)
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = t0 >= S[6]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if muted(T): continue
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and T > 2.3: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total or muted(T): continue
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def creak(T, d=1.8): tone(sfx, T, d, 160, 0.035, "sq", 0.5, f1=90, decay=d)
    def boing(T): tone(sfx, T, 0.45, 180, 0.08, "sq", 0.5, f1=900, decay=0.4)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.06, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.03, "sin", decay=0.2)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    # hook: 용수철이 눌리는 소리 → 사상 처음 → 터지면 대박?
    typing(S[0] + 0.1, "역대급숏쌓였다"); creak(S[0] + 0.3, 1.9)
    for k in range(5): thump(S[0] + 0.7 + k * 0.32)
    alarm(S[0] + 2.3, 2)
    tone(sfx, sg(0, 1), 0.7, 400, 0.04, "sq", 0.5, f1=500, decay=0.7); boing(sg(0, 1) + 0.8); stampfx(sg(0, 1) + 0.82)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # 01 what
    pop(S[1] + 0.5); swoosh(S[1] + 1.3); coin_s(S[1] + 2.1); coin_s(S[1] + 2.8); ding(S[1] + 2.9)
    rise(sg(1, 1) + 0.2, 1.4); alarm(sg(1, 1) + 1.7, 2)
    for k in range(5): pop(sg(1, 1) + 2.3 + k * 0.12)
    stampfx(sg(1, 1) + 2.6)
    # 02 who
    pop(S[2] + 0.6); thump(S[2] + 1.1); glitch(S[2] + 1.9, 6)
    rise(sg(2, 1) + 0.2, 1.1); lock(sg(2, 1) + 1.3); pop(sg(2, 1) + 2.0)
    # 03 why
    for i in range(3): pop(S[3] + 0.4 + i * 0.4)
    fall(S[3] + 1.8, 0.6)
    pop(sg(3, 1) + 0.0); ding(sg(3, 1) + 0.5); pop(sg(3, 1) + 0.9); thump(sg(3, 1) + 1.4)
    # 04 pain
    for k in range(5): thump(S[4] + 0.4 + k * 0.3)
    glitch(S[4] + 2.0, 6); fall(S[4] + 2.4, 0.6)
    fall(sg(4, 1) + 0.2, 0.8)
    for k in range(6): coin_s(sg(4, 1) + 1.2 + k * 0.15)
    stampfx(sg(4, 1) + 2.3)
    # 05 gme: 급등 → 경보 → 폭락
    rise(S[5] + 0.3, 2.1); stampfx(S[5] + 2.5); thump(S[5] + 1.4)
    alarm(sg(5, 1) + 0.1, 5); fall(a1, 1.2); thump(a1 + 0.05); lock(a1 + 1.2); pop(sg(5, 1) + 2.6)
    # predict
    pop(S[6] + 0.4); pop(S[6] + 1.3); creak(S[6] + 2.4, 1.0)
    boing(sg(6, 1) + 0.3); rise(sg(6, 1) + 0.4, 0.8); pop(sg(6, 1) + 1.0); fall(sg(6, 1) + 2.0, 0.5); stampfx(sg(6, 1) + 2.4)
    for i in range(3): pop(sg(6, 2) + 0.2 + i * 0.35)
    ding(sg(6, 2) + 1.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "scan":
        from nike_video import render_low
        for k, s in enumerate(scenes):
            for i in range(int(s["dur"] * FPS) + 1): render_low(s, i / FPS)
        print("scan ok"); sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

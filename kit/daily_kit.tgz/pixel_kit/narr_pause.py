"""순번 뒤 짧은 쉼 (10/25 사용자 지시)
"하나. 이십구 일 새벽…"처럼 순번 말(하나·둘·셋…, 악재 하나, 반전 둘, 이유 셋, 첫째…) 바로 뒤에 본문이 붙으면 헷갈리므로
순번 부분과 본문을 따로 합성하고 사이에 PAUSE초 무음을 넣는다. 사용법: 각 영상의 gen_narration()에서 synth 대신 synth_line을 쓴다.
"""
import re
import numpy as np

PAUSE = 0.38
_ORD = r"(하나|둘|셋|넷|다섯|여섯|일곱|여덟|아홉|열|첫째|둘째|셋째|넷째|다섯째|마지막)"
ORD_RE = re.compile(rf"^\s*((?:[가-힣]{{1,4}}\s)?{_ORD})\s*[.,!]\s*(.+)$")

def split_ordinal(text):
    m = ORD_RE.match(text)
    if not m: return None
    head, body = m.group(1), m.group(3)
    if len(head) > 8: return None
    return head + ".", body

def _trim(x):
    idx = np.where(np.abs(x) > 0.01)[0]
    return x[max(0, idx[0] - 600): idx[-1] + 2000] if len(idx) else x

def synth_line(tts, text, sid, speed, synth):
    """synth: tts_synth.synth. 순번이 있으면 [순번] + 무음 + [본문]으로 이어 붙인 float32 배열과 sr 반환"""
    sp = split_ordinal(text)
    if not sp:
        x, sr = synth(tts, text, sid, speed=speed); return _trim(x).astype(np.float32), sr
    a, sr = synth(tts, sp[0], sid, speed=speed); b, _ = synth(tts, sp[1], sid, speed=speed)
    gap = np.zeros(int(PAUSE * sr), dtype=np.float32)
    return np.concatenate([_trim(a), gap, _trim(b)]).astype(np.float32), sr

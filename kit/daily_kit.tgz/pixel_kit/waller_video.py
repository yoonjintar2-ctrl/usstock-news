"""인물사전 '크리스토퍼 월러' (3D 모션 + 마스코트 풀샷 컷, 60초 이내) — 2026-11-11 제작
사실 확인(2026-11-11 KST):
 · 1959년 네브래스카 출생, 경제학 박사(워싱턴주립대), 인디애나·켄터키·노터데임대 교수, 2009~ 세인트루이스 연은 연구 책임자(EVP)
 · 2020-12-03 상원 인준 48대 47, 12-18 취임, 임기 2030-01-31 (위키백과)
 · 연준 이사 7명 전원 매 회의 투표 / 지역 연은 총재는 12명 중 5명만 투표
 · 2022년 강한 인상 주장(4월), 기준금리 상단 0.25% → 4.50%(2022.1→12), 2022.6 CPI 9.1%
 · 2025-07-30 FOMC 9대 2, 월러·보먼 인하 주장 반대표(이사 2명 동시 반대는 1993년 이후 처음) → 2025-09-17 0.25%p 인하(상단 4.50→4.25)
 · 2025-10 재무장관이 차기 의장 후보 5인에 포함 확인
 · 2026-11-10 런던 연설(연준 원문): 12월 0.25%p 인상 쪽, 10월 근원 CPI가 0.3% 안팎이면 0.5%p도 검토해야 · 현재 3.75~4.00%(9월 인상, 10월 동결 10대 2) · 12월 FOMC 12/8~9
 · 닮은꼴 아닌 기하학 흉상, 가짜 인용 없음, 정당명 없음, 투자 권유 아님, 빨강/초록 구분 없음
python3 waller_video.py [times|audio]  → waller/out/spec.json, tl.json, mix.wav"""
import os, sys, math, json, hashlib, wave
import numpy as np
from make_video import tone, mtof, SR
TR = 0.4
BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "waller/out"); NDIR = os.path.join(BASE, "waller/narr")
def clip_path(n): return os.path.join(NDIR, hashlib.md5(f"q|{n}".encode()).hexdigest() + ".npy")
GAP, TAIL = 0.32, 0.5
HOST = {"host_hook", "host_mid", "host_end"}
SCRIPT = [
    ("host_hook", [("{48 대 47}, 단 한 표 차\n크리스토퍼 월러 연준 이사", "사십팔 대 사십칠. 단 한 표 차이로 연준에 들어온 사람, 크리스토퍼 월러 이사예요.", "h1"),
                   ("월가는 왜 이 사람 말에\n{유독 귀를 기울일까요?}", "월가는 왜, 이 사람 말에 유독 귀를 기울일까요?", "h2")]),
    ("profile", [("교수 출신 {경제학자}\n2020년 {연준 이사}가 됐어요", "월러는 교수 출신 경제학자예요. 세인트루이스 연은 연구 책임자를 거쳐, 이천이십 년 연준 이사가 됐죠.", "p1")]),
    ("seven", [("연준 이사는 모두 {7명}\n금리 회의마다 {빠짐없이 투표}", "연준 이사는 모두 일곱 명. 금리 회의마다 빠짐없이 투표해요.", "p2")]),
    ("hawk", [("2022년 물가가 치솟자\n{강하게 금리 인상}을 주장", "이천이십이 년, 물가가 치솟자 월러는 강하게 금리 인상을 주장했어요.", "r1")]),
    ("dissent", [("2025년 7월엔 {인하 주장 반대표}\n두 달 뒤 연준은 {실제로 인하}", "그런데 이천이십오 년 칠월엔, 금리를 내리자며 반대표를 던졌죠. 두 달 뒤 연준은 실제로 금리를 내렸어요.", "r2")]),
    ("host_mid", [("한쪽 편보다\n{데이터를 따라 움직인다}는 평가", "한쪽 편에 서기보다, 데이터를 따라 움직인다는 평가를 받아요.", "m1")]),
    ("five", [("{차기 연준 의장 후보 5명}에도\n이름을 올렸어요", "차기 연준 의장 후보 다섯 명에도 이름을 올렸고요.", "c1")]),
    ("now", [("2026년 11월, {12월 인상 쪽}으로\n물가 뜨거우면 {0.5%p도 검토}", "그런 월러가 이천이십육 년 십일월, 십이월 금리 인상 쪽으로 기울었다고 밝혔어요. 물가가 뜨거우면 영 점 오 퍼센트포인트 인상도 검토해야 한다고요.", "n1")]),
    ("host_end", [("월러의 {다음 한마디}\n어떻게 보세요?", "월러의 다음 한마디, 여러분은 어떻게 보세요?", "e1")]),
]
# 장면별 효과음(장면 시작 기준 초, 종류) — 3D 페이지의 등장 타이밍과 같은 규칙(u = 첫 줄 시작 + 비율×길이)
EV = {"profile": [(0.10, "pop"), (0.38, "pop"), (0.70, "pop"), (0.78, "thump")],
      "seven": [(0.05 + i * 0.07, "tick") for i in range(7)] + [(0.62, "pop")],
      "hawk": [(0.12 + i * 0.075, "tick") for i in range(8)] + [(0.78, "stamp")],
      "dissent": [(0.10, "pop"), (0.30, "thump"), (0.62, "pop"), (0.80, "thump")],
      "five": [(0.10 + i * 0.1, "tick") for i in range(5)] + [(0.66, "pop")],
      "now": [(0.06, "pop"), (0.36, "thump"), (0.70, "thump")]}

def placeholder_narration():
    """TTS 도착 전 레이아웃용 임시 무음(초당 6.3음절 추정) — 실제 테이크가 오면 덮어씀"""
    for _, lines in SCRIPT:
        for _, n, _ in lines:
            p = clip_path(n)
            if not os.path.exists(p):
                syl = len([c for c in n if '가' <= c <= '힣'])
                np.save(p.replace(".npy", ".ph.npy") if False else p, np.zeros(int(syl / 6.3 * SR), np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.12 if k == 0 else TR + 0.12
        seg, lens = [], []
        for sub, n, _ in lines:
            L = len(np.load(clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        host = fn in HOST
        dur = t - GAP + (TAIL + (0.25 if host else 0.15))
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=dur, host=host, subs=[s for s, _, _ in lines], narr=[n for _, n, _ in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def spec(scenes, starts, total):
    hosts, bubbles, subs = [], [], []
    for k, sc in enumerate(scenes):
        S = starts[k]
        if sc["host"]:
            hosts.append(dict(k=k, t0=S, t1=S + sc["dur"], fade_in=(k > 0)))
            for i, s in enumerate(sc["subs"]):
                t0 = S + sc["seg"][i]; t1 = S + (sc["seg"][i + 1] if i + 1 < len(sc["subs"]) else sc["seg"][i] + sc["lens"][i] + 0.35)
                bubbles.append(dict(t0=t0, t1=t1, text=s, first=(i == 0), last=(i == len(sc["subs"]) - 1)))
        else:
            for i, s in enumerate(sc["subs"]):
                t0 = S + sc["seg"][i]; t1 = S + (sc["seg"][i + 1] - 0.05 if i + 1 < len(sc["subs"]) else min(sc["dur"] - 0.05, sc["seg"][i] + sc["lens"][i] + 0.45))
                subs.append(dict(t0=t0, t1=t1, text=s))
    return dict(total=total, hosts=hosts, bubbles=bubbles, subs=subs)

# ================================================================ audio
def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(clip_path(n)).astype(np.float64)
            if np.abs(x).max() > 0:
                x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
                if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    # 잔잔하지만 살짝 수상한 분위기: A단조 (Am - F - Dm - E), 느린 템포, 부드러운 사인·삼각파
    bpm = 92; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = [([60, 64, 67], 48), ([57, 60, 64], 45), ([53, 57, 60], 41), ([55, 59, 62], 43)]
    mel = [[76, None, None, 79, None, None, 76, None], [72, None, None, 76, None, None, None, None],
           [77, None, None, 76, None, 72, None, None], [74, None, None, 71, None, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for nn in notes: tone(bgm, t0, bar * 0.98, mtof(nn), 0.014, "sin", decay=bar * 0.9, att=0.08, rel=0.3)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st in (0, 3, 6): tone(bgm, T, e * 1.4, mtof(root - 12), 0.10, "tri", decay=0.35)
            tone(bgm, T, e * 0.5, mtof(notes[st % 3] + 12), 0.008, "sq", 0.25, decay=0.08)
            if mm[st] and b % 2 == 1: tone(bgm, T, e * 2.2, mtof(mm[st]), 0.020, "sin", decay=0.6, att=0.01)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt in (0, 2): tone(bgm, T, 0.12, 110, 0.10, "sin", f1=45, decay=0.07)
            tone(bgm, T + e, 0.02, 0, 0.012, "noise", decay=0.008)
    ie = int(total * SR); fo = int(1.6 * SR); fi = int(0.2 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.05, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.03, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def pop(T): tone(sfx, T, 0.06, 600, 0.04, "sq", 0.5, f1=1300, decay=0.04)
    def bpop(T): tone(sfx, T, 0.07, 500, 0.03, "sin", f1=1100, decay=0.05)
    def tick(T): tone(sfx, T, 0.03, 1500, 0.025, "sq", 0.5, decay=0.015)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.12, "noise", decay=0.05)
    def creep(T): tone(sfx, T, 0.5, 400, 0.025, "sin", f1=180, decay=0.45)
    for k in range(1, len(scenes)): swoosh(S[k] - 0.05)
    for k, sc in enumerate(scenes):
        if sc["host"]:
            for i in range(len(sc["subs"])): bpop(S[k] + sc["seg"][i] - 0.04)
        for ev, kind in sc.get('ev', []): {'pop': pop, 'thump': thump, 'tick': tick, 'stamp': stampfx}[kind](S[k] + ev)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.58 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    g = 0.89 / max(1e-6, np.abs(mix).max()); mix = mix * g
    for p, a, ch in ((path, mix, 2), (path.replace(".wav", "_narr.wav"), nv * g, 1)):
        pcm = (np.clip(a, -1, 1) * 32767).astype(np.int16)
        with wave.open(p, "wb") as w:
            w.setnchannels(ch); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes() if ch == 1 else np.repeat(pcm[:, None], 2, axis=1).tobytes())


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "times"
    placeholder_narration()
    scenes, starts = layout(); total = starts[-1]
    for k, sc in enumerate(scenes):
        L = sc["seg"][-1] + sc["lens"][-1] - sc["seg"][0]; sc["L"] = L
        sc["ev"] = [(sc["seg"][0] + u * L, kind) for u, kind in EV.get(sc["fn"], [])]
    json.dump(spec(scenes, starts, total), open(f"{OUT}/spec.json", "w"), ensure_ascii=False, indent=1)
    json.dump(dict(total=total, scenes=[dict(name=s["fn"], t0=starts[k], dur=s["dur"], seg=s["seg"], lens=s["lens"], L=s["L"], host=s["host"]) for k, s in enumerate(scenes)]), open(f"{OUT}/tl.json", "w"), indent=1)
    for k, s in enumerate(scenes): print(k, s["fn"], round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
    print("total", round(total, 2))
    if mode == "audio": make_audio(f"{OUT}/mix.wav", scenes, starts, total); print("audio ok")

"""특별편 · 10/15 국장 대폭락 이유 + 11월 반전 카드(중간선거 · 클로드 상장 보도) (semicrash_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-15 오전): 디지털데일리·글로벌이코노믹·이투데이(9시 7분 사이드카, 9시 15~17분 지수·종목, 미국 9월 CPI 3.7%, 10년물 5.329%, 필라델피아 반도체 -4.30%),
MTN 10/5(키움증권: 중간선거 후 6개월 +6.3%, 12개월 +10.5%), Yahoo Finance 10/1·10/4(블룸버그 보도: 앤트로픽 11월 9일 주 마케팅, 최대 2조 달러, 미확정)
규칙(10/12~): 급락 알럿은 급락이 그래프에 반영되기 '전에' 띄우고, 그 다음 급락을 보여 준다.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK, bank)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from ackman_video import up_arrow, money_bag
from semicrash_video import alert_card, crash_line, qmark, shield, TEAL

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "kospi1015/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6

# ================================================================ drawings
def thermo(d, x, y, frac, col=SRED):
    d.rectangle([x + 4, y, x + 14, y + 80], fill=(30, 30, 46), outline=WHT2)
    h = int(76 * frac); d.rectangle([x + 6, y + 78 - h, x + 12, y + 78], fill=col)
    d.ellipse([x - 2, y + 74, x + 20, y + 96], fill=col, outline=WHT2)
    for k in range(5): d.line([(x + 15, y + 8 + k * 15), (x + 19, y + 8 + k * 15)], fill=GRAY)

def cart(d, x, y, t, n=3):
    d.line([(x - 8, y), (x, y)], fill=WHT2, width=2); d.line([(x, y), (x + 6, y + 22)], fill=WHT2, width=2)
    d.rectangle([x + 4, y + 6, x + 40, y + 22], outline=WHT2); d.line([(x + 6, y + 26), (x + 38, y + 26)], fill=WHT2)
    d.ellipse([x + 8, y + 27, x + 14, y + 33], fill=GRAY); d.ellipse([x + 30, y + 27, x + 36, y + 33], fill=GRAY)
    for k in range(n):
        d.rectangle([x + 8 + k * 11, y + 2 - (k % 2) * 3, x + 16 + k * 11, y + 12], fill=(ORG, GRN, SRED)[k % 3])

def price_tag(d, x, y, s, col=SRED, o=0):
    w = int(d.textlength(s, font=F9)) + 12
    d.polygon([(x, y + 6 + o), (x + 6, y + o), (x + w, y + o), (x + w, y + 12 + o), (x + 6, y + 12 + o)], fill=WHITE, outline=col)
    d.text((x + 8, y + 1 + o), s, font=F9, fill=col)

def candle(d, x, yo, yc, col=SRED):
    d.line([(x + 4, min(yo, yc) - 4), (x + 4, max(yo, yc) + 4)], fill=col)
    d.rectangle([x, min(yo, yc), x + 8, max(yo, yc)], fill=col)

def ballot_box(d, x, y, t, drop=0.0):
    d.rectangle([x, y + 14, x + 50, y + 54], fill=(40, 60, 110), outline=WHT2)
    d.rectangle([x + 14, y + 12, x + 36, y + 16], fill=DARK)
    d.text((x + 25, y + 30), "VOTE", font=F9, fill=WHITE, anchor="ma")
    if drop < 1:
        yy = int(lerp(y - 26, y + 6, ease(drop)))
        d.rectangle([x + 17, yy, x + 33, yy + 14], fill=WHITE, outline=GRAY)
        d.line([(x + 20, yy + 5), (x + 23, yy + 9), (x + 30, yy + 3)], fill=BLUE, width=2)

def server_rack(d, x, y, t, col=CYAN):
    d.rectangle([x, y, x + 40, y + 70], fill=(20, 24, 40), outline=col)
    for r in range(6):
        yy = y + 6 + r * 10
        d.rectangle([x + 4, yy, x + 36, yy + 6], fill=(34, 40, 62))
        for c in range(3):
            on = ((r * 3 + c + int(t * 5)) % 4) != 0
            d.rectangle([x + 26 + c * 3, yy + 2, x + 27 + c * 3, yy + 3], fill=GRN if on else DIM)

def bell(d, x, y, t, ring=True, col=GOLD):
    a = int(math.sin(t * 18) * 2) if ring else 0
    d.rectangle([x + 12 + a, y, x + 16 + a, y + 4], fill=col)
    d.pieslice([x + a, y + 2, x + 28 + a, y + 30], 180, 360, fill=col)
    d.rectangle([x + a, y + 16, x + 28 + a, y + 24], fill=col)
    d.rectangle([x - 4 + a, y + 24, x + 32 + a, y + 27], fill=dk(col, 0.7))
    d.ellipse([x + 11 + a, y + 26, x + 17 + a, y + 32], fill=dk(col, 0.6))
    if ring:
        for k in range(2):
            r = 6 + ((t * 14 + k * 6) % 12)
            d.arc([x - r, y + 14 - r, x - r + 2 * r, y + 14 + r], 150, 210, fill=YEL)
            d.arc([x + 28 - r, y + 14 - r, x + 28 + r, y + 14 + r], -30, 30, fill=YEL)

def ai_core(d, x, y, t, col=ORG):
    """원작 픽셀 아이콘(회사 로고 아님): 빛나는 AI 칩 + 'AI' 글자"""
    chip(d, x, y, 40, col, t, 4)
    d.rectangle([x + 10, y + 13, x + 30, y + 27], fill=DARK)
    d.text((x + 20, y + 14), "AI", font=F12, fill=col, anchor="ma")

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 2026.10.15 오전", "국장 대폭락!", "오늘 무슨 일이?", SRED)
    box(d, 34, 122, 216, 234, DIM)
    d.rectangle([40, 127, 44, 131], fill=WHITE); d.text((48, 125), "코스피", font=F9, fill=WHITE)
    d.text((210, 125), "7거래일째 ↓", font=F9, fill=GRAY, anchor="ra")
    uf = ease(prog(t, 0.3, 1.4)); ud = prog(t, 2.75, 3.45)
    crash_line(d, 42, 150, 210, 152, 64, uf, ud, WHITE, 2)
    if 1.4 < t < 2.75: d.line([(150, 140), (150, 226)], fill=DIM)
    alert_card(img, d, t, 1.5, 2.7, CX, 176)                           # 경보 먼저
    if t > 3.45:                                                        # 급락이 그려진 뒤 수치
        glitch_text(img, 82, 190, "-6%대", F24, SRED, t, 6 if t < 4.0 else 1)
        crack(d, 160, 150, 206, 226, t, 3.3, WHITE, 2)
    rows = [(3.6, "SK하이닉스", "-9.0%", SRED), (3.9, "삼성전자", "-6.9%", BLUE)]
    for i, (ts, nm, pc, col) in enumerate(rows):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 240 + i * 21 + o
        d.rectangle([34, y, 216, y + 18], fill=(10, 14, 30), outline=col)
        d.text((40, y + 3), nm, font=F12, fill=WHITE); d.text((212, y + 3), pc, font=F12, fill=col, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.1, 0.2)
        d.rectangle([34, 286 + o, 216, 310 + o], fill=(40, 10, 16), outline=SRED if blink(t, 3) else ORG)
        d.text((42, 291 + o), "코스피 5,640", font=F12, fill=WHITE)
        d.text((210, 291 + o), "-6.13%", font=F12, fill=SRED, anchor="ra")
        debris(d, 180, 298, t, seg[1] + 0.1, 12, (SRED, WHITE, ORG), 45, 0.7, 2)
        d.text((CX, 313), "오전 9시 17분 기준", font=F9, fill=GRAY, anchor="ma")
    if t > seg[1] + 1.2:
        stamp_slam(img, 160, 196, "사이드카", SRED, t, seg[1] + 1.2, "24", -10)
    fx = {}
    if 2.75 < t < 3.3: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
    if 1.5 < t < 1.6: fx["flash"] = 0.25
    if seg[1] + 1.2 < t < seg[1] + 1.32: fx["flash"] = 0.3
    return fx

def s_cpi(img, d, t, seg, dur):
    header(d, t, "01 · 미국 물가", "물가 쇼크", "미국 9월 소비자물가(CPI)", ORG)
    s1 = seg[1]
    if t < s1:
        thermo(d, 44, 126, 0.45 + 0.45 * ease(prog(t, 0.8, 2.6)))
        base = 232
        cols = [("전월", 3.4, GRAY, 0.9), ("예상", 3.6, WHT2, 1.3), ("실제", 3.7, SRED, 1.9)]
        for i, (nm, v, col, ts) in enumerate(cols):
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.45)); h = int((v - 3.0) * 140 * u); x = 92 + i * 42
            d.rectangle([x, base - h, x + 28, base], fill=col)
            d.text((x + 14, base + 3), nm, font=F9, fill=col, anchor="ma")
            if u >= 1: d.text((x + 14, base - h - 13), f"{v}%", font=F12 if i == 2 else F9, fill=WHITE if i < 2 else SRED, anchor="ma")
        d.line([(88, base + 1), (214, base + 1)], fill=GRAY)
        if t > 2.4:
            vis, o = slam(t, 2.4, 0.2)
            cart(d, 52, 262 + o, t)
            price_tag(d, 110, 262, "서비스 물가 ↑", SRED, o); price_tag(d, 110, 282, "유가 ↑", ORG, o)
        d.text((150, 312), "막대 높이 3.0%부터", font=F9, fill=DIM, anchor="ma") if t > 1.0 else None
    else:
        box(d, 34, 124, 216, 222, DIM)
        d.text((40, 128), "미국 10년물 국채금리", font=F9, fill=GRAY)
        k = ease(prog(t, s1 + 0.1, s1 + 1.3))
        pts = [(44 + j * 8, int(206 - 60 * (j / 20) ** 1.4 * k + 3 * math.sin(j * 1.3))) for j in range(int(20 * k) + 1)]
        if len(pts) > 1: d.line(pts, fill=ORG, width=2)
        if k >= 1:
            vis, o = slam(t, s1 + 1.3, 0.2)
            d.text((206, 134 + o), "5.329%", font=F12, fill=ORG, anchor="ra"); up_arrow(d, 150, 132 + o, ORG, 14)
        if t > s1 + 1.8:
            vis, o = slam(t, s1 + 1.8, 0.2)
            bank(d, 44, 236 + o, 60, WHT2); d.text((74, 290 + o), "중앙은행", font=F9, fill=GRAY, anchor="ma")
            d.rectangle([116, 238 + o, 216, 270 + o], fill=WHITE); d.polygon([(116, 258 + o), (108, 262 + o), (116, 266 + o)], fill=WHITE)
            d.text((166, 242 + o), "금리 더", font=F12, fill=SRED, anchor="ma"); d.text((166, 256 + o), "올릴까?", font=F9, fill=DARK, anchor="ma")
            qmark(d, 204, 274, t)
    chapter_flash(img, d, t, "01", "물가 쇼크", ORG)
    return {}

US = [("SOX", "반도체지수", "-4.30%", 4.30), ("SNDK", "샌디스크", "-5.33%", 5.33), ("MU", "마이크론", "-4.08%", 4.08), ("NVDA", "엔비디아", "-3.16%", 3.16)]
def s_semi(img, d, t, seg, dur):
    header(d, t, "02 · 간밤 뉴욕", "반도체 투매", "AI 수익성 걱정 재점화", PURP)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        box(d, 34, 122, 216, 262, PURP)
        d.text((CX, 126), "NEW YORK · 10.14 (현지) 마감", font=F9, fill=PURP, anchor="ma")
        alert_card(img, d, t, 0.75, 1.55, CX, 192)                       # 경보 → 하락 막대
        if t >= 1.6:
            for i, (tk, nm, vs, v) in enumerate(US):
                ts = 1.6 + i * 0.3
                if t < ts: continue
                vis, o = slam(t, ts, 0.18); y = 140 + i * 30 + o; q = ease(prog(t, ts + 0.1, ts + 0.6))
                d.text((40, y), tk, font=F9, fill=ORG); d.text((40, y + 11), nm, font=F9, fill=GRAY)
                d.text((212, y), vs, font=F12, fill=SRED, anchor="ra")
                d.rectangle([118, y + 16, 118 + int(14 * v * q), y + 21], fill=SRED)
    elif t < s2:
        server_rack(d, 40, 132, t); server_rack(d, 86, 132, t + 0.5)
        for k in range(4):
            ts = s1 + 0.2 + k * 0.3
            if t > ts:
                x = int(lerp(200, 136, ease(prog(t, ts, ts + 0.6))))
                money_bag(d, x - 13, 150 + (k % 2) * 30, "$")
        if t > s1 + 1.6:
            vis, o = slam(t, s1 + 1.6, 0.2)
            d.rectangle([34, 220 + o, 216, 266 + o], fill=(24, 12, 34), outline=PURP)
            d.text((CX, 226 + o), "AI에 너무 많이 쓴 건 아닐까?", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 246 + o), "인프라 과잉 투자 · 수익성 우려", font=F9, fill=PURP, anchor="ma")
            for k in range(3): qmark(d, 150 + k * 22, 200, t + k * 0.3)
    else:
        box(d, 34, 124, 216, 236, DIM)
        d.text((40, 128), "코스피 · 7거래일째 하락", font=F9, fill=GRAY)
        for k in range(7):
            ts = s2 + 0.1 + k * 0.18
            if t < ts: continue
            yo = 144 + k * 11; yc = yo + 10 + (k % 3) * 3 + (14 if k == 6 else 0)
            candle(d, 46 + k * 24, yo, yc, SRED)
            d.text((50 + k * 24, 224), str(k + 1), font=F9, fill=GRAY, anchor="ma")
        if t > s2 + 1.5:
            vis, o = slam(t, s2 + 1.5, 0.2)
            d.rectangle([34, 246 + o, 216, 290 + o], fill=(10, 14, 30), outline=BLUE)
            d.text((CX, 252 + o), "외국인 순매도 5,529억 원", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 272 + o), "오전 9시 17분 · 유가증권시장", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "02", "반도체 투매", PURP)
    return {"shake": (int(math.sin(t * 80) * 2), 0)} if 1.6 < t < 1.9 else {}

def s_vote(img, d, t, seg, dur):
    header(d, t, "03 · 11월 반전 카드 ①", "미국 중간선거", "2026년 11월 3일", BLUE)
    s1 = seg[1]
    if t < s1:
        if t > 0.75:
            vis, o = slam(t, 0.75, 0.2)
            ballot_box(d, 48, 150 + o, t, prog(t, 1.2, 1.8))
            calendar(d, 150, 160 + o, "11.3", "선거", BLUE)
        if t > 2.0:
            vis, o = slam(t, 2.0, 0.2)
            d.rectangle([34, 232 + o, 216, 290 + o], fill=(10, 14, 30), outline=BLUE)
            d.text((CX, 238 + o), "과거 코스피 패턴", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 252 + o), "선거 전엔 약하고", font=F12, fill=SRED, anchor="ma")
            d.text((CX, 270 + o), "선거 후엔 강했다", font=F12, fill=GRN, anchor="ma")
    else:
        base = 228; zero = 228
        cols = [("선거 전", "6개월", -5.2, SRED, s1 + 0.1), ("선거 후", "6개월", 6.3, GRN, s1 + 0.6), ("선거 후", "12개월", 10.5, GRN, s1 + 1.1)]
        d.line([(40, zero), (212, zero)], fill=GRAY)
        for i, (a, b, v, col, ts) in enumerate(cols):
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.45)); h = int(abs(v) * 8 * u); x = 50 + i * 56
            if v < 0: d.rectangle([x, zero, x + 34, zero + h], fill=col)
            else: d.rectangle([x, zero - h, x + 34, zero], fill=col)
            if u >= 1:
                ty = zero + h + 3 if v < 0 else zero - h - 14
                d.text((x + 17, ty), f"{v:+.1f}%", font=F12, fill=WHITE, anchor="ma")
            lab_y = 128 if v < 0 else 276
            d.text((x + 17, 274 if v < 0 else zero + 6), a, font=F9, fill=col, anchor="ma")
            d.text((x + 17, 286 if v < 0 else zero + 18), b, font=F9, fill=col, anchor="ma")
        if t > s1 + 1.6:
            target_lock(d, 179, int(zero - 84 * 1), t, s1 + 1.6, "", GRN)
        d.text((CX, 304), "키움증권 분석 · 과거 평균 수익률", font=F9, fill=DIM, anchor="ma")
    chapter_flash(img, d, t, "03", "중간선거", BLUE)
    return {}

def s_ipo(img, d, t, seg, dur):
    header(d, t, "04 · 11월 반전 카드 ②", "클로드 상장?", "앤트로픽 IPO 보도", GOLD)
    s1 = seg[1]
    if t < s1:
        if t > 0.75:
            vis, o = slam(t, 0.75, 0.2); ai_core(d, 44, 138 + o, t, ORG)
            d.text((64, 186 + o), "클로드 개발사", font=F9, fill=ORG, anchor="ma")
        if t > 1.3:
            vis, o = slam(t, 1.3, 0.2); bell(d, 150, 140 + o, t, t < 3.5)
            d.text((164, 186 + o), "상장 종", font=F9, fill=GOLD, anchor="ma")
        if t > 2.0:
            vis, o = slam(t, 2.0, 0.2)
            d.rectangle([34, 204 + o, 216, 280 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((CX, 210 + o), "블룸버그 보도 (10/1)", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 226 + o), "11월 9일 주 투자자 마케팅", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 246 + o), "추수감사절(11/26) 전 상장 목표", font=F9, fill=GOLD, anchor="ma")
            d.text((CX, 262 + o), "회사 공식 확정 아님", font=F9, fill=GRAY, anchor="ma")
    else:
        u = ease(prog(t, s1 + 0.2, s1 + 1.8))
        d.text((CX, 124), "목표 기업가치 (보도)", font=F9, fill=GRAY, anchor="ma")
        v = 2.0 * u
        ctext(d, 138, f"최대 {v:.1f}조 달러", F24, GOLD if u >= 1 else WHITE, full="최대 2.0조 달러")
        for k in range(8):
            ts = s1 + 0.2 + k * 0.18
            if t > ts: coin(d, 56 + (k % 4) * 14, int(min(214 - (k // 4) * 12, 170 + (t - ts) * 120)), 6, "$")
        ai_core(d, 150, 172, t, ORG)
        if t > s1 + 1.9:
            vis, o = slam(t, s1 + 1.9, 0.2)
            d.rectangle([34, 232 + o, 216, 276 + o], fill=(10, 20, 14), outline=GRN)
            d.text((CX, 238 + o), "흥행하면 AI 투자 심리 ↑", font=F12, fill=GRN, anchor="ma")
            d.text((CX, 258 + o), "→ AI 반도체 기대에 힘이 될 수도", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 300), "※ 보도 기준 · 일정·가치는 바뀔 수 있음", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "04", "클로드 상장", GOLD)
    return {}

def s_check(img, d, t, seg, dur):
    header(d, t, "05 · 체크포인트", "그래도 조심", "보장된 반등은 없다", GRN)
    items = [(0.75, "물가·금리가 계속 높으면", "반등이 늦어질 수 있음", ORG), (seg[1] + 0.1, "과거 평균은 평균일 뿐", "올해도 같다는 보장 없음", BLUE),
             (seg[1] + 1.0, "상장 일정·가치는 보도 기준", "연기·변경될 수 있음", GOLD)]
    for i, (ts, a, b, col) in enumerate(items):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 128 + i * 52 + o
        d.rectangle([34, y, 216, y + 44], fill=(10, 20, 14), outline=col)
        warn_icon(d, 42, y + 14, col)
        d.text((66, y + 7), a, font=F12, fill=WHITE); d.text((66, y + 25), b, font=F9, fill=col)
    if t > seg[1] + 2.0:
        vis, o = slam(t, seg[1] + 2.0, 0.2); shield(d, 117, 288 + o, GRN)
    chapter_flash(img, d, t, "05", "체크", GRN)
    return {}

def s_outro(img, d, t, seg, dur):
    marquee(d, 246, 2, 26, t, "물가 쇼크 · 반도체 투매 · 중간선거 · 클로드 상장", (dk(SRED, 0.55), dk(GOLD, 0.5)))
    header(d, t, "SUMMARY", "10.15 정리", "폭락 이유 2 · 반전 카드 2", GOLD)
    rows = [("DOWN", "물가 쇼크", "CPI 3.7%", SRED), ("DOWN", "반도체 투매", "SOX -4.3%", PURP), ("UP?", "중간선거", "11월 3일", BLUE), ("UP?", "클로드 상장", "11월 중순?", GOLD)]
    for i, (a, b, c, col) in enumerate(rows):
        ts = 0.3 + i * 0.4 + (0.0 if i < 2 else max(0, seg[1] - 1.5))
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 124 + i * 28
        d.rectangle([34, y + o, 216, y + 22 + o], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y + o, 74, y + 22 + o], fill=col)
        d.text((54, y + 6 + o), a, font=F9, fill=WHITE, anchor="ma")
        d.text((80, y + 4 + o), b, font=F12, fill=WHITE); d.text((212, y + 7 + o), c, font=F9, fill=col, anchor="ra")
    d.text((32, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("10월 15일 아침, 코스피 6% 넘게 급락!\n매도 사이드카까지 발동", "시월 십오 일 아침, 코스피가 육 퍼센트 넘게 급락했어요. 매도 사이드카까지 발동!"),
              ("삼성전자 -7%, SK하이닉스 -9%\n이유가 뭘까요?", "삼성전자는 칠 퍼센트, 에스케이하이닉스는 구 퍼센트 가까이 빠졌죠. 이유가 뭘까요?")]),
    (s_cpi, [("미국 9월 물가 3.7% 상승,\n예상치 3.6%를 넘었어요", "미국 구월 소비자물가가 삼 점 칠 퍼센트 올라, 예상치 삼 점 육 퍼센트를 넘었어요."),
             ("미국 10년물 금리 5.3%대,\n금리 인상 걱정이 커졌죠", "미국 십 년물 국채금리는 오 점 삼 퍼센트대. 금리를 더 올릴 수 있다는 걱정이 커졌죠.")]),
    (s_semi, [("간밤 미국 반도체지수 -4.3%,\n샌디스크 -5.3%", "간밤 미국 반도체지수는 사 점 삼 퍼센트, 샌디스크는 오 점 삼 퍼센트 빠졌어요."),
              ("AI에 너무 많이 투자했다는\n수익성 걱정도 다시 나왔고요", "에이아이에 너무 많이 투자했다는, 수익성 걱정도 다시 나왔고요."),
              ("코스피는 7거래일째 하락,\n외국인도 팔고 있어요", "코스피는 칠 거래일째 하락, 외국인도 팔고 있어요.")]),
    (s_vote, [("그런데 11월엔 반전 카드가 있어요\n첫째, 11월 3일 미국 중간선거", "그런데 십일월엔 반전 카드가 있어요. 첫째, 십일월 삼 일 미국 중간선거."),
              ("과거 코스피는 선거 후 6개월 평균 +6.3%,\n1년 평균 +10.5%", "과거 코스피는 선거 후 육 개월 평균 육 점 삼 퍼센트, 일 년 평균 십 점 오 퍼센트 올랐어요.")]),
    (s_ipo, [("둘째, 클로드를 만든 앤트로픽이\n11월 중순 상장을 준비한다는 보도", "둘째, 클로드를 만든 앤트로픽이, 십일월 중순 상장을 준비한다는 보도예요."),
             ("목표 기업가치 최대 2조 달러,\n흥행하면 AI 투자 심리를 살릴 수 있어요", "목표 기업가치는 최대 이조 달러. 흥행하면 에이아이 투자 심리를 살릴 수 있어요.")]),
    (s_check, [("다만 물가와 금리가 계속 높으면\n반등은 늦어질 수 있어요", "다만 물가와 금리가 계속 높으면, 반등은 늦어질 수 있어요."),
               ("과거 평균과 상장 보도는\n보장이 아니라는 점도 기억하세요", "과거 평균과 상장 보도는, 보장이 아니라는 점도 꼭 기억하세요.")]),
    (s_outro, [("오늘 폭락은\n물가 쇼크 + 반도체 투매", "오늘 폭락은 물가 쇼크와 반도체 투매."),
               ("11월엔 중간선거와 클로드 상장이\n반전 카드가 될 수 있어요", "십일월엔 중간선거와 클로드 상장이, 반전 카드가 될 수 있어요.")]),
]
TITLES = ["", "물가 쇼크", "반도체 투매", "중간선거", "클로드 상장", "체크", "정리"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # E minor tension (120 bpm) for the crash → G major lift from the 'November cards' (scene 3) on
    bpm = 120; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([64, 67, 71], 40), ([60, 64, 67], 36), ([62, 66, 69], 38), ([59, 63, 66], 35)]   # Em C D B
    prog_major = [([67, 71, 74], 43), ([62, 66, 69], 38), ([64, 67, 71], 40), ([60, 64, 67], 36)]   # G D Em C
    mel_m = [[76, None, 74, 71, 72, None, 71, None], [72, 74, 76, None, 79, None, 76, 74], [74, None, 69, None, 78, None, 76, 74], [75, None, 71, None, 66, None, None, None]]
    mel_M = [[79, None, 78, 79, 83, None, 81, 79], [78, None, 74, None, 78, 79, 81, None], [83, None, 79, 76, 74, None, 76, None], [76, 78, 79, None, 76, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = t0 >= S[3]
        tense = t0 < S[1]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and not tense: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
            if m and tense and st % 4 == 0 and T > 3.5: tone(bgm, T, e * 1.6, mtof(m - 12), 0.03, "sq", 0.5, decay=0.4)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if 1.5 <= T < 2.75: continue                                         # 경보 동안 드럼 멈춤 → 급락 때 다시
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def wahwah(T):
        for j, m in enumerate([67, 66, 65, 64]): tone(sfx, T + j * 0.25, 0.28 if j < 3 else 0.6, mtof(m), 0.07, "sq", 0.5, f1=mtof(m) * 0.98, decay=0.3)
    def bellfx(T):
        for j in range(3): tone(sfx, T + j * 0.22, 0.4, 1760, 0.06, "sin", decay=0.35); tone(sfx, T + j * 0.22, 0.4, 2637, 0.03, "sin", decay=0.3)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # hook: alarm FIRST, then the crash
    typing(S[0] + 0.1, "특별편국장대폭락"); alarm(S[0] + 1.5, 6); fall(S[0] + 2.75, 0.8); thump(S[0] + 2.8); glitch(S[0] + 3.45, 6)
    pop(S[0] + 3.6); pop(S[0] + 3.9); thump(sg(0, 1) + 0.1); stampfx(sg(0, 1) + 1.2); wahwah(sg(0, 1) + 1.4)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # cpi
    rise(S[1] + 0.8, 1.8); pop(S[1] + 0.9); pop(S[1] + 1.3); thump(S[1] + 1.9); pop(S[1] + 2.4)
    rise(sg(1, 1) + 0.1, 1.2); ding(sg(1, 1) + 1.3); pop(sg(1, 1) + 1.8)
    # semi: alarm first, then bars
    alarm(S[2] + 0.75, 4)
    for i in range(4): thump(S[2] + 1.6 + i * 0.3); fall(S[2] + 1.65 + i * 0.3, 0.4)
    for k in range(4): swoosh(sg(2, 1) + 0.2 + k * 0.3)
    pop(sg(2, 1) + 1.6)
    for k in range(7): thump(sg(2, 2) + 0.1 + k * 0.18)
    pop(sg(2, 2) + 1.5)
    # vote
    pop(S[3] + 0.75); coin_s(S[3] + 1.7); ding(S[3] + 2.0)
    fall(sg(3, 1) + 0.1, 0.4); rise(sg(3, 1) + 0.6, 0.5); rise(sg(3, 1) + 1.1, 0.5); lock(sg(3, 1) + 1.6)
    # ipo
    pop(S[4] + 0.75); bellfx(S[4] + 1.3); pop(S[4] + 2.0)
    for j in range(8): coin_s(sg(4, 1) + 0.2 + j * 0.18)
    rise(sg(4, 1) + 0.2, 1.6); fanfare(sg(4, 1) + 1.9)
    # check
    thump(S[5] + 0.75); thump(sg(5, 1) + 0.1); thump(sg(5, 1) + 1.0); ding(sg(5, 1) + 2.0)
    # outro
    for i in range(4): thump(S[6] + 0.3 + i * 0.4)
    fanfare(sg(6, 1) + 0.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

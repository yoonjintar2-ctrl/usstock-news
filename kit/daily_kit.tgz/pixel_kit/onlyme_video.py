"""특별편 12 · 나만 잃었나? 개미도, 국민연금도, 헤지펀드도 다 물렸다 (aiinvest_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-24 기준, Yahoo 종가):
 · 올해 고점 대비 10/23: 코스피 9,114.55(6/22)→5,550.30 −39.1% · 삼전 362,500(6/18)→215,500 −40.6% · 네이버 287,000(1/29)→173,600 −39.5%
   · 하닉 2,919,000(6/22)→1,277,000 −56.3% · 현대차 750,000(6/1)→295,500 −60.6% · SOXL 300.57$(6/22)→83.56$ −72.2%
 · 단일종목(삼전·하닉) 레버리지 ETF·ETN 5/27~8/14 개인 손실 6조3,130억 원(매매 2.32조+평가 3.99조), 거래계좌 54만6천 개, 계좌당 평균 약 1,156만 원,
   70대 이상 계좌당 약 2,994만 원, 40·50대 62.1% (금감원 → 박성훈 의원실, 이투데이 10/21)
 · SOXL 10/5 164.27$ → 10/16 93.67$ (−43%) · 10/6~16 서학개미 SOXL 순매수 약 32.9억$ · 미국 주식 보관액 10/5 약 2,008억$ → 10/15 약 1,890억$ (−118억$) (뉴시스 10/18)
 · 국민연금: 지분 5% 이상 287종목 평가액 6/30 515.9조 → 10/15 333.5조, −182.4조(−35.3%) 역대 최대, 삼전·하닉 −131.1조 (FnGuide, 헤럴드경제 10/18) · 매도로 확정된 손실이 아닌 평가액 감소(글로벌이코노믹 10/23)
 · 헤지펀드(골드만삭스 추정, 로이터 10/23): 10/22 하루 3대 전략(펀더멘털 롱숏·시스테매틱·멀티전략) 모두 −1% 넘게 — 코로나 이후 처음
   · 10월(10/22까지) 펀더멘털 롱숏 −3.8%(연초 대비 +8.8%) · 기술주 헤지펀드 약 −10% · 아시아 헤지펀드 약 −9%
 · 원화 환산: 원·달러 1,325원(10/21 종가) 기준
10/24 지시: 밝고 잔잔한 BGM 하나 · 배경색 그대로(챕터 카드 한 색) · 달러 금액엔 원화 환산 병기. 상승·하락 빨강/초록 구분 안 함.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, coin, F36, GOLD
from semicrash_video import news_card, qmark, TEAL
from survive_video import ant, speech, checkmark, xmark, PINK, MINT
from squeeze_video import CH, chapter_card, with_card
from aiinvest_video import flag_us

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "onlyme/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
CARD = YEL
NEU = WHT2                                                                     # 손실 수치는 중립색

# ================================================================ drawings
def hook(d, x, y, len_, col=GRAY):
    """위에서 내려오는 낚싯바늘(x,y = 바늘 끝)"""
    d.line([(x + 6, 60), (x + 6, y - 8)], fill=dk(col, 0.8))
    d.line([(x + 6, y - 8), (x + 6, y + 2)], fill=col, width=2); d.arc([x - 2, y - 4, x + 8, y + 6], 0, 180, fill=col, width=2)
    d.line([(x - 2, y + 1), (x - 2, y - 3)], fill=col, width=2)

def hooked_ant(d, x, y, t, mood="dazed"):
    sw = int(math.sin(t * 3) * 3)
    hook(d, x + 8 + sw, y - 4, 0); ant(d, x + sw, y, t, mood, bob=False)

def piggy(d, x, y, cracked=0.0, t=0.0):
    col = (240, 150, 170)
    d.ellipse([x, y, x + 56, y + 38], fill=col, outline=dk(col, 0.6))
    d.ellipse([x + 46, y + 12, x + 62, y + 26], fill=dk(col, 0.85), outline=dk(col, 0.6)); d.point((x + 52, y + 18), fill=DARK); d.point((x + 56, y + 18), fill=DARK)
    d.polygon([(x + 34, y + 2), (x + 40, y - 8), (x + 44, y + 4)], fill=col)
    d.rectangle([x + 38, y + 10, x + 40, y + 12], fill=DARK); d.rectangle([x + 20, y + 2, x + 32, y + 4], fill=dk(col, 0.4))
    for k in range(4): d.rectangle([x + 8 + k * 11, y + 36, x + 14 + k * 11, y + 44], fill=dk(col, 0.8))
    if cracked > 0:
        pts = [(x + 22, y + 4), (x + 18, y + 14), (x + 26, y + 20), (x + 20, y + 30), (x + 28, y + 37)]
        n = max(2, int(len(pts) * cracked)); d.line(pts[:n], fill=DARK, width=2)
    d.text((x + 28, y + 16), "연금", font=F9, fill=DARK, anchor="ma")

def suit(d, x, y, t, col=(60, 70, 100)):
    """정장 펀드매니저(실존 인물 아님) + 땀방울"""
    d.ellipse([x + 6, y, x + 22, y + 16], fill=SKIN)
    d.rectangle([x + 9, y + 5, x + 11, y + 7], fill=DARK); d.rectangle([x + 17, y + 5, x + 19, y + 7], fill=DARK)
    d.line([(x + 11, y + 12), (x + 17, y + 12)], fill=DARK)
    d.polygon([(x + 2, y + 18), (x + 26, y + 18), (x + 28, y + 44), (x, y + 44)], fill=col)
    d.polygon([(x + 12, y + 18), (x + 16, y + 18), (x + 15, y + 32), (x + 13, y + 32)], fill=SRED)
    d.rectangle([x + 30, y + 30, x + 44, y + 40], fill=(120, 80, 40), outline=(80, 50, 20)); d.rectangle([x + 34, y + 27, x + 40, y + 30], outline=(80, 50, 20))
    sy = y + 2 + int((t * 12) % 6); d.ellipse([x + 22, sy, x + 26, sy + 6], fill=CYAN)

def phone_acct(d, x, y, s, col=NEU):
    d.rounded_rectangle([x, y, x + 40, y + 66], radius=6, fill=(20, 24, 40), outline=GRAY)
    d.rectangle([x + 4, y + 8, x + 36, y + 56], fill=(10, 14, 30))
    d.text((x + 20, y + 14), "내 계좌", font=F9, fill=GRAY, anchor="ma"); d.text((x + 20, y + 30), s, font=F12, fill=col, anchor="ma")

def hbar(d, x, y, v, vmax, wmax, col, h=10, u=1.0):
    w = int(wmax * v / vmax * u); d.rectangle([x, y, x + max(2, w), y + h], fill=col); return w

# ================================================================ scenes
def punch_fx(t, t0, flash=False):
    fx = {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2))}
    if flash: fx["flash"] = 0.25
    return fx if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 계좌 위로", "나만 잃었나?", "계좌 보고 한숨 쉬는 당신에게", YEL)
    s1 = seg[1]
    if t < s1:
        ant(d, 70, 176, t, "sweat"); phone_acct(d, 118, 160, "-39%")
        if t > 1.2: speech(d, 100, 140, "나만 이래?", tail_left=True)
        if t > 2.0: qmark(d, 176, 150, t)
    else:
        for k in range(5):
            ts = s1 + 0.2 + k * 0.25
            if t > ts: hooked_ant(d, 36 + k * 36, 160 + (k % 2) * 16, t + k, ("dazed", "sweat")[k % 2])
        if t > s1 + 1.6:
            vis, o = slam(t, s1 + 1.6, 0.2)
            box(d, 34, 236 + o, 216, 266 + o, YEL, (30, 26, 8))
            d.text((CX, 244 + o), "다 같이 물렸어요", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 280), "반전은 마지막에", font=F9, fill=GRAY, anchor="ma")
    return {}

PEAK = [("코스피", 39.1), ("삼전", 40.6), ("네이버", 39.5), ("하닉", 56.3), ("현대차", 60.6), ("SOXL", 72.2)]

def s_peak(img, d, t, seg, dur):
    header(d, t, "01 · 고점에 샀다면", "최대 -72%", "올해 고점 → 10월 23일 종가", CYAN)
    s1 = seg[1]
    d.text((CX, 122), "고점에 샀다면 지금", font=F9, fill=GRAY, anchor="ma")
    for i, (nm, v) in enumerate(PEAK):
        ts = 0.3 + i * 0.35 if i < 3 else s1 + 0.2 + (i - 3) * 0.4
        if t < ts: continue
        y = 136 + i * 24; u = ease(prog(t, ts, ts + 0.6))
        d.text((36, y), nm, font=F9, fill=WHITE)
        w = hbar(d, 84, y, v, 72.2, 100, CYAN if i < 5 else GOLD, 11, u)
        if u >= 1: d.text((88 + w, y), f"-{v:.0f}%", font=F9, fill=WHITE)
    if t > s1 + 1.6: hooked_ant(d, 180, 286, t, "dazed")
    d.text((CX, 300), "Yahoo 종가 · 네이버는 1월 고점", font=F9, fill=DIM, anchor="ma")
    return {}

def s_lev(img, d, t, seg, dur):
    header(d, t, "02 · 레버리지 개미", "석 달에 6.3조", "삼전·하닉 단일종목 레버리지 ETF·ETN", ORG)
    s1 = seg[1]
    if t < s1:
        for k in range(12):
            ts = 0.2 + k * 0.08
            if t > ts: coin(d, 50 + (k % 6) * 30, 130 + (k // 6) * 22, 9, "W")
        v = 6.313 * ease(prog(t, 0.6, 2.0))
        d.text((CX, 192), "개인 투자자 손실 · 5/27~8/14", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 206), f"{v:.1f}조 원", font=F24, fill=YEL, anchor="ma")
        if t > 2.2: d.text((CX, 240), "매매손실 2.3조 + 평가손실 4.0조", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 300), "금융감독원 · 박성훈 의원실", font=F9, fill=DIM, anchor="ma")
    else:
        rows = [("계좌 수", "54만 6천 개"), ("계좌당 평균", "약 1,156만 원"), ("70대 이상 평균", "약 2,994만 원")]
        for i, (a, b) in enumerate(rows):
            ts = s1 + 0.2 + i * 0.5
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 128 + i * 36 + o
            d.rectangle([34, y, 216, y + 28], fill=(10, 14, 30), outline=ORG)
            d.text((42, y + 9), a, font=F9, fill=GRAY); d.text((208, y + 7), b, font=F12, fill=WHITE, anchor="ra")
        if t > s1 + 1.8: ant(d, 112, 246, t, "dazed")
    return {}

def s_us(img, d, t, seg, dur):
    header(d, t, "03 · 서학개미", "열흘 만에 -43%", "미국 반도체 3배 SOXL", PURP)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        flag_us(d, 34, 124)
        pts = [(40, 160), (80, 168), (110, 196), (140, 214), (170, 236), (210, 250)]
        u = ease(prog(t, 0.3, 2.0)); n = 1 + int(5 * u)
        d.line(pts[:n + 1] if n < 6 else pts, fill=CYAN, width=2)
        d.text((40, 148), "164.27$", font=F9, fill=WHITE);
        if u >= 1: d.text((210, 256), "93.67$", font=F9, fill=WHITE, anchor="ra"); stamp_slam(img, 150, 186, "-43%", YEL, t, 2.0, "24", -8)
        d.text((CX, 278), "10월 5일 → 16일", font=F9, fill=GRAY, anchor="ma")
    elif t < s2:
        for k in range(8):
            u = ((t * 0.7 + k / 8) % 1)
            if t > s1 + 0.2: d.rectangle([int(lerp(40, 200, u)), 150 + (k % 3) * 8, int(lerp(40, 200, u)) + 10, 156 + (k % 3) * 8], fill=GOLD)
        d.text((CX, 128), "그 열흘 동안 서학개미 SOXL 순매수", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 186), "32.9억 달러", font=F24, fill=YEL, anchor="ma")
        d.text((CX, 214), "= 한국 돈 약 4.4조 원", font=F12, fill=WHITE, anchor="ma")
        d.text((CX, 300), "뉴시스 10/18 · 1,325원/달러 환산", font=F9, fill=DIM, anchor="ma")
    else:
        d.text((CX, 128), "미국 주식 보관액 · 10/5 → 10/15", font=F9, fill=GRAY, anchor="ma")
        for i, (nm, v) in enumerate([("10/5", 2008), ("10/15", 1890)]):
            u = ease(prog(t, s2 + 0.2 + i * 0.4, s2 + 0.8 + i * 0.4)); h = int((v - 1700) / 320 * 90 * u); x = 76 + i * 70
            d.rectangle([x, 250 - h, x + 30, 250], fill=PURP)
            d.text((x + 15, 254), nm, font=F9, fill=WHITE, anchor="ma")
            if u >= 1: d.text((x + 15, 250 - h - 12), f"{v:,}억$", font=F9, fill=WHITE, anchor="ma")
        if t > s2 + 1.4:
            d.text((CX, 272), "118억 달러 감소 (약 15.6조 원)", font=F12, fill=YEL, anchor="ma")
    return {}

def s_nps(img, d, t, seg, dur):
    header(d, t, "반전 1 · 국민연금", "연금도 물렸다", "지분 5% 이상 287종목 평가액", TEAL)
    s1, s2 = seg[1], seg[2]
    piggy(d, 94, 128, prog(t, s1 + 0.4, s1 + 1.4) if t > s1 else 0, t)
    if t > s1:
        v = 182.4 * ease(prog(t, s1 + 0.2, s1 + 1.6))
        d.text((CX, 186), "6/30 → 10/15 · 3개월 반", font=F9, fill=GRAY, anchor="ma")
        d.text((CX, 200), f"-{v:.1f}조 원", font=F24, fill=YEL, anchor="ma")
        if t > s1 + 1.6: d.text((CX, 230), "(-35.3%) 역대 최대 평가손실", font=F12, fill=WHITE, anchor="ma")
    if t > s2:
        vis, o = slam(t, s2 + 0.2, 0.2)
        box(d, 34, 250 + o, 216, 290 + o, TEAL, (8, 24, 24))
        d.text((CX, 255 + o), "그중 삼전·하닉 131조 원", font=F12, fill=WHITE, anchor="ma")
        d.text((CX, 273 + o), "팔지 않은 평가액 감소예요", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 304), "FnGuide · 헤럴드경제 10/18", font=F9, fill=DIM, anchor="ma")
    return {}

HF = [("기술주 펀드", 10.0, "약 -10%"), ("아시아 펀드", 9.0, "약 -9%"), ("종목 선택 펀드", 3.8, "-3.8%")]

def s_hf(img, d, t, seg, dur):
    header(d, t, "반전 2 · 헤지펀드", "월가도 물렸다", "10월 수익률 · 골드만삭스 추정", GRN)
    s1, s2 = seg[1], seg[2]
    suit(d, 170, 122, t)
    if t > s1:
        for i, (nm, v, s) in enumerate(HF):
            ts = s1 + 0.2 + i * 0.4
            if t < ts: continue
            y = 176 + i * 22; u = ease(prog(t, ts, ts + 0.6))
            d.text((36, y), nm, font=F9, fill=WHITE)
            w = hbar(d, 110, y, v, 10, 70, GRN, 11, u)
            if u >= 1: d.text((114 + w, y), s, font=F9, fill=WHITE)
    else:
        d.text((90, 140), "돈 굴리는 프로들", font=F12, fill=WHITE, anchor="ma")
        speech(d, 70, 158, "우리도...", tail_left=True) if t > 1.0 else None
    if t > s2:
        vis, o = slam(t, s2 + 0.2, 0.2)
        box(d, 34, 250 + o, 216, 290 + o, GRN, (8, 24, 12))
        d.text((CX, 255 + o), "10/22 3대 전략 모두 하루 -1%↑", font=F9, fill=WHITE, anchor="ma")
        d.text((CX, 270 + o), "코로나 이후 처음", font=F12, fill=YEL, anchor="ma")
    d.text((CX, 304), "로이터 10/23", font=F9, fill=DIM, anchor="ma")
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "정리", "모두 물렸다", "개미 · 연금 · 헤지펀드", YEL)
    who = [("개미", 0.2), ("연금", 0.5), ("헤지펀드", 0.8)]
    for i, (nm, ts) in enumerate(who):
        if t < ts: continue
        x = 44 + i * 64; sw = int(math.sin((t + i) * 3) * 3)
        hook(d, x + 14 + sw, 128, 0)
        if i == 0: ant(d, x + 6 + sw, 134, t, "dazed", bob=False)
        elif i == 1: piggy(d, x - 8 + sw, 134, 1.0, t)
        else: suit(d, x + sw, 132, t)
        d.text((x + 18, 186), nm, font=F9, fill=WHITE, anchor="ma")
    if t > 1.4: stamp_slam(img, CX, 226, "나만 아님", YEL, t, 1.4, "24", -8)
    if len(seg) > 1 and t > seg[1] + 0.2:
        d.text((CX, 262), "그래도 비중·레버리지는 꼭 점검", font=F12, fill=WHITE, anchor="ma")
    d.text((32, 306), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.4, True)

SCRIPT = [
    (s_hook, [("계좌 보고 한숨 쉬는 중이라면\n'나만 잃었나?' 싶죠", "계좌 보고 한숨 쉬는 중이라면, 나만 잃었나 싶죠?"),
              ("결론부터: 다 같이 물렸어요\n반전은 마지막에", "결론부터 말하면, 다 같이 물렸어요. 반전은 마지막에 있어요.")]),
    (with_card(s_peak, "01", "고점에 샀다면", CARD), [
        ("올해 고점에 샀다면 지금\n코스피 −39% · 삼전 −41% · 네이버 −40%", "올해 고점에 샀다면 지금, 코스피는 마이너스 삼십구, 삼성전자는 마이너스 사십일, 네이버는 마이너스 사십 퍼센트예요."),
        ("하닉 −56% · 현대차 −61%\nSOXL은 −72%까지", "에스케이하이닉스는 마이너스 오십육, 현대차는 마이너스 육십일, 속슬은 마이너스 칠십이 퍼센트까지 빠졌어요.")]),
    (with_card(s_lev, "02", "레버리지 개미", CARD), [
        ("삼전·하닉 단일종목 레버리지 상품에서만\n석 달 만에 개인 손실 6.3조 원", "삼성전자와 에스케이하이닉스 단일종목 레버리지 상품에서만, 석 달 만에 개인 손실이 육 점 삼 조 원이에요."),
        ("계좌 54만 6천 개 · 계좌당 평균 약 1,156만 원\n70대 이상은 평균 약 2,994만 원", "계좌 오십사만 육천 개, 계좌당 평균 약 천백오십육만 원이고, 칠십 대 이상은 평균 약 이천구백구십사만 원을 잃었어요.")]),
    (with_card(s_us, "03", "서학개미", CARD), [
        ("미국 반도체 3배 SOXL\n10월 초 열흘 만에 −43%", "미국 주식도 마찬가지예요. 반도체 삼 배 속슬은 시월 초 열흘 만에 사십삼 퍼센트 빠졌어요."),
        ("그 열흘 동안 서학개미 SOXL 순매수\n32.9억 달러, 한국 돈 약 4.4조 원", "그 열흘 동안 서학개미는 속슬을 삼십이 점 구억 달러, 우리 돈 약 사 점 사 조 원어치 샀어요."),
        ("미국 주식 보관액은 열흘 새\n118억 달러, 약 15.6조 원 줄었어요", "그런데도 미국 주식 보관액은 열흘 새 백십팔억 달러, 우리 돈 약 십오 점 육 조 원이 줄었어요.")]),
    (with_card(s_nps, "04", "반전 1 · 국민연금", CARD), [
        ("반전 1. 국민연금도 물렸어요", "반전 하나. 국민연금도 물렸어요."),
        ("지분 5% 넘는 287개 종목 평가액\n3개월 반 만에 182조 원 감소, 역대 최대", "국민연금이 오 퍼센트 넘게 가진 이백팔십칠 개 종목의 평가액이, 삼 개월 반 만에 백팔십이 조 원 줄었어요. 역대 최대예요."),
        ("그중 삼전·하닉에서만 131조 원\n팔지 않은 평가액 감소예요", "그중 삼성전자와 에스케이하이닉스에서만 백삼십일 조 원. 다만 팔아서 확정된 손실이 아니라, 평가액이 줄어든 거예요.")]),
    (with_card(s_hf, "05", "반전 2 · 헤지펀드", CARD), [
        ("반전 2. 월가 헤지펀드도 물렸어요", "반전 둘. 월가 헤지펀드도 물렸어요."),
        ("10월 기술주 헤지펀드 약 −10%\n아시아 헤지펀드 약 −9%", "시월 들어 기술주 헤지펀드는 약 십 퍼센트, 아시아 헤지펀드는 약 구 퍼센트를 잃었어요."),
        ("10월 22일엔 3대 전략이 하루에 모두 −1% 넘게\n코로나 이후 처음 (골드만삭스)", "시월 이십이 일에는 헤지펀드 세 가지 주요 전략이 하루에 모두 일 퍼센트 넘게 잃었어요. 코로나 이후 처음이래요.")]),
    (s_end, [("개미도, 국민연금도, 헤지펀드도\n모두 물린 장이에요", "개미도, 국민연금도, 헤지펀드도, 모두 물린 장이에요. 나만 잃은 게 아니에요."),
             ("그래도 다 같이 물렸다고 괜찮은 건 아니에요\n비중과 레버리지는 꼭 점검", "그래도 다 같이 물렸다고 괜찮은 건 아니니까, 비중과 레버리지는 꼭 점검해 보세요.")]),
]
TITLES = ["", "고점에 샀다면", "석 달에 6.3조", "열흘 만에 -43%", "연금도 물렸다", "월가도 물렸다", "모두 물렸다"]


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    MINLINE = {(0, 0): 3.0, (0, 1): 2.8, (1, 0): 2.8, (2, 0): 2.8, (3, 0): 2.6, (4, 0): 2.0, (5, 0): 2.0, (6, 0): 3.0}
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (CH + 0.5 if 1 <= k <= 5 else 0.3)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += max(L, MINLINE.get((k, i), 0)) + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.4, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    # 밝고 잔잔한 장조 칩튠 하나를 처음부터 끝까지 (aiinvest와 같은 구성, 멜로디만 바꿈)
    bpm = 96; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = [([65, 69, 72], 53), ([60, 64, 67], 48), ([62, 65, 69], 50), ([58, 62, 65], 46)]       # F C Dm Bb
    mel = [[81, None, 77, None, 79, None, 81, None], [79, None, 76, None, 72, None, 76, None], [77, None, 74, None, 77, None, 81, None], [82, None, 81, None, 77, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            m = mm[st]
            if m: tone(bgm, T, e * 1.6, mtof(m), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR); fi = int(1.0 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.07, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.06, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.05, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.05, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.04, "sq", 0.5, f1=150, decay=d)
    def sigh(T): tone(sfx, T, 0.7, 520, 0.04, "sin", f1=300, decay=0.6)
    def plop(T): tone(sfx, T, 0.12, 900, 0.05, "sin", f1=300, decay=0.1); tone(sfx, T + 0.05, 0.1, 0, 0.03, "noise", decay=0.05)   # 낚싯바늘 '뽁'
    def crackfx(T):
        for j in range(4): tone(sfx, T + j * 0.06, 0.05, 0, 0.07, "noise", decay=0.03)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    typing(S[0] + 0.1, "나만잃었나"); sigh(S[0] + 1.0); pop(S[0] + 1.2)
    for k in range(5): plop(sg(0, 1) + 0.2 + k * 0.25)
    ding(sg(0, 1) + 1.6)
    for k in range(1, len(scenes)):
        if 1 <= k <= 5: chapter(S[k]); swoosh(S[k] + CH - 0.25); typing(S[k] + CH + 0.6, TITLES[k])
        else: swoosh(S[k]); typing(S[k] + 0.3, TITLES[k])
    C = lambda k: S[k] + CH
    for i in range(3): pop(C(1) + 0.3 + i * 0.35)
    for i in range(3): pop(sg(1, 1) + 0.2 + i * 0.4)
    fall(sg(1, 1) + 1.0, 0.8); plop(sg(1, 1) + 1.6)
    for k in range(12): coin_s(C(2) + 0.2 + k * 0.08)
    ding(C(2) + 2.0)
    for i in range(3): pop(sg(2, 1) + 0.2 + i * 0.5)
    sigh(sg(2, 1) + 1.8)
    fall(C(3) + 0.3, 1.7); stampfx(C(3) + 2.0)
    for k in range(6): coin_s(sg(3, 1) + 0.2 + k * 0.2)
    pop(sg(3, 2) + 0.2); pop(sg(3, 2) + 0.6); fall(sg(3, 2) + 1.4, 0.6)
    crackfx(sg(4, 1) + 0.4); fall(sg(4, 1) + 0.3, 1.3); thump(sg(4, 2) + 0.2)
    for i in range(3): pop(sg(5, 1) + 0.2 + i * 0.4)
    thump(sg(5, 2) + 0.2); sigh(sg(5, 2) + 0.6)
    for i in range(3): plop(S[6] + 0.2 + i * 0.3)
    stampfx(S[6] + 1.4); ding(sg(6, 1) + 0.3)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

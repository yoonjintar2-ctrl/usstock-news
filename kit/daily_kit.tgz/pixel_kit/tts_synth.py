import sys, time, numpy as np, wave
import sherpa_onnx as so
M = "tts/official/sherpa-onnx-supertonic-3-tts-int8-2026-05-11"
def make_tts():
    sc = so.OfflineTtsSupertonicModelConfig(
        duration_predictor=f"{M}/duration_predictor.int8.onnx", text_encoder=f"{M}/text_encoder.int8.onnx",
        vector_estimator=f"{M}/vector_estimator.int8.onnx", vocoder=f"{M}/vocoder.int8.onnx",
        tts_json=f"{M}/tts.json", unicode_indexer=f"{M}/unicode_indexer.bin", voice_style=f"{M}/voice.bin")
    mc = so.OfflineTtsModelConfig(); mc.supertonic = sc; mc.num_threads = 2
    cfg = so.OfflineTtsConfig(); cfg.model = mc
    return so.OfflineTts(cfg)
def synth(tts, text, sid, speed=1.0, steps=8):
    g = so.GenerationConfig(); g.sid = sid; g.speed = speed; g.num_steps = steps; g.extra = {"lang": "ko"}
    a = tts.generate(text, g)
    return np.array(a.samples, dtype=np.float32), a.sample_rate
def f0(x, sr):
    fr = int(0.04 * sr); vals = []
    for i in range(0, len(x) - fr, fr):
        s = x[i:i + fr]
        if np.sqrt((s ** 2).mean()) < 0.02: continue
        ac = np.correlate(s, s, 'full')[fr - 1:]
        lo, hi = int(sr / 400), int(sr / 70)
        k = lo + np.argmax(ac[lo:hi]); vals.append(sr / k)
    return float(np.median(vals)) if vals else 0
if __name__ == "__main__":
    tts = make_tts()
    print("speakers:", tts.num_speakers, "sr:", tts.sample_rate)
    txt = "샌디스크와 웨스턴디지털, 원래 한 회사였다는 거 아세요?"
    for sid in range(tts.num_speakers):
        t = time.time(); x, sr = synth(tts, txt, sid)
        print(sid, f"{len(x)/sr:.2f}s", f"f0={f0(x, sr):.0f}Hz", f"rt={time.time()-t:.1f}s", flush=True)
        np.save(f"tts/s{sid}.npy", x)

"""배경음악 키트 v2 (2026-11-11) — '음악이 너무 단조롭다'는 피드백 반영
예전: 4마디 화음·베이스·멜로디가 끝까지 똑같이 반복.
지금: ① 16마디 진행(A 8마디 + B 8마디) ② 악기 6종(건반/칼림바·패드·베이스·멜로디·타악·종) ③ 구간별 편곡(인트로 → 본론 → 쉬어가기 → 고조 → 마무리)
      ④ 8마디마다 필인 ⑤ 스윙·잔향·좌우 벌림. 그래도 '밝고 잔잔한 곡 하나'라는 규칙(10/24)은 유지 — 조·템포·음색은 한 곡 안에서 안 바뀜.
bgm(style, total, levels=None) → (N,2) float 배열(피크 약 0.25). style: 'lofi' | 'kalimba' | 'city'
levels: 마디별 편곡 단계 0~3 리스트(없으면 기본 흐름). level_plan(total, bar, quiet=[(t0,t1),...]) 로 진행자 컷 구간을 한 단계 낮출 수 있음."""
import numpy as np
from scipy.signal import fftconvolve, lfilter
SR = 44100
def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)
def _env(n, att, dec): t = np.arange(n) / SR; return np.minimum(1, t / max(att, 1e-4)) * np.exp(-t / dec)
def ep(f, dur, vel=1.0):          # 전기 피아노풍(FM): 부드러운 타건 + 맑은 배음이 빨리 사라짐
    n = int(dur * SR); t = np.arange(n) / SR
    mod = np.sin(2 * np.pi * f * 1.0 * t) * (1.4 * np.exp(-t / 0.25) + 0.25) + 0.3 * np.sin(2 * np.pi * f * 14 * t) * np.exp(-t / 0.03)
    return np.sin(2 * np.pi * f * t + mod * vel) * _env(n, 0.004, dur * 0.45) * (1 + 0.04 * np.sin(2 * np.pi * 4.6 * t))
def kal(f, dur, vel=1.0):         # 칼림바/마림바풍: 기음 + 4배음 짧게
    n = int(dur * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.32) + 0.35 * np.sin(2 * np.pi * f * 4.0 * t) * np.exp(-t / 0.05) + 0.12 * np.sin(2 * np.pi * f * 2 * t) * np.exp(-t / 0.18)) * np.minimum(1, t / 0.002)
def bell(f, dur, vel=1.0):        # 종/글로켄: 살짝 어긋난 배음
    n = int(dur * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t / 0.2) + 0.2 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t / 0.08)) * _env(n, 0.002, dur * 0.35)
def lead(f, dur, vel=1.0):        # 부드러운 신스 리드(비브라토)
    n = int(dur * SR); t = np.arange(n) / SR; ph = 2 * np.pi * f * t + 0.012 * f / 5.5 * np.sin(2 * np.pi * 5.5 * t) * np.minimum(1, t / 0.25)
    return (np.sin(ph) + 0.25 * np.sin(2 * ph) + 0.08 * np.sin(3 * ph)) * np.minimum(1, t / 0.02) * np.exp(-t / (dur * 0.7))
def pad(f, dur, vel=1.0):         # 패드: 살짝 어긋난 사인 3개, 느린 어택
    n = int(dur * SR); t = np.arange(n) / SR
    w = sum(np.sin(2 * np.pi * f * d * t + p) for d, p in ((1.0, 0), (1.004, 1.3), (0.996, 2.1))) / 3 + 0.15 * np.sin(2 * np.pi * 2 * f * t)
    return w * np.minimum(1, t / 0.5) * np.minimum(1, (dur - t) / 0.6).clip(0)
def bass(f, dur, vel=1.0):
    n = int(dur * SR); t = np.arange(n) / SR; ph = (f * t) % 1
    return (np.sin(2 * np.pi * f * t) + 0.22 * (2 * np.abs(2 * ph - 1) - 1)) * _env(n, 0.006, dur * 0.6)
_rng = np.random.default_rng(7)
def kick(): n = int(0.22 * SR); t = np.arange(n) / SR; return np.sin(2 * np.pi * (48 * t + 60 * 0.03 * (1 - np.exp(-t / 0.03)))) * np.exp(-t / 0.09)
def snap(): n = int(0.12 * SR); x = _rng.uniform(-1, 1, n); x = np.diff(x, prepend=0); return x * np.exp(-np.arange(n) / SR / 0.025) * 0.7 + 0.3 * np.sin(2 * np.pi * 900 * np.arange(n) / SR) * np.exp(-np.arange(n) / SR / 0.012)
def shk(dec=0.02): n = int(0.07 * SR); x = np.diff(_rng.uniform(-1, 1, n), prepend=0); x = np.diff(x, prepend=0); return x * _env(n, 0.004, dec) * 0.5
def riser(dur): n = int(dur * SR); x = np.diff(_rng.uniform(-1, 1, n), prepend=0); return x * (np.arange(n) / n) ** 2.5 * 0.5

CH_A = [(48, [64, 67, 71, 72]), (45, [64, 67, 69, 72]), (41, [64, 65, 69, 72]), (43, [62, 64, 67, 71]),
        (40, [62, 64, 67, 71]), (45, [60, 64, 67, 69]), (38, [60, 62, 65, 69]), (43, [60, 62, 65, 67])]      # Cmaj7 Am7 Fmaj7 G6 | Em7 Am7 Dm7 G7sus
CH_B = [(41, [60, 64, 65, 69]), (43, [59, 62, 64, 67]), (40, [59, 62, 64, 67]), (45, [60, 64, 67, 72]),
        (38, [60, 65, 69, 72]), (43, [59, 62, 65, 67]), (48, [59, 64, 67, 72]), (48, [57, 60, 64, 67])]      # Fmaj7 G6 Em7 Am7 | Dm7 G7 Cmaj7 C6
MEL_A = [[76, 0, 0, 79, 0, 76, 0, 74], [72, 0, 0, 0, 69, 0, 72, 0], [77, 0, 0, 76, 0, 72, 0, 69], [74, 0, 0, 0, 0, 0, 67, 71],
         [79, 0, 0, 76, 0, 79, 0, 83], [81, 0, 0, 0, 76, 0, 72, 0], [77, 0, 74, 0, 77, 0, 81, 0], [79, 0, 0, 0, 74, 0, 0, 0]]
MEL_B = [[81, 0, 0, 84, 0, 81, 0, 77], [79, 0, 0, 0, 74, 0, 79, 0], [79, 0, 76, 0, 0, 71, 0, 76], [72, 0, 0, 0, 76, 0, 81, 0],
         [77, 0, 0, 74, 0, 77, 0, 81], [79, 0, 0, 83, 0, 79, 0, 74], [76, 0, 0, 0, 79, 0, 84, 0], [84, 0, 0, 0, 0, 0, 0, 0]]
STY = dict(lofi=dict(bpm=84, swing=0.16, lp=5200), kalimba=dict(bpm=102, swing=0.0, lp=9000), city=dict(bpm=96, swing=0.07, lp=8000))

def level_plan(total, bar, quiet=()):
    """기본 흐름: 인트로 1 → 2 → 3, 가운데 2마디 쉬어가기(1), 다시 3, 끝 2마디 1. quiet 구간(진행자 컷)은 한 단계 낮춤"""
    nb = int(total / bar) + 1; lv = []
    for b in range(nb):
        u = b / max(1, nb - 1)
        l = 1 if b < 2 else (2 if u < 0.30 else 3)
        if abs(u - 0.5) < 1.2 / nb: l = 1
        if b >= nb - 2: l = 1
        t = b * bar
        if any(a - bar * 0.5 <= t < e - bar * 0.5 for a, e in quiet): l = max(1, l - 1)
        lv.append(l)
    return lv

def bgm(style, total, levels=None, seed=3):
    P = STY[style]; beat = 60 / P['bpm']; e = beat / 2; bar = beat * 4
    N = int((total + 3) * SR); L = np.zeros(N); R = np.zeros(N); send = np.zeros(N)
    lv = levels or level_plan(total, bar); nb = len(lv); rng = np.random.default_rng(seed)
    def add(t, sig, vol, pan=0.0, rev=0.0):
        i = int(t * SR)
        if i < 0 or i >= N: return
        s = sig[:N - i] * vol; L[i:i + len(s)] += s * (1 - max(0, pan)); R[i:i + len(s)] += s * (1 + min(0, pan))
        if rev: send[i:i + len(s)] += s * rev
    def sw(st): return st * e + (P['swing'] * e if st % 2 else 0)         # 엇박을 살짝 늦춤(스윙)
    K, S, H = kick(), snap(), shk()
    for b in range(nb):
        t0 = b * bar; sec = (b // 8) % 2; i8 = b % 8; root, tones = (CH_A, CH_B)[sec][i8]; mel = (MEL_A, MEL_B)[sec][i8]; l = lv[b]; rep = b // 16
        last = (i8 == 7)
        # 패드(2단계부터) · 베이스(2단계부터)
        if l >= 2:
            for n_ in tones[:3]: add(t0, pad(mtof(n_ - 12), bar * 1.02), 0.020, rev=0.5)
        if style == 'lofi':
            for st, vel, dur in ((0, 1.0, 3.2), (3, 0.6, 2.0)) + (((6, 0.5, 1.2),) if l >= 2 and i8 % 2 else ()):
                for j, n_ in enumerate(tones): add(t0 + sw(st) + j * 0.012, ep(mtof(n_ - 12), dur * e, vel), 0.035 * vel, pan=-0.25 + 0.17 * j, rev=0.35)
            if l >= 2:
                for st, n_ in ((0, root), (3, root), (5, root + 7), (7, root + (12 if not last else 5))): add(t0 + sw(st), bass(mtof(n_ - 12 if n_ > 45 else n_), e * 1.6), 0.13)
        elif style == 'kalimba':
            pat = [[0, 2, 1, 3, 2, 1, 3, 2], [0, 1, 2, 3, 2, 3, 1, 2], [3, 2, 1, 0, 1, 2, 3, 1], [0, 2, 3, 1, 3, 2, 0, 2]][(i8 + rep) % 4]
            for st in range(8):
                if l == 1 and st % 2: continue
                add(t0 + sw(st), kal(mtof(tones[pat[st]] + (12 if st in (3, 6) and l >= 3 else 0)), 0.9), 0.060 * (1.0 if st % 4 == 0 else 0.7), pan=0.35 * (-1) ** st, rev=0.45)
            if l >= 2:
                for st, n_ in ((0, root), (4, root + 7 if i8 % 2 else root)) + (((7, root + 5),) if last else ()): add(t0 + sw(st), bass(mtof(n_ - 12 if n_ > 45 else n_), e * 3.2), 0.13)
        else:   # city
            for st, vel in ((0, 1.0), (3, 0.7), (6, 0.8)) if i8 % 2 == 0 else ((0, 1.0), (2, 0.5), (5, 0.8)):
                for j, n_ in enumerate(tones): add(t0 + sw(st), ep(mtof(n_), e * 1.3, vel * 1.3), 0.026 * vel, pan=-0.2 + 0.13 * j, rev=0.3)
            if l >= 2:
                for st, n_ in ((0, root), (2, root + 12), (3, root), (5, root + 7), (6, root + 12)) + (((7, root + 10),) if last else ()):
                    nn = n_ - 12 if n_ > 52 else n_; add(t0 + sw(st), bass(mtof(nn), e * 0.9), 0.11 if st in (0, 3) else 0.08)
        # 멜로디: 3단계는 매 마디, 2단계는 짝수 마디만(여백). 두 번째 바퀴는 한 옥타브 위 종으로 메아리
        if l >= 2:
            for st, n_ in enumerate(mel):
                if not n_ or (l == 2 and i8 % 2 == 0): continue
                ins = dict(lofi=bell, kalimba=bell, city=lead)[style]
                add(t0 + sw(st), ins(mtof(n_ - (12 if style == 'city' else 0)), e * 2.6), 0.034 if style != 'city' else 0.040, pan=0.15, rev=0.6)
                if rep % 2 == 1 and st % 4 == 0: add(t0 + sw(st) + e, bell(mtof(n_ + 12), e * 2), 0.010, pan=-0.4, rev=0.8)
        # 타악: 1단계 없음 → 2단계 셰이커·림 → 3단계 킥 추가. 8마디 끝엔 필인 + 라이저
        if l >= 2:
            for st in range(8):
                add(t0 + sw(st), H, 0.030 * (1.0 if st % 2 == 0 else 0.6) * (0.8 + 0.4 * rng.random()), pan=0.3)
                if style == 'kalimba' and l >= 3: add(t0 + sw(st) + e / 2, H, 0.012, pan=-0.3)
            for bt in (1, 3): add(t0 + bt * beat, S, 0.055 if l >= 3 else 0.035, pan=-0.1, rev=0.25)
        if l >= 3:
            for st in ((0, 5) if style != 'city' else (0, 2, 4, 6)): add(t0 + sw(st), K, 0.20 if st == 0 else 0.13)
        if last and b + 1 < nb and lv[b + 1] >= 2:
            for k_, st in enumerate((5, 6, 6.5, 7, 7.5)): add(t0 + st * e, S, 0.03 + 0.008 * k_, pan=-0.4 + 0.2 * k_, rev=0.3)
            add(t0 + bar - 1.2, riser(1.2), 0.035, rev=0.5)
        if b + 1 < nb and lv[b + 1] > l and not last: add(t0 + bar - 0.9, riser(0.9), 0.03, rev=0.5)
        if l > 1 and b > 0 and lv[b - 1] < l: add(t0, bell(mtof(tones[-1] + 12), 1.6), 0.03, rev=0.9)      # 구간이 열릴 때 종 한 번
    # 잔향
    n = int(1.3 * SR); ir = np.random.default_rng(1).normal(0, 1, (n, 2)) * np.exp(-np.arange(n) / SR / 0.32)[:, None]; ir /= np.sqrt((ir ** 2).sum(0))
    wet = np.stack([fftconvolve(send, ir[:, 0])[:N], fftconvolve(send, ir[:, 1])[:N]], 1) * 0.55
    out = np.stack([L, R], 1) + wet
    a = np.exp(-2 * np.pi * P['lp'] / SR); out = lfilter([1 - a], [1, -a], out, axis=0)                     # 부드럽게(고역 살짝 깎음)
    out = out[:int((total + 0.5) * SR)]; ie = int(total * SR); fo = int(1.8 * SR); fi = int(0.15 * SR)
    out[:fi] *= np.linspace(0, 1, fi)[:, None]; out[ie - fo:ie] *= np.linspace(1, 0, fo)[:, None]; out[ie:] = 0
    return out * (0.22 / (np.abs(out).max() + 1e-9))

if __name__ == '__main__':
    import sys, soundfile as sf
    for s in STY: sf.write(f'{sys.argv[1]}/bgm_{s}.wav', bgm(s, float(sys.argv[2]) if len(sys.argv) > 2 else 40.0), SR); print(s)

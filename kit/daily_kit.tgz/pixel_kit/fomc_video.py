"""주식 용어 1분 사전 #3 · FOMC (60초 이내 · 첫 프레임에 큰 제목 · 순번 뒤 쉼 · 잔잔한 BGM 하나 · 카드 한 색)
사실 확인(2026-10-26 기준):
 · FOMC 10/27~28 → 결정 10/28 14:00 ET = 10/29(목) 03:00 KST (미국 서머타임 11/1 종료 전), 기자회견 30분 뒤
 · 투표권 12명 = 연준 이사 7 + 뉴욕연은 총재 + 지역 연은 총재 4(순번) · 정례회의 1년 8번(2026: 1·3·4·6·7·9·10·12월)
 · 회의록(의사록)은 회의 3주 뒤 공개 — 9/15~16 회의록 10/7 공개(federalreserve.gov)
 · 9월 회의: 0.25%p 인상 → 3.75~4.00%, 12:0 만장일치, 대부분 '연말까지 추가 인상 필요할 듯'(9월 회의록)
 · 로이터 설문 경제학자 100명 중 94명 10월 동결 예상, 100명 전원 12월 인상 예상(글로벌이코노믹 10/21)
 · 연준 의장 케빈 워시 — 실존 인물이라 얼굴·대사 없이 '의장' 기하학 실루엣만
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image

from sandisk_video import header, box, slam, CX, PURP, WHT2
from make_video import (FW, FH, FPS, F24, F12, F9, WHITE, YEL, CYAN, ORG, GRAY, DIM, lerp, prog, ease, tone, mtof, SR)
import mid_video as mv
from nike_video import stamp_slam, render_frame, dk, DARK
from option_video import big_text, coin, GOLD
from survive_video import ant, speech
from squeeze_video import CH, with_card
from citadel_video import shiver, deul, punch_fx
from circuit_video import clock

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "fomc/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
GAP, TAIL = 0.22, 0.45
CARD = YEL
STONE = (205, 208, 220); HAWK = (150, 100, 60); DOVE = (236, 238, 245); PAPER = (230, 228, 214)

# ================================================================ drawings
def fed_bldg(d, cx, y, w=96, col=STONE):
    """연준 건물(기둥 6개 신전형) 약 w x 72"""
    x0, x1 = cx - w // 2, cx + w // 2
    d.polygon([(x0 - 6, y + 20), (cx, y), (x1 + 6, y + 20)], fill=col, outline=dk(col, 0.6))
    d.text((cx, y + 8), "FED", font=F9, fill=DARK, anchor="ma")
    d.rectangle([x0 - 4, y + 20, x1 + 4, y + 26], fill=dk(col, 0.85))
    for k in range(6):
        px = x0 + 4 + k * (w - 14) // 5
        d.rectangle([px, y + 27, px + 6, y + 58], fill=col, outline=dk(col, 0.7))
    d.rectangle([x0 - 6, y + 59, x1 + 6, y + 64], fill=dk(col, 0.85)); d.rectangle([x0 - 10, y + 65, x1 + 10, y + 70], fill=dk(col, 0.7))

def person(d, x, y, col, s=1):
    d.ellipse([x - 3 * s, y, x + 3 * s, y + 6 * s], fill=col)
    d.rounded_rectangle([x - 5 * s, y + 7 * s, x + 5 * s, y + 15 * s], radius=2, fill=dk(col, 0.75))

def podium(d, x, y, t, talk=True):
    """기자회견 연단 + 기하학 실루엣(실존 인물 얼굴·대사 없음)"""
    d.ellipse([x + 12, y, x + 26, y + 14], fill=(120, 124, 140))
    d.rounded_rectangle([x + 6, y + 14, x + 32, y + 34], radius=4, fill=(40, 46, 70))
    d.polygon([(x + 17, y + 15), (x + 21, y + 15), (x + 19, y + 24)], fill=WHITE)
    d.polygon([(x, y + 30), (x + 38, y + 30), (x + 34, y + 62), (x + 4, y + 62)], fill=(70, 60, 50), outline=dk((70, 60, 50), 0.6))
    d.ellipse([x + 12, y + 38, x + 26, y + 52], outline=GOLD); d.text((x + 19, y + 41), "F", font=F9, fill=GOLD, anchor="ma")
    d.line([(x + 30, y + 30), (x + 34, y + 18)], fill=GRAY, width=2); d.ellipse([x + 32, y + 14, x + 37, y + 19], fill=GRAY)
    if talk:
        for k in range(3):
            r = 6 + k * 6 + int((t * 14) % 6)
            d.arc([x + 36 - r, y + 16 - r, x + 36 + r, y + 16 + r], -40, 40, fill=CYAN if k % 2 else WHT2)

def doc(d, x, y, t, title="회의록", hl=None, w=64, h=70):
    d.polygon([(x, y), (x + w - 12, y), (x + w, y + 12), (x + w, y + h), (x, y + h)], fill=PAPER, outline=GRAY)
    d.polygon([(x + w - 12, y), (x + w - 12, y + 12), (x + w, y + 12)], fill=dk(PAPER, 0.8))
    d.text((x + 6, y + 4), title, font=F9, fill=DARK)
    for k in range(6):
        yy = y + 20 + k * 8; ww = w - 14 - (k * 7) % 18
        col = YEL if hl is not None and k == hl else (150, 150, 140)
        if hl is not None and k == hl: d.rectangle([x + 4, yy - 2, x + 6 + ww, yy + 3], fill=YEL)
        d.line([(x + 6, yy), (x + 6 + ww, yy)], fill=DARK if col == YEL else col, width=2)

def bird(d, x, y, t, kind="hawk", s=1.0):
    """매(올리자) / 비둘기(내리자) — 직접 그린 캐릭터 약 48x40"""
    col = HAWK if kind == "hawk" else DOVE
    flap = math.sin(t * 8 + (0 if kind == "hawk" else 2))
    y -= int(abs(flap) * 2)
    d.ellipse([x + 6, y + 14, x + 40, y + 36], fill=col, outline=dk(col, 0.6))            # 몸
    d.polygon([(x + 6, y + 26), (x - 4, y + 32), (x + 2, y + 22)], fill=dk(col, 0.8))     # 꼬리
    wy = int(flap * 8)
    d.polygon([(x + 14, y + 20), (x + 30, y + 20), (x + 20, y + 6 - wy)], fill=dk(col, 0.85), outline=dk(col, 0.6))  # 날개
    d.ellipse([x + 30, y + 6, x + 48, y + 24], fill=col, outline=dk(col, 0.6))           # 머리
    d.rectangle([x + 40, y + 12, x + 42, y + 14], fill=DARK)
    if kind == "hawk":
        d.polygon([(x + 47, y + 14), (x + 54, y + 16), (x + 49, y + 21)], fill=ORG)        # 갈고리 부리
        d.line([(x + 37, y + 9), (x + 44, y + 11)], fill=DARK, width=2)                    # 눈썹(단호)
        for fx in (x + 16, x + 26): d.line([(fx, y + 36), (fx - 2, y + 41)], fill=ORG, width=2)
    else:
        d.polygon([(x + 47, y + 15), (x + 52, y + 17), (x + 47, y + 19)], fill=(240, 180, 120))
        d.line([(x + 50, y + 22), (x + 58, y + 20)], fill=(140, 180, 110), width=2)          # 올리브 가지
        d.ellipse([x + 55, y + 17, x + 59, y + 21], fill=(140, 180, 110))
        for fx in (x + 16, x + 26): d.line([(fx, y + 36), (fx - 2, y + 41)], fill=(240, 180, 120), width=2)

def seesaw(d, cx, y, ang, l, r, lc=YEL, rc=CYAN):
    """시소: ang>0 이면 왼쪽(l)이 올라감"""
    d.polygon([(cx - 10, y + 18), (cx + 10, y + 18), (cx, y)], fill=GRAY)
    L = 80; dx, dy = math.cos(ang) * L, math.sin(ang) * L
    d.line([(cx - dx, y + dy), (cx + dx, y - dy)], fill=WHT2, width=3)
    for sx, sy, lbl, c in ((cx - dx, y + dy, l, lc), (cx + dx, y - dy, r, rc)):
        d.rectangle([sx - 18, sy - 20, sx + 18, sy - 2], fill=(14, 18, 36), outline=c)
        d.text((sx, sy - 17), lbl, font=F12, fill=c, anchor="ma")

def poll(d, x0, y0, n, u=1.0, col=YEL):
    """100칸 점 그래프 (10x10)"""
    m = int(round(n * u))
    for k in range(100):
        gx, gy = x0 + (k % 10) * 6, y0 + (k // 10) * 6
        d.rectangle([gx, gy, gx + 3, gy + 3], fill=col if k < m else (40, 46, 70))

def mini_cal(d, x, y, m, on=False):
    d.rectangle([x, y, x + 16, y + 17], fill=PAPER if on else (60, 66, 90), outline=YEL if on else GRAY)
    d.rectangle([x, y, x + 16, y + 4], fill=YEL if on else GRAY)
    d.text((x + 8, y + 6), str(m), font=F9, fill=DARK if on else WHITE, anchor="ma")

def icon(d, kind, x, y, t):
    if kind == "clock": clock(d, x + 10, y + 10, 10, (t * 0.3) % 1, YEL)
    elif kind == "mic":
        d.ellipse([x + 6, y, x + 14, y + 10], fill=GRAY); d.line([(x + 10, y + 10), (x + 10, y + 20)], fill=GRAY, width=2); d.line([(x + 4, y + 20), (x + 16, y + 20)], fill=GRAY, width=2)
    elif kind == "doc":
        d.rectangle([x + 2, y, x + 18, y + 22], fill=PAPER); [d.line([(x + 5, y + 6 + k * 5), (x + 15, y + 6 + k * 5)], fill=DARK) for k in range(3)]

def item(d, t, t0, y, title, l1, col, ic=None):
    vis, o = slam(t, t0, 0.18)
    if not vis: return
    y += o
    box(d, 30, y, 220, y + 36, col, (10, 14, 28))
    d.text((38, y + 4), title, font=F12, fill=col)
    d.text((38, y + 21), l1, font=F9, fill=WHITE)
    if ic: icon(d, ic, 194, y + 7, t)

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    d.text((CX, 62), "10/29(목) 새벽 3시 · 미국 금리 결정", font=F9, fill=GRAY, anchor="ma")   # 첫 프레임부터 완성(타자 효과 없음)
    d.text((CX, 76), "주식 용어 1분 사전 #3", font=F12, fill=WHITE, anchor="ma")
    big_text(img, CX, 94, "FOMC", YEL, 3)
    fed_bldg(d, CX, 196, 90)
    clock(d, 196, 212, 13, (t * 0.25) % 1, YEL); d.text((196, 228), "3:00", font=F9, fill=YEL, anchor="ma")
    for k, x in enumerate((34, 64)): ant(d, x + shiver(t, k), 270, t, "sweat", bob=False)
    for k, x in enumerate((162, 192)): ant(d, x + shiver(t, k + 2), 270, t, "sweat", bob=False)
    deul(d, 98, 298, t, "숨죽이는 중", WHITE, F9)
    return {}

def s_what(img, d, t, seg, dur):
    header(d, t, "FOMC = 연방공개시장위원회", "금리 정하는 회의", "미국 기준금리를 투표로", YEL)
    fed_bldg(d, CX, 122, 80)
    cols = [YEL] * 7 + [CYAN] + [ORG] * 4
    for k in range(12):
        if t > 0.6 + k * 0.12:
            person(d, 50 + (k % 6) * 30, 204 + (k // 6) * 22, cols[k])
    if t > 2.2:
        d.text((34, 250), "이사 7", font=F9, fill=YEL); d.text((94, 250), "뉴욕연은 1", font=F9, fill=CYAN); d.text((160, 250), "지역 4(순번)", font=F9, fill=ORG)
    if t > 3.0:
        d.text((CX, 266), "1년에 8번", font=F12, fill=WHITE, anchor="ma")
        for k, m in enumerate((1, 3, 4, 6, 7, 9, 10, 12)):
            if t > 3.2 + k * 0.12: mini_cal(d, 36 + k * 23, 284, m, m == 10)
        if t > 4.4: d.text((36 + 6 * 23 + 8, 304), "이번", font=F9, fill=YEL, anchor="ma")
    return {}

def s_how(img, d, t, seg, dur):
    header(d, t, "진행 순서", "발표는 3단계", "", CYAN)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        clock(d, 70, 150, 24, (t * 0.4) % 1, YEL)
        d.text((112, 132), "미국 오후 2시", font=F12, fill=WHITE); d.text((112, 150), "= 한국 새벽 3시", font=F12, fill=YEL)
    elif t < s2:
        podium(d, 50, 112, t); d.text((112, 132), "30분 뒤", font=F12, fill=WHITE); d.text((112, 150), "의장 기자회견", font=F12, fill=CYAN)
    else:
        doc(d, 44, 112, t, "회의록", hl=2, h=62); d.text((120, 132), "3주 뒤 공개", font=F12, fill=WHITE); d.text((120, 150), "누가 뭐라 했나", font=F12, fill=YEL)
    item(d, t, 0.15, 186, "① 금리 발표 · 성명서", "이틀 회의 끝, 한국 새벽 3시", YEL, "clock")
    item(d, t, s1 + 0.1, 230, "② 의장 기자회견", "발표 30분 뒤 · 말 한마디가 변수", CYAN, "mic")
    item(d, t, s2 + 0.1, 274, "③ 회의록 공개", "3주 뒤 · 9월 회의록은 10/7", ORG, "doc")
    return {}

def s_why(img, d, t, seg, dur):
    header(d, t, "왜 중요?", "금리 = 돈의 값", "전 세계 돈의 방향", YEL)
    u = ease(prog(t, 0.6, 1.8))
    seesaw(d, CX, 168, 0.32 * u, "금리", "주가", YEL, CYAN)
    if t > 1.8:
        vis, o = slam(t, 1.8, 0.18)
        if vis: d.text((CX, 196 + o), "빌리는 값↑ → 성장주 부담", font=F9, fill=WHITE, anchor="ma")
    if t > 3.4:
        box(d, 30, 214, 220, 300, GRAY, (10, 14, 28))
        coin(d, 58, 246, 14, "$"); d.text((58, 266), "달러 강세", font=F9, fill=GOLD, anchor="ma")
        d.rectangle([150, 226, 210, 290], fill=(20, 26, 50), outline=GRAY); d.text((180, 230), "한국", font=F9, fill=WHITE, anchor="ma")
        for k in range(3):
            ax = 168 - int(((t - 3.4) * 30 + k * 22) % 70)
            ant(d, ax, 250 + (k % 2) * 6, t, "ok", bob=True)
        d.text((CX, 288), "외국인 돈 이탈", font=F9, fill=CYAN, anchor="ma")
    return {}

def s_now(img, d, t, seg, dur):
    header(d, t, "지금 상황", "9월에 또 올렸다", "", ORG)
    s1 = seg[1]
    big_text(img, CX, 96, "3.75~4%", YEL, 2)
    d.text((CX, 150), "미국 기준금리 · 9월 +0.25%p (12:0)", font=F9, fill=GRAY, anchor="ma")
    if t > s1:
        doc(d, 32, 166, t, "9월 회의록", hl=3, w=80, h=72)
        vis, o = slam(t, s1 + 0.3, 0.18)
        if vis: speech(d, 30, 244 + o, "연말까지 한 번 더?", tail_left=True)
        d.text((120, 168), "10월 동결 예상", font=F9, fill=WHITE)
        poll(d, 122, 182, 94, ease(prog(t, s1 + 1.2, s1 + 2.4)))
        if t > s1 + 2.4: d.text((152, 246), "100명 중 94명", font=F9, fill=YEL, anchor="ma")
        if t > s1 + 2.8: d.text((152, 262), "(로이터 설문)", font=F9, fill=GRAY, anchor="ma")
    return {}

def s_read(img, d, t, seg, dur):
    header(d, t, "결과 보는 법", "매파 vs 비둘기파", "", CYAN)
    s1 = seg[1]
    bird(d, 30, 124, t, "hawk"); bird(d, 150, 124, t, "dove")
    d.text((58, 172), "매파", font=F12, fill=ORG, anchor="ma"); d.text((58, 188), "올리자", font=F9, fill=WHITE, anchor="ma")
    d.text((180, 172), "비둘기파", font=F12, fill=CYAN, anchor="ma"); d.text((180, 188), "내리자", font=F9, fill=WHITE, anchor="ma")
    if t > s1:
        item(d, t, s1 + 0.1, 212, "숫자보다 '말'", "동결은 이미 예상 · 주가에 반영", YEL)
        item(d, t, s1 + 1.4, 256, "동결 + 매파 발언?", "→ 12월 인상 신호로 읽혀요", ORG)
    return {}

def s_end(img, d, t, seg, dur):
    header(d, t, "오늘의 용어", "FOMC", "", YEL)
    bird(d, 30, 120, t, "hawk"); bird(d, 156, 120, t, "dove")
    d.text((CX, 140), "VS", font=F24, fill=YEL, anchor="ma")
    if t > 1.0: stamp_slam(img, CX, 206, "FOMC", YEL, t, 1.0, "24", -8)
    if t > 2.4: speech(d, 46, 252, "이번엔 매파? 비둘기파?", tail_left=True)
    d.text((32, 306), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return punch_fx(t, 1.0)

SCRIPT = [
    (s_hook, [("10/29 새벽 3시, 전 세계 증시가 숨죽인다\nFOMC", "목요일 새벽 세 시, 전 세계 증시가 숨죽이는 회의가 있어요. 바로 에프오엠씨!")]),
    (with_card(s_what, "01", "뜻", CARD), [("미국 기준금리를 정하는 회의\n투표권 12명 · 1년에 8번", "에프오엠씨는 미국 기준금리를 정하는 회의예요. 열두 명이 투표하고, 일 년에 여덟 번 열려요.")]),
    (with_card(s_how, "02", "진행 순서", CARD), [
        ("① 이틀 회의 끝, 오후 2시 금리 발표\n한국은 새벽 3시", "하나. 이틀 회의 끝에 오후 두 시 금리 발표. 한국은 새벽 세 시예요."),
        ("② 30분 뒤 의장 기자회견", "둘. 삼십 분 뒤엔 의장 기자회견."),
        ("③ 3주 뒤 회의록 공개\n누가 무슨 말 했는지 다 나와요", "셋. 삼 주 뒤엔 회의록 공개. 누가 무슨 말을 했는지 다 나와요.")]),
    (with_card(s_why, "03", "왜 중요?", CARD), [("금리↑ = 돈 빌리는 값↑ → 성장주 부담\n달러 강세 → 외국인 돈 이탈", "금리가 오르면 돈 빌리는 값이 비싸져서, 반도체 같은 성장주엔 부담이에요. 달러가 강해지면 외국인 돈도 빠지기 쉽고요.")]),
    (with_card(s_now, "04", "지금 상황", CARD), [
        ("지금 미국 금리 3.75~4%\n9월에 0.25%p 또 인상", "지금 미국 금리는 삼 점 칠오에서 사 퍼센트. 구월에 또 올렸어요."),
        ("9월 회의록: 대부분 '연말까지 한 번 더'\n이번 10월은 동결 예상 우세", "구월 회의록엔 대부분이 연말까지 한 번 더 올려야 한다고 봤고, 이번 회의는 동결 예상이 우세해요.")]),
    (with_card(s_read, "05", "결과 보는 법", CARD), [
        ("올리자 = 매파 · 내리자 = 비둘기파", "올리자는 쪽은 매파, 내리자는 쪽은 비둘기파라고 해요."),
        ("동결이어도 기자회견이 매파면\n12월 인상 신호로 읽혀요", "동결이어도 기자회견이 매파적이면, 십이월 인상 신호로 읽혀요.")]),
    (s_end, [("오늘의 용어, FOMC!\n이번엔 매파? 비둘기파? 댓글로", "오늘의 용어, 에프오엠씨! 이번엔 매파일까요, 비둘기파일까요? 댓글로 예측해 주세요!")]),
]
NCH = 5   # 카드가 붙은 장면: 1~5


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    from narr_pause import synth_line                                            # 10/25 지시: 순번 뒤 짧은 쉼
    tts = make_tts()
    for n in todo:
        x, sr = synth_line(tts, n, VOICE_SID, SPEED, synth)
        np.save(mv.clip_path(n), x)

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.05 if k == 0 else (CH + 0.25 if 1 <= k <= NCH else 0.25)
        seg, lens = [], []
        for i, (sub, n) in enumerate(lines):
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL + 0.25, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts); sg = lambda k, i: starts[k] + scenes[k]["seg"][i]
    bpm = 96; beat = 60 / bpm; e = beat / 2; bar = beat * 4                  # 밝고 잔잔한 장조 하나 (C-G-Am-F)
    prog_ = [([60, 64, 67], 48), ([67, 71, 74], 55), ([69, 72, 76], 57), ([65, 69, 72], 53)]
    mel = [[76, None, 79, None, 77, None, 76, None], [74, None, 71, None, 74, None, 79, None], [76, None, 72, None, 74, None, 76, None], [77, None, 76, None, 72, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, beat * 0.9, mtof(root - 12), 0.10, "tri", decay=0.4)
            tone(bgm, T, e * 0.9, mtof(notes[st % 3] + 12), 0.018, "sq", 0.25, decay=0.12)
            if mm[st]: tone(bgm, T, e * 1.6, mtof(mm[st]), 0.024, "sq", 0.125, decay=0.35)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt == 0: tone(bgm, T, 0.12, 130, 0.12, "sin", f1=50, decay=0.06)
            if bt == 2: tone(bgm, T, 0.06, 0, 0.03, "noise", decay=0.03)
    ie = int(total * SR); fo = int(1.5 * SR); fi = int(0.3 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def ding(T): tone(sfx, T, 0.09, 1568, 0.07, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.06, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.06, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.04, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.14, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.045, "sq", 0.5, f1=1300, decay=0.04)
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def tick(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.25, 0.03, 2200 if j % 2 else 1800, 0.035, "sq", 0.5, decay=0.02)
    def chirp(T, hi=True):
        for j in range(2): tone(sfx, T + j * 0.1, 0.08, 1700 if hi else 900, 0.04, "sq", 0.5, f1=2300 if hi else 1200, decay=0.06)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.05, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.025, "sin", decay=0.2)
    thump(S[0] + 0.02); tick(S[0] + 0.3, 8)
    for k in range(1, NCH + 1): bell3(S[k]); thump(S[k] + 0.12); swoosh(S[k] + CH - 0.25)
    for j in range(12): blip(S[1] + CH + 0.6 + j * 0.12, 1200 + j * 40)
    for i in range(3): pop(sg(2, i) + 0.15)
    tick(sg(2, 0) + 0.2, 4)
    tone(sfx, S[3] + CH + 0.6, 0.8, 400, 0.04, "sq", 0.5, f1=900, decay=0.8); pop(S[3] + CH + 1.8)
    for j in range(10): blip(sg(4, 1) + 1.2 + j * 0.12, 1500 + j * 50, 0.025)
    chirp(S[5] + CH + 0.2, False); chirp(S[5] + CH + 0.5, True); pop(sg(5, 1) + 0.1); pop(sg(5, 1) + 1.4)
    swoosh(S[6]); stampfx(S[6] + 1.0); ding(S[6] + 2.4)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.55 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

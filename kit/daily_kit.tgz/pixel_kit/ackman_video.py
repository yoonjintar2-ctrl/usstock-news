"""1분 인물 사전 · 빌 애크먼 (option_video.py 복사 → 대본·장면·효과음 교체 · 레퍼런스 효과 픽셀판 재사용)"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, F36, GOLD

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "ackman/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
NAVY = (34, 44, 86); SILVER = (206, 210, 220); TIE = (60, 110, 220); GLASS = (70, 110, 160); MONEY = (90, 190, 110)

# ================================================================ sprites
def ackman_spr(scale=1, mega=False, happy=False, t=0.0):
    """원작 픽셀 인물(닮은꼴 아님): 은발 옆가르마 · 남색 정장 · 파란 넥타이, 손에 확성기(행동주의)"""
    im = Image.new("RGBA", (34, 50), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    x, y = 4, 2
    d.rectangle([x + 4, y + 3, x + 16, y + 15], fill=SKIN)                       # face
    d.rectangle([x + 3, y, x + 17, y + 4], fill=SILVER); d.rectangle([x + 3, y + 4, x + 5, y + 8], fill=SILVER)
    d.rectangle([x + 15, y + 4, x + 17, y + 7], fill=SILVER); d.line([(x + 8, y + 1), (x + 15, y + 1)], fill=WHITE)
    d.point((x + 8, y + 8), fill=DARK); d.point((x + 12, y + 8), fill=DARK)
    if happy: d.line([(x + 8, y + 11), (x + 12, y + 11)], fill=DARK); d.point((x + 7, y + 10), fill=DARK); d.point((x + 13, y + 10), fill=DARK)
    else: d.line([(x + 8, y + 12), (x + 12, y + 12)], fill=dk(SKIN, 0.6))
    d.rectangle([x + 8, y + 15, x + 12, y + 17], fill=dk(SKIN, 0.85))           # neck
    d.rectangle([x, y + 17, x + 20, y + 38], fill=NAVY)                          # suit
    d.polygon([(x + 7, y + 17), (x + 13, y + 17), (x + 10, y + 26)], fill=WHITE) # shirt
    d.line([(x + 10, y + 18), (x + 10, y + 27)], fill=TIE, width=2)
    d.rectangle([x + 3, y + 38, x + 8, y + 46], fill=(40, 42, 54)); d.rectangle([x + 12, y + 38, x + 17, y + 46], fill=(40, 42, 54))
    d.rectangle([x + 2, y + 45, x + 8, y + 47], fill=DARK); d.rectangle([x + 12, y + 45, x + 18, y + 47], fill=DARK)
    if mega:
        a = int(math.sin(t * 10) * 1)
        d.rectangle([x + 20, y + 18 + a, x + 24, y + 22 + a], fill=NAVY)        # raised arm
        d.polygon([(x + 23, y + 16 + a), (x + 29, y + 11 + a), (x + 29, y + 27 + a), (x + 23, y + 22 + a)], fill=WHT2, outline=GRAY)
    if scale > 1: im = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
    return im

def megaphone_waves(d, x, y, t, col=YEL):
    for k in range(3):
        r = 4 + ((t * 18 + k * 5) % 15)
        d.arc([x - r, y - r, x + r, y + r], -40, 40, fill=col)

def tower(d, x, y, w=40, h=96, col=GLASS, sign=None, lit=0.0):
    d.rectangle([x, y, x + w, y + h], fill=dk(col, 0.6), outline=col)
    for r in range(4, h - 6, 8):
        for c in range(4, w - 4, 8):
            on = ((r * 7 + c * 3) % 11) / 11 < lit
            d.rectangle([x + c, y + r, x + c + 4, y + r + 4], fill=YEL if on else col)
    if sign:
        d.rectangle([x - 4, y - 12, x + w + 4, y - 2], fill=DARK, outline=col)
        d.text((x + w // 2, y - 12), sign, font=F9, fill=WHITE, anchor="ma")

def paper(d, x, y, label, col=WHT2):
    d.rectangle([x, y, x + 34, y + 42], fill=col, outline=GRAY); d.polygon([(x + 26, y), (x + 34, y + 8), (x + 26, y + 8)], fill=GRAY)
    for k in range(4): d.line([(x + 5, y + 14 + k * 6), (x + 28, y + 14 + k * 6)], fill=DIM)
    d.text((x + 17, y + 2), label, font=F9, fill=DARK, anchor="ma")

def mall(d, x, y, t, rise=1.0):
    h = int(40 * rise); y0 = y + 40 - h
    d.rectangle([x, y0, x + 64, y + 40], fill=(120, 80, 140), outline=PURP)
    d.polygon([(x - 4, y0), (x + 68, y0), (x + 60, y0 - 8), (x + 4, y0 - 8)], fill=PURP)
    if h > 18: d.text((x + 32, y0 + 3), "MALL", font=F9, fill=WHITE, anchor="ma")
    for c in range(3):
        if h > 30: d.rectangle([x + 8 + c * 18, y + 24, x + 20 + c * 18, y + 38], fill=YEL if blink(t + c * .3, 2) else GLASS)

def virus(d, x, y, r, t, col=GRN):
    d.ellipse([x - r, y - r, x + r, y + r], fill=dk(col, 0.7), outline=col)
    for k in range(8):
        a = k / 8 * math.tau + t
        d.line([(x + math.cos(a) * r, y + math.sin(a) * r), (x + math.cos(a) * (r + 4), y + math.sin(a) * (r + 4))], fill=col)
        d.ellipse([x + math.cos(a) * (r + 4) - 1, y + math.sin(a) * (r + 4) - 1, x + math.cos(a) * (r + 4) + 1, y + math.sin(a) * (r + 4) + 1], fill=col)

def umbrella(d, x, y, col=CYAN):
    d.pieslice([x - 20, y - 16, x + 20, y + 16], 180, 360, fill=col)
    d.line([(x, y), (x, y + 20)], fill=WHT2, width=2); d.arc([x - 6, y + 16, x, y + 24], 0, 180, fill=WHT2)

def pyramid(d, x, y, col=ORG):
    for k in range(4):
        w = 64 - k * 16; yy = y + 36 - k * 10
        d.rectangle([x + (64 - w) // 2, yy, x + (64 - w) // 2 + w, yy + 9], fill=dk(col, 0.6 + k * 0.1), outline=col)

def shake_bottle(d, x, y):
    d.rectangle([x + 2, y, x + 16, y + 4], fill=GRN)
    d.rectangle([x, y + 4, x + 18, y + 34], fill=WHT2, outline=GRAY)
    d.rectangle([x, y + 14, x + 18, y + 24], fill=GRN)

def tv(d, x, y, t):
    d.rectangle([x, y, x + 96, y + 60], fill=DARK, outline=WHT2)
    d.rectangle([x + 4, y + 4, x + 92, y + 52], fill=(18, 24, 48))
    d.rectangle([x + 4, y + 44, x + 92, y + 52], fill=SRED); d.text((x + 48, y + 44), "LIVE · 생방송", font=F9, fill=WHITE, anchor="ma")
    put_img = ackman_spr(1)
    return put_img

def pill_bottle(d, x, y):
    d.rectangle([x, y, x + 24, y + 6], fill=WHT2); d.rectangle([x + 2, y + 6, x + 22, y + 38], fill=ORG, outline=dk(ORG, 0.6))
    d.rectangle([x + 4, y + 14, x + 20, y + 28], fill=WHITE); d.text((x + 12, y + 16), "Rx", font=F9, fill=DARK, anchor="ma")

def burrito(d, x, y):
    d.ellipse([x, y, x + 40, y + 18], fill=(210, 190, 150), outline=(150, 120, 80))
    d.line([(x + 10, y + 2), (x + 6, y + 16)], fill=(150, 120, 80)); d.line([(x + 30, y + 2), (x + 34, y + 16)], fill=(150, 120, 80))
    d.ellipse([x + 32, y + 4, x + 40, y + 14], fill=(110, 170, 70))

def up_arrow(d, x, y, col=SRED, h=20):
    d.rectangle([x + 3, y + 6, x + 7, y + h], fill=col); d.polygon([(x - 1, y + 7), (x + 11, y + 7), (x + 5, y)], fill=col)

def money_bag(d, x, y, label="$"):
    d.ellipse([x, y + 6, x + 26, y + 30], fill=MONEY, outline=dk(MONEY, 0.6)); d.rectangle([x + 9, y + 1, x + 17, y + 7], fill=MONEY)
    d.text((x + 13, y + 11), label, font=F12, fill=DARK, anchor="ma")

def fmt_usd(v):
    return f"{v / 1e8:.1f}억$".replace(".0억", "억") if v >= 1e8 else f"{v / 1e4:,.0f}만$"

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "1분 인물 사전", "빌 애크먼", "월가의 행동주의 투자자", ORG)
    u = ease(prog(t, 0.5, 3.0)); v = 2.7e7 * (2.6e9 / 2.7e7) ** u
    if t > 0.4:
        d.text((40, 128), "2020.03 · 코로나 폭락", font=F9, fill=GRAY)
        ctext(d, 142, "$" + (f"{v / 1e9:.2f}B" if v >= 1e9 else f"{v / 1e6:,.0f}M"), F36, GOLD if u >= 1 else WHITE, full="$2.60B")
        bars(d, 38, 232, 120, 34, 12, t, prog(t, 0.5, 1.6), 9 if u >= 1 else -1, WHT2, GOLD)
    if t > 1.0:
        vis, o = slam(t, 1.0, 0.2)
        put(img, ackman_spr(2, mega=False, happy=u >= 1, t=t), 160, 186 + o)
    target_lock(d, 183, 204, t, seg[1] - 0.1, "BILL ACKMAN", ORG, "퍼싱스퀘어 대표")
    if t > 3.1:
        stamp_slam(img, 96, 270, "×96", GOLD, t, 3.1, "24", -8)
        debris(d, 96, 270, t, 3.1, 14, (GOLD, YEL, WHITE), 50, 0.8, 3)
    fx = {}
    if 3.1 < t < 3.22: fx["flash"] = 0.35
    return fx

def s_who(img, d, t, seg, dur):
    header(d, t, "WHO", "누구?", "1966년생 · 헤지펀드 매니저", CYAN)
    cards = [(0.75, "1966", "미국 뉴욕주", CYAN), (seg[1] + 0.1, "1992", "고담 파트너스", YEL), (seg[1] + 1.2, "2004", "퍼싱스퀘어", ORG)]
    for i, (ts, yr, lab, col) in enumerate(cards):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); x = 34 + i * 62
        d.rectangle([x, 128 + o, x + 56, 176 + o], fill=(10, 14, 30), outline=col)
        d.text((x + 28, 132 + o), yr, font=F12, fill=col, anchor="ma")
        d.text((x + 28, 150 + o), lab, font=F9, fill=WHITE, anchor="ma")
        if i == 0: d.text((x + 28, 162 + o), "하버드 MBA", font=F9, fill=GRAY, anchor="ma")
        if i == 2: d.text((x + 28, 162 + o), "5,400만$로", font=F9, fill=GOLD, anchor="ma")
        if i < 2 and t > cards[i + 1][0]: d.polygon([(x + 57, 148), (x + 61, 152), (x + 57, 156)], fill=GRAY)
    if t > seg[2]:
        tower(d, 150, 196, 44, 100, GLASS, "회사", prog(t, seg[2], seg[2] + 2))
        vis, o = slam(t, seg[2] + 0.1, 0.2)
        put(img, ackman_spr(2, mega=True, t=t), 44, 212 + o)
        megaphone_waves(d, 112, 238, t)
        if t > seg[2] + 0.8:
            d.rectangle([108, 196, 146, 212], fill=WHITE); d.polygon([(120, 212), (126, 212), (122, 218)], fill=WHITE)
            d.text((127, 199), "바꿔!", font=F9, fill=SRED, anchor="ma")
        if t > seg[2] + 1.6:
            vis, o = slam(t, seg[2] + 1.6, 0.2)
            d.rectangle([34, 288 + o, 216, 308 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((CX, 292 + o), "행동주의 = 지분 사고 경영에 목소리", font=F9, fill=GOLD, anchor="ma")
    chapter_flash(img, d, t, "01", "누구", CYAN)
    return {}

def s_wins(img, d, t, seg, dur):
    header(d, t, "BIG WINS", "대박", "크게 걸어 크게 번 순간들", GRN)
    s1, s2 = seg[1], seg[2]
    rows = [(0.75, "MBIA 공매도", "2002→2009", "+10억$↑", WHT2), (s1 + 0.1, "쇼핑몰 GGP", "6천만$", "16억$", PURP), (s2 + 0.1, "코로나 헤지", "2,700만$", "26억$", CYAN)]
    for i, (ts, name, a, b, col) in enumerate(rows):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 126 + i * 62
        d.rectangle([34, y + o, 216, y + 56 + o], fill=(10, 14, 30), outline=col)
        if i == 0:
            paper(d, 40, y + 7 + o, "채권보증", WHT2)
            k = prog(t, ts + 0.4, ts + 1.4); d.rectangle([60, y + 30 + o, 70, y + 30 + int(14 * k) + o], fill=SRED)
        elif i == 1: mall(d, 38, y + 10 + o, t, ease(prog(t, ts + 0.3, ts + 1.4)))
        else:
            virus(d, 52, y + 22 + o, 7, t); umbrella(d, 82, y + 18 + o)
        d.text((110, y + 6 + o), name, font=F12, fill=WHITE)
        d.text((110, y + 24 + o), a, font=F9, fill=GRAY)
        q = prog(t, ts + 0.5, ts + 1.2)
        if q > 0:
            d.text((208, y + 36 + o), "→ " + b, font=F12, fill=GOLD, anchor="ra")
            if q >= 1: coin(d, 200, y + 14 + o, 6, "$")
    if t > s2 + 1.4:
        stamp_slam(img, 170, 296, "대박", GOLD, t, s2 + 1.4, "24", -8)
        confetti(d, t, s2 + 1.5, 14, (GOLD, GRN, WHITE), 120, 300)
    fx = {}
    if s2 + 1.4 < t < s2 + 1.52: fx["flash"] = 0.3
    chapter_flash(img, d, t, "02", "대박", GRN)
    return fx

def s_losses(img, d, t, seg, dur):
    header(d, t, "BIG LOSSES", "쪽박", "크게 걸어 크게 잃은 순간들", SRED)
    s1, s2 = seg[1], seg[2]
    if t < s2:
        if t > 0.75:
            vis, o = slam(t, 0.75, 0.2)
            pyramid(d, 36, 132 + o, ORG); shake_bottle(d, 110, 140 + o)
            d.rectangle([138, 132 + o, 216, 176 + o], fill=(30, 10, 14), outline=SRED)
            d.text((177, 136 + o), "허벌라이프", font=F9, fill=WHITE, anchor="ma")
            d.text((177, 150 + o), "공매도 10억$", font=F9, fill=SRED, anchor="ma")
            d.text((177, 162 + o), "'피라미드' 주장", font=F9, fill=ORG, anchor="ma")
        if t > s1:
            vis, o = slam(t, s1 + 0.1, 0.2)
            d.rectangle([40, 190 + o, 210, 262 + o], fill=DARK, outline=WHT2)
            d.rectangle([44, 194 + o, 206, 250 + o], fill=(18, 24, 48))
            put(img, ackman_spr(1, mega=True, t=t), 56, 198 + o)
            mini_person(d, 176, 222 + o, GRAY, t, 2); d.text((179, 240 + o), "아이칸", font=F9, fill=GRAY, anchor="ma")
            if blink(t, 4):
                d.polygon([(118, 206 + o), (128, 218 + o), (122, 220 + o), (132, 236 + o), (114, 222 + o), (120, 220 + o)], fill=YEL)
            d.rectangle([44, 250 + o, 206, 260 + o], fill=SRED); d.text((CX, 250 + o), "LIVE · 생방송 설전", font=F9, fill=WHITE, anchor="ma")
            if t > s1 + 1.6:
                vis2, o2 = slam(t, s1 + 1.6, 0.2)
                d.rectangle([60, 272 + o2, 190, 296 + o2], fill=(30, 10, 14), outline=SRED)
                d.text((CX, 278 + o2), "2018년 손실 보고 철수", font=F12, fill=SRED, anchor="ma")
    else:
        u = ease(prog(t, s2 + 0.1, s2 + 1.2))
        pill_bottle(d, 44, 134)
        d.text((80, 136), "밸리언트", font=F12, fill=WHITE); d.text((80, 154), "제약회사 · 2015~2017", font=F9, fill=GRAY)
        box(d, 34, 180, 216, 262, DIM)
        pts = [(44 + k * 8, int(196 + 50 * (k / 20) ** 1.6 * u + 4 * math.sin(k))) for k in range(int(20 * u) + 1)]
        if len(pts) > 1: d.line(pts, fill=SRED, width=2)
        glitch_text(img, CX, 270, "-40억 달러", F24, SRED, t, 6 if t < s2 + 1.6 else 1)
        crack(d, 120, 186, 200, 250, t, s2 + 1.0, WHITE)
    fx = {}
    if s2 + 0.1 < t < s2 + 0.5: fx["shake"] = (int(math.sin(t * 90) * 2), 0)
    chapter_flash(img, d, t, "03", "쪽박", SRED)
    return fx

def s_style(img, d, t, seg, dur):
    header(d, t, "STYLE", "스타일", "집중 투자 + 행동주의", PURP)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        # concentrated portfolio: ten coins gather into one target
        cx, cy = CX, 200
        for r in (40, 28, 16): d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(SRED if r == 16 else WHT2))
        n = 10; u = ease(prog(t, 0.8, 2.4))
        for k in range(n):
            a = k / n * math.tau; R = lerp(90, 22, u)
            coin(d, int(cx + math.cos(a) * R), int(cy + math.sin(a) * R * 0.8), 6, "")
        if u >= 1:
            vis, o = slam(t, 2.5, 0.2)
            d.rectangle([44, 262 + o, 206, 284 + o], fill=(20, 12, 34), outline=PURP)
            d.text((CX, 266 + o), "10개 안팎만 · 크게 · 오래", font=F12, fill=PURP, anchor="ma")
    elif t < s2:
        vis, o = slam(t, s1 + 0.1, 0.2)
        burrito(d, 44, 150 + o); d.text((64, 172 + o), "치폴레", font=F9, fill=WHITE, anchor="ma")
        put(img, ackman_spr(1, t=t), 106, 140 + o)
        if t > s1 + 0.8:
            mini_person(d, 150, 152, GRN, t); d.text((154, 172), "새 CEO", font=F9, fill=GRN, anchor="ma")
            d.line([(130, 160), (146, 160)], fill=YEL); d.polygon([(146, 156), (150, 160), (146, 164)], fill=YEL)
        k = ease(prog(t, s1 + 1.2, s2 - 0.3))
        box(d, 34, 196, 216, 256, DIM)
        pts = [(44 + j * 8, int(250 - 46 * (j / 20) ** 1.3 * k)) for j in range(int(20 * k) + 1)]
        if len(pts) > 1: d.line(pts, fill=GRN, width=2)
        up_arrow(d, 196, 202, GRN, 18)
        d.text((CX, 262), "2016 지분 → 2018 CEO 영입 도움", font=F9, fill=GRAY, anchor="ma")
    else:
        u = ease(prog(t, s2 + 0.2, s2 + 1.4))
        tower(d, 40, 150, 52, 110, (110, 140, 120), "하워드 휴즈", u)
        d.text((150, 150), "지분", font=F12, fill=WHITE, anchor="ma")
        ctext(d, 166, f"{int(47 * u)}%", F36, GOLD, cx=160, full="47%")
        d.rectangle([110, 214, 210, 224], fill=DARK, outline=GRAY); d.rectangle([110, 214, 110 + int(100 * 0.47 * u), 224], fill=GOLD)
        if t > s2 + 1.5:
            vis, o = slam(t, s2 + 1.5, 0.2)
            d.rectangle([100, 240 + o, 216, 270 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((158, 244 + o), "2025년의 꿈", font=F9, fill=GRAY, anchor="ma"); d.text((158, 255 + o), "'현대판 버크셔'", font=F12, fill=GOLD, anchor="ma")
    chapter_flash(img, d, t, "04", "스타일", PURP)
    return {}

def s_outro(img, d, t, seg, dur):
    marquee(d, 222, 2, 26, t, "대박 · 쪽박 · 행동주의", (dk(GOLD, 0.5), dk(SRED, 0.55)))
    header(d, t, "SUMMARY", "오늘의 인물", "빌 애크먼 · 퍼싱스퀘어", GOLD)
    rows = [("WIN", "대박", "MBIA · GGP · 코로나 헤지", GRN), ("LOSS", "쪽박", "허벌라이프 · 밸리언트", SRED), ("STYLE", "스타일", "집중 투자 · 행동주의", PURP)]
    for i, (a, b, c, col) in enumerate(rows):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 128 + i * 30
        d.rectangle([34, y + o, 216, y + 24 + o], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y + o, 74, y + 24 + o], fill=col)
        d.text((54, y + 7 + o), a, font=F9, fill=WHITE, anchor="ma")
        d.text((80, y + 5 + o), b, font=F12, fill=WHITE); d.text((212, y + 8 + o), c, font=F9, fill=col, anchor="ra")
    if t > seg[1]:
        put(img, ackman_spr(2, mega=True, happy=True, t=t), 150, 230)
        megaphone_waves(d, 218, 258, t, GOLD) if False else None
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([34, 276 + o, 150, 300 + o], fill=(30, 22, 6), outline=GOLD if blink(t, 2) else ORG)
            d.text((92, 282 + o), "오늘의 인물, 빌 애크먼!", font=F9, fill=GOLD, anchor="ma")
        confetti(d, t, seg[1] + 0.4, 14, (SRED, GOLD, CYAN, WHITE), 124, 240)
    d.text((CX, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM, anchor="ma")
    return {}

SCRIPT = [
    (s_hook, [("2,700만 달러로\n한 달도 안 돼 26억 달러?", "이천칠백만 달러로, 한 달도 안 돼 이십육억 달러를 번 사람이 있다?"),
              ("월가의 행동주의 투자자\n빌 애크먼 이야기예요", "월가의 행동주의 투자자, 빌 애크먼 이야기예요.")]),
    (s_who, [("1966년생 미국 헤지펀드 매니저\n하버드 경영대학원 출신이에요", "천구백육십육 년생 미국 헤지펀드 매니저로, 하버드 경영대학원을 나왔어요."),
             ("1992년 고담 파트너스,\n2004년엔 퍼싱스퀘어를 세웠죠", "천구백구십이 년 고담 파트너스를, 이천사 년엔 퍼싱스퀘어를 세웠죠."),
             ("지분을 크게 사서 경영진에게\n바꾸라고 요구하는 '행동주의 투자자'", "회사 지분을 크게 사서 경영진에게 바꾸라고 요구하는, 행동주의 투자자예요.")]),
    (s_wins, [("채권 보증회사 MBIA 공매도로\n금융위기 때 10억 달러 넘게 벌었고", "채권 보증회사 엠비아이에이 공매도로, 금융위기 때 십억 달러 넘게 벌었고,"),
              ("파산한 쇼핑몰 회사 GGP에 6천만 달러,\n16억 달러로 불렸어요", "파산한 쇼핑몰 회사 지지피에 육천만 달러를 넣어, 십육억 달러로 불렸어요."),
              ("2020년 코로나 폭락 땐 보험 같은 헤지로\n2,700만 → 26억 달러", "이천이십 년 코로나 폭락 때는 보험 같은 헤지로, 이천칠백만 달러를 이십육억 달러로 만들었죠.")]),
    (s_losses, [("허벌라이프를 '피라미드'라 주장하며\n10억 달러 공매도를 걸었지만", "반대로 허벌라이프를 피라미드라고 주장하며, 십억 달러 공매도를 걸었지만,"),
                ("칼 아이칸과 생방송 설전 끝에\n2018년 손실을 보고 물러났어요", "칼 아이칸과 생방송 설전까지 벌인 끝에, 이천십팔 년 손실을 보고 물러났어요."),
                ("제약회사 밸리언트에선\n약 40억 달러를 잃었고요", "제약회사 밸리언트에선, 약 사십억 달러를 잃었고요.")]),
    (s_style, [("종목은 10개 안팎만 골라\n크게 사서 오래 들고 가요", "종목은 열 개 안팎만 골라, 크게 사서 오래 들고 가는 스타일이에요."),
               ("치폴레에선 새 CEO 영입을 도왔고\n주가도 크게 올랐죠", "치폴레에선 새 최고경영자 영입을 도왔고, 주가도 크게 올랐죠."),
               ("2025년엔 하워드 휴즈 지분을 47%로 늘려\n'현대판 버크셔'를 꿈꿔요", "이천이십오 년엔 하워드 휴즈 지분을 사십칠 퍼센트로 늘리고, 현대판 버크셔를 꿈꾸고 있어요.")]),
    (s_outro, [("오늘의 인물, 빌 애크먼!", "오늘의 인물, 빌 애크먼!"),
               ("크게 걸고, 크게 이기고\n때로는 크게 지기도 한 투자자", "크게 걸고, 크게 이기고, 때로는 크게 지기도 한 투자자예요.")]),
]
TITLES = ["", "누구?", "대박", "쪽박", "스타일", "오늘의 인물"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)   # chapter flash needs ~0.55s before the first line
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # person-profile BGM: A minor → C major lift, 120 bpm, driving 8th bass (wins = brighter, losses = darker)
    bpm = 120; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([69, 72, 76], 45), ([65, 69, 72], 41), ([67, 71, 74], 43), ([64, 68, 71], 40)]   # Am F G E
    prog_major = [([72, 76, 79], 48), ([67, 71, 74], 43), ([69, 72, 76], 45), ([65, 69, 72], 41)]   # C G Am F
    mel_m = [[76, None, 74, 72, 71, None, 72, None], [72, 74, 76, None, 77, None, 76, 74], [74, None, 71, None, 79, None, 77, 76], [76, 74, 72, None, 71, None, None, None]]
    mel_M = [[79, None, 76, 79, 84, None, 83, 81], [79, None, 74, None, 79, 81, 83, None], [84, None, 81, 79, 76, None, 79, None], [77, 79, 81, None, 79, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = S[2] <= t0 < S[3] or t0 >= S[5]
        dark = S[3] <= t0 < S[4]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16 if not dark else 0.13, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and T > S[1] and not dark: tone(bgm, T, e * 0.8, mtof(m), 0.033, "sq", 0.125, decay=0.15)
            if m and dark and st % 4 == 0: tone(bgm, T, e * 1.6, mtof(m - 12), 0.03, "sq", 0.5, decay=0.4)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09 if not dark else 0.05, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.04, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def wahwah(T):
        for j, m in enumerate([67, 66, 65, 64]): tone(sfx, T + j * 0.25, 0.28 if j < 3 else 0.6, mtof(m), 0.07, "sq", 0.5, f1=mtof(m) * 0.98, decay=0.3)
    def zap(T):
        for j in range(4): tone(sfx, T + j * 0.06, 0.05, 2000 - j * 300, 0.04, "sq", 0.5, decay=0.03)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # hook: counter climbs, lock on, ×96 stamp
    typing(S[0] + 0.1, "1분인물사전빌애크먼"); rise(S[0] + 0.5, 2.5)
    for j in range(10): blip(S[0] + 0.5 + j * 0.25, 900 + j * 120, 0.025)
    pop(S[0] + 1.0); lock(sg(0, 1) - 0.1); stampfx(S[0] + 3.1); coin_s(S[0] + 3.15); fanfare(S[0] + 3.3)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # who
    pop(S[1] + 0.75); pop(sg(1, 1) + 0.1); pop(sg(1, 1) + 1.2); coin_s(sg(1, 1) + 1.3)
    pop(sg(1, 2) + 0.1); zap(sg(1, 2) + 0.8); zap(sg(1, 2) + 1.3); ding(sg(1, 2) + 1.6)
    # wins
    for i in range(3):
        ts = (0.75 if i == 0 else scenes[2]["seg"][i] + 0.1) + S[2]
        pop(ts); coin_s(ts + 0.6); ding(ts + 1.2)
    rise(sg(2, 1) + 0.3, 1.1); stampfx(sg(2, 2) + 1.4); fanfare(sg(2, 2) + 1.5)
    # losses
    pop(S[3] + 0.75); thump(S[3] + 0.9); pop(sg(3, 1) + 0.1)
    for j in range(6): zap(sg(3, 1) + 0.3 + j * 0.35)
    thump(sg(3, 1) + 1.6); wahwah(sg(3, 1) + 1.7)
    glitch(sg(3, 2) + 0.1, 8); fall(sg(3, 2) + 0.1, 1.2); thump(sg(3, 2) + 1.0); glitch(sg(3, 2) + 1.4, 4)
    # style
    for j in range(10): coin_s(S[4] + 0.8 + j * 0.15)
    ding(S[4] + 2.5); pop(sg(4, 1) + 0.1); pop(sg(4, 1) + 0.8); rise(sg(4, 1) + 1.2, 1.6)
    pop(sg(4, 2) + 0.2)
    for j in range(8): blip(sg(4, 2) + 0.2 + j * 0.15, 1000 + j * 140, 0.03)
    ding(sg(4, 2) + 1.5)
    # outro
    for i in range(3): thump(S[5] + 0.3 + i * 0.45)
    fanfare(sg(5, 1) + 0.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

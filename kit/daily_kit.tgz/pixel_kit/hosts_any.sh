#!/bin/bash
# usage: hosts_any.sh <out_dir>
D=$1; cd /home/claude/mascot3d
python3 -c "
import json; S=json.load(open('$D/spec.json'))
for h in S['hosts']: print(h['k'], h['t0'], h['t1']-h['t0'])" > $D/hosts.txt
while read k t0 dur; do
  LIGHT=v4_pixel MODE=host STEP=1 python3 talk_render2.py $D/mix_narr.wav $D/m/host_$k $t0 $dur 450 8 --resume > $D/host_$k.log 2>&1
  echo "host_$k done"
done < $D/hosts.txt
echo ALLDONE

"""음모론(?) 특별편 · '누가 반도체를 누르나?' (60초 이내) — 2026-11-10 제작
새 진행 방식 첫 적용(11/10 사용자 지시): 원형 인서트 폐지 → 마스코트 풀샷 컷(훅·전환·마무리) + 8비트 본론(하단 흰 자막)
사실 확인(2026-11-10 KST 기준, 종가는 Yahoo ^SOX):
 · 7/28 중국 창신메모리(CXMT) 상장 첫날 +465% · 코스피 -7.67%(6,237.65, 서킷브레이커) · 삼성전자 -8.66% · SK하이닉스 -10.85%
   (직전 SOX 7/20 11,744 → 7/22 12,411, +5.7%)
 · (10월 유가·금리 사례는 60초 맞추느라 뺌 — s_oct 함수만 남김)
 · 11/5(현지) 중간선거 이틀 뒤… 정확히는 선거(11/3) 후 11/4 랠리 → 11/5 SOX -12.2%(9,011.14) · 2020년 3월 이후 최대 낙폭(SBS Biz·로이터)
   원인 보도: 의회 구도 변화로 AI 인프라·데이터센터 확장 지연/규제 우려 (정당 언급은 하지 않음 — 정치 중립)
 · 11/5 마이클 버리, SMH 풋 25% 이익 실현(본인 공개)
 · 11/9(현지) SOX 9,390 → 10,034(+6.9%) · 같은 날 젠슨 황 사생활 보도 → 엔비디아 장중 -8.78%($170.24), 이사회 독립 조사 착수
   (상대 인물 실명·의혹 세부는 다루지 않음)
 · 환율 1,355원/달러: $101.9 ≈ 13.8만원
 · 결론을 내리지 않는 열린 결말, 특정 주체 지목 없음, 투자 권유 아님. 상승/하락 빨강·초록 구분 없음.
python3 press_video.py [times|stills T,T|audio|full|spec]"""
import os, sys, math, json, hashlib, wave
import numpy as np
from PIL import Image, ImageDraw

from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, CYAN, ORG, GRAY, DIM, BG, prog, ease, lerp, tone, mtof, SR, bg_img, typed, blink)
from sandisk_video import box, slam, CX, SX0, SX1, WHT2, chip
from nike_video import stamp_slam, debris, dk, DARK, render_low, shutter_mask, dissolve_mask, clamp, TR, warn_icon, put
from option_video import big_text
from semicrash_video import news_card

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "press/out"); os.makedirs(OUT, exist_ok=True)
NDIR = os.path.join(BASE, "press/narr"); os.makedirs(NDIR, exist_ok=True)
def clip_path(n): return os.path.join(NDIR, hashlib.md5(f"q|{n}".encode()).hexdigest() + ".npy")
GAP, TAIL = 0.32, 0.5
NEU = (200, 206, 220)          # 선 색(상승·하락 색 구분 없음)
BROWN = (150, 100, 60); HORN = (240, 232, 210)
SUIT = (34, 36, 52); CUFF = (230, 232, 240); SKINH = (232, 188, 146)
GOLD = (240, 190, 60)

# ================================================================ sprites
def bear(d, x, y, t):
    b = int(abs(math.sin(t * 4)) * 2); y -= b
    for ex in (x + 4, x + 30): d.ellipse([ex, y, ex + 10, y + 10], fill=BROWN, outline=dk(BROWN, 0.6))
    d.ellipse([x + 2, y + 4, x + 42, y + 34], fill=BROWN, outline=dk(BROWN, 0.6))
    d.ellipse([x + 14, y + 18, x + 30, y + 30], fill=(210, 170, 120))
    d.rectangle([x + 20, y + 19, x + 24, y + 22], fill=DARK)
    for ex in (x + 12, x + 28):
        d.rectangle([ex, y + 12, ex + 3, y + 15], fill=DARK)
        d.line([(ex - 2, y + 9 + (0 if ex < x + 20 else 3)), (ex + 5, y + 12 - (0 if ex < x + 20 else 3))], fill=DARK)

def money_bag(d, x, y, lbl="$", col=GOLD):
    d.polygon([(x + 6, y), (x + 14, y), (x + 12, y + 5), (x + 8, y + 5)], fill=dk(col, 0.8))
    d.ellipse([x, y + 4, x + 20, y + 24], fill=col, outline=dk(col, 0.6))
    d.text((x + 10, y + 9), lbl, font=F9, fill=DARK, anchor="ma")

def datacenter(d, x, y, t, col=CYAN, w=52):
    d.rectangle([x, y, x + w, y + 34], fill=(18, 22, 40), outline=col)
    d.rectangle([x + 3, y - 6, x + w - 3, y], fill=dk(col, 0.6))
    for r in range(2):
        for c in range(3):
            on = ((r * 3 + c + int(t * 5)) % 4) != 0
            d.rectangle([x + 5 + c * 16, y + 6 + r * 13, x + 16 + c * 16, y + 13 + r * 13], fill=(34, 40, 62))
            d.rectangle([x + 12 + c * 16, y + 9 + r * 13, x + 14 + c * 16, y + 10 + r * 13], fill=YEL if on else DIM)

def hand(img, cx, ybot, top):
    """위에서 내려오는 정체불명의 손(정장 소매 + '?' 단추). ybot = 손가락 끝, top 위로는 잘림(상자 안에서만 보임)"""
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); d.fontmode = "1"
    yb = int(ybot); fl = 9; hp = 22; yp = yb - fl - hp
    d.rectangle([cx - 26, yp - 120, cx + 26, yp - 6], fill=SUIT + (255,), outline=dk(SUIT, 0.6) + (255,))
    d.text((cx, yp - 24), "?", font=F12, fill=YEL + (255,), anchor="ma")
    d.rectangle([cx - 28, yp - 10, cx + 28, yp - 4], fill=CUFF + (255,))
    d.rounded_rectangle([cx - 24, yp - 4, cx + 24, yb - fl], radius=4, fill=SKINH + (255,), outline=dk(SKINH, 0.65) + (255,))
    for k in range(4):
        fx = cx - 22 + k * 12
        d.rounded_rectangle([fx, yb - fl - 3, fx + 9, yb], radius=3, fill=SKINH + (255,), outline=dk(SKINH, 0.65) + (255,))
    d.rounded_rectangle([cx + 20, yp + 2, cx + 30, yp + 18], radius=3, fill=SKINH + (255,), outline=dk(SKINH, 0.65) + (255,))
    d.rectangle([0, 0, W, top - 1], fill=(0, 0, 0, 0))
    img.paste(lay, (0, 0), lay)

def wig(x, seed):
    return math.sin(x * 0.31 + seed) * 3 + math.sin(x * 0.11 + seed * 2) * 4

def label_tag(d, x, y, s, col=CYAN, font=F9, anchor_r=False):
    w = int(d.textlength(s, font=font)) + 8
    x0 = x - w if anchor_r else x
    d.rectangle([x0, y, x0 + w, y + 14], fill=(10, 14, 30), outline=col)
    d.text((x0 + 4, y + 2), s, font=font, fill=col)

def head(d, t, small, big, col=YEL):
    d.text((CX, 52), small, font=F9, fill=GRAY, anchor="ma")
    s = typed(big, t, 0.1, 20)
    d.text((CX - d.textlength(big, font=F24) / 2, 64), s, font=F24, fill=col)

def punch_fx(t, t0, amp=4):
    u = t - t0
    return {"shake": (int(math.sin(u * 60) * amp * max(0, 1 - u / 0.3)), 0)} if 0 <= u < 0.3 else {}

# ================================================================ host stage (풀샷 컷 배경, 마스코트·말풍선은 compose에서)
STARS = [((i * 73) % 250 + 10, (i * 151) % 190 + 8, i % 3) for i in range(26)]
def stage(img, d, t, title, small, col=YEL):
    for (x, y, k) in STARS:
        if ((t * 1.3 + k * 0.4 + x * 0.01) % 1) < 0.75: d.point((x, y), fill=(120, 130, 170) if k else (200, 205, 230))
    # 계단식 스포트라이트(방사선 없음 — 위가 좁고 아래가 넓은 계단)
    for s in range(14):
        y0 = 150 + s * 22; hw = 22 + s * 9
        d.rectangle([W // 2 - hw, y0, W // 2 + hw, y0 + 22], fill=(26, 32, 62))
    d.rectangle([0, 452, W, H], fill=(18, 14, 18)); d.line([(0, 452), (W, 452)], fill=(220, 150, 50), width=1)
    tw = d.textlength(title, font=F24)
    d.text((W // 2 - tw / 2 + 1, 28 + 1), title, font=F24, fill=(0, 0, 0)); d.text((W // 2 - tw / 2, 28), title, font=F24, fill=col)
    if small: d.text((W // 2, 58), small, font=F12, fill=WHITE, anchor="ma")

def s_host_hook(img, d, t, seg, dur): stage(img, d, t, "누가 누르나?", "하이닉스 -10.9% · 엔비디아 -8.8%")
def s_host_mid(img, d, t, seg, dur): stage(img, d, t, "근데 말이죠", "누가 이득일까?")
def s_host_end(img, d, t, seg, dur):
    stage(img, d, t, "여러분 생각은?", "우연 vs 누군가")
    d.text((W // 2, 466), "※ 투자 권유 아님 · 11/10 기준", font=F9, fill=GRAY, anchor="ma")

# ================================================================ case scenes: 오르면 → 손이 쾅 → 하락
BX0, BY0, BX1, BY1 = 32, 126, 218, 250
def case(img, d, t, seg, dur, n, title, rise, news, stamp, sub=None, nv_line=False):
    head(d, t, f"반도체 오르면 쾅? {n}/3", title)
    L = seg[1] - seg[0] if len(seg) > 1 else dur - seg[0] - TAIL - 0.15
    T0 = seg[0]; Th = T0 + 0.40 * L; Thit = Th + 0.45
    box(d, BX0, BY0, BX1, BY1, DIM)
    base = 228; px = 150; peak = 164
    ur = ease(prog(t, 0.25, Th))
    # 상승 구간
    pts = []
    for x in range(BX0 + 6, int(BX0 + 6 + (px - BX0 - 6) * ur) + 1, 2):
        f = (x - BX0 - 6) / (px - BX0 - 6)
        pts.append((x, base - (base - peak) * (f ** 1.4) + wig(x, n) * (1 - f * 0.6)))
    press = ease(prog(t, Thit, Thit + 0.35))
    push = int(press * 30)
    if nv_line and t > Thit:                     # 지수는 계속 오르고(점선), 엔비디아만 눌림
        for x in range(px, int(px + 62 * prog(t, Thit, Thit + 1.0)), 4):
            d.line([(x, peak - (x - px) * 0.35), (x + 2, peak - (x + 2 - px) * 0.35)], fill=CYAN)
        if t > Thit + 0.6: d.text((212, peak - 34), "SOX", font=F9, fill=CYAN, anchor="ra")
    if t > Thit:
        ud = ease(prog(t, Thit + 0.2, Thit + 1.3))
        for x in range(px + 2, int(px + 2 + (BX1 - 8 - px) * ud) + 1, 2):
            f = (x - px) / (BX1 - 8 - px)
            pts.append((x, peak + push * min(1, f * 4) + (base + 10 - peak - push) * ease(f) + wig(x, n + 3) * 0.4))
    elif pts:
        pts[-1] = (pts[-1][0], pts[-1][1] + push)
    if len(pts) > 1: d.line(pts, fill=NEU, width=2)
    if pts: d.rectangle([pts[-1][0] - 2, pts[-1][1] - 2, pts[-1][0] + 2, pts[-1][1] + 2], fill=WHITE)
    d.text((BX0 + 6, BY0 + 4), "엔비디아" if nv_line else "반도체", font=F9, fill=GRAY)
    # 상승 라벨
    if t > 0.25 + (Th - 0.25) * 0.75:
        vis, o = slam(t, 0.25 + (Th - 0.25) * 0.75, 0.18)
        label_tag(d, BX0 + 6, BY0 + 16 + o, rise, CYAN)
    # 정체불명의 손: 상자 안 위에서 내려와 꼭짓점을 누름
    if t > Th:
        yb = lerp(BY0 + 2, peak - 3, ease(prog(t, Th, Thit))) + push
        if t > Thit + 1.5: yb -= ease(prog(t, Thit + 1.5, Thit + 1.9)) * (yb - BY0)   # 다시 올라가 사라짐
        if yb > BY0 + 3: hand(img, px, yb, BY0 + 1)
    # 뉴스 카드
    if t > Thit - 0.1:
        vis, o = slam(t, Thit - 0.1, 0.18)
        o = -o // 2; x0 = 30; d.rectangle([x0, 96 + o, x0 + 190, 122 + o], fill=(14, 16, 32), outline=YEL)
        d.rectangle([x0, 96 + o, x0 + 5, 122 + o], fill=YEL)
        a, b = (news + "\n").split("\n")[:2]
        d.text((x0 + 11, 98 + o), a, font=F9, fill=WHITE); d.text((x0 + 11, 110 + o), b, font=F9, fill=GRAY)
    # 결과 도장
    Ts = Thit + 0.9
    if t > Ts:
        stamp_slam(img, CX, 291, stamp, YEL, t, Ts, "24" if d.textlength(stamp, font=F24) < 176 else "12", -6)
        if sub and t > Ts + 0.3: d.text((CX, 252), sub, font=F9, fill=WHT2, anchor="ma")
    if Thit <= t < Thit + 0.6: debris(d, px, peak + 6, t, Thit, 10, (WHITE, YEL, NEU), 45, 0.6, n, 2)
    fx = punch_fx(t, Thit, 4)
    if Ts <= t < Ts + 0.08: fx["flash"] = 0.18
    return fx

def s_jul(img, d, t, seg, dur): return case(img, d, t, seg, dur, 1, "7월 · 창신메모리", "SOX 3일 +5.7%", "7/28 中 창신메모리 상장\n상장 첫날 +465%", "코스피 -7.7%", "하이닉스 -10.9% · 서킷브레이커")
def s_oct(img, d, t, seg, dur): return case(img, d, t, seg, dur, 2, "10월 · 유가·금리", "SOX 3주 +18.7%", "유가 $101.9(약 13.8만원)\n美 10년물 금리 5.1%", "8일 연속 하락", "10/16 하루 SOX -3.8%")
def s_nov(img, d, t, seg, dur): return case(img, d, t, seg, dur, 2, "11월 · 중간선거", "선거 직후 랠리", "선거 후 AI 인프라\n데이터센터 둔화 우려", "SOX -12.2%", "11/5 · 2020년 3월 이후 최대 낙폭")
def s_jhh(img, d, t, seg, dur): return case(img, d, t, seg, dur, 3, "11/9 · 젠슨 황", "반도체 랠리 중", "젠슨 황 사생활 보도\n이사회 독립 조사 착수", "장중 -8.8%", "같은 날 SOX는 +6.9%", nv_line=True)

# ================================================================ 누가 이득?
CARDS = [("하락 베팅", "버리 11/5 익절"), ("큰손", "더 싸게 줍줍?"), ("경쟁자", "따라잡을 시간?"), ("정치", "데이터센터 셈법")]
def s_who(img, d, t, seg, dur):
    head(d, t, "음모론? 일단 질문만", "누가 웃을까?")
    L1 = (dur - TAIL - 0.15) - seg[1]
    apps = [seg[0] + 0.1, seg[1] + 0.05, seg[1] + 0.05 + L1 * 0.30, seg[1] + 0.05 + L1 * 0.58]
    for k, ((ttl, sub), ta) in enumerate(zip(CARDS, apps)):
        if t < ta: continue
        vis, o = slam(t, ta, 0.2)
        x0 = 30 + (k % 2) * 96; y0 = 102 + (k // 2) * 96 + (o if k < 2 else -o)     # 아랫줄은 아래에서 올라옴(윗줄 글자 안 가림)
        on = (k == 0 and t < seg[1]) or (k > 0 and k == max(i for i, a in enumerate(apps) if t >= a))
        box(d, x0, y0, x0 + 90, y0 + 90, YEL if on else DIM)
        d.text((x0 + 45, y0 + 4), f"{k + 1}. {ttl}", font=F12, fill=YEL if on else WHITE, anchor="ma")
        cx, cy = x0 + 45, y0 + 50
        if k == 0: bear(d, cx - 22, cy - 26, t)
        elif k == 1:
            money_bag(d, cx - 22, cy - 22); money_bag(d, cx + 2, cy - 18, "₩")
        elif k == 2: chip(d, cx - 16, cy - 22, 32, CYAN, t, 3)
        else: datacenter(d, cx - 26, cy - 14, t)
        d.text((x0 + 45, y0 + 76), sub, font=F9, fill=WHT2, anchor="ma")
        if blink(t + k * 0.3, 1.6): d.text((x0 + 82, y0 + 18), "?", font=F12, fill=YEL, anchor="ma")
    return {}

# ================================================================ 반론: 높이 쌓일수록 흔들린다
def s_counter(img, d, t, seg, dur):
    head(d, t, "물론 반론도 있어요", "그냥 우연?", CYAN)
    L = dur - TAIL - 0.15 - seg[0]
    Tp = seg[0] + 0.45 * L
    sway = 0.0
    if t > Tp + 0.35: sway = math.sin((t - Tp) * 9) * 7 * math.exp(-(t - Tp - 0.35) * 1.4)
    n = 11; bh = 11; base = 286
    for i in range(n):
        if t < 0.3 + i * 0.07: break
        f = (i + 1) / n
        ox = int(sway * f * f)
        w = 52 if i % 2 == 0 else 46
        y0 = base - (i + 1) * bh
        col = dk(GOLD, 0.55 + 0.4 * f)
        d.rectangle([CX - w // 2 + ox, y0, CX + w // 2 + ox, y0 + bh - 1], fill=col, outline=dk(col, 0.6))
    d.line([(CX - 60, base), (CX + 60, base)], fill=GRAY)
    if t > 1.2:
        vis, o = slam(t, 1.2, 0.2)
        d.text((CX + 52, 150 + o), "많이", font=F12, fill=CYAN); d.text((CX + 52, 164 + o), "오름", font=F12, fill=CYAN)
        d.line([(CX + 44, 186), (CX + 44, 158)], fill=CYAN, width=2); d.polygon([(CX + 40, 160), (CX + 48, 160), (CX + 44, 153)], fill=CYAN)
    # 작은 돌멩이(작은 악재)가 날아와 톡
    if Tp - 0.5 < t < Tp + 0.35:
        u = prog(t, Tp - 0.5, Tp + 0.35); x = lerp(34, CX - 26, u); y = lerp(150, 196, u) - math.sin(u * math.pi) * 22
        d.ellipse([x - 4, y - 3, x + 4, y + 3], fill=GRAY, outline=WHITE)
    if t > Tp + 0.35:
        d.text((CX - 84, 176), "작은 악재", font=F9, fill=WHT2)
        if t < Tp + 0.6: debris(d, CX - 26, 196, t, Tp + 0.35, 8, (WHITE, GRAY), 30, 0.5, 2, 2)
    return punch_fx(t, Tp + 0.35, 2)

# ================================================================ script
HOST = {"s_host_hook", "s_host_mid", "s_host_end"}
SCRIPT = [
    (s_host_hook, [("하이닉스 하루 {-10.9%}\n엔비디아 장중 {-8.8%}", "하이닉스 하루 십 퍼센트 넘게, 엔비디아 장중 구 퍼센트 가까이.", "h1"),
                   ("둘 다 반도체가\n{막 반등하던 순간}", "둘 다, 반도체가 막 반등하던 순간이었어요.", "h2"),
                   ("혹시… 누가\n{누르는 걸까?}", "혹시… 누가 반도체를 누르는 걸까요?", "h3")]),
    (s_jul, [("7월 말 반등하던 그때 {중국 창신메모리 상장}\n코스피 하루 {-7.7%}", "칠월 말, 반등하던 그때 중국 창신메모리가 상장했고, 코스피는 칠 점 칠 퍼센트 급락했어요.", "a1")]),
    (s_nov, [("11월 중간선거 다음 날\n반도체지수 하루 {-12.2%}", "십일월 중간선거 다음 날엔, 반도체지수가 하루에 십이 퍼센트 폭락했고요.", "a3")]),
    (s_jhh, [("11/9 반도체 {+6.9%} 오른 날\n{젠슨 황 사생활 보도}", "그리고 십일월 구 일, 반도체가 칠 퍼센트 가까이 오른 날, 젠슨 황 사생활 보도가 터졌죠.", "a4")]),
    (s_host_mid, [("근데 말이죠\n누가 {이득}일까요?", "근데 말이죠. 반도체가 눌리면, 누가 이득일까요?", "t1")]),
    (s_who, [("① {하락에 돈 건 사람들}\n버리는 11/5 하락 베팅 일부 익절", "하락에 돈을 건 사람들. 마이클 버리는 선거 다음 날, 하락 베팅 일부를 이익 실현했어요.", "b1"),
             ("② 싸게 사려는 큰손 ③ 경쟁자\n④ {데이터센터 둘러싼 정치}", "더 싸게 사고 싶은 큰손, 따라잡으려는 경쟁자, 데이터센터를 둘러싼 정치까지.", "b2")]),
    (s_counter, [("물론 {그냥 우연}일 수도\n많이 오르면 작은 악재에도 흔들", "물론 그냥 우연일 수도 있어요. 많이 오르면, 작은 악재에도 크게 흔들리니까요.", "c1")]),
    (s_host_end, [("우연일까요, 아닐까요?\n{댓글로 알려주세요!}", "우연일까요, 아닐까요? 여러분 생각을 댓글로 남겨주세요!", "e1")]),
]

def placeholder_narration():
    """TTS 도착 전 레이아웃용 임시 무음(초당 6.3음절 추정) — 실제 테이크가 오면 덮어씀"""
    for _, lines in SCRIPT:
        for _, n, _ in lines:
            p = clip_path(n)
            if not os.path.exists(p):
                syl = len([c for c in n if '가' <= c <= '힣'])
                np.save(p.replace(".npy", ".ph.npy") if False else p, np.zeros(int(syl / 6.3 * SR), np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.12 if k == 0 else TR + 0.12
        seg, lens = [], []
        for sub, n, _ in lines:
            L = len(np.load(clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        host = fn.__name__ in HOST
        dur = t - GAP + (TAIL + (0.25 if host else 0.15))
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=dur, host=host, subs=[s for s, _, _ in lines], narr=[n for _, n, _ in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def spec(scenes, starts, total):
    hosts, bubbles, subs = [], [], []
    for k, sc in enumerate(scenes):
        S = starts[k]
        if sc["host"]:
            hosts.append(dict(k=k, t0=S, t1=S + sc["dur"], fade_in=(k > 0)))
            for i, s in enumerate(sc["subs"]):
                t0 = S + sc["seg"][i]; t1 = S + (sc["seg"][i + 1] if i + 1 < len(sc["subs"]) else sc["seg"][i] + sc["lens"][i] + 0.35)
                bubbles.append(dict(t0=t0, t1=t1, text=s, first=(i == 0), last=(i == len(sc["subs"]) - 1)))
        else:
            for i, s in enumerate(sc["subs"]):
                t0 = S + sc["seg"][i]; t1 = S + (sc["seg"][i + 1] - 0.05 if i + 1 < len(sc["subs"]) else min(sc["dur"] - 0.05, sc["seg"][i] + sc["lens"][i] + 0.45))
                subs.append(dict(t0=t0, t1=t1, text=s))
    return dict(total=total, hosts=hosts, bubbles=bubbles, subs=subs)

# ================================================================ audio
def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(clip_path(n)).astype(np.float64)
            if np.abs(x).max() > 0:
                x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
                if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = list(starts)
    # 잔잔하지만 살짝 수상한 분위기: A단조 (Am - F - Dm - E), 느린 템포, 부드러운 사인·삼각파
    bpm = 88; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = [([57, 60, 64], 45), ([53, 57, 60], 41), ([50, 53, 57], 38), ([52, 56, 59], 40)]
    mel = [[76, None, None, 72, None, None, 71, None], [72, None, None, 69, None, None, None, None],
           [74, None, None, 72, None, 69, None, None], [71, None, None, 68, None, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]; mm = mel[b % 4]
        for nn in notes: tone(bgm, t0, bar * 0.98, mtof(nn), 0.014, "sin", decay=bar * 0.9, att=0.08, rel=0.3)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st in (0, 3, 6): tone(bgm, T, e * 1.4, mtof(root - 12), 0.10, "tri", decay=0.35)
            tone(bgm, T, e * 0.5, mtof(notes[st % 3] + 12), 0.008, "sq", 0.25, decay=0.08)
            if mm[st] and b % 2 == 1: tone(bgm, T, e * 2.2, mtof(mm[st]), 0.020, "sin", decay=0.6, att=0.01)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: continue
            if bt in (0, 2): tone(bgm, T, 0.12, 110, 0.10, "sin", f1=45, decay=0.07)
            tone(bgm, T + e, 0.02, 0, 0.012, "noise", decay=0.008)
    ie = int(total * SR); fo = int(1.6 * SR); fi = int(0.2 * SR)
    bgm[:fi] *= np.linspace(0, 1, fi); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.05, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.03, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.3, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.08, "noise", decay=0.04)
    def pop(T): tone(sfx, T, 0.06, 600, 0.04, "sq", 0.5, f1=1300, decay=0.04)
    def bpop(T): tone(sfx, T, 0.07, 500, 0.03, "sin", f1=1100, decay=0.05)
    def tick(T): tone(sfx, T, 0.03, 1500, 0.025, "sq", 0.5, decay=0.015)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.12, "noise", decay=0.05)
    def creep(T): tone(sfx, T, 0.5, 400, 0.025, "sin", f1=180, decay=0.45)
    for k in range(1, len(scenes)): swoosh(S[k] - 0.05)
    for k, sc in enumerate(scenes):
        if sc["host"]:
            for i in range(len(sc["subs"])): bpop(S[k] + sc["seg"][i] - 0.04)
        fn = sc["fn"].__name__
        if fn in ("s_jul", "s_nov", "s_jhh"):
            T0 = sc["seg"][0]; L = sc["lens"][0]; Th = T0 + 0.40 * L; Thit = Th + 0.45
            creep(S[k] + Th); thump(S[k] + Thit); pop(S[k] + Thit - 0.1); stampfx(S[k] + Thit + 0.9)
        if fn == "s_who":
            L1 = (sc["dur"] - TAIL - 0.15) - sc["seg"][1]
            for ta in (sc["seg"][0] + 0.1, sc["seg"][1] + 0.05, sc["seg"][1] + 0.05 + L1 * 0.30, sc["seg"][1] + 0.05 + L1 * 0.58): pop(S[k] + ta)
        if fn == "s_counter":
            L = sc["dur"] - TAIL - 0.15 - sc["seg"][0]; Tp = sc["seg"][0] + 0.45 * L
            for i in range(11): tick(S[k] + 0.3 + i * 0.07)
            thump(S[k] + Tp + 0.35)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.58 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    g = 0.89 / max(1e-6, np.abs(mix).max()); mix = mix * g
    for p, a, ch in ((path, mix, 2), (path.replace(".wav", "_narr.wav"), nv * g, 1)):
        pcm = (np.clip(a, -1, 1) * 32767).astype(np.int16)
        with wave.open(p, "wb") as w:
            w.setnchannels(ch); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes() if ch == 1 else np.repeat(pcm[:, None], 2, axis=1).tobytes())

def render_px(T, scenes, starts, total):
    k = min(max(i for i in range(len(scenes)) if starts[i] <= T + 1e-9), len(scenes) - 1)
    t = T - starts[k]; sc = scenes[k]
    low = render_low(sc, t)
    if k > 0 and t < TR:
        prev = render_low(scenes[k - 1], scenes[k - 1]["dur"] + t)
        mask = shutter_mask(t / TR) if k % 2 else dissolve_mask(k, t / TR)
        low = Image.composite(low, prev, mask)
    a = np.asarray(low.resize((FW, FH), Image.NEAREST)).copy()
    a[3::4] = (a[3::4] * 0.82).astype(np.uint8)
    if T > total - 0.8: a = (a * clamp((total - T) / 0.8)).astype(np.uint8)
    return Image.fromarray(a)

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    placeholder_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    json.dump(spec(scenes, starts, total), open(f"{OUT}/spec.json", "w"), ensure_ascii=False, indent=1)
    if mode == "times":
        for k, s in enumerate(scenes): print(k, s["fn"].__name__, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_px(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    if mode == "audio": sys.exit()
    n = int(total * FPS); os.makedirs(f"{OUT}/px", exist_ok=True)
    for i in range(n):
        render_px(i / FPS, scenes, starts, total).save(f"{OUT}/px/{i:05d}.png", compress_level=1)
        if i % 300 == 0: print(i, "/", n, flush=True)
    print("done", total)

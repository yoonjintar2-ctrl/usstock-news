import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
import nike_video as nk
from nike_video import (put, debris, confetti, stamp_slam, crack, coin_stack, person, warn_icon, render_frame, dk, SKIN, DARK)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "laoer/out"); os.makedirs(OUT, exist_ok=True)
FD = os.path.join(BASE, "fonts/galmuri-2.40.3/package/dist")
F9B = ImageFont.truetype(f"{FD}/Galmuri9.ttf", 10)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
PINK = (250, 150, 180)

# ================================================================ drawings
def infinity(d, cx, cy, s=1.0, col=YEL, t=0):
    r = int(11 * s); w = int(3 * s)
    d.ellipse([cx - 2 * r, cy - r, cx, cy + r], outline=col, width=w)
    d.ellipse([cx, cy - r, cx + 2 * r, cy + r], outline=col, width=w)
    a = t * 3.2
    px = cx + math.sin(a) * 2 * r * 0.9 * (1 if math.cos(a) > -2 else 1)
    py = cy + math.sin(2 * a) * r * 0.55
    square(d, px - 2, py - 2, WHITE, 4)

def check(d, x, y, col=GRN):
    d.line([(x, y + 5), (x + 4, y + 9), (x + 11, y)], fill=col, width=3)

def cross(d, x, y, col=SRED):
    d.line([(x, y), (x + 10, y + 10)], fill=col, width=3); d.line([(x + 10, y), (x, y + 10)], fill=col, width=3)

def piggy(d, x, y, t=0):
    d.ellipse([x, y + 6, x + 40, y + 32], fill=PINK, outline=dk(PINK))
    d.ellipse([x + 32, y + 13, x + 44, y + 24], fill=PINK, outline=dk(PINK))
    d.point((x + 38, y + 18), fill=DARK); d.point((x + 41, y + 18), fill=DARK)
    d.rectangle([x + 28, y + 11, x + 30, y + 13], fill=DARK)
    d.polygon([(x + 22, y + 7), (x + 28, y), (x + 30, y + 8)], fill=PINK)
    for lx in (x + 8, x + 26): d.rectangle([lx, y + 30, lx + 5, y + 36], fill=dk(PINK))
    d.rectangle([x + 14, y + 7, x + 22, y + 9], fill=DARK)

def calendar(d, x, y, day, col=SRED):
    d.rectangle([x, y, x + 40, y + 42], fill=WHITE, outline=GRAY)
    d.rectangle([x, y, x + 40, y + 10], fill=col)
    for i in (8, 30): d.rectangle([x + i, y - 3, x + i + 2, y + 3], fill=GRAY)
    d.text((x + 20, y + 1), "DAY", font=F9, fill=WHITE, anchor="ma")
    d.text((x + 20, y + 14), f"{day}", font=F24 if day < 100 else F12, fill=DARK, anchor="ma")

def chalkboard(d, x, y, w, h, t):
    d.rectangle([x, y, x + w, y + h], fill=(18, 44, 30), outline=(150, 110, 60), width=2)
    d.text((x + 6, y + 6), "x²+y²=r²", font=F9, fill=(220, 230, 220))
    d.text((x + 6, y + 20), "∫ f(x)dx", font=F9B, fill=(220, 230, 220))

def tooth(d, x, y):
    d.rounded_rectangle([x, y, x + 18, y + 14], radius=5, fill=WHITE, outline=GRAY)
    d.rectangle([x + 2, y + 12, x + 7, y + 22], fill=WHITE); d.rectangle([x + 11, y + 12, x + 16, y + 22], fill=WHITE)
    d.point((x + 9, y + 4), fill=CYAN)

def laptop(d, x, y, t):
    d.rectangle([x, y, x + 50, y + 32], fill=(30, 34, 52), outline=WHT2)
    d.rectangle([x + 3, y + 3, x + 47, y + 29], fill=(20, 60, 40))
    d.text((x + 25, y + 6), "CAFE", font=F9, fill=GRN, anchor="ma")
    for i in range(3):
        if ((t * 2 + i) % 3) < 2: d.rectangle([x + 7 + i * 13, y + 18, x + 16 + i * 13, y + 24], fill=WHITE)
    d.polygon([(x - 6, y + 33), (x + 56, y + 33), (x + 60, y + 38), (x - 10, y + 38)], fill=GRAY)

def book(d, x, y, col=ORG):
    d.rectangle([x, y, x + 34, y + 44], fill=col, outline=dk(col, 0.5))
    d.rectangle([x, y, x + 4, y + 44], fill=dk(col, 0.6))
    d.text((x + 19, y + 8), "무한", font=F9, fill=WHITE, anchor="ma")
    d.text((x + 19, y + 20), "매수법", font=F9, fill=WHITE, anchor="ma")
    d.rectangle([x + 10, y + 34, x + 28, y + 36], fill=WHITE)

def rocket(d, x, y, t, label="3x"):
    d.polygon([(x + 10, y), (x + 20, y + 14), (x + 20, y + 34), (x, y + 34), (x, y + 14)], fill=WHT2)
    d.ellipse([x + 5, y + 12, x + 15, y + 22], fill=CYAN)
    d.polygon([(x, y + 26), (x - 7, y + 38), (x, y + 34)], fill=SRED); d.polygon([(x + 20, y + 26), (x + 27, y + 38), (x + 20, y + 34)], fill=SRED)
    for k in range(3):
        if (t * 12 + k) % 2 < 1.3: square(d, x + 5 + k * 4, y + 36 + (k % 2) * 3, [YEL, ORG, SRED][k], 3)
    d.text((x + 10, y + 24), label, font=F9, fill=DARK, anchor="ma")

def chart_icon(d, x, y):
    d.rectangle([x, y, x + 22, y + 16], outline=WHT2); d.line([(x + 2, y + 13), (x + 8, y + 7), (x + 13, y + 10), (x + 20, y + 3)], fill=GRN)
def news_icon(d, x, y):
    d.rectangle([x, y, x + 22, y + 16], fill=WHITE); d.rectangle([x + 2, y + 2, x + 10, y + 8], fill=GRAY)
    for i in range(3): d.line([(x + 12, y + 3 + i * 4), (x + 20, y + 3 + i * 4)], fill=DARK)
def ball_icon(d, x, y, t):
    d.ellipse([x + 2, y, x + 20, y + 16], fill=PURP, outline=WHT2)
    d.point((x + 7 + int(math.sin(t * 3) * 2), y + 5), fill=WHITE)
    d.rectangle([x + 4, y + 16, x + 18, y + 19], fill=(120, 80, 40))

def battery(d, x, y, frac, col):
    d.rectangle([x, y, x + 60, y + 18], outline=WHT2); d.rectangle([x + 61, y + 5, x + 64, y + 13], fill=WHT2)
    n = int(round(frac * 10))
    for i in range(n): d.rectangle([x + 2 + i * 6, y + 2, x + 6 + i * 6, y + 16], fill=col)

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    ctext(d, 62, "LAOER'S INFINITE BUYING", F9, GRAY)
    ctext(d, 74, "무한매수법", F24, YEL)
    infinity(d, CX, 118, 1.0, YEL, t)
    # calendar flipping + coins into piggy bank
    day = min(40, 1 + int(max(0, t - 0.2) * 9))
    calendar(d, 40, 150, day)
    piggy(d, 140, 168, t)
    for k in range(14):
        ts = 0.3 + k * 0.3
        fly(d, (84, 158), (158, 172), (t - ts) / 0.5, YEL, arc=22)
    # struck-out icons
    if t > 1.2:
        chart_icon(d, 44, 214); cross(d, 50, 217)
        news_icon(d, 84, 214); cross(d, 90, 217)
        d.text((128, 216), "차트·뉴스 안 봐도?", font=F9, fill=WHITE)
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.3)
        if vis:
            d.rectangle([40, 244 + o, 210, 290 + o], fill=(30, 26, 8), outline=YEL if blink(t, 3) else ORG)
            d.text((CX, 250 + o), "미국주식 투자자 사이 유명한", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 264 + o), "라오어의 무한매수법", font=F12, fill=YEL, anchor="ma")
        debris(d, CX, 266, t, seg[1] + 0.3, 14, (YEL, WHITE, ORG), 55, 0.8, 2)
    fx = {}
    if seg[1] + 0.3 < t < seg[1] + 0.42: fx["flash"] = 0.35
    return fx

def s_who(img, d, t, seg, dur):
    header(d, t, "WHO", "LAOER", "필명 '라오어'", CYAN)
    # three-stage life: teacher -> dental -> author/community
    stages = [(0.3, "수학 강사"), (1.4, "치과 진료"), (seg[1] + 0.2, "투자 저자")]
    xs = [36, 98, 160]
    for i, ((ts, lab), x) in enumerate(zip(stages, xs)):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        d.rectangle([x, 132 + o, x + 56, 206 + o], fill=(10, 14, 30), outline=[YEL, CYAN, GRN][i])
        if i == 0:
            chalkboard(d, x + 3, 136 + o, 50, 34, t); person(d, x + 20, 174 + o, YEL)
        elif i == 1:
            tooth(d, x + 19, 142 + o); person(d, x + 20, 174 + o, WHT2)
        else:
            book(d, x + 4, 140 + o); laptop(d, x + 30, 150 + o, t) if False else None
            d.rectangle([x + 40, 144 + o, x + 52, 156 + o], fill=SRED); d.polygon([(x + 44, 147 + o), (x + 44, 153 + o), (x + 49, 150 + o)], fill=WHITE)
            d.text((x + 46, 160 + o), "YT", font=F9, fill=WHITE, anchor="ma")
            for j in range(3):
                if (t * 2 + j) % 3 < 2: d.rectangle([x + 38, 172 + o + j * 9, x + 52, 178 + o + j * 9], fill=GRN)
        d.text((x + 28, 210 + o), lab, font=F9, fill=WHITE, anchor="ma")
        if i < 2 and t > (stages[i + 1][0]):
            d.polygon([(x + 58, 168), (x + 62, 172), (x + 58, 176)], fill=GRAY)
    if t > seg[1] + 0.8:
        vis, o = slam(t, seg[1] + 0.8)
        if vis:
            d.rectangle([36, 232 + o, 214, 294 + o], fill=(10, 14, 30), outline=ORG)
            book(d, 44, 240 + o)
            d.text((88, 242 + o), "『라오어의 미국주식", font=F9, fill=WHITE)
            d.text((88, 254 + o), " 무한매수법』", font=F9, fill=WHITE)
            d.text((88, 270 + o), "2021년 · 알키", font=F9, fill=ORG)
        confetti(d, t, seg[1] + 1.0, 10, (YEL, ORG, CYAN), 124, 226)
    return {}

def s_split(img, d, t, seg, dur):
    header(d, t, "HOW 1", "SPLIT 40", "돈을 40조각으로", GRN)
    # cash brick -> 40 tiles
    gx, gy, cw, ch = 40, 132, 21, 12
    cut = prog(t, 0.4, seg[1] - 0.1)
    for i in range(40):
        r, c = i // 8, i % 8
        x = gx + c * cw; y = gy + r * ch
        used = t > seg[1] and i < int((t - seg[1]) * 6)
        gapx = int(cut * 2); gapy = int(cut * 2)
        if used: col = (40, 60, 40)
        else: col = (90, 180, 90)
        d.rectangle([x + gapx, y + gapy, x + cw - 1, y + ch - 1], fill=col, outline=dk(col, 0.6))
        if not used and cut > 0.8: d.point((x + cw // 2, y + ch // 2), fill=dk(col, 0.5))
    if 0.4 < t < seg[1]:
        sx = gx + cut * 8 * cw
        d.line([(sx, gy - 4), (sx, gy + 5 * ch + 4)], fill=WHITE, width=2)
        square(d, sx - 2, gy - 8, YEL, 4)
    if cut >= 1: d.text((CX, gy + 5 * ch + 4), "1조각 = 1일치 매수금", font=F9, fill=GRN, anchor="ma")
    if t > seg[1]:
        rocket(d, 160, 220, t, "3x")
        d.text((170, 266), "TQQQ·SOXL", font=F9, fill=CYAN, anchor="ma")
        d.text((170, 278), "3배 레버리지 ETF", font=F9, fill=GRAY, anchor="ma")
        calendar(d, 44, 226, min(40, 1 + int((t - seg[1]) * 6)), GRN)
        for k in range(20):
            ts = seg[1] + 0.2 + k * 0.17
            fly(d, (88, 240), (158, 246), (t - ts) / 0.45, (90, 180, 90), arc=12)
    return {}

def s_profit(img, d, t, seg, dur):
    header(d, t, "HOW 2", "TAKE PROFIT", "평균 단가 위에서 판다", YEL)
    bx0, by0, bx1, by1 = SX0 + 2, 128, SX1 - 4, 270
    box(d, bx0, by0, bx1, by1, DIM)
    P = [100, 96, 92, 95, 89, 85, 88, 83, 86, 90, 94, 99, 103, 108]
    mp = lambda i, v: (bx0 + 10 + i / (len(P) - 1) * (bx1 - bx0 - 20), by1 - 12 - (v - 78) / (114 - 78) * (by1 - by0 - 24))
    n = prog(t, 0.3, seg[1] + 2.4)
    m = n * (len(P) - 1)
    pts = [mp(i, P[i]) for i in range(int(m) + 1)]
    if len(pts) > 1: d.line(pts, fill=WHITE, width=2)
    avg = []
    s = 0
    for i in range(len(P)):
        s += P[i]; avg.append(s / (i + 1))
    for i in range(int(min(m, 10)) + 1):
        x, y = mp(i, P[i]); d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=GRN)
    ap = [mp(i, avg[min(i, 10)]) for i in range(int(m) + 1)]
    for j in range(0, len(ap) - 1): d.line([ap[j], ap[j + 1]], fill=YEL if j % 2 == 0 else (120, 100, 30))
    if m > 2:
        x, y = ap[1]; d.text((x - 4, y - 14), "평균 단가", font=F9, fill=YEL)
    if m >= 12.5:
        x, y = mp(12.5, 105.5)
        stamp_slam(img, x - 24, y - 6, "익절!", GRN, t, seg[1] + 2.4, "12", -8)
        debris(d, x, y, t, seg[1] + 2.4, 16, (YEL, GRN, WHITE), 55, 0.9, 6)
        for k in range(8):
            ph = ((t - seg[1] - 2.4) * 1.2 + k * 0.13)
            if 0 < ph < 1: coin_stack(d, bx0 + 10 + k * 22, by0 + 4 + ph * 120, 1)
    if t > seg[1] + 3.2:
        vis, o = slam(t, seg[1] + 3.2)
        if vis:
            d.rectangle([52, 278 + o, 198, 298 + o], fill=(8, 24, 14), outline=GRN)
            d.text((CX, 282 + o), "수익 확정 → 다시 1일차부터", font=F9, fill=GRN, anchor="ma")
    fx = {}
    if seg[1] + 2.4 < t < seg[1] + 2.52: fx["flash"] = 0.35
    if seg[1] + 2.4 < t < seg[1] + 2.7: fx["zoom"] = 1 + 0.05 * (1 - prog(t, seg[1] + 2.4, seg[1] + 2.7))
    return fx

def s_why(img, d, t, seg, dur):
    header(d, t, "WHY", "NO FORECAST", "바닥을 맞힐 필요가 없다", PURP)
    icons = [("차트 분석", chart_icon), ("뉴스", news_icon), ("예측", None)]
    for i, (lab, fn) in enumerate(icons):
        ts = 0.3 + i * 0.4
        if t < ts: continue
        x = 44 + i * 56; y = 136
        if fn: fn(d, x + 6, y)
        else: ball_icon(d, x + 6, y, t)
        if t > ts + 0.3: cross(d, x + 12, y + 3)
        d.text((x + 17, y + 24), lab, font=F9, fill=GRAY, anchor="ma")
    if t > 1.6:
        vis, o = slam(t, 1.6)
        d.rectangle([60, 170 + o, 190, 196 + o], fill=(8, 24, 14), outline=GRN)
        check(d, 70, 177 + o)
        d.text((134, 177 + o), "정해진 규칙만", font=F12, fill=GRN, anchor="ma")
    if t > seg[1]:
        base = 292
        u = ease(prog(t, seg[1] + 0.2, seg[1] + 1.2))
        d.line([(44, base + 1), (206, base + 1)], fill=GRAY)
        for yr in range(5):
            h = int((10 + yr * 10) * u)
            d.rectangle([56 + yr * 30, base - h, 76 + yr * 30, base], fill=dk(YEL, 0.5 + yr * 0.12))
        if u > 0.95:
            d.text((CX, 212), "저자 제시: 연 20% 안팎", font=F12, fill=YEL, anchor="ma")
            d.text((CX, 228), "(백테스트 기준 · 미래 보장 아님)", font=F9, fill=GRAY, anchor="ma")
        confetti(d, t, seg[1] + 1.2, 8, (YEL, ORG), 240, 290)
    return {}

def s_risk(img, d, t, seg, dur):
    header(d, t, "BUT", "RISK", "3배 레버리지의 그림자", SRED)
    bx0, by0, bx1, by1 = SX0 + 2, 128, SX1 - 4, 214
    box(d, bx0, by0, bx1, by1, DIM)
    n = prog(t, 0.3, seg[1])
    steps = 18
    pts = []
    for i in range(int(n * steps) + 1):
        x = bx0 + 8 + i / steps * (bx1 - bx0 - 16)
        y = by0 + 14 + i * 3.4 + (6 if i % 2 else 0)
        pts.append((x, min(y, by1 - 6)))
    if len(pts) > 1: d.line(pts, fill=SRED, width=2)
    if n > 0.4:
        x, y = pts[-1]; d.text((x - 4, y - 16), "3배로 빠짐", font=F9, fill=SRED, anchor="ra")
        crack(d, bx0 + 40, by0 + 6, bx0 + 70, by1 - 6, t, 1.2, WHITE, 2)
    if t > seg[1]:
        frac = 1 - prog(t, seg[1] + 0.2, seg[1] + 2.2)
        battery(d, 52, 228, frac, GRN if frac > 0.3 else SRED)
        d.text((122, 230), f"시드 {int(round(frac * 40))}/40", font=F12, fill=WHITE)
        if frac <= 0.01:
            stamp_slam(img, CX, 270, "일부 손절", SRED, t, seg[1] + 2.3, "12", -8)
            debris(d, CX, 270, t, seg[1] + 2.3, 12, (SRED, WHITE), 50, 0.8, 4)
            if t > seg[1] + 2.8:
                d.text((CX, 290), "그래서 규칙도 계속 버전업 중", font=F9, fill=YEL, anchor="ma")
    fx = {}
    if 1.2 < t < 1.4: fx["shake"] = (int(math.sin(t * 70) * 2), 0)
    return fx

def s_outro(img, d, t, seg, dur):
    header(d, t, "SUMMARY", "RULES FIRST", "감정 대신 규칙", YEL)
    infinity(d, CX, 140, 0.8, YEL, t)
    rows = [("40분할, 매일 매수", GRN, 0), ("평균 단가 위에서 익절", YEL, 1), ("레버리지 위험 이해 필수", SRED, 2)]
    for i, (s, c, k) in enumerate(rows):
        ts = 0.4 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 164 + i * 30
        d.rectangle([36, y + o, 214, y + 24 + o], fill=(10, 14, 30), outline=c)
        if k < 2: check(d, 44, y + 7 + o, c)
        else: warn_icon(d, 42, y + 5 + o, c)
        d.text((134, y + 6 + o), s, font=F12, fill=WHITE, anchor="ma")
    d.text((CX, 262), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 274), "세부 규칙은 원저자 자료로 확인하세요", font=F9, fill=DIM, anchor="ma")
    return {}

SCRIPT = [
    (s_hook, [("차트도 뉴스도 안 보고\n규칙대로 매일 조금씩 산다?", "차트도, 뉴스도 안 보고, 규칙대로 매일 조금씩 산다?"),
              ("미국주식 투자자 사이에서 유명한\n라오어의 무한매수법이에요", "미국주식 투자자들 사이에서 유명한, 라오어의 무한매수법이에요.")]),
    (s_who, [("라오어는 필명이에요\n학원가 수학 강사 출신이죠", "라오어는 필명이에요. 학원가에서 수학을 가르쳤던 분이죠."),
             ("책을 낼 땐 치과 진료 일을 하던 가장,\n2021년 책을 내며 유명해졌어요", "책을 낼 땐 치과 진료 일을 하던 평범한 가장이었고, 이천이십일 년 책을 내며 유명해졌어요.")]),
    (s_split, [("방법은 단순해요\n투자금을 40조각으로 나누고", "방법은 단순해요. 투자금을 사십 조각으로 나누고,"),
               ("TQQQ 같은 3배 레버리지 ETF를\n매일 한 조각씩 사요", "티큐큐큐 같은 세 배 레버리지 이티에프를, 매일 한 조각씩 사요.")]),
    (s_profit, [("떨어질수록 싸게 사니까\n평균 단가가 내려가고", "떨어질수록 싸게 사니까, 평균 단가가 내려가고,"),
                ("평균 단가보다 일정 비율 오르면\n팔아서 수익을 확정해요", "평균 단가보다 일정 비율 오르면, 팔아서 수익을 확정해요.")]),
    (s_why, [("바닥을 맞힐 필요 없이\n규칙만 지키면 된다는 게 인기 비결", "바닥을 맞힐 필요 없이, 규칙만 지키면 된다는 게 인기 비결이에요."),
             ("저자는 백테스트 기준으로\n연 20% 안팎의 수익을 제시했죠", "저자는 백테스트 기준으로, 연 이십 퍼센트 안팎의 수익을 제시했죠.")]),
    (s_risk, [("다만 3배 레버리지라\n긴 하락장에선 손실도 커져요", "다만 세 배 레버리지라, 길고 깊은 하락장에선 손실도 크게 불어나요."),
              ("40번을 다 사고도 안 오르면\n일부를 손절해야 하죠", "사십 번을 다 사고도 안 오르면, 일부를 손절해야 하죠.")]),
    (s_outro, [("감정 대신 규칙으로\n사고파는 투자법", "정리하면, 감정 대신 규칙으로 사고파는 투자법."),
               ("다만 레버리지 위험을\n충분히 이해하고 접근하세요", "다만 레버리지의 위험을, 충분히 이해하고 접근하세요.")]),
]
TITLES = ["", "LAOER", "SPLIT 40", "TAKE PROFIT", "NO FORECAST", "RISK", "RULES FIRST"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    bpm = 118; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    major = [([60, 64, 67], 48), ([57, 60, 64], 45), ([53, 57, 60], 41), ([55, 59, 62], 43)]   # C Am F G (bright, loop = 'infinite')
    minor = [([57, 60, 64], 45), ([53, 57, 60], 41), ([52, 56, 59], 40), ([52, 56, 59], 40)]
    mel = [[72, None, 76, 79, 76, None, 72, 74], [76, None, 72, 69, 72, None, 76, None],
           [77, None, 76, 74, 72, 74, 76, None], [74, None, 71, 67, 71, None, None, None]]
    def sec(T):
        if T < S[5]: return "bright"
        if T < S[6]: return "risk"
        return "outro"
    for b in range(int(total / bar) + 1):
        t0 = b * bar; name = sec(t0)
        notes, root = (minor if name == "risk" else major)[b % 4]
        for st in range(16):
            T = t0 + st * s16
            if T >= total: break
            tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + 12), 0.045, "sq", 0.125, decay=0.08)
            if st % 2 == 0: tone(bgm, T, 0.03, 0, 0.028 if st % 4 else 0.016, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.9, mtof(root - 12 + (12 if st % 2 else 0)), 0.16, "tri")
            m = mel[b % 4][st]
            if m and name != "risk" and T > S[1]: tone(bgm, T, e * 0.95, mtof(m - 12), 0.04, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2): tone(bgm, T, 0.16, 150, 0.33, "sin", f1=45, decay=0.07)
            if bt in (1, 3) and name != "risk":
                tone(bgm, T, 0.12, 0, 0.11, "noise", decay=0.04); tone(bgm, T, 0.08, 190, 0.07, "tri", decay=0.04)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def coin(T): tone(sfx, T, 0.04, 988, 0.045, "sq", 0.5); tone(sfx, T + 0.04, 0.1, 1319, 0.045, "sq", 0.5, decay=0.05)
    def flip(T): tone(sfx, T, 0.04, 0, 0.04, "noise", decay=0.012)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    for k in range(14): coin(S[0] + 0.3 + k * 0.3 + 0.5)
    for k in range(39): flip(S[0] + 0.2 + k / 9)
    thump(sg(0, 1) + 0.3); ding(sg(0, 1) + 0.32)
    for k in range(1, len(scenes)): swoosh(S[k]); typing(S[k] + 0.1, TITLES[k])
    for ts in (0.3, 1.4, scenes[1]["seg"][1] + 0.2): thump(S[1] + ts)
    thump(sg(1, 1) + 0.8); ding(sg(1, 1) + 0.85)
    tone(sfx, S[2] + 0.4, scenes[2]["seg"][1] - 0.5, 300, 0.04, "noise", decay=None)
    for k in range(20): coin(sg(2, 1) + 0.2 + k * 0.17 + 0.45)
    stampfx(sg(3, 1) + 2.4); ding(sg(3, 1) + 2.45)
    for k in range(8): coin(sg(3, 1) + 2.5 + k * 0.1)
    for i in range(3): thump(S[4] + 0.6 + i * 0.4)
    ding(S[4] + 1.6); tone(sfx, sg(4, 1) + 0.2, 1.0, 300, 0.04, "sq", 0.5, f1=1200)
    tone(sfx, S[5] + 0.3, scenes[5]["seg"][1] - 0.3, 900, 0.04, "sq", 0.5, f1=120)
    for k in range(10): blip(sg(5, 1) + 0.2 + k * 0.2, 1200 - k * 80, 0.04)
    stampfx(sg(5, 1) + 2.3)
    for i in range(3): thump(S[6] + 0.4 + i * 0.45)
    ding(S[6] + 1.5)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

"""특별편 · AI는 진짜 버블일까? (semihit_video.py 복사 → 대본·장면·효과음 교체)
사실 확인(2026-10-22 기준):
 · Platformonomics 'Follow the CAPEX: Q2 2026 Scoreboard'(7/31): 아마존·구글·MS·메타 2026 설비투자 가이던스
   아마존 2,200억$ · 구글 1,950~2,050억$ · MS 1,750억$(리스 재분류, 실질 약 1,900억) · 메타 1,300~1,450억$ → 합계 7,200억$ 이상
   (1월 가이던스 합계 6,400억$ 이상), 2분기 설비투자 약 1,720억$(전년 대비 +77%), 4사 합산 TTM 잉여현금흐름 전년 대비 -24%, 아마존 TTM FCF 마이너스
 · Yahoo Finance/24/7 Wall St.(8/22): UBS 추정 아마존·구글·MS는 2026년 클라우드 매출의 102%를 설비투자에 씀
 · Reuters(2026/1/19): 오픈AI CFO, 연 매출 속도 2024년 60억$ → 2025년 200억$ 돌파
 · FT·Reuters(10월 초): 오픈AI 9월 말 연 매출 속도 약 500억$, 시장에 돌던 700억$보다 약 200억$ 적음
   (Bloomberg 10/9: 회사는 연말 700억$ 이상 기대) · Admirals 정리(10/12): 10/8 나스닥 -1.25%, 코어위브 -7.77%, 오라클 -5.48%
 · 닷컴: 나스닥 2000/3/10 5,048.62 → 2002/10/9 1,114.11 (-78%) · 유튜브 2005년 설립 · 넷플릭스 스트리밍 2007년 시작
 · 아마존 3분기 실적 10/29 발표(aboutamazon.com)
마지막 장면의 전망은 제작자의 예측(의견)으로 표시한다. 실존 인물 없음, 회사 로고 없음(이름 글자만).
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from ackman_video import up_arrow, money_bag, tower
from semicrash_video import alert_card, crash_line, qmark, news_card, TEAL
from kospi1015_video import server_rack, ai_core
from meta_video import robot

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "aibubble/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
SOAP = (150, 220, 255)

# ================================================================ drawings
def bubble(d, cx, cy, r, t, col=SOAP, wob=1.0):
    """비눗방울 (출렁이는 테두리 + 하이라이트)"""
    rx = r + int(math.sin(t * 6) * 2 * wob); ry = r + int(math.cos(t * 6) * 2 * wob)
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], outline=col, width=2)
    d.ellipse([cx - rx + 4, cy - ry + 4, cx + rx - 4, cy + ry - 4], outline=dk(col, 0.35))
    hx, hy = cx - int(rx * 0.55), cy - int(ry * 0.55)
    d.arc([hx - 8, hy - 8, hx + 10, hy + 10], 190, 280, fill=WHITE, width=2)
    d.rectangle([hx + 9, hy - 6, hx + 11, hy - 4], fill=WHITE)
    for k in range(3):                                                      # 안쪽 반짝이
        a = t * 1.3 + k * 2.1
        px, py = cx + int(math.cos(a) * r * 0.6), cy + int(math.sin(a * 1.3) * r * 0.6)
        if blink(t + k * 0.3, 3): d.point((px, py), fill=(200, 240, 255))

def needle(d, x, y, col=WHT2):
    """왼쪽을 찌르는 바늘(x,y = 바늘 끝)"""
    d.line([(x, y), (x + 34, y)], fill=col, width=2)
    d.ellipse([x + 32, y - 4, x + 40, y + 4], fill=SRED, outline=dk(SRED, 0.5))
    d.point((x - 1, y), fill=WHITE)

def balance(d, cx, y, tilt, lcol, rcol, lbl_l, lbl_r, nl=5, nr=1):
    """저울: tilt>0 이면 왼쪽이 내려감"""
    d.rectangle([cx - 2, y, cx + 2, y + 62], fill=GRAY); d.rectangle([cx - 18, y + 62, cx + 18, y + 66], fill=GRAY)
    L = 64; dy = int(tilt * 18)
    lx, ly, rx, ry = cx - L, y + dy, cx + L, y - dy
    d.line([(lx, ly), (rx, ry)], fill=WHT2, width=3); d.ellipse([cx - 4, y - 4, cx + 4, y + 4], fill=YEL)
    for (px, py, col, lbl, n, left) in ((lx, ly, lcol, lbl_l, nl, True), (rx, ry, rcol, lbl_r, nr, False)):
        d.line([(px, py), (px - 14, py + 24)], fill=GRAY); d.line([(px, py), (px + 14, py + 24)], fill=GRAY)
        d.rectangle([px - 22, py + 24, px + 22, py + 28], fill=col)
        for k in range(n):                                                  # 돈 더미
            r_, c_ = divmod(k, 3)
            bx, by = px - 18 + c_ * 12 + (r_ % 2) * 6, py + 16 - r_ * 8
            d.rectangle([bx, by, bx + 10, by + 7], fill=dk(col, 0.7), outline=col)
        d.text((px, py + 31), lbl, font=F9, fill=col, anchor="ma")

def fiber(d, x0, x1, y, t, n=4, col=TEAL):
    """광케이블 다발 + 흐르는 빛"""
    for k in range(n):
        yy = y + k * 5
        d.line([(x0, yy), (x1, yy)], fill=dk(col, 0.45), width=2)
        for j in range(3):
            px = x0 + int(((t * 60 + k * 23 + j * 61) % (x1 - x0)))
            d.rectangle([px, yy - 1, px + 3, yy + 1], fill=WHITE if (k + j) % 2 else col)

def play_btn(d, x, y, col=SRED, lbl=""):
    d.rounded_rectangle([x, y, x + 30, y + 20], radius=5, fill=col)
    d.polygon([(x + 12, y + 5), (x + 12, y + 15), (x + 20, y + 10)], fill=WHITE)
    if lbl: d.text((x + 15, y + 23), lbl, font=F9, fill=WHITE, anchor="ma")

def datacenter(d, x, y, t, col=CYAN, chained=False, shake=0):
    x += shake
    d.rectangle([x, y, x + 70, y + 50], fill=(18, 22, 40), outline=col)
    d.rectangle([x + 4, y - 8, x + 66, y], fill=dk(col, 0.6))
    for r in range(3):
        for c in range(4):
            on = ((r * 4 + c + int(t * 5)) % 5) != 0
            d.rectangle([x + 6 + c * 16, y + 6 + r * 14, x + 18 + c * 16, y + 14 + r * 14], fill=(34, 40, 62))
            d.rectangle([x + 14 + c * 16, y + 9 + r * 14, x + 16 + c * 16, y + 10 + r * 14], fill=GRN if on else DIM)
    if chained:                                                             # 빚 사슬
        for k in range(6):
            cx_, cy_ = x - 6 + k * 15, y + 52 + (k % 2) * 3
            d.ellipse([cx_, cy_, cx_ + 10, cy_ + 6], outline=GRAY)
        d.rectangle([x + 22, y + 58, x + 48, y + 72], fill=(40, 10, 16), outline=SRED)
        d.text((x + 35, y + 59), "빚", font=F12, fill=SRED, anchor="ma")

def nasdaq_pts(x0, x1, ytop, ybot):
    """나스닥 1995~2002 (대략 월말 흐름, 고점 5,048 · 저점 1,114)"""
    ks = [(1995.0, 750), (1996.0, 1050), (1997.0, 1290), (1998.0, 1570), (1998.6, 1800), (1998.8, 1500), (1999.0, 2190),
          (1999.5, 2690), (1999.95, 4070), (2000.2, 5048), (2000.4, 3800), (2000.7, 4200), (2001.0, 2470), (2001.3, 1840),
          (2001.45, 2160), (2001.7, 1420), (2002.0, 1950), (2002.5, 1460), (2002.78, 1114)]
    X = lambda yr: x0 + (yr - 1995) / (2002.78 - 1995) * (x1 - x0)
    Y = lambda v: ybot - (v - 500) / (5200 - 500) * (ybot - ytop)
    return [(X(a), Y(b)) for a, b in ks]

def path_until(pts, u):
    """누적 길이 비율 u 만큼만 그린 꺾은선"""
    seg = [math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]; L = sum(seg) * u; out = [pts[0]]
    for i, s in enumerate(seg):
        if L >= s: out.append(pts[i + 1]); L -= s
        else:
            f = L / s; out.append((lerp(pts[i][0], pts[i + 1][0], f), lerp(pts[i][1], pts[i + 1][1], f))); break
    return out

# ================================================================ scenes
def punch_fx(t, t0):
    return {"shake": (int(math.sin(t * 90) * 3), int(math.cos(t * 70) * 2)), "flash": 0.3} if t0 < t < t0 + 0.12 else ({"shake": (int(math.sin(t * 90) * 2), 0)} if t0 < t < t0 + 0.3 else {})

def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · AI 버블 검증", "AI는 버블일까?", "기술 · 돈 · 역사로 따져 보기", CYAN)
    s1 = seg[1]
    r = int(lerp(16, 56, ease(prog(t, 0.3, 2.6))))
    by = 190
    bubble(d, CX, by, r, t, SOAP, 1.0 if t > 2.6 else 0.4)
    if r > 26: ai_core(d, CX - 20, by - 20, t, ORG)
    for k in range(6):                                                      # 돈 가방이 방울 속으로
        ts = 0.4 + k * 0.32
        u = prog(t, ts, ts + 0.55)
        if 0 < u < 1:
            sx = 34 if k % 2 == 0 else 200
            x = int(lerp(sx, CX - 13, ease(u))); y = int(lerp(132 + (k % 3) * 34, by - 12, ease(u)))
            money_bag(d, x, y, "$")
    if t < s1:
        if t > 1.0:
            v = 7200 * ease(prog(t, 1.0, 2.6))
            d.text((CX, 258), f"{int(v):,}억 달러+", font=F24, fill=YEL if v >= 7199 else WHITE, anchor="ma")
            d.text((CX, 288), "빅테크 4곳 · 2026 AI 투자 계획", font=F9, fill=GRAY, anchor="ma")
    else:
        nx = int(lerp(214, CX + r + 4, ease(prog(t, s1 + 0.1, s1 + 0.9))))
        needle(d, nx, by + 6)
        for k in range(3): qmark(d, CX - 30 + k * 30, 124, t + k * 0.3)
        if t > s1 + 1.0:
            stamp_slam(img, CX, 262, "버블?", SRED, t, s1 + 1.0, "24", -8)
    fx = {}
    if 2.55 < t < 2.7: fx["flash"] = 0.25
    if t > s1 + 1.0: fx.update(punch_fx(t, s1 + 1.0))
    return fx

def s_real(img, d, t, seg, dur):
    header(d, t, "01 · 먼저 기술부터", "AI 기술은 진짜", "돈 내고 쓰는 사람이 는다", GRN)
    s1 = seg[1]
    robot(d, 38, 136, t, GRN, "AI")
    d.text((150, 124), "오픈AI 연 매출 속도", font=F9, fill=GRAY, anchor="ma")
    base = 262
    cols = [("2024말", 60, "60억", GRAY, 0.6), ("2025말", 200, "200억+", TEAL, 1.2), ("2026.9", 500, "약 500억", GRN, 1.8)]
    for i, (nm, v, lab, col, ts) in enumerate(cols):
        if t < ts: continue
        u = ease(prog(t, ts, ts + 0.5)); h = int(v * 0.2 * u); x = 98 + i * 40
        d.rectangle([x, base - h, x + 30, base], fill=col)
        d.text((x + 15, base + 3), nm, font=F9, fill=col, anchor="ma")
        if u >= 1: d.text((x + 15, base - h - 12), lab, font=F9, fill=WHITE, anchor="ma")
    d.line([(92, base + 1), (216, base + 1)], fill=GRAY)
    d.text((216, 278), "단위: 달러", font=F9, fill=DIM, anchor="ra")
    if t > s1:
        target_lock(d, 193, 168, t, s1 + 0.1, "2년도 안 돼 8배", GRN)
        for k in range(4):                                                   # 동전 내는 사람들
            ts = s1 + 0.6 + k * 0.2
            if t > ts:
                mini_person(d, 40 + k * 12, 226, (BLUE, ORG, GRN, PURP)[k], t, k)
                fly(d, (44 + k * 12, 222), (56, 196), prog(t, ts, ts + 0.5), GOLD, 10)
        if t > s1 + 1.6: stamp_slam(img, 66, 296, "진짜!", GRN, t, s1 + 1.6, "12", -10)
    chapter_flash(img, d, t, "01", "기술은 진짜", GRN)
    return punch_fx(t, s1 + 1.6) if t > s1 else {}

def s_spend(img, d, t, seg, dur):
    header(d, t, "02 · 그런데", "투자는 더 빨랐다", "올해 설비투자 계획(달러)", ORG)
    s1 = seg[1]
    if t < s1:
        if t > 0.6:
            vis, o = slam(t, 0.6, 0.2)
            box(d, 34, 124 + o, 112, 160 + o, GRAY); d.text((73, 128 + o), "1월 계획", font=F9, fill=GRAY, anchor="ma")
            d.text((73, 142 + o), "6,400억", font=F12, fill=WHITE, anchor="ma")
        if t > 1.2:
            d.polygon([(118, 136), (128, 142), (118, 148)], fill=ORG)
        if t > 1.4:
            vis, o = slam(t, 1.4, 0.2)
            box(d, 134, 124 + o, 216, 160 + o, ORG if blink(t, 3) else YEL, (40, 22, 6)); d.text((175, 128 + o), "7월 또 올림", font=F9, fill=ORG, anchor="ma")
            d.text((175, 142 + o), "7,200억+", font=F12, fill=YEL, anchor="ma")
            up_arrow(d, 204, 140 + o, SRED, 14)
        rows = [("아마존", 2200, "2,200억"), ("구글", 1950, "1,950억+"), ("MS", 1750, "1,750억"), ("메타", 1300, "1,300억+")]
        for i, (nm, v, lab) in enumerate(rows):
            ts = 1.9 + i * 0.25
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.45)); w = int(v / 2200 * 96 * u); y = 176 + i * 26
            d.text((36, y + 3), nm, font=F9, fill=WHITE)
            d.rectangle([76, y, 76 + w, y + 14], fill=(ORG, GOLD, TEAL, BLUE)[i])
            if u >= 1: d.text((76 + w + 3, y + 2), lab, font=F9, fill=WHITE)
        if t > 3.1: d.text((CX, 286), "Platformonomics 집계 · 7월 말", font=F9, fill=DIM, anchor="ma")
    else:
        n = min(4, 1 + int((t - s1) / 0.35))
        for k in range(n):
            server_rack(d, 36 + k * 46, 150, t + k * 0.4, (CYAN, ORG, TEAL, GOLD)[k])
        for k in range(5):
            ts = s1 + 0.2 + k * 0.25
            u = prog(t, ts, ts + 0.5)
            if 0 < u < 1: money_bag(d, int(lerp(CX - 13, 40 + k * 40, u)), int(lerp(122, 150, u)), "$")
        if t > s1 + 1.2:
            vis, o = slam(t, s1 + 1.2, 0.2)
            box(d, 34, 232 + o, 216, 280 + o, ORG, (40, 22, 6))
            d.text((CX, 237 + o), "2분기에만 1,720억 달러", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 258 + o), "1년 전보다 +77%", font=F12, fill=YEL, anchor="ma")
    chapter_flash(img, d, t, "02", "투자 속도", ORG)
    return {"flash": 0.2} if 1.4 < t < 1.5 else {}

def s_gap(img, d, t, seg, dur):
    header(d, t, "03 · 버는 돈 vs 쓰는 돈", "속도 차이", "AI 대장이 버는 속도와 비교", SRED)
    s1 = seg[1]
    if t < s1:
        tilt = ease(prog(t, 0.8, 1.8)) * (1 + 0.08 * math.sin(t * 8) * (1 - prog(t, 1.8, 2.6)))
        balance(d, CX, 150, tilt, ORG, GRN, "투자 7,200억+", "매출 속도 500억", 9 if t > 0.5 else 0, 1 if t > 0.5 else 0)
        if t > 2.0:
            glitch_text(img, CX, 248, "약 14배", F24, SRED, t, 5 if t < 2.5 else 1)
        if t > 2.4: d.text((CX, 290), "※ 오픈AI 한 곳 매출 속도 기준", font=F9, fill=DIM, anchor="ma")
    else:
        d.text((36, 126), "클라우드 매출 대비 설비투자", font=F9, fill=WHITE)
        d.text((36, 138), "아마존·구글·MS · UBS 추정", font=F9, fill=GRAY)
        u = ease(prog(t, s1 + 0.2, s1 + 1.3)); v = 102 * u
        x100 = 36 + 160
        d.rectangle([36, 154, 200, 170], outline=WHT2)
        w = int(160 * min(v, 100) / 100); d.rectangle([38, 156, 36 + w, 168], fill=ORG)
        if v > 100: d.rectangle([x100, 156, x100 + int((v - 100) * 2.5), 168], fill=SRED)
        d.line([(x100, 150), (x100, 174)], fill=YEL); d.text((x100, 176), "100%", font=F9, fill=YEL, anchor="ma")
        d.text((40, 176), f"{int(v)}%", font=F12, fill=SRED if v > 100 else WHITE)
        if v > 100: debris(d, x100 + 4, 162, t, s1 + 1.3, 8, (SRED, YEL, WHITE), 30, 0.6, 4)
        if t > s1 + 1.7:
            vis, o = slam(t, s1 + 1.7, 0.2)
            box(d, 34, 210 + o, 216, 262 + o, SRED, (40, 10, 16))
            d.text((CX, 214 + o), "남는 현금(4사 합산)", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 227 + o), "1년 새 -24%", font=F24, fill=SRED, anchor="ma")
            d.text((CX, 268), "아마존은 최근 1년 마이너스", font=F9, fill=WHITE, anchor="ma") if t > s1 + 2.2 else None
    chapter_flash(img, d, t, "03", "버는 돈 vs 쓰는 돈", SRED)
    return {"shake": (int(math.sin(t * 80) * 2), 0)} if s1 + 1.3 < t < s1 + 1.6 else {}

def s_crack(img, d, t, seg, dur):
    header(d, t, "04 · 10월 초", "첫 균열", "숫자 하나에 흔들린 시장", SRED)
    s1 = seg[1]
    if t < s1:
        if t > 0.5:
            vis, o = slam(t, 0.5, 0.2); news_card(d, 34, 124, o, "FT·로이터 · 오픈AI 연 매출 속도", SRED)
        base = 262
        for i, (nm, v, col, ts) in enumerate([("시장 기대", 700, GRAY, 1.0), ("9월 말 실제", 500, SRED, 1.6)]):
            if t < ts: continue
            u = ease(prog(t, ts, ts + 0.5)); h = int(v * 0.15 * u); x = 64 + i * 80
            if i == 0:
                for yy in range(base - h, base, 4): d.line([(x, yy), (x + 44, yy)], fill=GRAY)
                d.rectangle([x, base - h, x + 44, base], outline=GRAY)
            else: d.rectangle([x, base - h, x + 44, base], fill=col)
            d.text((x + 22, base + 3), nm, font=F9, fill=col, anchor="ma")
            if u >= 1: d.text((x + 22, base - h - 13), f"{v}억$", font=F12, fill=WHITE, anchor="ma")
        d.line([(50, base + 1), (210, base + 1)], fill=GRAY)
        if t > 2.3: target_lock(d, 166, 182, t, 2.3, "-200억$", SRED, "기대 대비")
    else:
        box(d, 34, 122, 216, 214, DIM)
        d.text((40, 125), "나스닥 · 10.8", font=F9, fill=WHITE)
        a0, a1 = s1 + 0.1, s1 + 1.15                                          # 경보 먼저 → 급락
        uf = ease(prog(t, s1, s1 + 0.6)); ud = prog(t, a1, a1 + 0.6)
        crash_line(d, 42, 150, 210, 152, 46, uf, ud, WHITE, 5)
        alert_card(img, d, t, a0, a1, CX, 170, "급락 경보", "AI 매출 쇼크")
        if t > a1 + 0.6:
            glitch_text(img, 86, 184, "-1.25%", F24, SRED, t, 6 if t < a1 + 1.1 else 1)
            crack(d, 150, 152, 206, 212, t, a1 + 0.6, WHITE, 3)
        rows = [(a1 + 0.9, "코어위브", "-7.77%", "AI 데이터센터"), (a1 + 1.2, "오라클", "-5.48%", "AI 클라우드")]
        for i, (ts, nm, pc, note) in enumerate(rows):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 224 + i * 24 + o
            d.rectangle([34, y, 216, y + 20], fill=(10, 14, 30), outline=SRED)
            d.text((40, y + 4), nm, font=F12, fill=WHITE); d.text((134, y + 6), note, font=F9, fill=GRAY, anchor="ma"); d.text((212, y + 4), pc, font=F12, fill=SRED, anchor="ra")
    chapter_flash(img, d, t, "04", "첫 균열", SRED)
    fx = {}
    if t > s1:
        a1 = s1 + 1.15
        if a1 < t < a1 + 0.5: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
        if s1 + 0.1 < t < s1 + 0.2: fx["flash"] = 0.25
    return fx

def s_history(img, d, t, seg, dur):
    header(d, t, "05 · 2000년에도 그랬다", "닷컴의 교훈", "기술은 진짜, 주가는 버블", PURP)
    s1 = seg[1]
    if t < s1:
        box(d, 34, 122, 216, 252, DIM)
        d.text((40, 125), "나스닥 1995~2002", font=F9, fill=WHITE)
        pts = nasdaq_pts(42, 210, 140, 244)
        ip = 9                                                              # 고점 인덱스
        up_pts = pts[:ip + 1]; dn_pts = pts[ip:]
        a0, a1 = 1.9, 2.8                                                   # 경보 먼저 → 폭락
        p1 = path_until(up_pts, ease(prog(t, 0.4, 1.9)))
        if len(p1) > 1: d.line(p1, fill=GRN, width=2)
        alert_card(img, d, t, a0, a1, CX, 200, "버블 경보", "2000.3 고점")
        if t >= a1:
            p2 = path_until(dn_pts, ease(prog(t, a1, a1 + 1.2)))
            if len(p2) > 1: d.line(p2, fill=SRED, width=2)
        if t > 1.9:
            px, py = pts[ip]; d.text((px, py - 12), "5,048", font=F9, fill=YEL, anchor="ma")
        if t > a1 + 1.2:
            px, py = pts[-1]; d.text((px, py - 12), "1,114", font=F9, fill=SRED, anchor="ra")
            target_lock(d, int(pts[-1][0]) - 4, int(pts[-1][1]) - 4, t, a1 + 1.2, "-78%", SRED, "2년 7개월")
        if t > 1.0: d.text((CX, 262), "인터넷은 진짜였지만 주가는 -78%", font=F9, fill=WHITE, anchor="ma")
    else:
        d.text((CX, 124), "2000년 무렵 너무 많이 깐 광케이블", font=F9, fill=GRAY, anchor="ma")
        u = ease(prog(t, s1, s1 + 0.8))
        fiber(d, 36, 36 + int(178 * u), 150, t)
        if t > s1 + 0.8:
            vis, o = slam(t, s1 + 0.8, 0.2)
            d.text((CX, 176 + o), "남아돌아 헐값이 됐는데…", font=F12, fill=TEAL, anchor="ma")
        for i, (nm, yr, ts) in enumerate([("유튜브", "2005", 1.5), ("넷플릭스", "2007 스트리밍", 1.9)]):
            if t < s1 + ts: continue
            vis, o = slam(t, s1 + ts, 0.22)
            x = 58 + i * 92
            play_btn(d, x, 206 + o, SRED if i == 0 else (200, 30, 40))
            d.text((x + 15, 230 + o), nm, font=F12, fill=WHITE, anchor="ma")
            d.text((x + 15, 246 + o), yr, font=F9, fill=GRAY, anchor="ma")
        if t > s1 + 2.6: confetti(d, t, s1 + 2.6, 14, (YEL, GRN, CYAN, SRED))
        if t > s1 + 2.6:
            vis, o = slam(t, s1 + 2.6, 0.2)
            box(d, 34, 272 + o, 216, 294 + o, PURP, (24, 12, 34))
            d.text((CX, 277 + o), "그 위에서 새 공룡이 컸다", font=F12, fill=WHITE, anchor="ma")
    chapter_flash(img, d, t, "05", "닷컴의 교훈", PURP)
    fx = {}
    if t < s1 and 2.8 < t < 3.2: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
    return fx

def s_predict(img, d, t, seg, dur):
    header(d, t, "PREDICTION · 제작자 의견", "그래서 어떻게 될까?", "제 예측은 '펑'보다 '피식'", GOLD)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        r = int(lerp(56, 30, ease(prog(t, 1.2, 3.2))))
        bubble(d, CX, 190, r, t, SOAP, 1.0)
        for k in range(4):                                                  # 새는 바람
            ph = (t * 1.6 + k * 0.25) % 1
            if t > 1.2: d.text((CX + r + 4 + int(ph * 26), 176 - k * 6 + int(ph * 6)), "~", font=F12, fill=dk(SOAP, 1 - ph * 0.7))
        if t > 0.6:
            vis, o = slam(t, 0.6, 0.2)
            d.text((60, 128 + o), "펑!", font=F24, fill=GRAY, anchor="ma")
            if t > 1.0: d.line([(40, 132), (82, 156)], fill=SRED, width=3); d.line([(40, 156), (82, 132)], fill=SRED, width=3)
        if t > 1.4:
            vis, o = slam(t, 1.4, 0.2)
            d.text((180, 136 + o), "피시식~", font=F12, fill=SOAP, anchor="ma")
        if t > 2.2: stamp_slam(img, CX, 270, "제 예측", GOLD, t, 2.2, "24", -8)
    else:
        sh = int(math.sin(t * 50) * 2) if t > s1 + 0.6 else 0
        datacenter(d, 38, 140, t, CYAN, True, sh)
        if t > s1 + 0.6: crack(d, 48, 140, 90, 190, t, s1 + 0.6, WHITE, 4)
        if t > s1 + 0.4:
            vis, o = slam(t, s1 + 0.4, 0.2)
            d.text((73, 220 + o), "빚으로 짓는", font=F9, fill=WHITE, anchor="ma"); d.text((73, 232 + o), "AI 인프라", font=F12, fill=SRED, anchor="ma")
            d.polygon([(66, 252 + o), (80, 252 + o), (73, 262 + o)], fill=SRED)
            d.text((73, 266 + o), "먼저 흔들림", font=F9, fill=SRED, anchor="ma")
        if t > s2:
            tower(d, 140, 136, 32, 72, (60, 90, 140), "빅테크", 0.7)
            robot(d, 178, 156, t, GRN, "AI")
            for k in range(3):
                u = prog(t, s2 + 0.3 + k * 0.25, s2 + 0.8 + k * 0.25)
                if 0 < u < 1: coin(d, int(lerp(214, 196, u)), int(lerp(130, 170, u)), 6, "$")
            vis, o = slam(t, s2 + 0.3, 0.2)
            d.text((175, 220 + o), "현금 많은 빅테크", font=F9, fill=WHITE, anchor="ma"); d.text((175, 232 + o), "돈 버는 AI", font=F12, fill=GRN, anchor="ma")
            up_arrow(d, 170, 248 + o, GRN, 14)
            d.text((175, 266 + o), "살아남아 더 큼", font=F9, fill=GRN, anchor="ma")
            d.line([(CX, 140), (CX, 276)], fill=DIM)
    d.text((32, 306), "※ 제작자 의견 · 투자 권유 아님", font=F9, fill=DIM)
    return {}

def s_outro(img, d, t, seg, dur):
    header(d, t, "CHECK · 10.22 기준", "확인할 숫자 2개", "", CYAN)
    s1 = seg[1]
    if t < s1:
        rows = [(0.4, "10월 말", "실적", "빅테크 실적 발표", "내년 투자 계획 더 늘까?", ORG),
                (1.0, "12월", "연말", "오픈AI 연 매출 속도", "700억 달러 찍을까?", GRN)]
        for i, (ts, top, body, a, b, col) in enumerate(rows):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 126 + i * 66 + o
            d.rectangle([34, y, 216, y + 56], fill=(10, 14, 30), outline=col)
            calendar(d, 40, y + 10, top, body, col)
            d.text((88, y + 12), a, font=F12, fill=WHITE); d.text((88, y + 32), b, font=F9, fill=col)
    else:
        marquee(d, 132, 2, 28, t, "기술은 남고 거품은 빠진다", (dk(CYAN, 0.6), dk(GOLD, 0.55)))
        u = prog(t, s1 + 0.3, s1 + 0.6)
        if u > 0:
            vis, o = slam(t, s1 + 0.3, 0.2)
            box(d, 34, 204 + o, 216, 262 + o, YEL if blink(t, 3) else ORG, (30, 22, 6))
            d.text((CX, 210 + o), "버블일까, 아닐까?", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 232 + o), "생각은 댓글로!", font=F24, fill=YEL, anchor="ma")
        for k in range(3): qmark(d, 60 + k * 64, 276, t + k * 0.4)
    d.text((32, 306), "※ 교육용 · 투자 권유 아님", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("빅테크 4곳이 올해 AI에 쏟는 돈,\n최소 7,200억 달러", "빅테크 네 곳이 올해 에이아이에 쏟는 돈, 최소 칠천이백억 달러예요."),
              ("AI, 진짜 버블일까?\n끝에 예측까지 해볼게요", "에이아이, 진짜 버블일까요? 끝에 예측까지 해 볼게요.")]),
    (s_real, [("오픈AI 연 매출 속도\n60억 → 200억 → 약 500억 달러", "먼저, 기술은 진짜예요. 오픈에이아이 연 매출 속도는 육십억, 이백억, 지난달엔 오백억 달러 가까이."),
              ("2년도 안 돼 8배,\n돈 내고 쓰는 사람이 실제로 늘어요", "이 년도 안 돼 여덟 배. 돈 내고 쓰는 사람이 실제로 늘고 있죠.")]),
    (s_spend, [("올해 투자 계획, 1월 6,400억 달러\n→ 7월에 7,200억 달러 이상으로", "그런데 투자는 더 빨랐어요. 연초 육천사백억 달러였던 계획을, 칠월엔 칠천이백억 달러 넘게 또 올렸죠."),
               ("2분기에만 1,720억 달러,\n1년 전보다 77% 더 썼어요", "이 분기에만 천칠백이십억 달러, 일 년 전보다 칠십칠 퍼센트 더 썼어요.")]),
    (s_gap, [("AI 대장 오픈AI가 버는 속도 500억 달러,\n빅테크가 쓰는 돈은 그 14배", "에이아이 대장 오픈에이아이가 버는 속도가 오백억 달러인데, 빅테크가 쓰는 돈은 그 열네 배예요."),
             ("클라우드로 버는 돈보다 더 투자하고(UBS)\n남는 현금은 1년 새 24% 줄었어요", "유비에스는 클라우드로 버는 돈보다 투자가 더 많다고 봤고, 남는 현금은 일 년 새 이십사 퍼센트 줄었어요.")]),
    (s_crack, [("10월 초 보도: 오픈AI 매출 속도가\n기대(700억)보다 200억 달러 적어요", "그리고 이번 달 초, 오픈에이아이 매출 속도가 기대보다 이백억 달러 적다는 보도가 나왔어요."),
               ("10월 8일 나스닥 -1.25%,\nAI 인프라 주식은 더 크게 빠졌어요", "그날 나스닥은 일 점 이오 퍼센트, 에이아이 인프라 주식은 더 크게 빠졌죠.")]),
    (s_history, [("2000년 닷컴 버블, 인터넷은 진짜였지만\n나스닥은 2년 7개월 동안 -78%", "이천 년 닷컴 때도 그랬어요. 인터넷은 진짜였지만, 나스닥은 칠십팔 퍼센트 빠졌죠."),
                 ("남아돌던 광케이블 위에서\n유튜브·넷플릭스가 나중에 컸어요", "그런데 그때 너무 많이 깔아 둔 광케이블 위에서, 나중에 유튜브와 넷플릭스가 컸어요.")]),
    (s_predict, [("제 예측: '펑' 터지기보다\n바람이 서서히 빠지는 쪽", "제 예측은요, 펑 터지기보단 바람이 서서히 빠지는 쪽이에요."),
                 ("투자 속도가 꺾이면 빚으로 짓는\nAI 인프라 회사부터 흔들릴 거예요", "투자 속도가 꺾이는 순간, 빚을 내서 데이터센터를 짓는 회사부터 흔들릴 거예요."),
                 ("현금 많은 빅테크와 돈 버는 AI는\n살아남아 더 커질 거예요", "반대로 현금 많은 빅테크와, 실제로 돈 버는 에이아이는 살아남아 더 커질 거고요.")]),
    (s_outro, [("확인할 숫자: 이달 말 빅테크 실적의\n내년 투자 계획, 오픈AI 연말 700억", "확인할 숫자는 두 개. 이달 말 빅테크 실적의 내년 투자 계획, 그리고 오픈에이아이가 연말에 칠백억 달러를 찍는지."),
               ("기술은 남고, 거품은 빠진다\n여러분 생각은 댓글로!", "기술은 남고, 거품은 빠진다. 여러분 생각은 댓글로 남겨 주세요!")]),
]
TITLES = ["", "AI 기술은 진짜", "투자는 더 빨랐다", "속도 차이", "첫 균열", "닷컴의 교훈", "그래서 어떻게 될까?", "확인할 숫자 2개"]


def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 2 else LEAD + 0.3)
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    # 훅 첫 줄은 카운터(2.6초)가 다 오를 때까지
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # E minor, curious-tense chiptune (120 bpm) → G major lift on prediction/outro
    bpm = 120; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([64, 67, 71], 40), ([60, 64, 67], 36), ([62, 66, 69], 38), ([59, 63, 66], 35)]   # Em C D B
    prog_major = [([67, 71, 74], 43), ([62, 66, 69], 38), ([64, 67, 71], 40), ([60, 64, 67], 36)]   # G D Em C
    mel_m = [[76, None, 74, 71, 72, None, 71, None], [72, 74, 76, None, 79, None, 76, 74], [74, None, 69, None, 78, None, 76, 74], [75, None, 71, None, 66, None, None, None]]
    mel_M = [[79, None, 78, 79, 83, None, 81, 79], [78, None, 74, None, 78, 79, 81, None], [83, None, 79, 76, 74, None, 76, None], [76, 78, 79, None, 76, None, None, None]]
    mutes = [(sg(4, 1) + 0.1, sg(4, 1) + 1.15), (S[5] + 1.9, S[5] + 2.8)]       # 경보 동안 음악 멈춤
    muted = lambda T: any(a <= T < b for a, b in mutes)
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = t0 >= S[6]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if muted(T): continue
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and T > 2.6: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total or muted(T) or T < 1.0: continue
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def bell3(T):
        for j in range(3): tone(sfx, T + j * 0.12, 0.25, 1760, 0.06, "sin", decay=0.2); tone(sfx, T + j * 0.12, 0.25, 2637, 0.03, "sin", decay=0.2)
    def hiss(T, d=1.6): tone(sfx, T, d, 0, 0.05, "noise", decay=d)
    def chapter(T): bell3(T); thump(T + 0.12)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    # hook: 방울이 부풀고 돈이 들어감 → 바늘 → 버블?
    typing(S[0] + 0.1, "AI는버블일까"); rise(S[0] + 0.3, 2.3)
    for k in range(6): coin_s(S[0] + 0.95 + k * 0.32)
    ding(S[0] + 2.6)
    tone(sfx, sg(0, 1) + 0.1, 0.8, 500, 0.035, "sq", 0.5, f1=900, decay=0.8); stampfx(sg(0, 1) + 1.0)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 2: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # 01 real
    for i in range(3): pop(S[1] + 0.6 + i * 0.6)
    ding(S[1] + 2.3); lock(sg(1, 1) + 0.1)
    for k in range(4): coin_s(sg(1, 1) + 0.9 + k * 0.2)
    stampfx(sg(1, 1) + 1.6)
    # 02 spend
    pop(S[2] + 0.6); swoosh(S[2] + 1.2); stampfx(S[2] + 1.4); rise(S[2] + 1.45, 0.6)
    for i in range(4): pop(S[2] + 1.9 + i * 0.25)
    for k in range(4): thump(sg(2, 1) + k * 0.35)
    for k in range(5): coin_s(sg(2, 1) + 0.2 + k * 0.25)
    stampfx(sg(2, 1) + 1.2)
    # 03 gap
    for k in range(3): thump(S[3] + 0.8 + k * 0.33)
    glitch(S[3] + 2.0, 6)
    rise(sg(3, 1) + 0.2, 1.1); alarm(sg(3, 1) + 1.3, 1); stampfx(sg(3, 1) + 1.7); fall(sg(3, 1) + 1.8, 0.7)
    # 04 crack: 경보 먼저 → 급락
    pop(S[4] + 0.5); pop(S[4] + 1.0); pop(S[4] + 1.6); lock(S[4] + 2.3)
    alarm(sg(4, 1) + 0.1, 5); fall(sg(4, 1) + 1.15, 0.7); thump(sg(4, 1) + 1.2); glitch(sg(4, 1) + 1.75, 6)
    pop(sg(4, 1) + 2.05); pop(sg(4, 1) + 2.35)
    # 05 history: 상승 → 경보 → 폭락
    rise(S[5] + 0.4, 1.5); alarm(S[5] + 1.9, 4); fall(S[5] + 2.8, 1.2); thump(S[5] + 2.85); lock(S[5] + 4.0)
    for k in range(6): blip(sg(5, 1) + k * 0.13, 900 + k * 120, 0.03)
    pop(sg(5, 1) + 0.8); ding(sg(5, 1) + 1.5); ding(sg(5, 1) + 1.9); stampfx(sg(5, 1) + 2.6)
    # predict
    pop(S[6] + 0.6); thump(S[6] + 1.0); hiss(S[6] + 1.2, 2.0); pop(S[6] + 1.4); stampfx(S[6] + 2.2)
    pop(sg(6, 1) + 0.4); fall(sg(6, 1) + 0.6, 0.8); thump(sg(6, 1) + 0.65)
    for k in range(3): coin_s(sg(6, 2) + 0.3 + k * 0.25)
    rise(sg(6, 2) + 0.3, 0.8)
    # outro
    pop(S[7] + 0.4); pop(S[7] + 1.0); swoosh(sg(7, 1)); ding(sg(7, 1) + 0.3)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

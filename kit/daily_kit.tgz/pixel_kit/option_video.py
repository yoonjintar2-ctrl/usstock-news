"""주식 용어 1분 사전 #3 · 옵션 (juseok_video.py 복사 → 대본·장면·효과음 교체 + 레퍼런스 효과 픽셀판)"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import bungeo, mini_person, BROWN

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "option/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
GOLD = (240, 190, 60); OLIVE = (110, 150, 60); OLV = (70, 50, 90); WOOD = (150, 100, 60)
F36 = ImageFont.truetype(f"{FD}/Galmuri11-Bold.ttf", 36)

# ================================================================ reference-reel effects, pixel versions
def big_text(img, cx, y, s, col, scale=3, font=F24):
    """chunky pixel text: render small, scale up NEAREST, paste (chapter numbers)"""
    tmp = Image.new("RGBA", (int(font.getlength(s)) + 4, font.size + 8), (0, 0, 0, 0))
    ImageDraw.Draw(tmp).text((2, 0), s, font=font, fill=col)
    tmp = tmp.resize((tmp.width * scale, tmp.height * scale), Image.NEAREST)
    img.paste(tmp, (int(cx - tmp.width / 2), int(y)), tmp)

def chapter_flash(img, d, t, num, label, col=ORG):
    """레퍼런스 #12: 화면을 밀고 들어오는 강조색 패널 + 거대한 숫자 (장면 첫 0.55초)"""
    if t >= 0.55: return
    xin = int(W * ease(prog(t, 0, 0.15))); xout = int(W * ease(prog(t, 0.4, 0.55)))
    if xin <= xout: return
    d.rectangle([xout, 0, xin, H], fill=col)
    if xin > 200:
        big_text(img, 96, 150, num, DARK, 4)
        d.text((168, 206), label, font=F12, fill=DARK)
        d.line([(168, 200), (214, 200)], fill=DARK, width=2)

def target_lock(d, x, y, t, t0, label, col=ORG, sub=None):
    """레퍼런스 #2: 원이 줄어들며 한 점에 고정 + 십자선 + 지시선 + 타자 라벨"""
    if t < t0: return
    u = ease(prog(t, t0, t0 + 0.45)); r = int(lerp(46, 10, u))
    d.ellipse([x - r, y - r, x + r, y + r], outline=col, width=2)
    if u > 0.6: d.ellipse([x - r // 2, y - r // 2, x + r // 2, y + r // 2], outline=dk(col, 0.7))
    d.line([(x - 6, y), (x + 6, y)], fill=WHITE); d.line([(x, y - 6), (x, y + 6)], fill=WHITE)
    q = prog(t, t0 + 0.35, t0 + 0.6)
    if q > 0:
        lx, ly = x + 14 + int(16 * q), y - 14 - int(12 * q)
        d.line([(x + 8, y - 8), (lx, ly)], fill=WHITE); d.line([(lx, ly), (lx + int(40 * prog(t, t0 + 0.5, t0 + 0.7)), ly)], fill=WHITE)
        s = label[:int(max(0, t - t0 - 0.55) * 18)]
        if s: d.text((lx + 2, ly - 12), s, font=F9, fill=col)
        if sub and t > t0 + 0.9: d.text((lx + 2, ly + 3), sub[:int((t - t0 - 0.9) * 18)], font=F9, fill=GRAY)

def bars(d, x0, yb, w, h, n, t, p, accent=-1, col=WHT2, acol=SRED, seed=3):
    """레퍼런스 #11: 튀는 스펙트럼 막대 (강조 막대 하나)"""
    bw = w / n
    for k in range(n):
        base = 0.3 + 0.6 * ((math.sin(k * 12.9898 + seed) * 43758.5453) % 1) * (1 - k / n * 0.4)
        wob = 0.12 * math.sin(t * 9 + k * 1.7) + 0.08 * math.sin(t * 5.3 + k * 0.6)
        hh = int(h * clamp(base + wob) * ease(clamp(p * 1.6 - k / n * 0.6)))
        if hh < 1: continue
        x = int(x0 + k * bw)
        d.rectangle([x + 1, yb - hh, x + int(bw) - 2, yb], fill=acol if k == accent else col)

def glitch_text(img, cx, y, s, font, col, t, amt=6):
    """레퍼런스 #15: 가로 띠가 어긋나는 글리치 + 빨강/하늘 색 분리"""
    w = int(font.getlength(s)) + 12; h = font.size + 8
    layers = []
    for c, dx in ((SRED, -2), (CYAN, 2), (col, 0)):
        im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); ImageDraw.Draw(im).text((6 + dx, 2), s, font=font, fill=c); layers.append(im)
    seed = int(t * 14); n = 6; sh = h // n + 1
    for li, im in enumerate(layers):
        for k in range(n):
            r = (math.sin(seed * 78.233 + k * 12.9898) * 43758.5453) % 1
            off = int((r - 0.5) * 2 * amt) if r > 0.55 or r < 0.2 else 0
            band = im.crop((0, k * sh, w, min(h, (k + 1) * sh)))
            img.paste(band, (int(cx - w / 2 + off), int(y + k * sh)), band)

def marquee(d, y0, rows, rowh, t, phrase, cols):
    """레퍼런스 #16: 줄마다 반대로 흐르는 문장, 채움/외곽선 교대"""
    unit = phrase + "  —  "; uw = int(d.textlength(unit, font=F24))
    for r in range(rows):
        dirn = 1 if r % 2 else -1; off = int((t * 40 * dirn) % uw); y = y0 + r * rowh; c = cols[r % len(cols)]
        x = -uw + off - (r * 37) % uw
        while x < W + uw:
            if r % 2: d.text((x, y), unit, font=F24, fill=BG, stroke_width=1, stroke_fill=c)
            else: d.text((x, y), unit, font=F24, fill=c)
            x += uw

# ================================================================ drawings
def ticket(d, x, y, kind, o=0, label=None, faded=0.0):
    col = SRED if kind == "CALL" else BLUE
    if faded > 0: col = tuple(int(lerp(c, g, faded)) for c, g in zip(col, DIM))
    d.rectangle([x, y + o, x + 84, y + 52 + o], fill=(12, 14, 30), outline=col)
    d.rectangle([x, y + o, x + 84, y + 14 + o], fill=col)
    for yy in (y + 24 + o, y + 38 + o):
        d.ellipse([x - 4, yy - 4, x + 4, yy + 4], fill=BG); d.ellipse([x + 80, yy - 4, x + 88, yy + 4], fill=BG)
    d.text((x + 42, y + 2 + o), kind + " 옵션", font=F9, fill=WHITE, anchor="ma")
    d.text((x + 42, y + 20 + o), label or ("살 권리" if kind == "CALL" else "팔 권리"), font=F12, fill=WHITE if faded < 0.5 else GRAY, anchor="ma")
    d.text((x + 42, y + 36 + o), "↑ 오르면 이득" if kind == "CALL" else "↓ 내리면 이득", font=F9, fill=col, anchor="ma")

def coin(d, x, y, r=8, label="P"):
    d.ellipse([x - r, y - r, x + r, y + r], fill=GOLD, outline=dk(GOLD, 0.6))
    d.ellipse([x - r + 2, y - r + 2, x + r - 2, y + r - 2], outline=dk(GOLD, 0.8))
    if label: d.text((x, y - 5), label, font=F9, fill=DARK, anchor="ma")

def stock_card(d, x, y, price, col=WHITE, o=0):
    d.rectangle([x, y + o, x + 76, y + 56 + o], fill=(12, 14, 30), outline=ORG)
    d.text((x + 38, y + 3 + o), "붕어빵(주)", font=F9, fill=ORG, anchor="ma")
    bungeo(d, x + 14, y + 16 + o, 0.8)
    d.text((x + 38, y + 40 + o), price, font=F9, fill=col, anchor="ma")

def calendar(d, x, y, top, body, col=SRED):
    d.rectangle([x, y, x + 40, y + 36], fill=WHITE, outline=GRAY)
    d.rectangle([x, y, x + 40, y + 11], fill=col)
    d.text((x + 20, y + 1), top, font=F9, fill=WHITE, anchor="ma")
    d.text((x + 20, y + 16), body, font=F12, fill=DARK, anchor="ma")

def olive_tree(d, x, y, t, n_olive):
    d.rectangle([x + 26, y + 40, x + 34, y + 78], fill=WOOD)
    d.line([(x + 30, y + 52), (x + 18, y + 40)], fill=WOOD, width=3)
    for cx, cy, r in ((x + 30, y + 26, 22), (x + 14, y + 36, 14), (x + 46, y + 36, 14), (x + 30, y + 10, 14)):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=OLIVE, outline=dk(OLIVE, 0.7))
    for k in range(n_olive):
        ox = x + 8 + (k * 13) % 46; oy = y + 8 + (k * 7) % 36
        d.ellipse([ox, oy, ox + 4, oy + 5], fill=OLV)

def press(d, x, y, t, turning=False):
    """올리브 압착기: 나무 틀 + 나사 + 받침통"""
    d.rectangle([x, y, x + 6, y + 64], fill=WOOD); d.rectangle([x + 46, y, x + 52, y + 64], fill=WOOD)
    d.rectangle([x - 2, y, x + 54, y + 8], fill=dk(WOOD, 0.8))
    ph = int(t * 8) % 4 if turning else 0
    d.rectangle([x + 22, y + 8, x + 30, y + 34], fill=GRAY)
    for k in range(5): d.line([(x + 22, y + 10 + k * 5 + ph), (x + 30, y + 12 + k * 5 + ph)], fill=WHT2)
    d.rectangle([x + 12, y + 34, x + 40, y + 40], fill=dk(WOOD, 0.7))
    d.rectangle([x + 8, y + 44, x + 44, y + 62], fill=(90, 70, 50), outline=dk(WOOD, 0.6))
    d.ellipse([x + 14, y + 46, x + 38, y + 54], fill=(200, 180, 60))

def thales(d, x, y, t):
    """그리스 철학자 (흰 옷 + 수염, 기하학 도형 픽셀 인물)"""
    b = int(abs(math.sin(t * 5)) * 1)
    d.rectangle([x + 2, y - b, x + 10, y + 8 - b], fill=SKIN)
    d.rectangle([x + 2, y + 6 - b, x + 10, y + 10 - b], fill=WHT2)
    d.polygon([(x - 1, y + 11), (x + 13, y + 11), (x + 15, y + 30), (x - 3, y + 30)], fill=(236, 230, 214))
    d.line([(x + 1, y + 12), (x + 11, y + 26)], fill=(120, 100, 200))

def hourglass(d, x, y, frac):
    d.rectangle([x, y, x + 24, y + 3], fill=WOOD); d.rectangle([x, y + 37, x + 24, y + 40], fill=WOOD)
    d.polygon([(x + 3, y + 4), (x + 21, y + 4), (x + 13, y + 20), (x + 11, y + 20)], outline=WHT2)
    d.polygon([(x + 11, y + 20), (x + 13, y + 20), (x + 21, y + 36), (x + 3, y + 36)], outline=WHT2)
    top = int(14 * frac)
    if top > 0: d.polygon([(x + 12 - int(top * .55), y + 20 - top), (x + 12 + int(top * .55), y + 20 - top), (x + 12, y + 20)], fill=YEL)
    bot = int(14 * (1 - frac))
    if bot > 0: d.polygon([(x + 12 - int(bot * .6), y + 36), (x + 12 + int(bot * .6), y + 36), (x + 12, y + 36 - bot)], fill=YEL)
    if 0 < frac < 1: d.line([(x + 12, y + 20), (x + 12, y + 35)], fill=YEL)

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "주식 용어 1분 사전 #3", "옵션", "주식을 '찜'하는 권리", ORG)
    up = prog(t, 0.6, 2.4)
    if t > 0.3:
        vis, o = slam(t, 0.3, 0.2)
        stock_card(d, 40, 136, f"{int(lerp(10000, 15000, ease(up))):,}원", SRED if up > 0 else WHITE, o)
        if 0 < up < 1:
            for k in range(3): d.text((122 + k * 8, 150 - int(((t * 1.5 + k * .3) % 1) * 14)), "↑", font=F12, fill=SRED)
    if t > 1.0:
        mini_person(d, 176, 168, CYAN, t)
        d.rectangle([164, 140, 200, 158], fill=WHITE); d.polygon([(178, 158), (184, 158), (180, 164)], fill=WHITE)
        d.text((182, 143), "?!" if t < seg[1] else "찜!", font=F12, fill=DARK, anchor="ma")
        for k in range(4):
            u = prog(t, 1.2 + k * 0.25, 1.7 + k * 0.25)
            if 0 < u < 1: fly(d, (118, 160), (182, 176), u, GOLD)
    target_lock(d, 78, 164, t, seg[1] - 0.2, "LOCK · 찜해 둔 가격", ORG, "10,000원에 살 권리")
    if t > seg[1] + 0.9:
        stamp_slam(img, CX, 270, "옵션 = 권리", ORG, t, seg[1] + 1.0, "24", -6)
        debris(d, CX, 270, t, seg[1] + 1.0, 14, (ORG, YEL, WHITE), 50, 0.8, 3)
    fx = {}
    if seg[1] + 1.0 < t < seg[1] + 1.12: fx["flash"] = 0.35
    return fx

def s_what(img, d, t, seg, dur):
    header(d, t, "MEANING", "뜻", "살 권리 · 팔 권리", YEL)
    if t > 0.6:
        vis, o = slam(t, 0.6, 0.2)
        calendar(d, 40, 128 + o, "만기", "D-30")
        d.rectangle([92, 130 + o, 216, 162 + o], fill=(12, 14, 30), outline=YEL)
        d.text((154, 134 + o), "정해진 날 · 정해진 가격", font=F9, fill=YEL, anchor="ma")
        d.text((154, 147 + o), "사거나 팔 수 있는 권리", font=F9, fill=WHITE, anchor="ma")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.1, 0.2); ticket(d, 34, 176, "CALL", o)
    if t > seg[1] + 0.9:
        vis, o = slam(t, seg[1] + 0.9, 0.2); ticket(d, 132, 176, "PUT", o)
    if t > seg[2]:
        u = ease(prog(t, seg[2] + 0.1, seg[2] + 0.6))
        cx = int(lerp(20, CX, u))
        coin(d, cx, 262, 10, "₩")
        if u >= 1:
            vis, o = slam(t, seg[2] + 0.6, 0.2)
            d.rectangle([44, 278 + o, 206, 304 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((CX, 282 + o), "프리미엄 = 권리의 가격", font=F12, fill=GOLD, anchor="ma")
            confetti(d, t, seg[2] + 0.7, 8, (GOLD, YEL, WHITE), 240, 300)
    chapter_flash(img, d, t, "01", "뜻", ORG)
    return {}

def s_origin(img, d, t, seg, dur):
    header(d, t, "ORIGIN", "2,600년 전 그리스", "철학자 탈레스의 올리브", GRN)
    n = int(lerp(3, 18, ease(prog(t, seg[0] + 0.5, seg[1])))) if t < seg[2] else 26
    olive_tree(d, 34, 130, t, n)
    thales(d, 112, 168, t)
    if t < seg[1]:
        d.ellipse([196, 126, 214, 144], fill=YEL)
        if t > 0.8:
            d.rectangle([92, 140, 156, 158], fill=WHITE); d.polygon([(116, 158), (122, 158), (118, 164)], fill=WHITE)
            d.text((124, 143), "올해 풍년!", font=F9, fill=DARK, anchor="ma")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.1, 0.2)
        calendar(d, 172, 128 + o, "겨울", "예약", BLUE)
        press(d, 160, 176 + o, t, False)
        if t < seg[2]:
            coin(d, 144, 214, 6, "")
            d.text((186, 246 + o), "싼값에 찜!", font=F9, fill=CYAN, anchor="ma")
    if t > seg[2]:
        press(d, 160, 176, t, True)
        calendar(d, 172, 128, "수확", "풍년", SRED)
        for k in range(3): mini_person(d, 124 + k * 11, 222, (SRED, CYAN, GRN)[k], t, k)
        nc = min(6, int((t - seg[2]) / 0.25))
        for k in range(nc): coin(d, 46 + (k % 3) * 18, 262 - (k // 3) * 10, 7, "")
        vis, o = slam(t, seg[2] + 1.2, 0.2)
        if vis:
            d.rectangle([92, 256 + o, 216, 280 + o], fill=(30, 22, 6), outline=GOLD)
            d.text((154, 262 + o), "비싸게 빌려줘 큰돈", font=F12, fill=GOLD, anchor="ma")
        confetti(d, t, seg[2] + 1.3, 10, (GOLD, GRN, WHITE), 200, 300)
    d.text((CX, 304), "※ 아리스토텔레스 「정치학」 속 이야기", font=F9, fill=DIM, anchor="ma")
    chapter_flash(img, d, t, "02", "유래", GRN)
    return {}

def s_example(img, d, t, seg, dur):
    header(d, t, "EXAMPLE", "붕어빵 주식회사", "※ 가상의 예시예요", ORG)
    s1, s2 = seg[1], seg[2]
    if t > 0.5:
        vis, o = slam(t, 0.5, 0.2); stock_card(d, 34, 126, "지금 10,000원", WHITE, o)
    if t > 1.4:
        vis, o = slam(t, 1.4, 0.2); ticket(d, 128, 128, "CALL", o, "1만원에 살 권리")
        coin(d, 208, 128 + o, 9, ""); d.text((208, 140 + o), "500원", font=F9, fill=GOLD, anchor="ma")
    if s1 < t < s2:
        u = ease(prog(t, s1 + 0.1, s1 + 1.6)); price = int(lerp(10000, 15000, u) // 100 * 100)
        ctext(d, 192, f"{price:,}원", F36, SRED, full="15,000원")
        bars(d, 38, 262, 174, 26, 18, t, prog(t, s1, s1 + 1.0), 12)
        if u >= 1:
            vis, o = slam(t, s1 + 1.7, 0.2)
            d.rectangle([34, 268 + o, 216, 300 + o], fill=(30, 10, 14), outline=SRED)
            d.text((CX, 272 + o), "15,000 - 10,000 - 500", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 284 + o), "= +4,500원 (낸 돈의 9배)", font=F9, fill=YEL, anchor="ma")
            stamp_slam(img, 186, 210, "×9", SRED, t, s1 + 2.0, "24", -10)
    if t > s2:
        u = ease(prog(t, s2 + 0.1, s2 + 0.8)); price = int(lerp(10000, 9000, u) // 100 * 100)
        glitch_text(img, CX, 188, f"{price:,}원", F36, BLUE, t, 7 if t < s2 + 1.2 else 2)
        if t > s2 + 1.0:
            d.line([(124, 130), (216, 180)], fill=GRAY, width=2); d.line([(216, 130), (124, 180)], fill=GRAY, width=2)
            vis, o = slam(t, s2 + 1.0, 0.2)
            d.rectangle([150, 154 + o, 210, 170 + o], fill=DARK, outline=GRAY); d.text((180, 157 + o), "권리 포기", font=F9, fill=WHITE, anchor="ma")
        if t > s2 + 1.6:
            vis, o = slam(t, s2 + 1.6, 0.2)
            d.rectangle([34, 256 + o, 216, 296 + o], fill=(8, 18, 34), outline=BLUE)
            d.text((CX, 262 + o), "주식을 샀다면 -1,000원", font=F9, fill=GRAY, anchor="ma")
            d.text((CX, 276 + o), "옵션은 -500원뿐", font=F12, fill=CYAN, anchor="ma")
    fx = {}
    if s1 + 2.0 < t < s1 + 2.12: fx["flash"] = 0.3
    if s2 + 0.1 < t < s2 + 0.5: fx["shake"] = (int(math.sin(t * 90) * 2), 0)
    chapter_flash(img, d, t, "03", "예시", ORG)
    return fx

def s_caution(img, d, t, seg, dur):
    header(d, t, "CAUTION", "주의할 점", "권리에도 유통기한이 있어요", SRED)
    if t < seg[1]:
        frac = 1 - prog(t, 0.5, seg[1] - 0.4)
        hourglass(d, 40, 138, frac)
        ticket(d, 80, 136, "CALL", 0, "1만원에 살 권리", 1 - frac)
        if frac <= 0.02:
            glitch_text(img, 170, 200, "0원", F24, SRED, t, 5)
            crack(d, 84, 140, 160, 186, t, seg[1] - 0.5, WHITE)
        d.text((CX, 238), "만기 지나면 권리 소멸", font=F12, fill=WHT2, anchor="ma")
    elif t < seg[2]:
        box(d, 34, 132, 216, 236, DIM)
        d.text((40, 136), "옵션 값", font=F9, fill=GRAY); d.text((210, 224), "만기", font=F9, fill=SRED, anchor="ra")
        u = prog(t, seg[1] + 0.1, seg[2] - 0.2); pts = []
        for k in range(0, int(150 * u) + 1, 3):
            x = 44 + k; v = math.sqrt(max(0, 1 - k / 150)); pts.append((x, int(220 - 70 * v)))
        if len(pts) > 1: d.line(pts, fill=YEL, width=2)
        if pts: d.ellipse([pts[-1][0] - 3, pts[-1][1] - 3, pts[-1][0] + 3, pts[-1][1] + 3], fill=YEL)
        hourglass(d, 186, 140, 1 - u)
        d.text((CX, 246), "시간이 갈수록 ↓ (시간가치)", font=F12, fill=YEL, anchor="ma")
    else:
        warn_icon(d, 44, 140, SRED)
        mini_person(d, 96, 150, PURP, t)
        d.text((100, 172), "파는 쪽", font=F9, fill=PURP, anchor="ma")
        u = ease(prog(t, seg[2] + 0.3, seg[2] + 1.4))
        y1 = int(lerp(150, 220, u)); d.rectangle([150, 150, 166, y1], fill=SRED); d.polygon([(142, y1), (174, y1), (158, y1 + 14)], fill=SRED)
        d.text((190, 160), "손실", font=F12, fill=SRED, anchor="ma"); d.text((190, 176), "커질 수", font=F9, fill=SRED, anchor="ma"); d.text((190, 188), "있음", font=F9, fill=SRED, anchor="ma")
        vis, o = slam(t, seg[2] + 1.4, 0.2)
        if vis:
            d.rectangle([34, 250 + o, 216, 280 + o], fill=(30, 10, 14), outline=SRED if blink(t, 2) else YEL)
            d.text((CX, 253 + o), "사는 쪽: 최대 손실 = 프리미엄", font=F9, fill=WHITE, anchor="ma")
            d.text((CX, 266 + o), "파는 쪽: 손실이 훨씬 클 수 있음", font=F9, fill=YEL, anchor="ma")
    fx = {}
    if t < seg[1] and seg[1] - 0.5 < t < seg[1] - 0.3: fx["shake"] = (int(math.sin(t * 80) * 2), 0)
    chapter_flash(img, d, t, "04", "주의", SRED)
    return fx

def s_outro(img, d, t, seg, dur):
    marquee(d, 222, 3, 26, t, "콜 · 풋 · 프리미엄", (dk(SRED, 0.55), dk(BLUE, 0.6), dk(GOLD, 0.55)))
    header(d, t, "SUMMARY", "오늘의 용어", "옵션 = 정해진 가격에 사고팔 권리", GOLD)
    rows = [("CALL", "콜옵션", "살 권리 ↑", SRED), ("PUT", "풋옵션", "팔 권리 ↓", BLUE), ("₩", "프리미엄", "권리의 가격", GOLD)]
    for i, (a, b, c, col) in enumerate(rows):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 128 + i * 30
        d.rectangle([34, y + o, 216, y + 24 + o], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y + o, 70, y + 24 + o], fill=col)
        d.text((52, y + 6 + o), a, font=F9 if len(a) > 1 else F12, fill=WHITE, anchor="ma")
        d.text((78, y + 5 + o), b, font=F12, fill=WHITE); d.text((210, y + 7 + o), c, font=F9, fill=col, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.2)
        if vis:
            d.rectangle([44, 276 + o, 206, 300 + o], fill=(30, 22, 6), outline=GOLD if blink(t, 2) else ORG)
            d.text((CX, 282 + o), "오늘의 용어, 옵션!", font=F12, fill=GOLD, anchor="ma")
        confetti(d, t, seg[1] + 0.4, 14, (SRED, GOLD, CYAN, WHITE), 124, 240)
    d.text((CX, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM, anchor="ma")
    return {}

SCRIPT = [
    (s_hook, [("주식을 안 사고도\n오를 때 돈을 번다?", "주식을 안 사고도, 오를 때 돈을 버는 방법이 있다?"),
              ("정답은 '옵션'\n주식을 미리 찜해 두는 권리예요", "정답은 옵션. 주식을 미리 찜해 두는 권리예요.")]),
    (s_what, [("정해진 날, 정해진 가격에\n사거나 팔 수 있는 권리", "정해진 날, 정해진 가격에, 사거나 팔 수 있는 권리를 말해요."),
              ("살 권리는 콜옵션\n팔 권리는 풋옵션", "살 권리는 콜옵션, 팔 권리는 풋옵션이라고 해요."),
              ("권리를 사는 값은 '프리미엄'\n미리 내고 사요", "이 권리를 사려면, 프리미엄이라는 값을 미리 내야 해요.")]),
    (s_origin, [("약 2,600년 전 그리스 철학자 탈레스는\n올리브 풍년을 예상했어요", "약 이천육백 년 전, 그리스 철학자 탈레스는 올리브 풍년을 예상했어요."),
                ("올리브 짜는 기계를\n겨울에 미리 싼값에 예약했죠", "그래서 올리브 짜는 기계를, 겨울에 미리 싼값에 예약해 뒀죠."),
                ("풍년이 들자 비싸게 빌려줘\n큰돈을 벌었대요", "풍년이 들자 기계를 비싸게 빌려줘서, 큰돈을 벌었다고 해요.")]),
    (s_example, [("1만원짜리 주식을 한 달 뒤\n1만원에 살 권리, 500원에 샀다면?", "지금 만 원인 붕어빵 주식을, 한 달 뒤 만 원에 살 수 있는 콜옵션을, 오백 원에 샀다면?"),
                 ("1만5천원이 되면 1만원에 사서\n4,500원 이득! 낸 돈의 9배", "주가가 만 오천 원이 되면, 만 원에 사서 사천오백 원 이득. 낸 돈의 아홉 배예요."),
                 ("9천원으로 떨어지면?\n권리를 버리면 끝, 손실은 500원", "반대로 구천 원으로 떨어지면, 권리를 버리면 끝. 손실은 오백 원뿐이에요.")]),
    (s_caution, [("만기가 지나면 권리는 사라지고\n옵션 값은 0원이 될 수 있어요", "하지만 만기가 지나면 권리는 사라지고, 옵션 값은 영 원이 될 수 있어요."),
                 ("시간이 갈수록\n옵션 값도 줄어들어요", "시간이 갈수록, 옵션 값도 조금씩 줄어들고요."),
                 ("옵션을 '파는' 쪽은\n손실이 훨씬 커질 수 있어요", "그리고 옵션을 파는 쪽은, 손실이 훨씬 커질 수 있어요.")]),
    (s_outro, [("오늘의 용어, 옵션!", "오늘의 용어, 옵션!"),
               ("콜은 살 권리, 풋은 팔 권리\n프리미엄은 권리의 가격", "콜은 살 권리, 풋은 팔 권리, 프리미엄은 권리의 가격. 기억해 두세요!")]),
]
TITLES = ["", "뜻", "2,600년 전 그리스", "붕어빵 주식회사", "주의할 점", "오늘의 용어"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)   # chapter flash needs ~0.55s before the first line
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # term-series BGM: F major oom-pah, 124 bpm (주석 편과 같은 계열, 멜로디만 새로)
    bpm = 124; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    chords = [([65, 69, 72], 41), ([62, 65, 69], 38), ([58, 62, 65], 46), ([60, 64, 67], 48)]   # F Dm Bb C
    mel = [[72, None, 77, 76, 74, None, 72, None], [69, 72, 74, None, 77, None, 74, 72],
           [70, None, 74, 77, 79, None, 77, None], [76, 74, 72, None, 67, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = chords[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st % 2 == 0: tone(bgm, T, e * 0.5, mtof(root - 12 + (7 if st % 4 == 2 else 0)), 0.17, "tri")
            else:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.022, "sq", 0.25, decay=0.05)
            m = mel[b % 4][st]
            if m and T > S[1]: tone(bgm, T, e * 0.8, mtof(m), 0.035, "sq", 0.125, decay=0.15)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.08, 0, 0.08, "noise", decay=0.03)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def wahwah(T):
        for j, m in enumerate([67, 66, 65, 64]): tone(sfx, T + j * 0.25, 0.28 if j < 3 else 0.6, mtof(m), 0.07, "sq", 0.5, f1=mtof(m) * 0.98, decay=0.3)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # hook
    typing(S[0] + 0.1, "옵션주식을찜"); pop(S[0] + 0.3); rise(S[0] + 0.6, 1.8)
    for k in range(4): coin_s(S[0] + 1.2 + k * 0.25)
    lock(sg(0, 1) - 0.2); stampfx(sg(0, 1) + 1.0)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # meaning
    pop(S[1] + 0.6); pop(sg(1, 1) + 0.1); pop(sg(1, 1) + 0.9); coin_s(sg(1, 2) + 0.6); ding(sg(1, 2) + 0.7)
    # origin
    pop(S[2] + 0.8); pop(sg(2, 1) + 0.1); coin_s(sg(2, 1) + 0.4)
    for j in range(6): coin_s(sg(2, 2) + j * 0.25)
    fanfare(sg(2, 2) + 1.2)
    # example
    pop(S[3] + 0.5); pop(S[3] + 1.4); coin_s(S[3] + 1.5); rise(sg(3, 1) + 0.1, 1.5); stampfx(sg(3, 1) + 2.0); fanfare(sg(3, 1) + 2.1)
    glitch(sg(3, 2) + 0.1); wahwah(sg(3, 2) + 0.3); pop(sg(3, 2) + 1.0); ding(sg(3, 2) + 1.6)
    # caution
    glitch(sg(4, 1) - 0.55); thump(sg(4, 1) - 0.5); tone(sfx, sg(4, 1) + 0.1, 2.0, 900, 0.03, "sq", 0.5, f1=300, decay=2.0)
    thump(sg(4, 2) + 0.3); tone(sfx, sg(4, 2) + 0.3, 1.0, 600, 0.04, "sq", 0.5, f1=150, decay=1.0); ding(sg(4, 2) + 1.4)
    # outro
    for i in range(3): thump(S[5] + 0.3 + i * 0.45)
    fanfare(sg(5, 1) + 0.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

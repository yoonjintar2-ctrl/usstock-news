import os, sys, math, hashlib, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, tag, stamp, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from mid_video import render_frame, eout

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "semi/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6

# SOXX daily closes Jul 31 -> Oct 9, 2026 (stockanalysis.com)
SOXX = [504.89, 507.68, 542.21, 530.70, 532.52, 543.27, 529.39, 534.20, 546.61, 550.74, 550.42, 559.12, 531.39,
        519.67, 522.35, 520.05, 506.18, 514.06, 515.40, 525.43, 508.62, 511.04, 500.31, 501.44, 502.20, 519.86,
        528.40, 532.00, 517.43, 527.07, 497.40, 498.85, 502.06, 519.10, 533.07, 559.34, 572.78, 565.72, 566.07,
        572.68, 560.79, 567.44, 568.64, 576.33, 588.90, 589.51, 589.45, 582.82, 563.28, 559.40]
# stylised path: Jan=100 -> late-June peak 186 (+86%) -> late-July low 132 (-29%) -> real SOXX scaled
PRE = [100, 104, 111, 118, 126, 133, 141, 150, 158, 166, 175, 186, 172, 158, 146, 138, 132]
K = 132 / SOXX[0]
FLOW = PRE + [v * K for v in SOXX[1:]]

# ------------------------------------------------------------------ scenes
def s_hook(img, d, t, seg, dur):
    ctext(d, 62, "AI 반도체 · 2026년 10월", F9, GRAY)
    ctext(d, 76, typed_q(t), F24, YEL, full="왜 제자리?")
    # left: AI capex bars
    box(d, 32, 112, 120, 232, GRN, (8, 20, 12))
    d.text((76, 116), "AI 투자", font=F12, fill=GRN, anchor="ma")
    u = ease(prog(t, 0.2, 1.2))
    base = 214
    d.rectangle([46, base - 30, 70, base], fill=(40, 110, 60))
    h2 = int(30 + 30 * u); d.rectangle([82, base - h2, 106, base], fill=GRN)
    d.text((58, base + 3), "'25", font=F9, fill=GRAY, anchor="ma"); d.text((94, base + 3), "'26", font=F9, fill=GRN, anchor="ma")
    if u > 0.5: d.text((94, base - h2 - 12), "x2", font=F12, fill=YEL, anchor="ma")
    # right: chip price stuck in box
    box(d, 130, 112, 218, 232, SRED, (24, 10, 14))
    d.text((174, 116), "반도체 주가", font=F12, fill=SRED, anchor="ma")
    top, bot = 150, 206
    for x in range(136, 214, 5): d.point((x, top), fill=YEL); d.point((x, bot), fill=YEL)
    n = prog(t, 0.2, 1.6)
    pts = []
    for i in range(int(n * 40) + 1):
        x = 138 + i * 1.9
        y = 178 + math.sin(i * 0.55) * 20 + math.sin(i * 1.7) * 4
        pts.append((x, clamp(y, top + 2, bot - 2)))
    if len(pts) > 1: d.line(pts, fill=WHITE, width=1)
    if t > 1.0: d.text((174, 212), "제자리", font=F9, fill=YEL, anchor="ma")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.3)
        if vis:
            d.rectangle([CX - 50, 244 + o, CX + 50, 284 + o], fill=(10, 14, 30), outline=YEL if blink(t, 3) else ORG)
            ctext(d, 252 + o, "WHY?", F24, YEL)
    return (0, 0)

def typed_q(t):
    s = "왜 제자리?"
    return s[:int(max(0, t - 0.1) * 12)]

def s_flow(img, d, t, seg, dur):
    header(d, t, "WHAT HAPPENED", "THE BOX", "8월부터 박스권", YEL)
    bx = (SX0 + 2, 128, SX1 - 4, 292)
    box(d, *bx, DIM)
    lo, hi = 90, 195
    def mp(i, v):
        return bx[0] + 8 + i / (len(FLOW) - 1) * (bx[2] - bx[0] - 16), bx[3] - 10 - (v - lo) / (hi - lo) * (bx[3] - bx[1] - 22)
    n = prog(t, 0.2, seg[1] + 2.2)
    m = n * (len(FLOW) - 1)
    pts = [mp(i, FLOW[i]) for i in range(int(m) + 1)]
    if len(pts) > 1:
        for j in range(len(pts) - 1):
            i = j
            col = GRN if i < 11 else (SRED if i < 16 else WHITE)
            d.line([pts[j], pts[j + 1]], fill=col, width=2)
        x, y = pts[-1]; d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=YEL)
    if m >= 11:
        x, y = mp(11, FLOW[11]); d.text((x, y - 12), "+86%", font=F12, fill=GRN, anchor="ma")
        d.text((x, y - 22), "6월 고점", font=F9, fill=GRAY, anchor="ma")
    if m >= 16:
        x, y = mp(16, FLOW[16]); d.text((x - 2, y + 6), "-29%", font=F12, fill=SRED, anchor="ma")
    if t > seg[1] + 1.4:
        xa = mp(16, 0)[0]; xb = mp(len(FLOW) - 1, 0)[0]
        yt = mp(0, 589.5 * K)[1] - 3; yb = mp(0, 497.4 * K)[1] + 3
        c = YEL if blink(t, 2.5) else ORG
        for x in range(int(xa), int(xb), 4): d.point((x, yt), fill=c); d.point((x, yb), fill=c)
        d.line([(xa, yt), (xa, yb)], fill=c); d.line([(xb, yt), (xb, yb)], fill=c)
        d.text((xb, yt - 11), "SOXX $590", font=F9, fill=YEL, anchor="ra")
        d.text((xb, yb + 3), "$500", font=F9, fill=YEL, anchor="ra")
    d.text((bx[0] + 4, bx[3] + 3), "1월", font=F9, fill=GRAY)
    d.text((bx[2] - 2, bx[3] + 3), "10월", font=F9, fill=GRAY, anchor="ra")
    d.text((CX, 306), "※ SOX 지수·SOXX ETF 흐름 재구성", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

def s_priced(img, d, t, seg, dur):
    header(d, t, "REASON 1", "PRICED IN", "기대가 이미 꽉 찼다", ORG)
    # beaker
    x0, x1, y0, y1 = 82, 168, 150, 252
    lvl = ease(prog(t, 0.3, seg[1]))
    fill_top = int(y1 - (y1 - y0 - 4) * lvl)
    if fill_top < y1 - 2: d.rectangle([x0 + 2, fill_top, x1 - 2, y1 - 2], fill=(150, 70, 30))
    for yy in range(fill_top + 6, y1 - 4, 10):
        for xx in range(x0 + 8, x1 - 8, 14):
            if (xx + yy + int(t * 8)) % 3 == 0: d.point((xx, yy), fill=ORG)
    d.line([(x0, y0), (x0, y1), (x1, y1), (x1, y0)], fill=WHITE, width=2)
    if lvl > 0.3: d.text((CX, max(fill_top + 8, 160)), "기대감", font=F12, fill=WHITE, anchor="ma")
    if lvl >= 1: d.text((x1 + 6, y0 + 2), "FULL", font=F9, fill=SRED)
    if t > seg[1]:
        for k in range(10):
            ts = seg[1] + 0.2 + k * 0.35
            u = (t - ts) / 0.6
            if 0 <= u <= 1:
                y = lerp(128, y0, u); square(d, CX - 4 + (k % 3 - 1) * 14, y, GRN, 4)
            if 1 < u < 2.2:
                side = -1 if k % 2 else 1
                xs = (x0 - 4 - (u - 1) * 6) if side < 0 else (x1 + 2 + (u - 1) * 6)
                square(d, xs, y0 + (u - 1) * 60, GRN, 3)
        d.text((36, 126), "호재 뉴스 ▼", font=F9, fill=GRN)
        vis, o = slam(t, seg[1] + 1.2)
        if vis:
            d.rectangle([60, 264 + o, 190, 292 + o], fill=(10, 14, 30), outline=YEL)
            d.text((CX, 270 + o), "넘쳐도 주가는 ━", font=F12, fill=YEL, anchor="ma")
    return (0, 0)

def s_speed(img, d, t, seg, dur):
    header(d, t, "REASON 2", "SLOWDOWN", "늘긴 느는데, 덜 빨리", CYAN)
    # gauge
    cx, cy, r = CX, 198, 44
    d.arc([cx - r, cy - r, cx + r, cy + r], 180, 360, fill=GRAY, width=3)
    d.arc([cx - r, cy - r, cx + r, cy + r], 300, 360, fill=GRN, width=3)
    v = 106 if t < seg[1] + 1.6 else lerp(106, 56, ease(prog(t, seg[1] + 1.6, seg[1] + 2.6)))
    ang = math.pi * (1 - v / 120)
    d.line([(cx, cy), (cx + math.cos(ang) * (r - 6), cy - math.sin(ang) * (r - 6))], fill=YEL, width=2)
    d.ellipse([cx - 4, cy - 4, cx + 4, cy + 4], fill=YEL)
    d.text((cx, cy + 6), f"+{v:.0f}%", font=F12, fill=YEL, anchor="ma")
    d.text((cx, cy + 22), "AI 투자 증가율", font=F9, fill=GRAY, anchor="ma")
    if t > seg[1]:
        base = 292
        u1 = ease(prog(t, seg[1] + 0.2, seg[1] + 1.0)); u2 = ease(prog(t, seg[1] + 1.6, seg[1] + 2.4))
        h1 = int(106 * 0.42 * u1); h2 = int(56 * 0.42 * u2)
        d.line([(40, base + 1), (210, base + 1)], fill=GRAY)
        d.rectangle([60, base - h1, 100, base], fill=GRN); d.rectangle([150, base - h2, 190, base], fill=CYAN)
        if u1 > 0: d.text((80, base - h1 - 12), "+106%", font=F9, fill=WHITE, anchor="ma")
        if u2 > 0: d.text((170, base - h2 - 12), "+56%", font=F9, fill=WHITE, anchor="ma")
        d.text((80, base + 3), "2026", font=F9, fill=GRAY, anchor="ma"); d.text((170, base + 3), "2027 전망", font=F9, fill=GRAY, anchor="ma")
    if len(seg) > 2 and t > seg[2]:
        vis, o = slam(t, seg[2] + 0.2)
        if vis:
            d.rectangle([44, 136 + o, 206, 154 + o], fill=(10, 14, 30), outline=YEL)
            d.text((CX, 140 + o), "속도가 줄면 주가는 주춤", font=F9, fill=YEL, anchor="ma")
    d.text((CX, 306), "※ 씨티 전망 (글로벌이코노믹 보도)", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

def s_cash(img, d, t, seg, dur):
    header(d, t, "REASON 3", "SHOW ME", "그래서 돈은 언제 버나", GRN)
    box(d, 34, 140, 96, 196, BLUE, (10, 18, 40))
    d.text((65, 146), "빅테크", font=F12, fill=CYAN, anchor="ma")
    d.text((65, 166), "$$$", font=F12, fill=YEL, anchor="ma")
    box(d, 152, 140, 216, 196, SRED, (30, 10, 14))
    d.text((184, 146), "AI", font=F12, fill=SRED, anchor="ma")
    d.text((184, 162), "데이터센터", font=F9, fill=WHITE, anchor="ma")
    for k in range(int(dur / 0.18)):
        ts = 0.3 + k * 0.18
        fly(d, (98, 160 + (k * 5) % 14), (148, 160 + (k * 7) % 14), (t - ts) / 0.5, YEL, arc=10)
    d.text((CX, 128), "투자 →", font=F9, fill=YEL, anchor="ma")
    # return path
    y = 220
    for x in range(64, 186, 6): d.line([(x, y), (x + 2, y)], fill=GRN if blink(t, 2) else (40, 110, 60))
    d.line([(64, 214), (64, 220)], fill=GRN); d.line([(186, 196), (186, 220)], fill=GRN)
    d.polygon([(64, 200), (58, 210), (70, 210)], fill=GRN)
    d.text((CX, 226), "← 이익 회수?", font=F12, fill=GRN, anchor="ma")
    for i in range(3):
        if blink(t + i * 0.3, 2): d.text((80 + i * 40, 246), "?", font=F24, fill=WHITE)
    if t > seg[1] + 1.0:
        vis, o = slam(t, seg[1] + 1.0)
        if vis:
            d.rectangle([44, 278 + o, 206, 298 + o], fill=(8, 24, 14), outline=GRN)
            d.text((CX, 282 + o), "실적으로 증명해야 오른다", font=F9, fill=GRN, anchor="ma")
    return (0, 0)

def s_next(img, d, t, seg, dur):
    header(d, t, "NEXT", "PROOF TIME", "10월, 증거가 나온다", YEL)
    rows = [("10월 중", "삼성 · SK하이닉스 실적", CYAN), ("10/29", "알파벳 · 메타 실적", GRN), ("10/30", "마이크로소프트 실적", GRN)]
    for i, (a, b, c) in enumerate(rows):
        ts = seg[1] + i * 0.5
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 134 + i * 30
        d.rectangle([34, y + o, 216, y + 24 + o], fill=(10, 14, 30), outline=c)
        d.text((40, y + 6 + o), a, font=F12, fill=c)
        d.text((210, y + 7 + o), b, font=F9, fill=WHITE, anchor="ra")
    if t < seg[1]:
        # hourglass
        d.polygon([(105, 150), (145, 150), (125, 180)], outline=YEL)
        d.polygon([(105, 210), (145, 210), (125, 180)], outline=YEL)
        u = ((t * 0.5) % 1)
        d.polygon([(112 + 7 * u, 154 + 12 * u), (138 - 7 * u, 154 + 12 * u), (125, 178)], fill=YEL)
        d.rectangle([123, 180, 127, 206], fill=YEL if blink(t, 4) else (120, 100, 30))
        d.text((CX, 216), "증거 대기 중", font=F9, fill=GRAY, anchor="ma")
    if len(seg) > 2 and t > seg[2]:
        vis, o = slam(t, seg[2] + 0.2)
        if vis:
            d.rectangle([34, 232 + o, 216, 260 + o], fill=(8, 24, 14), outline=GRN)
            d.text((44, 237 + o), "▲ 이익 확인", font=F12, fill=GRN)
            d.text((208, 239 + o), "박스 위로", font=F9, fill=WHITE, anchor="ra")
            d.rectangle([34, 266 + o, 216, 294 + o], fill=(30, 10, 14), outline=SRED)
            d.text((44, 271 + o), "▼ 실망", font=F12, fill=SRED)
            d.text((208, 273 + o), "박스 아래로", font=F9, fill=WHITE, anchor="ra")
    d.text((CX, 304), "※ 일정은 한국 시간 기준 · 유안타증권 자료", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

def s_outro(img, d, t, seg, dur):
    header(d, t, "SUMMARY", "WAITING", "증거를 기다리는 중", CYAN)
    rows = [("1", "너무 빨리 올랐다", ORG), ("2", "투자 증가 속도 둔화", CYAN), ("3", "이익 확인 대기", GRN)]
    for i, (a, b, c) in enumerate(rows):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2)
        y = 132 + i * 30
        d.rectangle([40, y + o, 210, y + 24 + o], fill=(10, 14, 30), outline=c)
        d.text((50, y + 6 + o), a, font=F12, fill=c)
        d.text((CX + 10, y + 7 + o), b, font=F9, fill=WHITE, anchor="ma")
    if t > 1.9:
        vis, o = slam(t, 1.9)
        d.rectangle([44, 228 + o, 206, 258 + o], fill=(30, 26, 8), outline=YEL if blink(t, 2) else ORG)
        ctext(d, 233 + o, "= 박스권 횡보", F12, YEL)
    d.text((CX, 270), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=GRAY, anchor="ma")
    d.text((CX, 282), "자료: Schwab · 씨티 · 유안타 · Yahoo 외", font=F9, fill=DIM, anchor="ma")
    return (0, 0)

SCRIPT = [
    (s_hook, [("AI 투자는 올해\n두 배로 느는데", "에이아이 투자는 올해 두 배로 느는데,"),
              ("반도체 주가는 왜\n두 달째 제자리일까요?", "반도체 주가는, 왜 두 달째 제자리일까요?")]),
    (s_flow, [("반도체 지수는 상반기에만\n86% 오른 뒤", "반도체 지수는 상반기에만 팔십육 퍼센트 오른 뒤,"),
              ("7월에 29% 급락하고\n8월부터 박스권에 갇혔어요", "칠월에 이십구 퍼센트 급락하고, 팔월부터는 박스권에 갇혔어요.")]),
    (s_priced, [("첫째, 너무 빨리 올랐어요", "첫째, 너무 빨리 올랐어요."),
                ("좋은 소식이 이미 주가에 반영돼서\n웬만한 호재엔 꿈쩍 안 하죠", "좋은 소식이 이미 주가에 반영돼서, 웬만한 호재엔 꿈쩍 안 하죠.")]),
    (s_speed, [("둘째, 투자 증가 속도가\n느려지고 있어요", "둘째, 투자 증가 속도가 느려지고 있어요."),
               ("AI 투자 증가율은 올해 106%,\n내년엔 56%로 예상돼요", "에이아이 투자 증가율은 올해 백육 퍼센트, 내년엔 오십육 퍼센트로 예상돼요."),
               ("여전히 늘지만, 시장은\n'얼마나 빨리'에 반응하거든요", "여전히 늘지만, 시장은 얼마나 빨리 느는지에 반응하거든요.")]),
    (s_cash, [("셋째, 그래서 돈은 언제 버나요?", "셋째, 그래서 돈은 언제 버나요?"),
              ("빅테크가 쏟는 돈이\n이익이 되는지 보고 싶은 거죠", "빅테크가 쏟는 돈이, 이익이 되는지 보고 싶은 거죠.")]),
    (s_next, [("그래서 시장은 지금\n증거를 기다리는 중이에요", "그래서 시장은 지금, 증거를 기다리는 중이에요."),
              ("이달 삼성전자·SK하이닉스,\n말일엔 빅테크 실적이 나와요", "이달 삼성전자와 에스케이하이닉스, 말일엔 빅테크 실적이 나와요."),
              ("투자 계획과 이익이 확인되면\n박스권의 방향이 정해질 거예요", "투자 계획과 이익이 확인되면, 박스권의 방향이 정해질 거예요.")]),
    (s_outro, [("많이 올랐고, 속도는 줄었고\n증거를 기다리는 중", "정리하면, 많이 올랐고, 속도는 줄었고, 증거를 기다리는 중."),
               ("그게 지금\n반도체 횡보의 이유예요", "그게 지금, 반도체 횡보의 이유예요.")]),
]
TITLES = ["", "THE BOX", "PRICED IN", "SLOWDOWN", "SHOW ME", "PROOF TIME", "WAITING"]

def clip_path(text_): return mv.clip_path(text_)

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else LEAD
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # BGM: E minor ostinato (a 'stuck in a box' loop), 112 bpm
    bpm = 112; beat = 60 / bpm; e = beat / 2; s16 = beat / 4; bar = beat * 4
    chords = [([64, 67, 71], 40), ([60, 64, 67], 48), ([62, 66, 69], 50), ([59, 62, 66], 47)]   # Em C D Bm
    mel = [[76, None, 74, 71, 74, None, 71, 67], [72, None, 71, 67, 69, None, 67, None],
           [74, None, 76, 78, 76, 74, 71, None], [71, None, 74, 71, 66, None, None, None]]
    def sec(T):
        if T < S[1]: return "hook"
        if T < S[2]: return "light"
        if T < S[5]: return "tense"
        if T < S[6]: return "build"
        return "full"
    for b in range(int(total / bar) + 1):
        t0 = b * bar; name = sec(t0); notes, root = chords[b % 4]
        drums = name in ("hook", "build", "full")
        for st in range(16):
            T = t0 + st * s16
            if T >= total: break
            tone(bgm, T, s16 * 0.9, mtof(notes[st % 3] + 12), 0.045, "sq", 0.125, decay=0.08)
            if st % 2 == 0 and name != "light": tone(bgm, T, 0.03, 0, 0.028 if st % 4 else 0.016, "noise", decay=0.01)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.9, mtof(root - 12 + (12 if st % 2 else 0)), 0.16, "tri")
            m = mel[b % 4][st]
            if m and name in ("full", "build"): tone(bgm, T, e * 0.95, mtof(m - 12), 0.04, "sq", 0.25, decay=0.25)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if bt in (0, 2) and name != "light": tone(bgm, T, 0.16, 150, 0.33, "sin", f1=45, decay=0.07)
            if bt in (1, 3) and drums:
                tone(bgm, T, 0.12, 0, 0.11, "noise", decay=0.04); tone(bgm, T, 0.08, 190, 0.07, "tri", decay=0.04)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def drip(T): tone(sfx, T, 0.07, 1800, 0.05, "sin", f1=700, decay=0.04)
    def coin(T): tone(sfx, T, 0.04, 988, 0.04, "sq", 0.5); tone(sfx, T + 0.04, 0.08, 1319, 0.04, "sq", 0.5, decay=0.05)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    typing(S[0] + 0.1, "왜 제자리?", 12); tone(sfx, S[0] + 0.2, 1.0, 300, 0.04, "sq", 0.5, f1=900)
    thump(sg(0, 1) + 0.3); ding(sg(0, 1) + 0.32)
    for k in range(1, len(scenes)): swoosh(S[k]); typing(S[k] + 0.1, TITLES[k])
    tone(sfx, S[1] + 0.3, 1.6, 300, 0.035, "sq", 0.5, f1=1200)
    tone(sfx, sg(1, 1), 0.8, 900, 0.05, "sq", 0.5, f1=150); thump(sg(1, 1) + 1.4)
    tone(sfx, S[2] + 0.3, scenes[2]["seg"][1] - 0.3, 200, 0.03, "tri", f1=600)
    for k in range(10): drip(sg(2, 1) + 0.8 + k * 0.35)
    thump(sg(2, 1) + 1.2)
    tone(sfx, sg(3, 1) + 1.6, 1.0, 900, 0.045, "sq", 0.5, f1=400); thump(sg(3, 2) + 0.2)
    for k in range(0, int(scenes[4]["dur"] / 0.18), 2): coin(S[4] + 0.3 + k * 0.18 + 0.5)
    thump(sg(4, 1) + 1.0)
    for i in range(3): thump(sg(5, 1) + i * 0.5)
    ding(sg(5, 2) + 0.2)
    for i in range(3): thump(S[6] + 0.3 + i * 0.45)
    thump(S[6] + 1.9); ding(S[6] + 1.92)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

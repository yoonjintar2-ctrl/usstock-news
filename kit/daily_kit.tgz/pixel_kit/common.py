"""스타일 샘플 공용: 내레이션(Supertonic 3 'A', pixel_kit 캐시 공유) · 칩튠 없는 부드러운 BGM 합성 · 자막 · ffmpeg 렌더"""
import os, sys, math, subprocess, wave, hashlib
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

PK = "/home/claude/pixel_kit"
sys.path.insert(0, PK)
from make_video import tone, mtof, SR                      # noqa: E402

BASE = os.path.dirname(os.path.abspath(__file__))
FD = os.path.join(BASE, "fonts")
W, H, FPS = 1080, 1920, 30
VOICE_SID, SPEED = 1, 1.05
NDIR = os.path.join(PK, "narr2")
NOTO_B = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
NOTO_M = "/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc"
NOTO_K = 1                                                  # KR index in ttc

def font(name, size):
    if name == "noto_b": return ImageFont.truetype(NOTO_B, size, index=NOTO_K)
    if name == "noto_m": return ImageFont.truetype(NOTO_M, size, index=NOTO_K)
    return ImageFont.truetype(os.path.join(FD, name), size)

def clip_path(t): return os.path.join(NDIR, hashlib.md5(f"{VOICE_SID}|{SPEED}|{t}".encode()).hexdigest() + ".npy")

def narrate(lines):
    todo = [n for n in lines if not os.path.exists(clip_path(n))]
    if todo:
        cwd = os.getcwd(); os.chdir(PK)
        from tts_synth import make_tts, synth
        tts = make_tts()
        for n in todo:
            x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
            idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
            np.save(clip_path(n), x.astype(np.float32))
        os.chdir(cwd)
    return [len(np.load(clip_path(n))) / SR for n in lines]

# ---------------------------------------------------------------- easing
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def prog(t, a, b): return clamp((t - a) / (b - a)) if b > a else float(t >= a)
def ease(u): return 1 - (1 - u) ** 3
def back(u, s=1.7): u -= 1; return u * u * ((s + 1) * u + s) + 1
def lerp(a, b, u): return a + (b - a) * u

# ---------------------------------------------------------------- subtitles (쇼츠 세이프존: 상단 y=1296, 중심 x=500, 폭 740)
SUB_Y, SUB_CX, SUB_MAXW = 1296, 500, 740
def sub_img(s, fill=(255, 255, 255), stroke=(0, 0, 0), fname="noto_b"):
    lines = s.split("\n"); size = 52
    f = font(fname, size); tmp = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while max(tmp.textlength(l, font=f) for l in lines) > SUB_MAXW: size -= 2; f = font(fname, size)
    lh = int(size * 1.3)
    im = Image.new("RGBA", (W, lh * len(lines) + 20), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for i, l in enumerate(lines):
        d.text((SUB_CX, 8 + i * lh), l, font=f, fill=fill, anchor="ma", stroke_width=6, stroke_fill=stroke)
    return im

# ---------------------------------------------------------------- audio
def mix(path, total, narr, sfx_fn, bgm_fn):
    """narr: [(start_sec, text)], sfx_fn(buf), bgm_fn(buf, total)"""
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for st, n in narr:
        x = np.load(clip_path(n)).astype(np.float64)
        x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
        if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
        i = int(st * SR); nv[i:i + len(x)] += x[:max(0, N - i)]
    bgm_fn(bgm, total); sfx_fn(sfx)
    ie = int(total * SR); fo = int(1.5 * SR); bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same"); act = np.clip(env / 0.04, 0, 1)
    m = np.tanh((bgm * (1 - 0.6 * act) + sfx * (1 - 0.3 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    m = m / max(1e-6, np.abs(m).max()) * 0.89
    pcm = (m * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

def soft_bgm(buf, total, bpm=96, prog_=None, root_oct=-12, lead=True, kick=True, keys="sin"):
    """부드러운 로파이 계열 반주: 사인/삼각 패드 + 베이스 + 가벼운 드럼"""
    beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_ = prog_ or [([60, 64, 67, 71], 48), ([57, 60, 64, 67], 45), ([62, 65, 69, 72], 50), ([55, 59, 62, 65], 43)]
    mel = [[72, None, 76, None, 74, 72, None, 71], [72, None, 69, None, 67, None, 69, None], [74, None, 77, 76, 74, None, 72, None], [71, None, 67, None, None, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar; notes, root = prog_[b % 4]
        for nn in notes: tone(buf, t0, bar * 0.98, mtof(nn), 0.018, keys, decay=bar * 0.9, att=0.05, rel=0.3)
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            if st in (0, 3, 4, 6): tone(buf, T, e * 0.9, mtof(root + root_oct), 0.11, "tri", decay=0.3)
            m = mel[b % 4][st]
            if lead and m and b % 2 == 1: tone(buf, T, e * 1.4, mtof(m), 0.028, "sin", decay=0.4, att=0.01)
        if kick:
            for bt in range(4):
                T = t0 + bt * beat
                if T >= total: break
                if bt in (0, 2): tone(buf, T, 0.12, 120, 0.22, "sin", f1=45, decay=0.06)
                else: tone(buf, T, 0.06, 0, 0.05, "noise", decay=0.03)
                tone(buf, T + e, 0.02, 0, 0.018, "noise", decay=0.008)

def render(path, total, frame_fn, wav):
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                          "-i", wav, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                          "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest",
                          "-movflags", "+faststart", path], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame_fn(i / FPS).convert("RGB").tobytes())
    p.stdin.close(); p.wait()

def timeline(narr_lines, start=0.4, gap=0.35, extra=None):
    """narr_lines -> [(t, len)] 순차 배치. extra[i] = i번째 줄 뒤에 더 줄 시간"""
    lens = narrate(narr_lines); t = start; out = []
    for i, L in enumerate(lens):
        out.append((t, L)); t += L + gap + (extra or {}).get(i, 0)
    return out, t + 0.6

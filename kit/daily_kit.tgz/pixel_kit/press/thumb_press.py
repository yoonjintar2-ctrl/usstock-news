"""'누가 반도체를 누르나?' 썸네일 — 새 스타일: 사건 수사 보드(코르크판 + 사진 카드 + 노란 실 + 물음표 카드)
python3 thumb_press.py <mascot_rgba.png> <out.jpg>"""
import sys, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 1080, 1920
FB = '/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc'
FM = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def f(sz, black=True): return ImageFont.truetype(FB if black else FM, sz, index=1)
YEL = (255, 210, 60); INK = (24, 22, 26); PAPER = (246, 240, 226)

rng = np.random.default_rng(3)
base = np.zeros((H, W, 3), np.float32) + np.array([58, 42, 30], np.float32)
noise = rng.normal(0, 1, (H // 4, W // 4)); noise = np.array(Image.fromarray(((noise + 3) * 40).clip(0, 255).astype(np.uint8)).resize((W, H), Image.BICUBIC), np.float32) / 255
base *= (0.75 + 0.4 * noise[..., None])
spk = rng.random((H, W)) > 0.985; base[spk] *= 1.35
yy, xx = np.mgrid[0:H, 0:W]; vig = 1 - 0.55 * (((xx - W / 2) / (W * 0.75)) ** 2 + ((yy - H * 0.45) / (H * 0.7)) ** 2)
base *= vig.clip(0.35, 1)[..., None]
im = Image.fromarray(base.clip(0, 255).astype(np.uint8)).convert('RGBA')
d = ImageDraw.Draw(im)

def card(cx, cy, w, h, ang, date, what, num, pin=True):
    c = Image.new('RGBA', (w + 40, h + 40), (0, 0, 0, 0)); g = ImageDraw.Draw(c)
    g.rectangle([20, 20, 20 + w, 20 + h], fill=PAPER)
    g.rectangle([34, 34, 20 + w - 14, 20 + int(h * 0.52)], fill=(30, 34, 52))
    # 카드 속 작은 하락 그래프(색 구분 없이 흰 선)
    pts = []; x0, x1 = 50, 20 + w - 30; yb = 20 + int(h * 0.52) - 18
    for i in range(24):
        u = i / 23; x = x0 + (x1 - x0) * u
        y = yb - (u / 0.6) * (h * 0.30) if u < 0.6 else yb - h * 0.30 + ((u - 0.6) / 0.4) * (h * 0.32)
        pts.append((x, y + math.sin(i * 1.7) * 5))
    g.line(pts, fill=(235, 238, 245), width=6)
    g.text((20 + w // 2, 20 + int(h * 0.56)), date, font=f(40, False), fill=(90, 80, 70), anchor='ma')
    g.text((20 + w // 2, 20 + int(h * 0.56) + 50), what, font=f(44, False), fill=INK, anchor='ma')
    fs = 64
    while g.textlength(num, font=f(fs)) > w - 40: fs -= 2
    g.text((20 + w // 2, 20 + int(h * 0.56) + 102), num, font=f(fs), fill=INK, anchor='ma')
    sh = Image.new('RGBA', c.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rectangle([28, 30, 28 + w, 30 + h], fill=(0, 0, 0, 150))
    c = Image.alpha_composite(sh.filter(ImageFilter.GaussianBlur(10)), c)
    c = c.rotate(ang, resample=Image.BICUBIC, expand=True)
    im.alpha_composite(c, (int(cx - c.width / 2), int(cy - c.height / 2)))
    return (cx, cy - h / 2 + 8)

# 1) 실(뒤) — 카드 윗변 핀끼리, 물음표 카드로 모임
C = [(260, 830), (815, 850), (275, 1330)]; HC = 420
P = [(x, y - HC // 2 + 14) for x, y in C]
Q = (790, 1150)
for p in P: d.line([p, Q], fill=(200, 160, 40), width=7)
d.line([P[0], P[1]], fill=(200, 160, 40), width=7)
qq = Image.new('RGBA', (330, 330), (0, 0, 0, 0)); g = ImageDraw.Draw(qq)
g.rectangle([15, 15, 315, 315], fill=(20, 20, 26), outline=YEL, width=8)
g.text((165, 22), "?", font=f(250), fill=YEL, anchor='ma')
qq = qq.rotate(6, resample=Image.BICUBIC, expand=True)
im.alpha_composite(qq, (Q[0] - qq.width // 2, Q[1] - 30))
for (x, y), a, dt, wt, nm in zip(C, (4, -5, -3), ("7/28", "11/5", "11/9"), ("창신메모리 상장", "선거 다음 날", "젠슨 황 보도"), ("코스피 -7.7%", "SOX -12.2%", "엔비디아 장중 -8.8%")):
    card(x, y, 440, HC, a, dt, wt, nm)
# 핀
for (x, y) in list(P) + [(Q[0], Q[1] + 4)]:
    d.ellipse([x - 18, y - 18, x + 18, y + 18], fill=(250, 200, 50), outline=(120, 90, 20), width=3)
    d.ellipse([x - 7, y - 10, x + 2, y - 2], fill=(255, 245, 200))

# 3) 마스코트(오른쪽 아래에서 빼꼼)
m = Image.open(sys.argv[1]).convert('RGBA'); bb = m.getbbox(); m = m.crop(bb)
s = 660 / m.height; m = m.resize((int(m.width * s), int(m.height * s)), Image.LANCZOS)
im.alpha_composite(m, (W - m.width + 40, H - m.height + 200))

# 4) 제목
d = ImageDraw.Draw(im)
band = Image.new('RGBA', (W, 560), (0, 0, 0, 0)); bd = ImageDraw.Draw(band)
for y in range(560): bd.line([(0, y), (W, y)], fill=(12, 10, 12, int(235 * (1 - max(0, y - 420) / 140))))
im.alpha_composite(band, (0, 0))
d.text((W // 2, 150), "반도체 오를 때마다 쾅…", font=f(76, False), fill=(240, 236, 228), anchor='ma')
d.text((W // 2, 262), "누가 누르나?", font=f(150), fill=YEL, anchor='ma', stroke_width=6, stroke_fill=(20, 16, 10))
im.convert('RGB').save(sys.argv[2], quality=92)
print('ok', sys.argv[2])

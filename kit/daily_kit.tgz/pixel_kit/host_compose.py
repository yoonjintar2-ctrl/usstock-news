"""8비트 + 마스코트 풀샷 컷 합성기 (2026-11-10 새 진행 방식 · press_video 첫 적용)
python3 host_compose.py <spec.json> <px_dir> <mascot_root> <mix.wav> <out.mp4> [n_frames]
spec: {total, hosts:[{k,t0,t1,fade_in}], bubbles:[{t0,t1,text,first,last}], subs:[{t0,t1,text}], clips:[{t0,kind,cx,foot,scale}](선택)}
 · mascot_root/host_<k>/NNNNN.png = talk_render.py MODE=host 프레임(600×800, STEP=2면 짝수 프레임만)
 · 풀샷 컷: 마스코트 1.72배 아래 중앙(발끝 y≈1830) + 위쪽 흰 말풍선(꼬리 ↓). 전환 가림막과 겹치지 않게 들어올 때 0.42초 뒤 페이드인, 끝나기 0.3초 전 페이드아웃
 · 본론 컷: 원형 인서트 없음, 하단 흰 자막(y≈1250, 중심 x 500 — 쇼츠 오른쪽 버튼 열 피함). {강조}는 노란 글자(빨강·초록 금지)"""
import sys, os, json, re, math, subprocess, functools
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FPS = 30; W, H = 1080, 1920
FB = '/home/claude/pixel_kit/fonts/pretendard/Pretendard-Bold.otf'      # 말풍선·자막 = 프리텐다드(10/30 지시: 기본 폰트 말고 깔끔한 글씨체)
FX = '/home/claude/pixel_kit/fonts/pretendard/Pretendard-ExtraBold.otf'
INK = (22, 26, 42); YEL = (255, 214, 64)
M_SCALE = float(os.environ.get('M_SCALE', 1.72)); M_FOOT = 1830; M_CX = 540
BUB_CY = 470; BUB_MAXW = 860
GRADE = [float(v) for v in os.environ['GRADE'].split(',')] if os.environ.get('GRADE') else None
SUB_TOP = 1290            # 하단 자막 위치(8비트 결과 도장과 겹치지 않게, 쇼츠 하단 UI 위)

def ease(u): u = min(1.0, max(0.0, u)); return u * u * (3 - 2 * u)
def back(u, s=1.6): u = min(1.0, max(0.0, u)) - 1; return u * u * ((s + 1) * u + s) + 1

def parse(line):
    return [(m.group(1), True) if m.group(1) is not None else (m.group(2), False) for m in re.finditer(r'\{([^}]*)\}|([^{]+)', line)]

@functools.lru_cache(None)
def font(size, fp=FB): return ImageFont.truetype(fp, size)

def text_block(text, size, maxw):
    lines = [parse(l) for l in text.split('\n')]
    tmp = ImageDraw.Draw(Image.new('RGB', (1, 1)))
    while True:
        f = font(size)
        ws = [sum(tmp.textlength(s, font=f) for s, _ in segs) for segs in lines]
        if max(ws) <= maxw or size <= 30: return lines, f, ws, size
        size -= 2

@functools.lru_cache(None)
def bubble_img(text):
    """흰 말풍선, 글자는 가로·세로 정중앙 + 넉넉한 여백(10/30 지시: 덜 꽉 차 보이게)"""
    lines, f, ws, size = text_block(text, 50, BUB_MAXW - 120)
    lh = int(size * 1.42); pw, ph = 62, 40
    bw = int(max(ws)) + 2 * pw; bh = lh * len(lines) + 2 * ph; tail = 46
    S = 2
    im = Image.new('RGBA', ((bw + 16) * S, (bh + tail + 16) * S), (0, 0, 0, 0))
    o = 8 * S
    sh = Image.new('RGBA', im.size, (0, 0, 0, 0)); ds = ImageDraw.Draw(sh)
    ds.rounded_rectangle([o, o + 10 * S, o + bw * S, o + bh * S + 10 * S], radius=44 * S, fill=(0, 0, 0, 110))
    im = Image.alpha_composite(im, sh.filter(ImageFilter.GaussianBlur(8 * S))); d = ImageDraw.Draw(im)
    cx = o + bw * S // 2
    d.rounded_rectangle([o, o, o + bw * S, o + bh * S], radius=44 * S, fill=(252, 252, 250, 255), outline=INK + (255,), width=5 * S)
    d.polygon([(cx - 26 * S, o + bh * S - 6 * S), (cx + 26 * S, o + bh * S - 6 * S), (cx, o + (bh + tail) * S)], fill=INK + (255,))
    d.polygon([(cx - 17 * S, o + bh * S - 9 * S), (cx + 17 * S, o + bh * S - 9 * S), (cx, o + (bh + tail - 12) * S)], fill=(252, 252, 250, 255))
    fS = ImageFont.truetype(FB, size * S)
    for i, segs in enumerate(lines):
        x = cx - ws[i] * S / 2; ym = o + ph * S + (i + 0.5) * lh * S          # 줄 세로 중심
        for s, em in segs:
            wseg = d.textlength(s, font=fS)
            if em: d.rounded_rectangle([x - 4 * S, ym + size * S * 0.02, x + wseg + 4 * S, ym + size * S * 0.46], radius=6 * S, fill=YEL + (235,))
            d.text((x, ym), s, font=fS, fill=INK + (255,), anchor='lm'); x += wseg
    im = im.resize((im.width // S, im.height // S), Image.LANCZOS)
    return im, cx // S, o // S + bh + tail          # 이미지, 꼬리 x, 꼬리 끝 y

@functools.lru_cache(None)
def sub_img(text):
    lines, f, ws, size = text_block(text, 54, 760)
    f = font(size, FX); lh = int(size * 1.32)
    im = Image.new('RGBA', (W, lh * len(lines) + 30), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for i, segs in enumerate(lines):
        x = 500 - ws[i] / 2; y = 10 + i * lh
        for s, em in segs:
            d.text((x, y), s, font=f, fill=YEL if em else (255, 255, 255), stroke_width=7, stroke_fill=(0, 0, 0)); x += d.textlength(s, font=f)
    return im

def paste(fr, im, x, y, a=1.0, scale=1.0):
    if a <= 0.004: return
    if abs(scale - 1) > 1e-3:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.BICUBIC)
    x, y = int(round(x)), int(round(y))
    x0, y0 = max(0, x), max(0, y); x1, y1 = min(W, x + im.width), min(H, y + im.height)
    if x1 <= x0 or y1 <= y0: return
    arr = np.asarray(im, dtype=np.float32)[y0 - y:y1 - y, x0 - x:x1 - x]
    al = arr[..., 3:4] / 255.0 * a
    fr[y0:y1, x0:x1] = fr[y0:y1, x0:x1] * (1 - al) + arr[..., :3] * al

SHADOW = None
def shadow():
    global SHADOW
    if SHADOW is None:
        im = Image.new('RGBA', (520, 90), (0, 0, 0, 0)); ImageDraw.Draw(im).ellipse([20, 20, 500, 70], fill=(0, 0, 0, 215 if GRADE else 150))
        SHADOW = im.filter(ImageFilter.GaussianBlur(12))
    return SHADOW

@functools.lru_cache(maxsize=8)
def mascot(path):
    im = Image.open(path).convert('RGBA')
    im = im.resize((int(im.width * M_SCALE), int(im.height * M_SCALE)), Image.LANCZOS)
    if GRADE:    # 11/11 v3: 배경에 묻히게 — 아래로 갈수록 어둡게 + 배경색을 살짝 섞음(GRADE="r,g,b" 배경 평균색)
        a = np.asarray(im, dtype=np.float32).copy(); y = np.linspace(0, 1, a.shape[0])[:, None, None]
        a[..., :3] *= 1 - 0.12 * np.clip((y - 0.5) / 0.5, 0, 1); a[..., :3] = a[..., :3] * 0.97 + np.array(GRADE, np.float32) * 0.03
        im = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA')
    return im

CLIP_DIR = os.environ.get('CLIP_DIR', '/mnt/user-data/outputs/mascot_clips'); _CLIPC = {}
def clip_frame(kind, i):
    """미리 렌더한 반응 클립(mascot_clips/<동작>.webm, VP9 알파)을 처음 쓸 때 PNG로 풀어 두고 i번째 프레임을 돌려줌"""
    if kind not in _CLIPC:
        d = f'/tmp/mclip_{kind}'; os.makedirs(d, exist_ok=True)
        if not os.listdir(d): subprocess.run(['ffmpeg', '-y', '-v', 'error', '-c:v', 'libvpx-vp9', '-i', f'{CLIP_DIR}/{kind}.webm', '-pix_fmt', 'rgba', f'{d}/%05d.png'], check=True)
        _CLIPC[kind] = sorted(os.listdir(d))
    fs = _CLIPC[kind]; i = min(len(fs) - 1, max(0, i)); return Image.open(f'/tmp/mclip_{kind}/{fs[i]}').convert('RGBA'), len(fs)

def host_alpha(h, t, total):
    a = 1.0
    if h['fade_in']: a *= ease((t - h['t0'] - 0.42) / 0.2)
    if h['t1'] < total - 0.01: a *= 1 - ease((t - (h['t1'] - 0.30)) / 0.25)
    return a

def bubble_state(b, t, nxt):
    """(alpha, scale): 첫 줄은 팝(오버슈트), 마지막 줄 끝나면 쪼그라들며 사라짐, 중간 교체는 살짝 튕김"""
    if t < b['t0'] - 0.06 or t > b['t1'] + 0.22: return 0, 1
    u = (t - b['t0'] + 0.06) / 0.26
    if b['first']: sc = 0.55 + 0.45 * back(u); a = ease(u * 1.6)
    else: sc = 1 + 0.05 * math.sin(min(1, max(0, u)) * math.pi); a = 1
    if t > b['t1']:
        if b['last'] or nxt is None or nxt['t0'] > b['t1'] + 0.05:
            v = ease((t - b['t1']) / 0.2); sc *= 1 - 0.4 * v; a *= 1 - v
        else: return 0, 1
    return a, sc

def main():
    sp, pxdir, mroot, wav, out = sys.argv[1:6]
    S = json.load(open(sp)); total = S['total']
    n = int(sys.argv[6]) if len(sys.argv) > 6 else int(total * FPS)
    step = int(os.environ.get('STEP', 1))
    p = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                          '-i', wav, '-t', f'{n / FPS:.3f}', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p',
                          '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-shortest',
                          '-movflags', '+faststart', out], stdin=subprocess.PIPE)
    B = S['bubbles']
    for i in range(n):
        t = i / FPS
        fr = np.asarray(Image.open(os.path.join(pxdir, f'{i:05d}.png')).convert('RGB'), dtype=np.float32).copy()
        gfade = min(1.0, max(0.0, (total - t) / 0.8))
        for h in S['hosts']:
            if not (h['t0'] <= t < h['t1']): continue
            a = host_alpha(h, t, total) * gfade
            loc = int(round((t - h['t0']) * FPS)) // step * step
            mp = os.path.join(mroot, f"host_{h['k']}", f'{loc:05d}.png')
            while not os.path.exists(mp) and loc > 0: loc -= step; mp = os.path.join(mroot, f"host_{h['k']}", f'{loc:05d}.png')
            if os.path.exists(mp):
                m = mascot(mp)
                paste(fr, shadow(), M_CX - 260, M_FOOT - 55, a * 0.9)
                paste(fr, m, M_CX - 301 * M_SCALE, M_FOOT - 790 * M_SCALE, a)
        for c in S.get('clips', []):      # 반응 클립 끼워 넣기: {"t0":12.3,"kind":"wow","cx":820,"foot":1240,"scale":0.8} — 본론 장면 구석에 마스코트 리액션
            im, nf = clip_frame(c['kind'], int(round((t - c['t0']) * FPS))) if c['t0'] <= t < c['t0'] + 10 else (None, 0)
            if im is None or t >= c['t0'] + nf / FPS: continue
            u = (t - c['t0']); a = ease(u / 0.15) * (1 - ease((u - (nf / FPS - 0.2)) / 0.2)) * gfade; sc = c.get('scale', 0.8) * (0.85 + 0.15 * back(u / 0.25))
            paste(fr, im, c.get('cx', 820) - 240 * sc, c.get('foot', 1240) - 630 * sc, a, sc)
        for j, b in enumerate(B):
            a, sc = bubble_state(b, t, B[j + 1] if j + 1 < len(B) else None)
            if a <= 0: continue
            im, tx, ty = bubble_img(b['text'])
            # 꼬리 끝을 기준으로 스케일(말풍선이 마스코트 쪽에서 튀어나오는 느낌)
            ax, ay = M_CX, BUB_CY + im.height / 2 - 8
            paste(fr, im, ax - tx * sc, ay - ty * sc, a * gfade, sc)
        for s in S['subs']:
            if s['t0'] <= t < s['t1']:
                a = ease((t - s['t0']) / 0.08) * (1 - ease((t - s['t1'] + 0.08) / 0.08)) * gfade
                paste(fr, sub_img(s["text"]), 0, SUB_TOP, a)
        p.stdin.write(np.clip(fr, 0, 255).astype(np.uint8).tobytes())
        if i % 300 == 0: print(i, '/', n, flush=True)
    p.stdin.close(); p.wait(); print('done', out)

if __name__ == '__main__':
    main()

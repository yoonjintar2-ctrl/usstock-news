"""마스코트 말풍선 자막 (10/30 사용자 지시: 자막을 마스코트가 말하는 것처럼 말풍선으로)
- 말할 때 팝(오버슈트)으로 생기고, 말이 끊기면 꼬리 쪽으로 쪼그라들며 사라짐
- 이어지는 대사는 말풍선이 유지된 채 크기가 부드럽게 바뀌며 글자만 교체(살짝 튕김)
- 종류: n 보통(둥근 말풍선) · s 외침(만화 뾰족 말풍선, 테두리가 부글부글 + 흔들림) · t 생각(구름 + 점점 작은 방울 3개)
- 강조 {단어}: 형광펜이 왼쪽→오른쪽으로 그어짐 (상승/하락 색 구분 금지 규칙 때문에 글자색은 바꾸지 않음)
- 위치: 원형 마스코트(왼쪽 아래, 238px · top 1060) 오른쪽, 쇼츠 오른쪽 버튼 열·하단 설명 영역 침범 금지
사용: track = BubbleTrack(bubbles); frame_rgba = track.draw(frame_bgr_float, t)"""
import math, re
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

FB = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FK = '/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc'
SS = 2                                     # 슈퍼샘플링
PIP_CX, PIP_CY, PIP_R = 52 + 119, 1060 + 119, 119
TIP = (296, 1128)                          # 꼬리 끝(원 테두리 오른쪽 위 바로 밖)
BODY_X0 = 338                              # 말풍선 몸통 왼쪽
BODY_CY = 1098                             # 몸통 세로 중심
X_MAX = 900                                # 오른쪽 한계(쇼츠 버튼 열 침범 금지)
Y_MIN, Y_MAX = 948, 1330
INK = (22, 26, 42)
FILL = {'n': (252, 252, 250), 's': (255, 214, 64), 't': (238, 242, 255)}
MARK = {'n': (255, 214, 64, 230), 's': (255, 255, 255, 235), 't': (255, 214, 64, 230)}
OPEN, CLOSE, MORPH = 0.30, 0.20, 0.24

def _font(style, size):
    return ImageFont.truetype(FK if style == 's' else FB, size, index=1)

def parse(text):
    """'{강조}' → [[(문자열, 강조여부), ...] 줄별]"""
    out = []
    for line in text.split('\n'):
        segs = []
        for m in re.finditer(r'\{([^}]*)\}|([^{]+)', line):
            if m.group(1) is not None: segs.append((m.group(1), True))
            else: segs.append((m.group(2), False))
        out.append(segs)
    return out

def ease(u): u = min(1.0, max(0.0, u)); return u * u * (3 - 2 * u)
def back_out(u, k=1.9):
    u = min(1.0, max(0.0, u)); u -= 1; return 1 + u * u * ((k + 1) * u + k)

class Layout:
    """한 대사의 글자 배치와 몸통 크기"""
    def __init__(self, text, style):
        self.style = style; self.lines = parse(text)
        size = 50 if style == 's' else 44
        maxw = X_MAX - BODY_X0 - (90 if style == 's' else 70)
        while True:
            f = _font(style, size)
            ws = [sum(f.getlength(s) for s, _ in ln) for ln in self.lines]
            if max(ws) <= maxw or size <= 30: break
            size -= 2
        self.f, self.size, self.ws = f, size, ws
        self.lh = int(size * 1.32)
        padx, pady = (46, 34) if style == 's' else (34, 24)
        self.w = int(max(ws) + 2 * padx); self.h = int(len(self.lines) * self.lh + 2 * pady - (self.lh - size) * 0.5)
        self.w = max(self.w, 220)

def body_rect(w, h):
    cy = min(max(BODY_CY, Y_MIN + h / 2), Y_MAX - h / 2)
    return BODY_X0, cy - h / 2, BODY_X0 + w, cy + h / 2

def _shape_mask(style, w, h, t, canvas, off, seed=0):
    """몸통+꼬리 마스크(슈퍼샘플). canvas=(W,H) 1x, off=캔버스 원점(1x 전역좌표)"""
    W_, H_ = canvas
    m = Image.new('L', (W_ * SS, H_ * SS), 0); d = ImageDraw.Draw(m)
    x0, y0, x1, y1 = body_rect(w, h)
    P = lambda x, y: ((x - off[0]) * SS, (y - off[1]) * SS)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if style == 'n':
        d.rounded_rectangle([*P(x0, y0), *P(x1, y1)], radius=int(min(h / 2, 44) * SS), fill=255)
    elif style == 's':
        rng = np.random.default_rng(seed)
        n = 22; pts = []
        rx, ry = w / 2 + 22, h / 2 + 26
        for k in range(2 * n):
            a = math.pi * k / n + 0.13
            r = (1.0 + rng.uniform(-0.04, 0.10)) if k % 2 == 0 else 0.80 + rng.uniform(-0.02, 0.03)
            pts.append(P(cx + math.cos(a) * rx * r, cy + math.sin(a) * ry * r))
        d.polygon(pts, fill=255)
        d.ellipse([*P(cx - rx * 0.82, cy - ry * 0.80), *P(cx + rx * 0.82, cy + ry * 0.80)], fill=255)
    else:  # 생각 구름
        rx, ry = w / 2, h / 2
        d.ellipse([*P(x0 + 6, y0 + 6), *P(x1 - 6, y1 - 6)], fill=255)
        n = max(9, int((w + h) / 52))
        for k in range(n):
            a = 2 * math.pi * k / n
            r = min(rx, ry) * 0.34 + (k % 2) * 6
            ex, ey = cx + math.cos(a) * (rx - r * 0.55), cy + math.sin(a) * (ry - r * 0.55)
            d.ellipse([*P(ex - r, ey - r), *P(ex + r, ey + r)], fill=255)
    # 꼬리
    if style in ('n', 's'):
        by0, by1 = cy + h * 0.06, cy + h * 0.30
        if style == 's': by0, by1 = cy + h * 0.10, cy + h * 0.32
        bx = x0 + (34 if style == 'n' else 26)
        base_a, base_b = (bx, by0), (bx + 6, by1)
        tip = TIP
        def bez(p0, c, p1, n=12): return [((1 - u) ** 2 * p0[0] + 2 * (1 - u) * u * c[0] + u * u * p1[0], (1 - u) ** 2 * p0[1] + 2 * (1 - u) * u * c[1] + u * u * p1[1]) for u in np.linspace(0, 1, n)]
        c1 = ((base_a[0] + tip[0]) / 2 + 4, (base_a[1] + tip[1]) / 2 - 8); c2 = ((base_b[0] + tip[0]) / 2 + 10, (base_b[1] + tip[1]) / 2 + 6)
        poly = bez(base_a, c1, tip) + bez(tip, c2, base_b)[1:]
        d.polygon([P(*q) for q in poly], fill=255)
    return np.asarray(m, np.float32) / 255.0

def think_dots(t_local, scale):
    """생각 방울 3개: 원 쪽에서 몸통 쪽으로 차례로 퐁"""
    x0, y0, x1, y1 = body_rect(10, 10)
    pts = [(TIP[0] - 8, TIP[1] + 10, 9), (TIP[0] + 14, TIP[1] - 8, 13), (TIP[0] + 38, TIP[1] - 30, 17)]
    out = []
    for k, (x, y, r) in enumerate(pts):
        u = back_out((t_local - k * 0.07) / 0.2, 2.2)
        if u > 0.02: out.append((x, y, r * u * scale))
    return out

class BubbleTrack:
    def __init__(self, bubbles):
        self.E = [dict(b) for b in sorted(bubbles, key=lambda b: b['t0'])]
        for e in self.E:
            e['L'] = Layout(e['text'], e['style']); e['show0'] = e['t0'] - 0.07; e['show1'] = e['t1'] + 0.30
        # 체인: 같은 종류가 0.45초 안에 이어지면 말풍선 유지
        self.chains = []; cur = [0]
        for i in range(1, len(self.E)):
            a, b = self.E[i - 1], self.E[i]
            if b['style'] == a['style'] and b['show0'] - a['show1'] < 0.45: cur.append(i)
            else: self.chains.append(cur); cur = [i]
        self.chains.append(cur)

    def state(self, t):
        for ch in self.chains:
            s0 = self.E[ch[0]]['show0']; s1 = self.E[ch[-1]]['show1']
            if s0 <= t < s1 + CLOSE:
                j = ch[0]
                for i in ch:
                    if self.E[i]['show0'] <= t: j = i
                return ch, j, s0, s1
        return None

    def draw(self, fr, t):
        """fr: HxWx3 float BGR 프레임에 말풍선 합성 (제자리 수정)"""
        st = self.state(t)
        if st is None: return fr
        ch, j, s0, s1 = st
        e = self.E[j]; style = e['style']; L = e['L']
        # 크기 모핑(체인 안에서 대사 바뀔 때)
        k = ch.index(j); morph = 1.0; prevL = None
        if k > 0:
            m = (t - e['show0']) / MORPH
            if m < 1: morph = ease(m); prevL = self.E[ch[k - 1]]['L']
        w = L.w if prevL is None else prevL.w + (L.w - prevL.w) * morph
        h = L.h if prevL is None else prevL.h + (L.h - prevL.h) * morph
        # 전체 스케일·알파
        if t < s0 + OPEN:
            u = (t - s0) / OPEN
            sc = 0.15 + 0.85 * back_out(u, 2.6 if style == 's' else 1.9); al = ease(u / 0.45)
        elif t >= s1:
            v = (t - s1) / CLOSE
            sc = 1 - 0.38 * ease(v) if style != 't' else 1 + 0.08 * math.sin(min(1, v) * math.pi) - 0.3 * ease(v)
            al = 1 - ease(v)
        else:
            sc = 1.0; al = 1.0
        if prevL is not None and morph < 1: sc *= 1 + 0.035 * math.sin(morph * math.pi)
        sc *= 1 + 0.006 * math.sin(t * 2 * math.pi / 1.7)                                     # 숨쉬듯
        rot = 0.0; shx = shy = 0.0
        if style == 's':
            ts = t - s0
            rot = 5.0 * math.exp(-ts * 6) * math.sin(ts * 38)                                # 착지 흔들림
            shx = 2.0 * math.sin(t * 61) * (0.4 + 0.6 * math.exp(-ts * 4)); shy = 1.5 * math.cos(t * 53) * (0.4 + 0.6 * math.exp(-ts * 4))
        floaty = 3.0 * math.sin(t * 2 * math.pi / 2.2)
        # 캔버스(1x 전역 영역)
        x0, y0, x1, y1 = body_rect(w, h)
        pad = 60
        ox, oy = int(min(TIP[0] - 30, x0 - pad)), int(y0 - pad); W_, H_ = int(x1 + pad - ox), int(max(y1, TIP[1]) + pad - oy)
        seed = int(t * 10) if style == 's' else 0                                          # 외침 테두리 부글부글(0.1초마다)
        mask = _shape_mask(style, w, h, t, (W_, H_), (ox, oy), seed)
        ow = (7 if style == 's' else 6) * SS
        ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * ow + 1, 2 * ow + 1))
        outline = cv2.dilate(mask, ker)
        img = np.zeros((H_ * SS, W_ * SS, 4), np.float32)
        # 그림자(오른쪽 아래로 살짝)
        shadow = np.roll(np.roll(outline, 9 * SS, 0), 6 * SS, 1); shadow = cv2.GaussianBlur(shadow, (0, 0), 3 * SS) * 0.38
        img[..., 3] = shadow
        def over(rgb, a):
            a = a[..., None]; img[..., :3] = img[..., :3] * (1 - a) + np.array(rgb, np.float32) * a; img[..., 3:] = img[..., 3:] * (1 - a) + a
        over(INK[::-1], outline); over(FILL[style][::-1], mask)
        if style == 't':
            # 구름 안쪽 은은한 하이라이트
            pass
        pim = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8) if False else np.zeros((1, 1, 4), np.uint8))
        # ---- 글자 (PIL, 슈퍼샘플)
        txt = Image.new('RGBA', (W_ * SS, H_ * SS), (0, 0, 0, 0)); dt = ImageDraw.Draw(txt)
        def put_text(Lx, a_mul, t_in):
            if a_mul <= 0.01: return
            f = ImageFont.truetype(Lx.f.path, Lx.size * SS, index=1)
            bx0, by0, bx1, by1 = body_rect(Lx.w if prevL is None else w, Lx.h if prevL is None else h)
            n = len(Lx.lines); tot = n * Lx.lh
            ytop = (by0 + by1) / 2 - tot / 2 + (Lx.lh - Lx.size) * 0.15
            for li, segs in enumerate(Lx.lines):
                u = ease((t_in - 0.06 * li) / 0.16); a_line = u * a_mul
                if a_line <= 0.01: continue
                lw = Lx.ws[li]; x = (bx0 + bx1) / 2 - lw / 2; y = ytop + li * Lx.lh + (1 - u) * 10
                for s, emph in segs:
                    sw = Lx.f.getlength(s)
                    if emph:
                        hu = ease((t_in - 0.25 - 0.06 * li) / 0.28)
                        if hu > 0:
                            mc = MARK[style]
                            dt.rounded_rectangle([(x - 4 - ox) * SS, (y + Lx.size * 0.52 - oy) * SS, (x - 4 + (sw + 8) * hu - ox) * SS, (y + Lx.size * 1.12 - oy) * SS],
                                                 radius=6 * SS, fill=(mc[0], mc[1], mc[2], int(mc[3] * a_line)))
                    dt.text(((x - ox) * SS, (y - oy) * SS), s, font=f, fill=(INK[0], INK[1], INK[2], int(255 * a_line)))
                    x += sw
        if prevL is not None and morph < 1:
            put_text(prevL, 1 - ease(morph / 0.5), 9.0)
            put_text(L, ease((morph - 0.4) / 0.6), (t - e['show0'] - MORPH * 0.4))
        else:
            put_text(L, 1.0, t - (s0 + OPEN * 0.35) if k == 0 else t - e['show0'] - MORPH * 0.4)
        ta = np.asarray(txt, np.float32); a = ta[..., 3:4] / 255.0
        img[..., :3] = img[..., :3] * (1 - a) + ta[..., 2::-1][..., :3] * a
        # 슈퍼샘플 → 1x
        img = cv2.resize(img, (W_, H_), interpolation=cv2.INTER_AREA)
        # 생각 방울
        dots = think_dots(t - s0, 1.0 if t < s1 else max(0, 1 - (t - s1) / CLOSE)) if style == 't' else []
        # 변환: 꼬리 끝을 기준으로 스케일·회전
        piv = (TIP[0] - ox, TIP[1] - oy)
        M = cv2.getRotationMatrix2D(piv, rot, sc); M[0, 2] += TIP[0] - piv[0] + shx - 0; M[1, 2] += TIP[1] - piv[1] + shy + floaty
        # 전역 좌표 영역에 바로 워프
        Hf, Wf = fr.shape[:2]
        gx0, gy0 = max(0, int(ox - 80)), max(0, int(oy - 80)); gx1, gy1 = min(Wf, int(ox + W_ + 80)), min(Hf, int(oy + H_ + 80))
        M[0, 2] -= gx0; M[1, 2] -= gy0
        # M은 캔버스→전역(원점 TIP 기준) 이므로 캔버스 원점 보정
        M[0, 2] += 0; M[1, 2] += 0
        warped = cv2.warpAffine(img, M, (gx1 - gx0, gy1 - gy0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        a = warped[..., 3:4] / 255.0 * al
        reg = fr[gy0:gy1, gx0:gx1]
        reg[:] = reg * (1 - a) + warped[..., :3] * a
        for (x, y, r) in dots:
            if r < 1: continue
            for rr, col in ((r + 5, INK[::-1]), (r, FILL['t'][::-1])):
                yy, xx = np.mgrid[gy0:gy1, gx0:gx1]
                mm = np.clip(rr - np.sqrt((xx - x) ** 2 + (yy - y - floaty) ** 2) + 0.5, 0, 1)[..., None] * al
                reg[:] = reg * (1 - mm) + np.array(col, np.float32) * mm
        return fr

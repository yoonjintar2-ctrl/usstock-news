"""특별편 · 10월 반도체 대폭락! 무슨 일이 있었나? (ackman_video.py 복사 → 대본·장면·효과음 교체 · 레퍼런스 효과 픽셀판 재사용)
사실 확인(2026-10-13): 아시아투데이·포인트경제(10/12 마감 수치·수급), 뉴스핌(CXMT 4F² · 트렌드포스 점유율), 뉴스1(10/12 뉴욕 마감), TradingKey(샌디스크 장중 · 모닝스타 시각)
규칙(10/12~): 급락 알럿은 급락이 그래프에 반영되기 '전에' 띄우고, 그 다음 급락을 보여 준다.
"""
import os, sys, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import sandisk_video as sv
from sandisk_video import ctext, header, box, slam, CX, SX0, SX1, BLUE, SRED, PURP, WHT2, sub_img, chip
from make_video import (W, H, FW, FH, FPS, F24, F12, F9, WHITE, YEL, RED, GRN, CYAN, ORG, GRAY, DIM, BG, FD,
                        lerp, clamp, prog, ease, blink, bg_img, text, square, fly, tone, mtof, SR)
import mid_video as mv
from nike_video import (put, debris, confetti, stamp_slam, crack, warn_icon, render_frame, dk, SKIN, DARK)
from gap_video import mini_person
from option_video import big_text, chapter_flash, target_lock, bars, glitch_text, marquee, coin, calendar, F36, GOLD
from ackman_video import up_arrow, money_bag, tower

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "semicrash/out"); os.makedirs(OUT, exist_ok=True)
VOICE_SID, SPEED = 1, 1.05
LEAD, GAP, TAIL = 0.3, 0.28, 0.6
TEAL = (60, 200, 190)

# ================================================================ drawings
def alert_card(img, d, t, t0, t1, cx=CX, cy=172, label="급락 경보", sub="ALERT"):
    """급락 직전에 뜨는 경보 카드 (t0~t1). 이 카드가 사라진 뒤에 급락이 그려진다."""
    if not (t0 <= t < t1): return
    vis, o = slam(t, t0, 0.18)
    x0, x1, y0, y1 = cx - 64, cx + 64, cy - 22 + o, cy + 22 + o
    d.rectangle([x0, y0, x1, y1], fill=(44, 8, 14), outline=SRED if blink(t, 6) else YEL, width=2)
    warn_icon(d, x0 + 8, y0 + 8, YEL if blink(t, 6) else ORG)
    d.text((cx + 10, y0 + 6), label, font=F12, fill=WHITE, anchor="ma")
    d.text((cx + 10, y0 + 24), sub, font=F9, fill=SRED, anchor="ma")

def wiggle(x, base, seed): return base + 4 * math.sin(x * 0.13 + seed) + 2 * math.sin(x * 0.41 + seed * 2)

def crash_line(d, x0, xs, x1, base, drop, uf, ud, col, seed, width=2):
    """x0→xs 횡보(uf), xs→x1 급락(ud)"""
    pts = [(x, wiggle(x, base, seed)) for x in range(x0, int(x0 + (xs - x0) * uf) + 1, 2)]
    if ud > 0:
        for x in range(xs, int(xs + (x1 - xs) * ud) + 1, 2):
            pts.append((x, wiggle(x, base, seed) + drop * ease((x - xs) / (x1 - xs))))
    if len(pts) > 1: d.line(pts, fill=col, width=width)
    return pts[-1] if pts else None

def f2(d, x, y, s, col, font=F12, anchor="la"):
    d.text((x, y), s, font=font, fill=col, anchor=anchor)

def factory(d, x, y, t, sign="CXMT", col=(150, 120, 110)):
    d.rectangle([x, y + 30, x + 70, y + 80], fill=dk(col, 0.5), outline=col)
    for k in range(3): d.polygon([(x + k * 23, y + 30), (x + k * 23 + 23, y + 30), (x + k * 23 + 23, y + 18)], fill=dk(col, 0.7), outline=col)
    d.rectangle([x + 52, y, x + 62, y + 30], fill=dk(col, 0.6), outline=col)
    for k in range(3):
        u = ((t * 0.8 + k / 3) % 1); r = 3 + int(5 * u)
        cxs, cys = x + 57 + int(8 * u), y - 4 - int(22 * u)
        d.ellipse([cxs - r, cys - r, cxs + r, cys + r], outline=dk(WHT2, 1 - 0.5 * u))
    for c in range(3):
        d.rectangle([x + 8 + c * 20, y + 44, x + 18 + c * 20, y + 54], fill=YEL if blink(t + c * 0.4, 1.5) else (60, 60, 80))
    d.rectangle([x + 8, y + 62, x + 62, y + 76], fill=DARK, outline=SRED)
    d.text((x + 35, y + 64), sign, font=F9, fill=WHITE, anchor="ma")

def news_card(d, x, y, o, head, col):
    d.rectangle([x, y + o, x + 182, y + 20 + o], fill=(14, 16, 32), outline=col)
    d.rectangle([x, y + o, x + 6, y + 20 + o], fill=col)
    d.text((x + 12, y + 5 + o), head, font=F9, fill=WHITE)

def zz(d, x, y, t):
    for k in range(2):
        u = (t * 0.7 + k * 0.5) % 1
        d.text((x + int(6 * u) + k * 5, y - int(12 * u)), "z" if k == 0 else "Z", font=F9, fill=dk(CYAN, 1 - 0.6 * u))

def cells(d, x, y, w, h, cw, ch, col, u):
    n = 0; total = (w // cw) * (h // ch)
    for r in range(h // ch):
        for c in range(w // cw):
            if n < int(total * u + 1e-6):
                d.rectangle([x + c * cw, y + r * ch, x + (c + 1) * cw - 2, y + (r + 1) * ch - 2], fill=dk(col, 0.7), outline=col)
            n += 1
    return total

def hbm_stack(d, x, y, col=GOLD, n=5):
    for k in range(n):
        yy = y + 34 - k * 7
        d.rectangle([x, yy, x + 40, yy + 6], fill=dk(col, 0.55 + k * 0.08), outline=col)
    d.rectangle([x - 6, y + 41, x + 46, y + 46], fill=(40, 60, 50), outline=GRN)

def shield(d, x, y, col=GRN):
    d.polygon([(x, y), (x + 16, y), (x + 16, y + 12), (x + 8, y + 20), (x, y + 12)], fill=dk(col, 0.6), outline=col)
    d.line([(x + 4, y + 9), (x + 7, y + 13), (x + 12, y + 5)], fill=WHITE, width=2)

def flask(d, x, y, t):
    d.rectangle([x + 8, y, x + 16, y + 12], outline=WHT2)
    d.polygon([(x + 8, y + 12), (x + 16, y + 12), (x + 24, y + 32), (x, y + 32)], fill=(40, 70, 90), outline=WHT2)
    d.polygon([(x + 4, y + 22), (x + 20, y + 22), (x + 24, y + 32), (x, y + 32)], fill=TEAL)
    for k in range(2):
        u = (t * 1.2 + k * 0.5) % 1
        d.ellipse([x + 9 + k * 4, y + 18 - int(14 * u), x + 12 + k * 4, y + 21 - int(14 * u)], outline=TEAL)

def qmark(d, x, y, t, col=YEL):
    if blink(t, 2.5): d.text((x, y), "?", font=F12, fill=col, anchor="ma")

# ================================================================ scenes
def s_hook(img, d, t, seg, dur):
    header(d, t, "특별편 · 2026.10.12", "반도체 대폭락!", "무슨 일이 있었나?", SRED)
    box(d, 34, 122, 216, 234, DIM)
    d.rectangle([40, 127, 44, 131], fill=SRED); d.text((48, 125), "SK하이닉스", font=F9, fill=SRED)
    d.rectangle([110, 127, 114, 131], fill=BLUE); d.text((118, 125), "삼성전자", font=F9, fill=BLUE)
    uf = ease(prog(t, 0.3, 1.4)); ud = prog(t, 2.75, 3.45)
    crash_line(d, 42, 158, 210, 156, 50, uf, ud, SRED, 1)
    crash_line(d, 42, 158, 210, 172, 44, uf, ud, BLUE, 4)
    if 1.4 < t < 2.75: d.line([(158, 140), (158, 226)], fill=DIM)
    alert_card(img, d, t, 1.5, 2.7, CX, 176)                           # 경보 먼저
    if t > 3.45:                                                        # 급락이 그려진 뒤 수치
        glitch_text(img, 82, 196, "-4%대", F24, SRED, t, 6 if t < 4.0 else 1)
        crack(d, 170, 150, 206, 226, t, 3.3, WHITE, 2)
    rows = [(3.6, "SK하이닉스", "1,605,000원", "-4.52%", SRED), (3.9, "삼성전자", "250,500원", "-4.39%", BLUE)]
    for i, (ts, nm, px, pc, col) in enumerate(rows):
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 240 + i * 21 + o
        d.rectangle([34, y, 216, y + 18], fill=(10, 14, 30), outline=col)
        d.text((40, y + 3), nm, font=F12, fill=WHITE); d.text((150, y + 5), px, font=F9, fill=GRAY, anchor="ra")
        d.text((212, y + 3), pc, font=F12, fill=col, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.1, 0.2)
        d.rectangle([34, 286 + o, 216, 312 + o], fill=(40, 10, 16), outline=SRED if blink(t, 3) else ORG)
        d.text((42, 292 + o), "코스피 6,384.24", font=F12, fill=WHITE)
        d.text((210, 292 + o), "-3.65%", font=F12, fill=SRED, anchor="ra")
        debris(d, 180, 299, t, seg[1] + 0.1, 12, (SRED, WHITE, ORG), 45, 0.7, 2)
    if t > seg[1] + 1.2:
        stamp_slam(img, 168, 196, "폭락", SRED, t, seg[1] + 1.2, "24", -10)
    fx = {}
    if 2.75 < t < 3.3: fx["shake"] = (int(math.sin(t * 80) * 2), int(math.cos(t * 60)))
    if 1.5 < t < 1.6: fx["flash"] = 0.25
    if seg[1] + 1.2 < t < seg[1] + 1.32: fx["flash"] = 0.3
    return fx

def s_holiday(img, d, t, seg, dur):
    header(d, t, "01 · 연휴 동안", "쌓인 악재", "한국이 쉬는 사이 미국에선", ORG)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        cals = [("10.9", "한글날", SRED), ("10.10", "토", GRAY), ("10.11", "일", SRED), ("10.12", "월", ORG)]
        for i, (top, body, col) in enumerate(cals):
            ts = 0.75 + i * 0.25
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); x = 36 + i * 46
            calendar(d, x, 124 + o, top, body, col)
            if i < 3:
                d.text((x + 20, 164), "휴장", font=F9, fill=GRAY, anchor="ma"); zz(d, x + 30, 132, t + i)
            else:
                if blink(t, 3): d.rectangle([x - 2, 122 + o, x + 42, 162 + o], outline=YEL)
                d.text((x + 20, 164), "개장!", font=F9, fill=YEL, anchor="ma")
        heads = [(1.9, "미국 반도체주 급락", SRED), (2.4, "미국 국채금리 재상승", ORG), (2.9, "오픈AI 매출 논란", PURP)]
        d.text((CX, 186), "그 사이 미국 뉴스", font=F9, fill=GRAY, anchor="ma") if t > 1.8 else None
        for i, (ts, h, col) in enumerate(heads):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); news_card(d, 34, 200 + i * 26, o, h, col)
            warn_icon(d, 196, 202 + i * 26 + o, YEL)
    elif t < s2:
        box(d, 34, 124, 216, 230, DIM)
        d.text((40, 128), "필라델피아 반도체지수 · 10월 8일", font=F9, fill=GRAY)
        uf = ease(prog(t, s1 + 0.05, s1 + 0.6)); ud = prog(t, s1 + 1.5, s1 + 2.0)
        end = crash_line(d, 42, 150, 208, 168, 34, uf, ud, WHITE, 3)
        alert_card(img, d, t, s1 + 0.65, s1 + 1.45, CX, 176)             # 경보 → 급락
        if t > s1 + 2.0:
            vis, o = slam(t, s1 + 2.0, 0.2)
            d.text((206, 140 + o), "약 -3.4%", font=F12, fill=SRED, anchor="ra")
        if t > s1 + 2.3:
            vis, o = slam(t, s1 + 2.3, 0.2)
            d.rectangle([34, 240 + o, 216, 290 + o], fill=(30, 20, 8), outline=ORG)
            d.text((44, 246 + o), "미국 국채금리", font=F12, fill=WHITE); d.text((44, 264 + o), "다시 오름 → 성장주 부담", font=F9, fill=ORG)
            k = ease(prog(t, s1 + 2.4, s1 + 3.2))
            pts = [(150 + j * 4, int(280 - 22 * (j / 14) * k + 2 * math.sin(j))) for j in range(int(14 * k) + 1)]
            if len(pts) > 1: d.line(pts, fill=ORG, width=2)
            up_arrow(d, 200, 248 + o, ORG, 18)
    else:
        d.rectangle([40, 126, 70, 156], fill=(30, 30, 50), outline=PURP)
        d.text((55, 134), "AI", font=F12, fill=PURP, anchor="ma")
        d.text((78, 128), "오픈AI 연 매출", font=F12, fill=WHITE); d.text((78, 144), "연환산 · 10월 8일 보도", font=F9, fill=GRAY)
        u1 = ease(prog(t, s2 + 0.1, s2 + 0.6)); u2 = ease(prog(t, s2 + 0.8, s2 + 1.4))
        d.text((40, 168), "알려진 수치", font=F9, fill=GRAY); d.rectangle([40, 180, 40 + int(150 * u1), 192], fill=WHT2)
        if u1 >= 1: d.text((196, 166), "700억$", font=F12, fill=WHITE, anchor="ra")
        d.text((40, 202), "보도된 수치", font=F9, fill=GRAY); d.rectangle([40, 214, 40 + int(107 * u2), 226], fill=SRED)
        if u2 >= 1:
            d.text((152, 200), "500억$", font=F12, fill=SRED, anchor="ra")
            q = prog(t, s2 + 1.5, s2 + 1.9)
            if q > 0:
                for yy in range(214, 227, 3): d.point((147 + int(43 * q), yy), fill=ORG)
                d.rectangle([148, 214, 148 + int(42 * q), 226], outline=ORG)
                if q >= 1: d.text((169, 230), "-200억$", font=F9, fill=ORG, anchor="ma")
        if t > s2 + 2.0:
            for k in range(3):
                mini_person(d, 52 + k * 22, 262, (CYAN, ORG, GRN)[k], t, k); qmark(d, 55 + k * 22, 246, t + k * 0.3)
            glitch_text(img, 166, 256, "AI 거품?", F12, YEL, t, 3)
        if t > s2 + 2.4: d.text((CX, 296), "※ 집계 방식 차이라는 설명도 나왔어요", font=F9, fill=GRAY, anchor="ma")
    chapter_flash(img, d, t, "01", "연휴 악재", ORG)
    return {"shake": (int(math.sin(t * 80) * 2), 0)} if s1 + 1.5 < t < s1 + 1.9 else {}

def s_china(img, d, t, seg, dur):
    header(d, t, "02 · 중국 메모리", "CXMT 추격", "차세대 D램 기술 공개", SRED)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        if t > 0.75:
            vis, o = slam(t, 0.75, 0.2); factory(d, 38, 140 + o, t)
        if t > 1.4:
            vis, o = slam(t, 1.4, 0.2)
            chip(d, 128, 172 + o, 34, CYAN, t, 2)
            d.text((145, 212 + o), "D램", font=F9, fill=CYAN, anchor="ma")
        target_lock(d, 145, 189, t, 1.9, "4F² D램", SRED, "10.10 공개")
        if t > 2.6:
            vis, o = slam(t, 2.6, 0.2)
            d.rectangle([34, 250 + o, 216, 300 + o], fill=(30, 10, 14), outline=SRED)
            d.text((CX, 256 + o), "CXMT = 창신메모리", font=F12, fill=WHITE, anchor="ma")
            d.text((CX, 276 + o), "중국 최대 D램 회사", font=F9, fill=GRAY, anchor="ma")
    elif t < s2:
        u = ease(prog(t, s1 + 0.2, s1 + 1.4))
        box(d, 34, 124, 122, 214, GRAY); box(d, 128, 124, 216, 214, SRED)
        f2(d, 78, 128, "지금 6F²", WHT2, F12, "ma"); f2(d, 172, 128, "차세대 4F²", SRED, F12, "ma")
        n1 = cells(d, 42, 148, 72, 48, 18, 12, GRAY, u)
        n2 = cells(d, 136, 148, 72, 48, 12, 12, SRED, u)
        if u >= 1:
            d.text((78, 200), f"{n1}칸", font=F9, fill=WHT2, anchor="ma"); d.text((172, 200), f"{n2}칸", font=F9, fill=YEL, anchor="ma")
        if t > s1 + 1.6:
            vis, o = slam(t, s1 + 1.6, 0.2)
            d.text((CX, 222 + o), "칸 하나 면적 약 ⅓ ↓  →  같은 넓이에 더 많이", font=F9, fill=YEL, anchor="ma")
        if t > s1 + 2.4:
            vis, o = slam(t, s1 + 2.4, 0.2)
            calendar(d, 40, 248 + o, "연말", "출시", SRED)
            d.rectangle([90, 252 + o, 216, 280 + o], fill=(14, 16, 32), outline=CYAN)
            d.text((153, 256 + o), "서버용 DDR5", font=F12, fill=CYAN, anchor="ma")
            d.text((CX, 292 + o), "※ 아직 양산 제품으로 확인된 건 아님", font=F9, fill=GRAY, anchor="ma")
    else:
        d.text((CX, 124), "D램 매출 점유율 · 2026년 2분기", font=F9, fill=GRAY, anchor="ma")
        rows = [("삼성전자", 39.4, BLUE), ("SK하이닉스", 24.9, SRED), ("마이크론", 23.3, WHT2), ("CXMT", 9.5, ORG)]
        for i, (nm, v, col) in enumerate(rows):
            ts = s2 + 0.1 + i * 0.25
            if t < ts: continue
            y = 140 + i * 24; u = ease(prog(t, ts, ts + 0.5))
            vv = lerp(7.6, 9.5, ease(prog(t, s2 + 1.4, s2 + 2.0))) if nm == "CXMT" else v
            d.text((40, y + 2), nm, font=F9, fill=col)
            d.rectangle([96, y, 96 + max(2, int(2.8 * vv * u)), y + 12], fill=col)
            d.text((96 + int(2.8 * vv * u) + 4, y + 1), f"{vv:.1f}%", font=F9, fill=WHITE)
        if t > s2 + 1.4: up_arrow(d, 150, 210, ORG, 14); d.text((166, 214), "7.6%에서", font=F9, fill=ORG)
        target_lock(d, 112, 218, t, s2 + 1.9, "세계 4위", ORG)
        if t > s2 + 2.6:
            glitch_text(img, CX, 252, "중국 추격 공포", F24, SRED, t, 5 if t < s2 + 3.2 else 1)
        d.text((CX, 300), "자료: 트렌드포스", font=F9, fill=DIM, anchor="ma")
    chapter_flash(img, d, t, "02", "중국 추격", SRED)
    return {}

def jo(v):
    j, e = divmod(int(round(v)), 10000)
    return (f"{j}조 " if j else "") + f"{e:,}억"

def s_flow(img, d, t, seg, dur):
    header(d, t, "03 · 수급", "외국인 매도", "유가증권시장 · 10월 12일", BLUE)
    s1, s2 = seg[1], seg[2]
    if t < s1:
        u = ease(prog(t, 0.8, 2.6))
        d.text((CX, 122), "외국인 순매도", font=F9, fill=GRAY, anchor="ma")
        ctext(d, 134, "-" + jo(20256 * u), F24, SRED if u >= 1 else WHITE, full="-2조 256억")
        d.rectangle([180, 168, 214, 214], fill=(20, 22, 40), outline=WHT2); d.rectangle([186, 174, 208, 214], fill=(60, 40, 30))
        d.text((197, 160), "EXIT", font=F9, fill=GRN, anchor="ma")
        for k in range(5):
            ts = 0.8 + k * 0.35
            if t < ts: continue
            x = 36 + (t - ts) * 70
            if x < 176: money_bag(d, int(x), 182, "₩" if False else "$")
        rows = [(1.6, "SK하이닉스", 10431, SRED), (2.0, "삼성전자", 5331, BLUE)]
        for i, (ts, nm, v, col) in enumerate(rows):
            if t < ts: continue
            q = ease(prog(t, ts, ts + 0.5)); y = 228 + i * 30
            d.text((40, y), nm, font=F9, fill=col)
            d.rectangle([40, y + 12, 40 + int(150 * v / 10431 * q), y + 22], fill=col)
            d.text((212, y), "-" + jo(v), font=F9, fill=WHITE, anchor="ra")
    elif t < s2:
        u = prog(t, s1 + 1.0, s1 + 2.2)
        tilt = int(6 * ease(u) * (1 + 0.3 * math.sin(t * 9)))
        d.rectangle([84, 140 + tilt, 166, 172 + tilt], fill=(60, 50, 10), outline=YEL)
        d.text((CX, 148 + tilt), "주가", font=F12, fill=YEL, anchor="ma")
        pc = tuple(int(lerp(c, g, ease(u))) for c, g in zip(GRN, DIM))
        h = int(64 * (1 - 0.55 * ease(u)))
        d.rectangle([108, 236 - h, 142, 236], fill=dk(pc, 0.5), outline=pc)
        for k, ch in enumerate("자사주"):
            if 236 - h + 4 + k * 14 < 230: d.text((125, 236 - h + 4 + k * 14), ch, font=F12, fill=pc, anchor="ma")
        d.line([(60, 237), (190, 237)], fill=GRAY, width=2)
        if t > s1 + 1.0: crack(d, 112, 238 - h, 140, 232, t, s1 + 1.0, WHITE, 5)
        if t > s1 + 0.4:
            vis, o = slam(t, s1 + 0.4, 0.2)
            d.text((CX, 250 + o), "삼성·하이닉스 대규모 자사주 매입", font=F9, fill=WHT2, anchor="ma")
            d.text((CX, 264 + o), "마무리 단계 → 받침대가 약해질까?", font=F9, fill=ORG, anchor="ma")
        if t > s1 + 1.0: warn_icon(d, 172, 182, YEL if blink(t, 4) else ORG)
    else:
        base = 268; u = ease(prog(t, s2 + 0.2, s2 + 1.0)); v = ease(prog(t, s2 + 0.9, s2 + 1.7))
        h1 = int(100 * u); h2 = int(100 * 14681 / 20256 * v)
        d.line([(40, base + 1), (210, base + 1)], fill=GRAY)
        d.rectangle([56, base - h1, 104, base], fill=SRED); d.rectangle([146, base - h2, 194, base], fill=GRN)
        d.text((80, base + 4), "외국인", font=F9, fill=SRED, anchor="ma"); d.text((170, base + 4), "개인", font=F9, fill=GRN, anchor="ma")
        if u >= 1: d.text((80, base - h1 - 26), "팔았다", font=F9, fill=GRAY, anchor="ma"); d.text((80, base - h1 - 14), "2조 256억", font=F9, fill=WHITE, anchor="ma")
        if v >= 1:
            d.text((170, base - h2 - 26), "샀다", font=F9, fill=GRAY, anchor="ma"); d.text((170, base - h2 - 14), "1조 4,681억", font=F9, fill=WHITE, anchor="ma")
            for k in range(3): mini_person(d, 150 + k * 16, base - h2 - 46, (CYAN, ORG, YEL)[k], t, k)
            for k in range(4):
                ts = s2 + 1.8 + k * 0.3
                if t > ts: coin(d, 162 + (k % 2) * 16, int(base - h2 - 70 + min(20, (t - ts) * 60)), 5, "")
    chapter_flash(img, d, t, "03", "외국인 매도", BLUE)
    return {}

US = [("SNDK", "샌디스크", "장중 -7.1%", 7.1), ("MU", "마이크론", "-3.9%", 3.9), ("SKHY", "SK하이닉스 ADR", "-4.05%", 4.05), ("SOX", "반도체지수", "-2.67%", 2.67)]
def s_us(img, d, t, seg, dur):
    header(d, t, "04 · 같은 날 밤", "뉴욕도 출렁", "미국 메모리주 동반 하락", PURP)
    box(d, 34, 122, 216, 270, PURP)
    d.text((CX, 126), "NEW YORK · 10.12 (현지)", font=F9, fill=PURP, anchor="ma")
    alert_card(img, d, t, 0.75, 1.55, CX, 196)                           # 경보 → 하락 막대
    if t >= 1.6:
        for i, (tk, nm, vs, v) in enumerate(US):
            ts = 1.6 + i * 0.3
            if t < ts: continue
            vis, o = slam(t, ts, 0.18); y = 142 + i * 31 + o; q = ease(prog(t, ts + 0.1, ts + 0.6))
            d.text((40, y), tk, font=F9, fill=ORG); d.text((40, y + 11), nm, font=F9, fill=GRAY)
            d.text((212, y), vs, font=F12, fill=SRED, anchor="ra")
            d.rectangle([118, y + 16, 118 + int(12 * v * q), y + 21], fill=SRED)
    target_lock(d, 104, 160, t, seg[1] + 0.2, "SNDK", YEL)
    if t > seg[1] + 1.0:
        vis, o = slam(t, seg[1] + 1.0, 0.2)
        d.rectangle([34, 278 + o, 216, 300 + o], fill=(30, 22, 6), outline=GOLD if blink(t, 2) else ORG)
        d.text((CX, 283 + o), "샌디스크 · 우리 채널 이름의 그 종목!", font=F9, fill=GOLD, anchor="ma")
    d.text((CX, 306), "샌디스크는 장중 기준 · 나머지는 종가", font=F9, fill=DIM, anchor="ma")
    chapter_flash(img, d, t, "04", "뉴욕도", PURP)
    return {"shake": (int(math.sin(t * 80) * 2), 0)} if 1.6 < t < 1.9 else {}

def s_check(img, d, t, seg, dur):
    header(d, t, "05 · 팩트 체크", "진짜 위기?", "아직 확인 안 된 것들", GRN)
    s1 = seg[1]
    if t < s1:
        d.text((CX, 122), "모닝스타의 시각", font=F9, fill=GRAY, anchor="ma")
        if t > 0.75:
            vis, o = slam(t, 0.75, 0.2); flask(d, 48, 140 + o, t)
            d.text((60, 176 + o), "실험실", font=F9, fill=TEAL, anchor="ma")
        if t > 1.2:
            q = prog(t, 1.2, 1.6); d.line([(84, 158), (84 + int(36 * q), 158)], fill=WHT2); d.polygon([(120, 154), (126, 158), (120, 162)], fill=WHT2) if q >= 1 else None
        if t > 1.6:
            vis, o = slam(t, 1.6, 0.2); factory(d, 132, 120 + o, t, "양산")
        qmark(d, 108, 168, t)
        items = [(2.4, "같은 품질로 대량 생산 가능?"), (2.9, "서버 고객의 신뢰·호환 검증?")]
        for i, (ts, s) in enumerate(items):
            if t < ts: continue
            vis, o = slam(t, ts, 0.2); y = 222 + i * 30 + o
            d.rectangle([34, y, 216, y + 24], fill=(10, 20, 14), outline=GRN)
            d.rectangle([40, y + 6, 50, y + 16], outline=YEL); qmark(d, 45, y + 5, t + i * 0.2)
            d.text((58, y + 6), s, font=F9, fill=WHITE)
        if t > 3.4:
            vis, o = slam(t, 3.4, 0.2)
            d.text((CX, 286 + o), "→ 상용화는 매우 어려울 수도", font=F12, fill=GRN, anchor="ma")
    else:
        if t > s1 + 0.1:
            vis, o = slam(t, s1 + 0.1, 0.2)
            chip(d, 52, 150 + o, 36, CYAN, t, 5); d.text((70, 196 + o), "서버 DDR5", font=F9, fill=CYAN, anchor="ma")
            d.text((70, 208 + o), "경쟁 시작", font=F9, fill=ORG, anchor="ma")
        if t > s1 + 0.6:
            vis, o = slam(t, s1 + 0.6, 0.2)
            hbm_stack(d, 148, 146 + o); d.text((168, 198 + o), "HBM", font=F12, fill=GOLD, anchor="ma")
        if t > s1 + 1.2:
            d.rectangle([118, 140, 122, 210], fill=GRAY)
            shield(d, 186, 140, GRN)
        if t > s1 + 1.6:
            vis, o = slam(t, s1 + 1.6, 0.2)
            d.rectangle([34, 228 + o, 216, 270 + o], fill=(10, 20, 14), outline=GRN)
            d.text((CX, 234 + o), "다른 제품 · 다른 시장", font=F12, fill=GRN, anchor="ma")
            d.text((CX, 252 + o), "충격도 같다고 볼 순 없어요", font=F9, fill=WHITE, anchor="ma")
    chapter_flash(img, d, t, "05", "팩트 체크", GRN)
    return {}

def s_outro(img, d, t, seg, dur):
    marquee(d, 222, 2, 26, t, "연휴 악재 · 중국 추격 · 외국인 매도", (dk(SRED, 0.55), dk(ORG, 0.5)))
    header(d, t, "SUMMARY", "10.12 정리", "반도체 대폭락의 세 가지 이유", GOLD)
    rows = [("US", "연휴 악재", "반도체·금리·오픈AI", ORG), ("CN", "중국 추격", "CXMT 4F² D램", SRED), ("SELL", "외국인 매도", "하루 2조 원+", BLUE)]
    for i, (a, b, c, col) in enumerate(rows):
        ts = 0.3 + i * 0.45
        if t < ts: continue
        vis, o = slam(t, ts, 0.2); y = 126 + i * 30
        d.rectangle([34, y + o, 216, y + 24 + o], fill=(10, 14, 30), outline=col)
        d.rectangle([34, y + o, 70, y + 24 + o], fill=col)
        d.text((52, y + 7 + o), a, font=F9, fill=WHITE, anchor="ma")
        d.text((76, y + 5 + o), b, font=F12, fill=WHITE); d.text((212, y + 8 + o), c, font=F9, fill=col, anchor="ra")
    if t > seg[1]:
        vis, o = slam(t, seg[1] + 0.1, 0.2)
        d.rectangle([34, 278 + o, 216, 300 + o], fill=(30, 22, 6), outline=GOLD if blink(t, 2) else ORG)
        d.text((CX, 283 + o), "다음 변수: 실적 발표 · 미국 9월 물가", font=F9, fill=GOLD, anchor="ma")
    d.text((32, 306), "※ 투자 권유가 아닌 정보 제공용", font=F9, fill=DIM)
    return {}

SCRIPT = [
    (s_hook, [("10월 12일, 삼성전자·SK하이닉스\n나란히 4%대 급락!", "시월 십이 일, 삼성전자와 에스케이하이닉스가, 나란히 사 퍼센트 넘게 급락했어요."),
              ("코스피도 3.65% 하락\n대체 무슨 일이 있었을까요?", "코스피도 삼 점 육오 퍼센트 하락. 대체 무슨 일이 있었을까요?")]),
    (s_holiday, [("한국 증시가 한글날 연휴로 쉬는 사이\n미국에서 악재가 쌓였어요", "한국 증시가 한글날 연휴로 쉬는 사이, 미국에서 악재가 쌓였어요."),
                 ("8일 미국 반도체지수 약 3.4% 하락,\n미국 국채금리도 다시 올랐죠", "팔 일 미국 필라델피아 반도체지수가 약 삼 점 사 퍼센트 빠졌고, 미국 국채금리도 다시 올랐죠."),
                 ("오픈AI 연 매출이 700억 아닌 500억 달러?\n보도에 AI 투자 걱정이 커졌어요", "오픈에이아이 매출이 알려진 것보다 이백억 달러 적다는 보도에, 에이아이 투자 걱정이 커졌어요.")]),
    (s_china, [("10일, 중국 메모리 회사 CXMT가\n차세대 D램 기술 '4F²'를 공개했어요", "십 일, 중국 메모리 회사 씨엑스엠티가, 차세대 디램 기술, 포 에프 스퀘어를 공개했어요."),
               ("메모리 칸 하나를 약 3분의 1 줄이는 구조,\n연말 서버용 DDR5에 쓰겠다고 했죠", "메모리 칸 하나의 면적을 약 삼분의 일 줄이는 구조로, 연말 서버용 디디알 파이브에 쓰겠다고 했죠."),
               ("D램 점유율도 9.5%, 세계 4위까지\n중국 추격 공포가 번졌어요", "디램 매출 점유율도 구 점 오 퍼센트로 세계 사 위. 중국 추격 공포가 번졌어요.")]),
    (s_flow, [("외국인은 이날 2조 원 넘게 팔았어요\nSK하이닉스만 1조 원어치", "외국인은 이날 이조 원 넘게 팔았는데, 에스케이하이닉스만 일조 원어치였어요."),
              ("주가를 받쳐 주던 자사주 매입이\n끝나 간다는 걱정도 겹쳤고요", "주가를 받쳐 주던 대규모 자사주 매입이, 끝나 간다는 걱정도 겹쳤고요."),
              ("반대로 개인은 1조 4,681억 원어치를\n사들였어요", "반대로 개인은 일조 사천육백팔십일억 원어치를 사들였어요.")]),
    (s_us, [("같은 날 밤 뉴욕에서도\n메모리주가 줄줄이 빠졌어요", "같은 날 밤, 뉴욕에서도 메모리주가 줄줄이 빠졌어요."),
            ("샌디스크는 장중 7% 넘게,\n마이크론은 3.9% 하락", "샌디스크는 장중 칠 퍼센트 넘게, 마이크론은 삼 점 구 퍼센트 떨어졌죠.")]),
    (s_check, [("하지만 모닝스타는 이 기술을 양산하기는\n매우 어려울 수 있다고 봤어요", "하지만 모닝스타는, 이 기술을 실제로 대량 생산하기는 매우 어려울 수 있다고 봤어요."),
               ("서버용 D램 경쟁이 곧 HBM까지\n같은 충격이라는 뜻도 아니고요", "서버용 디램 경쟁이, 곧 에이치비엠까지 같은 충격이라는 뜻도 아니고요.")]),
    (s_outro, [("연휴 악재 + 중국 추격 공포\n+ 외국인 매도가 한꺼번에!", "정리하면, 연휴 동안 쌓인 악재, 중국 추격 공포, 외국인 매도가 한꺼번에 몰린 하루였어요."),
               ("다음 변수는 실적 발표와\n미국 9월 물가예요", "다음 변수는, 반도체 기업들의 실적 발표와 미국 구월 물가예요.")]),
]
TITLES = ["", "연휴 악재", "중국 추격", "외국인 매도", "뉴욕도", "팩트 체크", "정리"]

def gen_narration():
    todo = [n for _, lines in SCRIPT for _, n in lines if not os.path.exists(mv.clip_path(n))]
    if not todo: return
    from tts_synth import make_tts, synth
    tts = make_tts()
    for n in todo:
        x, sr = synth(tts, n, VOICE_SID, speed=SPEED)
        idx = np.where(np.abs(x) > 0.01)[0]; x = x[max(0, idx[0] - 600): idx[-1] + 2000]
        np.save(mv.clip_path(n), x.astype(np.float32))

def layout():
    scenes = []
    for k, (fn, lines) in enumerate(SCRIPT):
        t = 0.15 if k == 0 else (0.75 if k < len(SCRIPT) - 1 else LEAD)   # chapter flash needs ~0.55s before the first line
        seg, lens = [], []
        for sub, n in lines:
            L = len(np.load(mv.clip_path(n))) / SR
            seg.append(t); lens.append(L); t += L + GAP
        scenes.append(dict(fn=fn, seg=seg, lens=lens, dur=t - GAP + TAIL, subs=[s for s, _ in lines], narr=[n for _, n in lines]))
    return scenes, np.cumsum([0] + [s["dur"] for s in scenes]).tolist()

def make_audio(path, scenes, starts, total):
    N = int((total + 0.5) * SR)
    bgm = np.zeros(N); sfx = np.zeros(N); nv = np.zeros(N)
    for k, sc in enumerate(scenes):
        for i, n in enumerate(sc["narr"]):
            x = np.load(mv.clip_path(n)).astype(np.float64)
            x *= 0.11 / (np.sqrt((x ** 2).mean()) + 1e-9)
            if np.abs(x).max() > 0.5: x *= 0.5 / np.abs(x).max()
            st = int((starts[k] + sc["seg"][i]) * SR); nv[st:st + len(x)] += x[:max(0, N - st)]
    S = starts
    # news-special BGM: D minor tension (118 bpm, driving 8th bass) → F major lift at the fact check / summary
    bpm = 118; beat = 60 / bpm; e = beat / 2; bar = beat * 4
    prog_minor = [([62, 65, 69], 38), ([58, 62, 65], 34), ([60, 64, 67], 36), ([57, 61, 64], 33)]   # Dm Bb C A
    prog_major = [([65, 69, 72], 41), ([60, 64, 67], 36), ([62, 65, 69], 38), ([58, 62, 65], 34)]   # F C Dm Bb
    mel_m = [[74, None, 72, 69, 70, None, 69, None], [70, 72, 74, None, 77, None, 74, 72], [72, None, 67, None, 76, None, 74, 72], [73, None, 69, None, 64, None, None, None]]
    mel_M = [[77, None, 76, 77, 81, None, 79, 77], [76, None, 72, None, 76, 77, 79, None], [81, None, 77, 74, 72, None, 74, None], [74, 76, 77, None, 74, None, None, None]]
    for b in range(int(total / bar) + 1):
        t0 = b * bar
        bright = t0 >= S[5]
        tense = t0 < S[1]
        notes, root = (prog_major if bright else prog_minor)[b % 4]
        mel = (mel_M if bright else mel_m)[b % 4]
        for st in range(8):
            T = t0 + st * e
            if T >= total: break
            tone(bgm, T, e * 0.7, mtof(root - 12), 0.16, "tri")
            if st % 2 == 1:
                for nn in notes: tone(bgm, T, e * 0.4, mtof(nn), 0.02, "sq", 0.25, decay=0.05)
            m = mel[st]
            if m and T > S[0] + 3.5 and not tense: tone(bgm, T, e * 0.8, mtof(m), 0.03, "sq", 0.125, decay=0.15)
            if m and tense and st % 4 == 0 and T > 3.5: tone(bgm, T, e * 1.6, mtof(m - 12), 0.03, "sq", 0.5, decay=0.4)
        for bt in range(4):
            T = t0 + bt * beat
            if T >= total: break
            if 1.5 <= T < 2.75: continue                                         # 경보 동안 드럼 멈춤 → 급락 때 다시
            if bt in (0, 2): tone(bgm, T, 0.14, 150, 0.3, "sin", f1=50, decay=0.06)
            else: tone(bgm, T, 0.1, 0, 0.09, "noise", decay=0.04)
            tone(bgm, T + e, 0.03, 0, 0.03, "noise", decay=0.01)
    ie = int(total * SR); fo = int(2.0 * SR)
    bgm[ie - fo:ie] *= np.linspace(1, 0, fo); bgm[ie:] = 0
    def blip(T, f=1500, v=0.03): tone(sfx, T, 0.03, f, v, "sq", 0.5, decay=0.015)
    def ding(T): tone(sfx, T, 0.09, 1568, 0.08, "sq", 0.5, decay=0.06); tone(sfx, T + 0.08, 0.2, 2093, 0.07, "sq", 0.5, decay=0.1)
    def coin_s(T): tone(sfx, T, 0.06, 1976, 0.07, "sq", 0.5, decay=0.04); tone(sfx, T + 0.06, 0.2, 2637, 0.07, "sq", 0.5, decay=0.12)
    def swoosh(T): tone(sfx, T, 0.25, 0, 0.07, "noise", decay=0.08); tone(sfx, T, 0.22, 900, 0.045, "sq", 0.5, f1=200)
    def thump(T): tone(sfx, T, 0.3, 120, 0.32, "sin", f1=40, decay=0.12); tone(sfx, T, 0.12, 0, 0.1, "noise", decay=0.04)
    def stampfx(T): thump(T); tone(sfx, T, 0.18, 0, 0.16, "noise", decay=0.05)
    def pop(T): tone(sfx, T, 0.06, 600, 0.05, "sq", 0.5, f1=1300, decay=0.04)
    def rise(T, d=1.4): tone(sfx, T, d, 300, 0.04, "sq", 0.5, f1=1200, decay=d)
    def fall(T, d=1.0): tone(sfx, T, d, 900, 0.045, "sq", 0.5, f1=150, decay=d)
    def lock(T): tone(sfx, T, 0.3, 1800, 0.035, "sq", 0.5, f1=600, decay=0.25); tone(sfx, T + 0.35, 0.05, 2400, 0.05, "sq", 0.5, decay=0.03)
    def alarm(T, n=4):
        for j in range(n): tone(sfx, T + j * 0.2, 0.1, 1320, 0.05, "sq", 0.5, decay=0.08); tone(sfx, T + j * 0.2 + 0.1, 0.1, 990, 0.05, "sq", 0.5, decay=0.08)
    def glitch(T, n=6):
        for j in range(n): tone(sfx, T + j * 0.045, 0.04, 0, 0.06, "noise", decay=0.02); tone(sfx, T + j * 0.045, 0.03, 300 + (j * 370) % 1200, 0.03, "sq", 0.5, decay=0.02)
    def fanfare(T):
        for j, m in enumerate([72, 76, 79, 84]): tone(sfx, T + j * 0.1, 0.16, mtof(m), 0.07, "sq", 0.25, decay=0.1)
    def wahwah(T):
        for j, m in enumerate([67, 66, 65, 64]): tone(sfx, T + j * 0.25, 0.28 if j < 3 else 0.6, mtof(m), 0.07, "sq", 0.5, f1=mtof(m) * 0.98, decay=0.3)
    def chapter(T): swoosh(T); thump(T + 0.12); tone(sfx, T + 0.12, 0.25, 0, 0.08, "noise", decay=0.08)
    def typing(T0, s, cps=22):
        for c in range(0, len(s), 2): blip(T0 + c / cps, 1500 + (c % 3) * 150)
    sg = lambda k, i: S[k] + scenes[k]["seg"][i]
    # hook: alarm FIRST, then the crash
    typing(S[0] + 0.1, "특별편반도체대폭락"); alarm(S[0] + 1.5, 6); fall(S[0] + 2.75, 0.8); thump(S[0] + 2.8); glitch(S[0] + 3.45, 6)
    pop(S[0] + 3.6); pop(S[0] + 3.9); thump(sg(0, 1) + 0.1); stampfx(sg(0, 1) + 1.2); wahwah(sg(0, 1) + 1.4)
    for k in range(1, len(scenes)):
        if k < len(scenes) - 1: chapter(S[k])
        else: swoosh(S[k])
        typing(S[k] + 0.6, TITLES[k])
    # holiday
    for i in range(4): pop(S[1] + 0.75 + i * 0.25)
    for i in range(3): thump(S[1] + 1.9 + i * 0.5); blip(S[1] + 1.95 + i * 0.5, 900)
    alarm(sg(1, 1) + 0.65, 4); fall(sg(1, 1) + 1.5, 0.6); thump(sg(1, 1) + 1.55); pop(sg(1, 1) + 2.0); rise(sg(1, 1) + 2.4, 0.8)
    pop(sg(1, 2) + 0.1); pop(sg(1, 2) + 0.8); fall(sg(1, 2) + 0.9, 0.5); ding(sg(1, 2) + 1.9); glitch(sg(1, 2) + 2.0, 4)
    # china
    thump(S[2] + 0.75); pop(S[2] + 1.4); lock(S[2] + 1.9); pop(S[2] + 2.6)
    for j in range(12): blip(sg(2, 1) + 0.2 + j * 0.1, 900 + j * 90, 0.025)
    ding(sg(2, 1) + 1.6); pop(sg(2, 1) + 2.4)
    for i in range(4): pop(sg(2, 2) + 0.1 + i * 0.25)
    rise(sg(2, 2) + 1.4, 0.6); lock(sg(2, 2) + 1.9); glitch(sg(2, 2) + 2.6, 8); thump(sg(2, 2) + 2.65)
    # flow
    for j in range(5): swoosh(S[3] + 0.8 + j * 0.35)
    for j in range(14): blip(S[3] + 0.8 + j * 0.13, 1200 - j * 40, 0.025)
    thump(S[3] + 1.6); thump(S[3] + 2.0)
    pop(sg(3, 1) + 0.4); for_ = [glitch(sg(3, 1) + 1.0, 4), fall(sg(3, 1) + 1.0, 1.2), thump(sg(3, 1) + 1.1)]
    pop(sg(3, 2) + 0.2); pop(sg(3, 2) + 0.9)
    for k in range(4): coin_s(sg(3, 2) + 1.8 + k * 0.3)
    # us: alarm first, then the bars drop
    alarm(S[4] + 0.75, 4)
    for i in range(4): thump(S[4] + 1.6 + i * 0.3); fall(S[4] + 1.65 + i * 0.3, 0.4)
    lock(sg(4, 1) + 0.2); ding(sg(4, 1) + 1.0)
    # check
    pop(S[5] + 0.75); pop(S[5] + 1.6); ding(S[5] + 2.4); ding(S[5] + 2.9); rise(S[5] + 3.4, 0.6)
    pop(sg(5, 1) + 0.1); pop(sg(5, 1) + 0.6); coin_s(sg(5, 1) + 1.2); ding(sg(5, 1) + 1.6)
    # outro
    for i in range(3): thump(S[6] + 0.3 + i * 0.45)
    fanfare(sg(6, 1) + 0.2)
    win = int(0.12 * SR); pk = np.maximum.reduceat(np.abs(nv), np.arange(0, N, win))
    env = np.convolve(np.repeat(pk, win)[:N], np.ones(win) / win, mode="same")
    act = np.clip(env / 0.04, 0, 1)
    mix = np.tanh((bgm * (1 - 0.62 * act) * 0.9 + sfx * (1 - 0.35 * act)) * 1.2) / np.tanh(1.2) * 0.55 + nv
    mix = mix / max(1e-6, np.abs(mix).max()) * 0.89
    pcm = (mix * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.repeat(pcm[:, None], 2, axis=1).tobytes())

if __name__ == "__main__":
    gen_narration()
    scenes, starts = layout(); total = starts[-1]
    print("scene durations:", [round(s["dur"], 1) for s in scenes], "total:", round(total, 1))
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "stills":
        for T in [float(x) for x in sys.argv[2].split(",")]:
            render_frame(T, scenes, starts, total).resize((360, 640), Image.LANCZOS).save(f"{OUT}/s_{T:05.1f}.png")
        sys.exit()
    if mode == "times":
        for k, s in enumerate(scenes): print(k, round(starts[k], 2), [round(starts[k] + x, 2) for x in s["seg"]], round(s["dur"], 2))
        sys.exit()
    make_audio(f"{OUT}/mix.wav", scenes, starts, total)
    n = int(total * FPS)
    p = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{FW}x{FH}",
                          "-r", str(FPS), "-i", "-", "-i", f"{OUT}/mix.wav", "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart",
                          f"{OUT}/video.mp4"], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(render_frame(i / FPS, scenes, starts, total).tobytes())
        if i % 600 == 0: print(i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", total)

import sys, os, bpy, usb_mascot as M, gestures as G
from expressions import EXPR
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
M.build(); M.setup_render('pip', 400, 14); M.stage_light_v3('studio'); c=bpy.data.objects['cam']; c.data.lens=150; bpy.data.objects['cam_tgt'].location=(0,0,1.62)
for i, (k, kw) in enumerate(EXPR.items()): M.pose(**kw); M.render(f'{out}/e{i:02d}.png')
M.setup_render('host', 360, 12); M.stage_light_v3('studio')
T = dict(wow=0.3, jump=0.48, bow=0.6, count=0.3)
for i, k in enumerate(G.DUR):
    L, R, ex = G.gest(k, T.get(k, 0.75), 1); kw = dict(open=ex.pop('mouth', 0.25), smile=ex.pop('smile', 1.0)); kw.update(ex)
    M.pose(arm_l=tuple(L), arm_r=tuple(R), **kw); M.render(f'{out}/g{i:02d}_{k}.png')

"""오디오(내레이션) → 마스코트 말하기 애니메이션 RGBA 프레임 렌더
python3 talk_render.py <narr.wav> <out_dir> [start_sec] [dur_sec] [res] [samples] [--resume]
MODE=host 환경변수 → 진행자 풀샷(600×800~720×960), 기본 pip(원형 인서트용 상반신)
STEP=2 환경변수 → 짝수 프레임만 렌더(15fps 애니, 시간 절반)"""
import sys, os, math, wave, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, bpy, usb_mascot as M
FPS = 30
STEP = int(os.environ.get('STEP', 1))                # 기본 1(30fps). STEP=2(15fps)는 뚝뚝 끊겨 느려 보여서 11/10부터 쓰지 않음
wav, out = sys.argv[1], sys.argv[2]
t0 = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
dur = float(sys.argv[4]) if len(sys.argv) > 4 else None
res = int(sys.argv[5]) if len(sys.argv) > 5 else 400
spp = int(sys.argv[6]) if len(sys.argv) > 6 else 24
os.makedirs(out, exist_ok=True)

w = wave.open(wav); sr = w.getframerate(); ch = w.getnchannels()
x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32).reshape(-1, ch).mean(1) / 32768; w.close()
N_all = int(len(x) / sr * FPS); hop = sr // FPS
env = np.array([np.sqrt(np.mean(x[i * hop:(i + 1) * hop] ** 2) + 1e-12) for i in range(N_all)])
ref = np.percentile(env[env > 1e-3], 92)
op = np.clip((env / ref - .1) / .75, 0, 1) ** .8
sm = np.zeros_like(op); v = 0
for i, o in enumerate(op): v = v + (o - v) * (.75 if o > v else .45); sm[i] = v
talk = np.convolve(sm, np.ones(21) / 21, 'same')                 # 말하는 중(느린 포락선)
speaking = talk > 0.12

# 구절 시작(0.25초 이상 쉬었다가 말 시작) → 손 제스처 트리거
starts, quiet = [], 99
for i in range(N_all):
    if sm[i] < 0.05: quiet += 1
    else:
        if quiet >= 8: starts.append(i / FPS)
        quiet = 0
# 강조(포락선 피크) → 눈썹
peak = np.convolve(np.clip(sm - np.convolve(sm, np.ones(31) / 31, 'same'), 0, 1), np.ones(7) / 7, 'same')

rng = np.random.default_rng(11)
blinks, b = [], 0.9
while b < len(x) / sr: blinks.append(b); b += rng.uniform(2.4, 4.6)
glances, g = [], 2.0
while g < len(x) / sr:
    glances.append((g, rng.uniform(0.5, 1.0), (rng.uniform(-.6, .6), rng.uniform(-.2, .35)))); g += rng.uniform(3.0, 5.5)

def ease(u): u = min(1, max(0, u)); return u * u * (3 - 2 * u)
def blink_v(t):
    v = 0
    for bt in blinks:
        d = t - bt
        if 0 <= d < 0.07: v = max(v, d / 0.07)                 # 빨리 감고
        elif 0.07 <= d < 0.22: v = max(v, 1 - (d - 0.07) / 0.15)  # 천천히 뜸
    return v
def look_v(t):
    for gt, gd, (lx, ly) in glances:
        if gt <= t < gt + gd:
            k = ease((t - gt) / 0.12) * (1 - ease((t - gt - gd + 0.15) / 0.15)); return (lx * k, ly * k)
    return (0.0, 0.0)
# 한 구절이 길면(쉼 없이 2.3초 넘게 말하면) 중간에 동작을 하나 더 넣어 손이 오래 내려가 있지 않게
_st2, last = [], -9
for i in range(N_all):
    tt = i / FPS
    if any(abs(tt - s0) < 1 / FPS for s0 in starts): last = tt
    elif speaking[i] and tt - last > 2.3 and i + 20 < N_all and speaking[i + 20]: _st2.append(tt); last = tt
starts = sorted(starts + _st2)
import gestures as GL, json
# 동작 선택: CUES=<json> [{t, kind, side?}] 가 있으면 그 시각의 구절은 지정 동작, 없으면 순환(같은 동작 연속 금지)
CUES = json.load(open(os.environ['CUES'])) if os.environ.get('CUES') else []
CYCLE = ['explain', 'open', 'point', 'beat', 'explain', 'think', 'open', 'yes']
plan = []
for k, st in enumerate(starts):
    c = next((c for c in CUES if abs(c['t'] - st) < 0.6), None)
    plan.append((st, c['kind'] if c else CYCLE[k % len(CYCLE)], (c or {}).get('side', 1 if k % 2 == 0 else -1)))
for c in CUES:                                                     # 말 시작과 무관한 지정 동작(예: 끝인사 손 흔들기)
    if c.get('force') and not any(abs(c['t'] - p[0]) < 0.6 for p in plan): plan.append((c['t'], c['kind'], c.get('side', 1)))
plan.sort()
print('gesture plan:', [(round(a, 2), b, c) for a, b, c in plan], flush=True)
def gesture(t):
    L = np.zeros(4); R = np.zeros(4); EX = {}
    for j, (st, kind, side) in enumerate(plan):
        l, r, ex = GL.gest(kind, t - st, side)
        wgt = 1 - ease((t - plan[j + 1][0] + 0.1) / 0.3) if j + 1 < len(plan) else 1.0     # 다음 동작이 시작되면 앞 동작은 빠르게 접음(겹쳐서 과장되지 않게)
        L += np.array(l) * wgt; R += np.array(r) * wgt
        ex = {k2: (tuple(np.multiply(v, wgt)) if k2 == 'look' else (v if k2 == 'smile' else v * wgt)) for k2, v in ex.items()}
        for k2, v in ex.items():
            if k2 == 'look': EX[k2] = tuple(np.add(EX.get(k2, (0, 0)), v))
            elif k2 == 'smile': EX[k2] = v
            else: EX[k2] = EX.get(k2, 0) + v
    return L, R, EX

M.build(); M.setup_render(os.environ.get('MODE', 'pip'), res, spp)
f0 = int(t0 * FPS); N = int(dur * FPS) if dur else N_all - f0
hl = np.zeros(4); hr = np.zeros(4); vl = np.zeros(4); vr = np.zeros(4)                                 # 손 이차 움직임(지연)
tm = time.time()
for f in range(f0, f0 + N):
    t = f / FPS; i = min(f, N_all - 1)
    o = float(sm[i]); tk = float(talk[i])
    breath = math.sin(2 * math.pi * t / 3.6)
    L, R, EX = gesture(t)
    jig = tk * 0.03 * math.sin(t * 5.3)
    L = np.array(L) + [0, 0, jig + 0.012 * breath, 0]; R = np.array(R) + [0, 0, -jig + 0.012 * breath, 0]
    # 손: 스프링(살짝 넘쳤다 돌아옴) — 단순 지연보다 탄력 있게
    vl += (L - hl) * 0.22 - vl * 0.42; hl += vl; vr += (R - hr) * 0.22 - vr * 0.42; hr += vr
    lk = np.add(look_v(t), EX.get('look', (0, 0)))
    M.pose(open=max(o, EX.get('mouth', 0)), blink=blink_v(t), look=tuple(lk), brow=0.15 + 1.6 * float(peak[i]) + 0.15 * tk + EX.get('brow', 0),
           smile=EX.get('smile', 1.0) - 0.25 * o,
           lean=2.2 * math.sin(t * 0.62) + 1.6 * tk * math.sin(t * 2.3 + .5) + EX.get('lean', 0),
           nod=-2.6 * tk * (0.5 + 0.5 * math.sin(t * 4.4)) + EX.get('nod', 0),
           bob=0.010 * breath + 0.018 * tk * abs(math.sin(t * 3.1)) + EX.get('bob', 0),
           squash=0.010 * breath + 0.018 * o + EX.get('squash', 0),
           yaw=5.0 * math.sin(t * 0.37) + 2.0 * tk * math.sin(t * 1.7) + EX.get('yaw', 0),
           arm_l=tuple(hl), arm_r=tuple(hr), widen=EX.get('widen', 0), brow_tilt=EX.get('brow_tilt', 0), lid=EX.get('lid', 0), squint=EX.get('squint', 0), blush=EX.get('blush', 0), hop=EX.get('hop', 0))
    fp = os.path.join(out, f'{f - f0:05d}.png')
    if (f - f0) % STEP: continue                                   # STEP=2 → 15fps 렌더(합성 때 2프레임씩 유지)
    if os.path.exists(fp) and os.path.getsize(fp) > 1000 and '--resume' in sys.argv: continue
    M.render(fp)
    if (f - f0) % 15 == 0: print(f - f0, '/', N, round(time.time() - tm), 's', flush=True)
print('done', N)

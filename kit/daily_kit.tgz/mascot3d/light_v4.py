"""조명 v3 시험: 장면에 '같이 서 있는' 느낌 — ①몸 광택(코트) 줄임 ②정면광 낮추고 위→아래 감쇠 ③무대 링 색 바닥 반사광(카메라엔 안 보이는 발광 링) ④테두리광 약하게"""
import sys, math, bpy, usb_mascot as M, gestures as G
out = sys.argv[1]
M.build(); M.setup_render('host', 600, 20)
L, R, ex = G.gest('explain', 0.75, 1); M.pose(open=0.35, smile=1.1, arm_l=tuple(L), arm_r=tuple(R))
def bsdf(n): return bpy.data.materials[n].node_tree.nodes['Principled BSDF']
def render(tag): M.render(f'{out}/{tag}.png')
M.stage_light_v4('pixel'); render('v4_pixel')
M.stage_light_v4('studio'); render('v4_studio')
M.stage_light_v4('neutral'); render('v4_neutral')

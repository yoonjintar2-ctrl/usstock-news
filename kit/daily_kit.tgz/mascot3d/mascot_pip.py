"""마스코트 RGBA 프레임을 8비트 화면 왼쪽 아래 원형 인서트(수어 통역 화면 방식)로 합성
python3 mascot_pip.py <px_dir> <mascot_dir> <mix.wav> <out.mp4> [start_frame] [n_frames]"""
import cv2, numpy as np, glob, os, sys, subprocess
FPS = 30
PIP_D = int(os.environ.get('PIP_D', 238)); PIP_R = PIP_D // 2
PIP_X, PIP_Y = 52 + PIP_R, int(os.environ.get('PIP_TOP', 1060)) + PIP_R
def disc(d, r, aa=1.5):
    yy, xx = np.mgrid[0:d, 0:d].astype(np.float32) - (d - 1) / 2
    return np.clip((r - np.sqrt(xx * xx + yy * yy)) / aa + .5, 0, 1)
DISC = disc(PIP_D, PIP_R - 1)
RING = np.clip(disc(PIP_D + 16, PIP_R + 6) - np.pad(DISC, 8), 0, 1)
SHADOW = cv2.GaussianBlur(np.pad(disc(PIP_D, PIP_R + 4), 8), (0, 0), 6)[..., None] * 0.45
# 원 안 배경: 밝은 웜그레이 → 아래로 살짝 푸른 톤 + 가운데 은은한 빛
yy, xx = np.mgrid[0:PIP_D, 0:PIP_D].astype(np.float32) / PIP_D
top = np.array([238, 242, 246], np.float32); bot = np.array([214, 220, 230], np.float32)   # BGR
BG = top * (1 - yy[..., None]) + bot * yy[..., None]
glow = np.exp(-(((xx - .5) / .38) ** 2 + ((yy - .42) / .38) ** 2))[..., None]
BG = BG * (1 - .35 * glow) + 252 * .35 * glow

def compose(fr, m, fade=1.0):
    """fr: 1080x1920 BGR float, m: 마스코트 BGRA uint8 (정사각)"""
    m = cv2.resize(m, (PIP_D, PIP_D), interpolation=cv2.INTER_AREA).astype(np.float32)
    a = m[..., 3:4] / 255.0
    inner_img = BG * (1 - a) + m[..., :3] * a
    y0, x0 = PIP_Y - PIP_R - 8, PIP_X - PIP_R - 8
    reg = fr[y0:y0 + PIP_D + 16, x0:x0 + PIP_D + 16]
    reg[:] = reg * (1 - SHADOW * fade)
    ring = RING[..., None] * fade; reg[:] = reg * (1 - ring) + np.array([245, 245, 250], np.float32) * ring
    inner = reg[8:8 + PIP_D, 8:8 + PIP_D]; d = DISC[..., None] * fade
    inner[:] = inner * (1 - d) + inner_img * d
    return fr

if __name__ == '__main__':
    pxdir, mdir, wav, out = sys.argv[1:5]
    s0 = int(sys.argv[5]) if len(sys.argv) > 5 else 0
    frames = sorted(glob.glob(os.path.join(pxdir, '*.png')))
    ms = sorted(glob.glob(os.path.join(mdir, '*.png')))
    n = int(sys.argv[6]) if len(sys.argv) > 6 else len(ms)
    p = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', '1080x1920', '-r', str(FPS), '-i', '-',
                          '-ss', f'{s0 / FPS:.3f}', '-t', f'{n / FPS:.3f}', '-i', wav, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19',
                          '-pix_fmt', 'yuv420p', '-af', f'afade=t=out:st={max(0, n / FPS - 0.5):.2f}:d=0.5',
                          '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-shortest', '-movflags', '+faststart', out], stdin=subprocess.PIPE)
    for i in range(n):
        fr = cv2.imread(frames[min(s0 + i, len(frames) - 1)]).astype(np.float32)
        m = cv2.imread(ms[min(i, len(ms) - 1)], cv2.IMREAD_UNCHANGED)
        p.stdin.write(np.clip(compose(fr, m), 0, 255).astype(np.uint8).tobytes())
    p.stdin.close(); p.wait(); print('done', out)

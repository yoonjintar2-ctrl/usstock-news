"""마스코트 도감 시트: 턴어라운드 4면 + 표정 6종 → sheet/mascot_sheet.png, 개별 PNG도 저장"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bpy, usb_mascot as M
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sheet'); os.makedirs(D, exist_ok=True)
SPP = int(sys.argv[1]) if len(sys.argv) > 1 else 48
ONLY = os.environ.get('ONLY')            # 예: ONLY=happy → 해당 표정만 다시 렌더 / ONLY=none → 합성만
M.build()
views = [('front', (0, -8.2, 1.5)), ('q34', (4.2, -7.0, 2.2)), ('side', (8.2, 0, 1.5)), ('back', (-3.0, 7.6, 1.9))]
for k, loc in views:
    if ONLY: break
    M.setup_render('front', 560, SPP)
    bpy.data.objects['cam'].location = loc
    M.pose(open=0.0, arm_l=(0, 0, 0), arm_r=(0, 0, 0))
    M.render(f'{D}/view_{k}.png')
expr = {
    'smile':   dict(),
    'talk':    dict(open=0.75, brow=0.3, smile=0.8, arm_r=(-0.12, -0.2, 0.36, 18)),
    'wow':     dict(open=0.95, brow=1.0, smile=0.0, look=(0, 0.2), lean=-3, arm_l=(-0.05, -0.2, 0.4, 10), arm_r=(-0.05, -0.2, 0.4, 10)),
    'happy':   dict(open=0.55, blink=0.30, brow=0.7, smile=1.0, squash=0.04, look=(0, 0.25)),
    'think':   dict(open=0.0, look=(-0.7, 0.6), brow=-0.4, smile=0.3, lean=4, arm_r=(-0.25, -0.25, 0.30, 40)),
    'point':   dict(open=0.3, brow=0.2, look=(0.6, 0), yaw=-8, arm_l=(0.25, -0.15, 0.45, -10)),
}
for k, kw in expr.items():
    if ONLY and k not in ONLY.split(','): continue
    M.setup_render('pip', 480, SPP)
    M.pose(**kw)
    M.render(f'{D}/expr_{k}.png')
if not ONLY: M.pose(); M.save(os.path.join(os.path.dirname(D), 'usb_mascot.blend'))

# ---- 시트 합성
from PIL import Image, ImageDraw, ImageFont
F = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def font(s): return ImageFont.truetype(F, s, index=1)
W = 2400; Hh = 1600
sheet = Image.new('RGB', (W, Hh), (240, 237, 232)); d = ImageDraw.Draw(sheet)
d.rectangle([0, 0, W, 110], fill=(28, 28, 32))
d.text((60, 22), '샌디스크 올인 마스코트 · 캐릭터 도감 (3D)', font=font(52), fill=(255, 255, 255))
tb = d.textbbox((0, 0), 'USB · v2 · 2026.10', font=font(32)); bw = tb[2] - tb[0] + 44
d.rectangle([W - 60 - bw, 28, W - 60, 82], fill=(200, 20, 24)); d.text((W - 60 - bw + 22, 32), 'USB · v2 · 2026.10', font=font(32), fill=(255, 255, 255))
labels = {'front': '정면', 'q34': '3/4', 'side': '측면', 'back': '후면'}
x = 40
for k, _ in views:
    im = Image.open(f'{D}/view_{k}.png').convert('RGBA'); im = im.crop(im.getchannel('A').getbbox())
    sc = min(640 / im.height, 540 / im.width); im = im.resize((int(im.width * sc), int(im.height * sc)), Image.LANCZOS)
    sheet.paste(im, (x + (560 - im.width) // 2, 140 + (640 - im.height)), im); d.text((x + 240, 805), labels[k], font=font(36), fill=(60, 60, 66)); x += 590
d.line([40, 870, W - 40, 870], fill=(200, 196, 190), width=3)
el = {'smile': '기본 미소', 'talk': '설명', 'wow': '놀람', 'happy': '활짝', 'think': '생각', 'point': '가리키기'}
x = 40
for k in expr:
    im = Image.open(f'{D}/expr_{k}.png').convert('RGBA').resize((360, 360), Image.LANCZOS)
    mask = Image.new('L', (360, 360), 0); ImageDraw.Draw(mask).ellipse([0, 0, 359, 359], fill=255)
    bg = Image.new('RGBA', (360, 360), (226, 230, 238, 255)); bg.alpha_composite(im)
    d.ellipse([x - 8, 902, x + 368, 1278], fill=(255, 255, 255))
    sheet.paste(bg, (x, 910), mask); d.text((x + 180 - len(el[k]) * 19, 1300), el[k], font=font(38), fill=(60, 60, 66)); x += 390
d.text((60, 1400), '차콜 무광 몸체(반사 적게) · 빨간 뒷 껍데기 · 은색 USB-A 단자 · 빨간 스위블 캡(고리) · 큰 갈색 눈 · 가슴 빨간 픽셀 체커 · 장갑 손 + 빨간 밴드 · 빨간 밑창 신발', font=font(32), fill=(80, 80, 86))
d.text((60, 1460), '영상에서는 이름 소개 없이 왼쪽 아래 원형 인서트로 등장 · 내레이션 목소리 6번', font=font(32), fill=(80, 80, 86))
sheet.save(f'{D}/mascot_sheet.png'); print('sheet ok')

"""v3 동작 시연 클립(소리 없음): 인사→옆 화면 가리킴→깜짝→이마 짚기→만세→꾸벅"""
import sys, os, math, numpy as np, bpy, usb_mascot as M, gestures as G
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
SEQ = [(0.2, 'wave', 1), (1.9, 'side', -1), (4.1, 'wow', 1), (5.5, 'facepalm', 1), (7.6, 'cheer', 1), (9.3, 'bow', 1)]; N = int(11.0 * 30)
M.build(); M.setup_render('host', 420, 12); M.stage_light_v3('studio')
def ease(u): u = min(1, max(0, u)); return u * u * (3 - 2 * u)
hl = np.zeros(4); hr = np.zeros(4); vl = np.zeros(4); vr = np.zeros(4)
for f in range(N):
    t = f / 30; L = np.zeros(4); R = np.zeros(4); EX = {}
    for st, k, sd in SEQ:
        l, r, ex = G.gest(k, t - st, sd); L += l; R += r
        for a, v in ex.items():
            if a == 'look': EX[a] = tuple(np.add(EX.get(a, (0, 0)), v))
            elif a == 'smile': EX[a] = v
            else: EX[a] = EX.get(a, 0) + v
    br = math.sin(2 * math.pi * t / 3.6)
    vl += (L - hl) * 0.22 - vl * 0.42; hl += vl; vr += (R - hr) * 0.22 - vr * 0.42; hr += vr
    bl = max((1 - abs((t - b) / 0.09 - 1)) if 0 <= t - b < 0.18 else 0 for b in (1.3, 3.7, 6.9, 8.9))
    M.pose(open=EX.get('mouth', 0.12 + 0.1 * abs(math.sin(t * 9)) * (t % 2 < 1.2)), blink=bl, look=EX.get('look', (0, 0)), brow=0.15 + EX.get('brow', 0), smile=EX.get('smile', 1.0),
           lean=2.0 * math.sin(t * 0.62) + EX.get('lean', 0), nod=EX.get('nod', 0), bob=0.010 * br + EX.get('bob', 0), squash=0.010 * br + EX.get('squash', 0),
           yaw=4.0 * math.sin(t * 0.37) + EX.get('yaw', 0), arm_l=tuple(hl), arm_r=tuple(hr), widen=EX.get('widen', 0), brow_tilt=EX.get('brow_tilt', 0),
           lid=EX.get('lid', 0), squint=EX.get('squint', 0), blush=EX.get('blush', 0), hop=EX.get('hop', 0))
    fp = f'{out}/{f:05d}.png'
    if not os.path.exists(fp): M.render(fp)
print('DEMODONE')

import sys, os, bpy, usb_mascot as M, gestures as G
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
M.build()
M.setup_render('host', 360, 12); M.stage_light_v4('neutral')
T = dict(wow=0.3, jump=0.48, bow=0.6, count=0.3, rise=1.0, fall=1.2, weigh=0.4, doze=0.75, pump=0.3, around=0.5, stretch=1.2)
NEW = list(G.DUR)[20:]
for i, k in enumerate(NEW):
    L, R, ex = G.gest(k, T.get(k, 0.75), 1); kw = dict(open=ex.pop('mouth', 0.25), smile=ex.pop('smile', 1.0)); kw.update(ex)
    M.pose(arm_l=tuple(L), arm_r=tuple(R), **kw); M.render(f'{out}/n{i:02d}_{k}.png')

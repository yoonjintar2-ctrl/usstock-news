"""샌디스크 올인 USB 마스코트 — 3D 캐릭터 자산 (Blender bpy, 헤드리스)

레퍼런스: ref/logo_mascot_ref.jpg (로고 그림체), ref/clay_ref.png (클레이 버전)
구성: 차콜 무광 몸체 + 은색 USB-A 단자 + 뒤쪽 빨간 스위블 캡(고리 구멍) + 큰 갈색 눈 + 웃는 입
      + 가슴 빨간 체커 엠블럼 + 장갑 손(빨간 손목 밴드) + 짧은 다리와 빨간 밑창 신발.

사용:
    import usb_mascot as M
    M.build()                                  # 씬 생성
    M.pose(open=0.6, blink=0, look=(0,0), brow=0.2, lean=0, bob=0, yaw=0,
           arm_l=(0,0,0), arm_r=(0,0,0))       # 표정·자세
    M.setup_render('pip')                      # 'pip'(원형 인서트용 상반신) / 'full'(전신)
    M.render('/path/out.png')
pose 인수: open 입 벌림 0~1, blink 눈 감김 0~1, look 눈동자(-1~1, -1~1), brow 눈썹 올림 -1~1,
          smile 입꼬리 0~1, lean 몸 좌우 기울임(도), nod 앞뒤 끄덕(도), bob 상하(단위), squash 눌림(-0.1~0.1),
          yaw 몸 좌우 회전(도), arm_l/arm_r 손 위치 오프셋 (x 바깥, y 앞, z 위) 단위."""
import bpy, bmesh, math
from mathutils import Vector, Matrix, Euler

# ---------------------------------------------------------------- 치수 (Z 위, 정면은 -Y)
BA, BB, BC = 0.50, 0.29, 0.74          # 몸체 반폭·반두께·반높이
FRONT = -BB                            # 정면 평면 y
EYE_X, EYE_Z = 0.205, 0.30
MOUTH_Z = 0.035
EMB_Z = -0.25
SHOULDER = (0.47, 0.0, -0.06)
HIP_X, HIP_Z = 0.21, -0.70

P = {}                                 # 이름 → 오브젝트

# ---------------------------------------------------------------- 유틸
def _sp(v, e):
    return math.copysign(abs(v) ** e, v)

def superq_mesh(name, a, b, c, e1=0.3, e2=0.3, nu=56, nv=72, taper=0.0, taper_y=0.0):
    """둥근 사각 덩어리(슈퍼쿼드릭). taper: 아래로 갈수록 x 폭 축소 비율"""
    verts, faces = [], []
    us = [-math.pi / 2 + math.pi * i / nu for i in range(1, nu)]
    for u in us:
        for j in range(nv):
            v = -math.pi + 2 * math.pi * j / nv
            x = a * _sp(math.cos(u), e1) * _sp(math.cos(v), e2)
            y = b * _sp(math.cos(u), e1) * _sp(math.sin(v), e2)
            z = c * _sp(math.sin(u), e1)
            k = max(0.0, -z / c)
            x *= 1 - taper * k ** 1.6
            y *= 1 - taper_y * k ** 1.6
            verts.append((x, y, z))
    bot = len(verts); verts.append((0, 0, -c))
    top = len(verts); verts.append((0, 0, c))
    R = len(us)
    for i in range(R - 1):
        for j in range(nv):
            a0 = i * nv + j; a1 = i * nv + (j + 1) % nv
            faces.append((a0, a1, a1 + nv, a0 + nv))
    for j in range(nv):
        faces.append((bot, (j + 1) % nv, j))
        faces.append((top, (R - 1) * nv + j, (R - 1) * nv + (j + 1) % nv))
    me = bpy.data.meshes.new(name); me.from_pydata(verts, [], faces); me.update()
    for p in me.polygons: p.use_smooth = True
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob)
    return ob

def mat(name, color, rough=0.5, metal=0.0, coat=0.0, emit=None, spec=0.5, sss=0.0):
    m = bpy.data.materials.get(name)
    if m: return m
    m = bpy.data.materials.new(name); m.use_nodes = True
    b = m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = (*color, 1)
    b.inputs['Roughness'].default_value = rough
    b.inputs['Metallic'].default_value = metal
    b.inputs['Coat Weight'].default_value = coat
    b.inputs['Coat Roughness'].default_value = 0.25
    b.inputs['Specular IOR Level'].default_value = spec
    if emit is not None:
        b.inputs['Emission Color'].default_value = (*emit, 1); b.inputs['Emission Strength'].default_value = 1.0
    return m

def outline_mat():
    m = bpy.data.materials.get('Outline')
    if m: return m
    m = bpy.data.materials.new('Outline'); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    mix = nt.nodes.new('ShaderNodeMixShader')
    tr = nt.nodes.new('ShaderNodeBsdfTransparent')
    em = nt.nodes.new('ShaderNodeEmission'); em.inputs['Color'].default_value = (0.008, 0.008, 0.01, 1); em.inputs['Strength'].default_value = 1
    # 카메라 광선에만 보이게(그림자·반사 광선엔 투명) — 안 그러면 껍데기가 빛을 막아 몸이 새까매짐
    lp = nt.nodes.new('ShaderNodeLightPath')
    inv = nt.nodes.new('ShaderNodeMath'); inv.operation = 'SUBTRACT'; inv.inputs[0].default_value = 1.0
    nt.links.new(lp.outputs['Is Camera Ray'], inv.inputs[1])
    mx = nt.nodes.new('ShaderNodeMath'); mx.operation = 'MAXIMUM'
    nt.links.new(geo.outputs['Backfacing'], mx.inputs[0]); nt.links.new(inv.outputs[0], mx.inputs[1])
    nt.links.new(mx.outputs[0], mix.inputs['Fac'])
    nt.links.new(em.outputs[0], mix.inputs[1]); nt.links.new(tr.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs['Surface'])
    return m

def give(ob, m, outline=0.0):
    ob.data.materials.clear(); ob.data.materials.append(m)
    if outline > 0:
        ob.data.materials.append(outline_mat())
        sd = ob.modifiers.new('outline', 'SOLIDIFY')
        sd.thickness = outline; sd.offset = 1.0; sd.use_flip_normals = True; sd.use_rim = False
        sd.material_offset = 1
    return ob

def parent(ch, pa, keep=True):
    mw = ch.matrix_world.copy(); ch.parent = pa
    if keep: ch.matrix_parent_inverse = pa.matrix_world.inverted()
    return ch

def empty(name, loc=(0, 0, 0), pa=None):
    e = bpy.data.objects.new(name, None); e.location = loc; e.empty_display_size = 0.1
    bpy.context.scene.collection.objects.link(e)
    if pa: e.parent = pa
    P[name] = e
    return e

def sphere(name, loc, scale, m, seg=40, ring=24, outline=0.0, pa=None):
    me = bpy.data.meshes.new(name); bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=seg, v_segments=ring, radius=1.0)
    bm.to_mesh(me); bm.free()
    for p in me.polygons: p.use_smooth = True
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob)
    ob.location = loc; ob.scale = scale
    give(ob, m, outline)
    if pa: ob.parent = pa
    P[name] = ob
    return ob

def flat_poly(name, pts2d, y, m, pa=None):
    """정면(-Y 방향)을 보는 평면 다각형 (x,z) 리스트. 삼각 팬"""
    n = len(pts2d)
    cx = sum(p[0] for p in pts2d) / n; cz = sum(p[1] for p in pts2d) / n
    verts = [(cx, y, cz)] + [(p[0], y, p[1]) for p in pts2d]
    faces = [(0, 1 + (i + 1) % n, 1 + i) for i in range(n)]
    me = bpy.data.meshes.new(name); me.from_pydata(verts, [], faces); me.update()
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob)
    give(ob, m)
    if pa: ob.parent = pa
    P[name] = ob
    return ob

def box(name, loc, half, m, bevel=0.0, seg=3, outline=0.0, pa=None):
    me = bpy.data.meshes.new(name); bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=2.0); bm.to_mesh(me); bm.free()
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob)
    ob.location = loc; ob.scale = half
    if bevel > 0:
        bv = ob.modifiers.new('bevel', 'BEVEL'); bv.width = bevel; bv.segments = seg; bv.limit_method = 'NONE'
        bv.harden_normals = False
        for p in me.polygons: p.use_smooth = True
        me.shade_smooth() if hasattr(me, 'shade_smooth') else None
    give(ob, m, outline)
    if pa: ob.parent = pa
    P[name] = ob
    return ob

def tube_curve(name, pts, radius, m, outline=0.0, pa=None):
    cu = bpy.data.curves.new(name, 'CURVE'); cu.dimensions = '3D'
    cu.bevel_depth = radius; cu.bevel_resolution = 6; cu.use_fill_caps = True; cu.resolution_u = 16
    sp = cu.splines.new('NURBS'); sp.points.add(len(pts) - 1)
    for p, q in zip(sp.points, pts): p.co = (*q, 1)
    sp.use_endpoint_u = True; sp.order_u = 3
    ob = bpy.data.objects.new(name, cu); bpy.context.scene.collection.objects.link(ob)
    cu.materials.append(m)
    if outline > 0:
        cu.materials.append(outline_mat())
        sd = ob.modifiers.new('outline', 'SOLIDIFY'); sd.thickness = outline; sd.offset = 1.0
        sd.use_flip_normals = True; sd.use_rim = False; sd.material_offset = 1
    if pa: ob.parent = pa
    P[name] = ob
    return ob

# ---------------------------------------------------------------- 재질
def materials():
    return dict(
        body=mat('Charcoal', (0.030, 0.030, 0.034), rough=0.48, coat=0.25, spec=0.45),
        red=mat('RedPlastic', (0.62, 0.016, 0.018), rough=0.32, coat=0.4),
        metal=mat('Silver', (0.80, 0.80, 0.82), rough=0.2, metal=1.0),
        gold=mat('Gold', (1.0, 0.68, 0.28), rough=0.25, metal=1.0),
        hole=mat('Hole', (0.01, 0.01, 0.012), rough=0.8),
        white=mat('EyeWhite', (0.92, 0.91, 0.89), rough=0.12, coat=0.6),
        iris=mat('Iris', (0.20, 0.075, 0.025), rough=0.12, coat=0.8),
        iris_ring=mat('IrisRing', (0.035, 0.012, 0.006), rough=0.2),
        pupil=mat('Pupil', (0.004, 0.003, 0.003), rough=0.08, coat=1.0),
        hi=mat('Highlight', (1, 1, 1), rough=0.5, emit=(1, 1, 1)),
        ink=mat('Ink', (0.006, 0.006, 0.008), rough=0.6),
        brow=mat('Brow', (0.012, 0.012, 0.014), rough=0.5),
        cavity=mat('MouthCavity', (0.16, 0.006, 0.010), rough=0.5),
        tongue=mat('Tongue', (0.85, 0.20, 0.22), rough=0.35, coat=0.3),
        teeth=mat('Teeth', (0.95, 0.94, 0.92), rough=0.25),
        glove=mat('Glove', (0.040, 0.040, 0.044), rough=0.55, coat=0.15),
        cream=mat('Cream', (0.80, 0.74, 0.62), rough=0.4),
    )

# ---------------------------------------------------------------- 입 (매 프레임 정점 갱신)
MOUTH_N = 25
MOUTH_HW = 0.115

def mouth_curves(o, smile=1.0):
    """윗선·아랫선 (x, z) — o: 벌림 0~1"""
    top, bot = [], []
    hw = MOUTH_HW * (1 - 0.18 * o)               # 크게 벌리면 살짝 좁아짐
    d = 0.016 + 0.135 * o                         # 아래 깊이
    for i in range(MOUTH_N):
        s = -1 + 2 * i / (MOUTH_N - 1); x = s * hw
        up = (0.030 * smile + 0.004) * s * s       # 입꼬리 올라감
        zt = up + 0.010 * o * (1 - s * s)           # 벌리면 윗입술 살짝 들림
        zb = up - d * math.sqrt(max(0.0, 1 - s * s)) ** 0.9 - 0.004
        top.append((x, zt)); bot.append((x, zb))
    return top, bot

def mouth_mesh_coords(o, smile, grow=0.0):
    top, bot = mouth_curves(o, smile)
    vs = []
    for (x, zt), (_, zb) in zip(top, bot):
        k = 1 + grow / MOUTH_HW
        vs.append((x * k, zt + grow)); vs.append((x * k, zb - grow))
    # 끝점 바깥으로 살짝(외곽선 두께 유지)
    return vs

def make_strip(name, m, y, pa):
    n = MOUTH_N
    verts = [(0, y, 0)] * (2 * n)
    faces = [(2 * i, 2 * i + 2, 2 * i + 3, 2 * i + 1) for i in range(n - 1)]
    me = bpy.data.meshes.new(name); me.from_pydata(verts, [], faces); me.update()
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob)
    give(ob, m); ob.parent = pa; P[name] = ob
    return ob

def set_strip(ob, coords, y):
    for i, (x, z) in enumerate(coords):
        ob.data.vertices[i].co = (x, y, z)
    ob.data.update()

def update_mouth(o, smile=1.0):
    y0 = FRONT - 0.0015
    set_strip(P['mouth_ink'], mouth_mesh_coords(o, smile, grow=0.012), y0)
    set_strip(P['mouth_cav'], mouth_mesh_coords(o, smile), y0 - 0.0015)
    # 혀: 아랫부분 타원 (벌림에 비례해 나타남)
    t = max(0.0, (o - 0.18) / 0.82)
    tg = P['tongue']; tg.scale = (0.072 * (0.4 + 0.6 * t), 0.004, 0.040 * t + 1e-4)
    top, bot = mouth_curves(o, smile)
    zb = bot[MOUTH_N // 2][1]
    tg.location = (0.0, y0 - 0.003, zb + 0.026 * t + 0.006)
    tg.hide_render = t < 0.02
    # 윗니: 윗선 아래 얇은 띠
    tt = min(1.0, max(0.0, (o - 0.10) / 0.35))
    tc = []
    for i, (x, zt) in enumerate(top):
        s = -1 + 2 * i / (MOUTH_N - 1)
        h = 0.030 * tt * math.sqrt(max(0.0, 1 - s * s)) ** 0.6
        k = 0.80
        tc.append((x * k, zt - 0.003)); tc.append((x * k, zt - 0.003 - h))
    set_strip(P['teeth'], tc, y0 - 0.0035)
    P['teeth'].hide_render = tt < 0.02

# ---------------------------------------------------------------- 빌드
def build():
    sc = bpy.context.scene
    for ob in list(bpy.data.objects): bpy.data.objects.remove(ob, do_unlink=True)
    P.clear()
    M = materials()

    root = empty('root')                      # 전체 위치 (발밑 기준)
    hip = empty('hip', (0, 0, 0), root)       # 몸 회전·기울임 피벗 (몸 아랫부분)
    body_pv = empty('body', (0, 0, 0), hip)   # 몸통 중심

    # 몸체
    body = superq_mesh('body_mesh', BA, BB, BC, e1=0.30, e2=0.34, taper=0.16, taper_y=0.10)
    give(body, M['body'], outline=0.014); body.parent = body_pv; P['body_mesh'] = body
    # 상단 칼라(단자 들어가는 턱)
    col = superq_mesh('collar', 0.345, 0.150, 0.045, e1=0.25, e2=0.25, nu=20, nv=48)
    col.location = (0, 0.0, BC - 0.012); give(col, M['body'], outline=0.010); col.parent = body_pv; P['collar'] = col

    # USB-A 단자 (은색 쉘)
    plug = empty('plug', (0, 0.0, BC + 0.02), body_pv)
    sh = superq_mesh('plug_shell', 0.300, 0.118, 0.255, e1=0.10, e2=0.12, nu=40, nv=64)
    sh.location = (0, 0, 0.235); give(sh, M['metal'], outline=0.010); sh.parent = plug; P['plug_shell'] = sh
    # 윗면 개구부(어두운 안쪽) + 빨간 혀(내부 플라스틱)
    flat_top = BC  # 참조용
    op = box('plug_open', (0, 0, 0.235 + 0.255 - 0.004), (0.272, 0.094, 0.006), M['hole'], pa=plug)
    tongue = box('plug_tongue', (0, 0.035, 0.235 + 0.255 - 0.003), (0.250, 0.040, 0.006), M['red'], pa=plug)
    # 정면 사각 구멍 2개 + 금색 접점
    for sx, nm in ((-1, 'L'), (1, 'R')):
        hx = sx * 0.125; hz = 0.235 + 0.075
        box(f'plug_hole_{nm}', (hx, -0.118 - 0.002, hz), (0.050, 0.004, 0.045), M['hole'], pa=plug)
        box(f'plug_gold_{nm}', (hx, -0.118 - 0.0045, hz - 0.016), (0.032, 0.002, 0.018), M['gold'], pa=plug)

    # 뒤 빨간 스위블 캡 + 고리
    cap = superq_mesh('swivel', 0.535, 0.050, 0.70, e1=0.28, e2=0.30, nu=40, nv=56, taper=0.14)
    cap.location = (0, BB + 0.010, -0.03); give(cap, M['red'], outline=0.012); cap.parent = body_pv; P['swivel'] = cap
    tab = superq_mesh('swivel_tab', 0.135, 0.050, 0.30, e1=0.45, e2=0.30, nu=36, nv=48)
    tab.location = (0.36, BB + 0.010, BC + 0.05); tab.rotation_euler = (0, math.radians(-14), 0)
    give(tab, M['red'], outline=0.012); tab.parent = body_pv; P['swivel_tab'] = tab
    hole = superq_mesh('tab_hole_cut', 0.050, 0.3, 0.085, e1=0.7, e2=0.7, nu=16, nv=24)
    hole.parent = tab; hole.location = (0, 0, 0.15)
    hole.hide_render = True; hole.hide_viewport = True
    bo = tab.modifiers.new('hole', 'BOOLEAN'); bo.object = hole; bo.operation = 'DIFFERENCE'; bo.solver = 'EXACT'
    tab.modifiers.move(len(tab.modifiers) - 1, 0)

    # 눈 (각 눈: eye_X 피벗 → 흰자/외곽 · 동공 그룹 look_X)
    for sx, nm in ((-1, 'L'), (1, 'R')):
        ex = sx * EYE_X
        e = empty(f'eye_{nm}', (ex, FRONT - 0.005, EYE_Z), body_pv)
        sphere(f'eye_ink_{nm}', (0, 0.010, 0), (0.122, 0.040, 0.150), M['ink'], pa=e)
        sphere(f'eye_white_{nm}', (0, 0.002, 0), (0.106, 0.042, 0.134), M['white'], pa=e)
        lk = empty(f'look_{nm}', (sx * 0.012, 0, -0.012), e)
        sphere(f'iris_ring_{nm}', (0, -0.030, 0), (0.077, 0.014, 0.090), M['iris_ring'], pa=lk)
        sphere(f'iris_{nm}', (0, -0.036, -0.004), (0.068, 0.012, 0.080), M['iris'], pa=lk)
        sphere(f'pupil_{nm}', (0, -0.043, -0.002), (0.040, 0.008, 0.048), M['pupil'], pa=lk)
        sphere(f'hi1_{nm}', (0.024, -0.050, 0.030), (0.020, 0.005, 0.023), M['hi'], pa=lk)
        sphere(f'hi2_{nm}', (-0.026, -0.049, -0.034), (0.009, 0.004, 0.010), M['hi'], pa=lk)
        # 눈썹 (곡선 튜브)
        b = empty(f'brow_{nm}', (ex + sx * 0.005, FRONT - 0.004, EYE_Z + 0.205), body_pv)
        tube_curve(f'brow_tube_{nm}', [(-sx * 0.060, 0, -0.022), (sx * 0.0, 0, 0.012), (sx * 0.068, 0, -0.008)], 0.0125, M['brow'], pa=b)

    # 입
    mpv = empty('mouth', (0, 0, MOUTH_Z), body_pv)
    make_strip('mouth_ink', M['ink'], FRONT, mpv)
    make_strip('mouth_cav', M['cavity'], FRONT, mpv)
    make_strip('teeth', M['teeth'], FRONT, mpv)
    sphere('tongue', (0, FRONT, 0), (0.05, 0.004, 0.03), M['tongue'], pa=mpv)
    update_mouth(0.0)

    # 가슴 엠블럼: 빨간 픽셀 체커 (로고의 체크 무늬)
    pat = [(1, 0), (0, 1), (1, 2), (0, 3)]
    s = 0.034
    for i, (cx, cz) in enumerate(pat):
        box(f'emb_{i}', ((cx - 0.5) * s * 1.05, FRONT - 0.003, EMB_Z + (1.5 - cz) * s * 1.05), (s / 2, 0.006, s / 2), M['red'], bevel=0.004, seg=2, pa=body_pv)

    # 팔·손
    for sx, nm in ((-1, 'L'), (1, 'R')):
        sh_ = empty(f'shoulder_{nm}', (sx * SHOULDER[0], SHOULDER[1], SHOULDER[2]), body_pv)
        hand = empty(f'hand_{nm}', (sx * 0.70, -0.16, -0.36), body_pv)
        arm = tube_curve(f'arm_{nm}', [(0, 0, 0)] * 3, 0.058, M['glove'], outline=0.010, pa=body_pv)
        # 손: 장갑(둥근 손바닥 + 손가락 셋 + 엄지) + 빨간 손목 밴드
        g = empty(f'glove_{nm}', (0, 0, 0), hand)
        sphere(f'palm_{nm}', (0, 0, 0), (0.105, 0.085, 0.092), M['glove'], outline=0.010, pa=g)
        for k in range(3):
            sphere(f'finger_{nm}{k}', (sx * (0.02 + 0.0) + (k - 1) * 0.062, -0.060, -0.065), (0.040, 0.050, 0.048), M['glove'], outline=0.008, pa=g)
        sphere(f'thumb_{nm}', (-sx * 0.085, -0.050, 0.010), (0.038, 0.042, 0.050), M['glove'], outline=0.008, pa=g)
        cuff = superq_mesh(f'cuff_{nm}', 0.083, 0.083, 0.030, e1=0.6, e2=1.0, nu=16, nv=32)
        cuff.location = (0, 0.0, 0.095); give(cuff, M['red'], outline=0.008); cuff.parent = g; P[f'cuff_{nm}'] = cuff

    # 다리·신발
    for sx, nm in ((-1, 'L'), (1, 'R')):
        lg = tube_curve(f'leg_{nm}', [(sx * HIP_X, 0.02, HIP_Z + 0.05), (sx * (HIP_X + 0.02), 0.0, -0.88), (sx * (HIP_X + 0.03), -0.02, -1.02)], 0.060, M['glove'], outline=0.010, pa=hip)
        shoe = superq_mesh(f'shoe_{nm}', 0.115, 0.170, 0.075, e1=0.45, e2=0.6, nu=24, nv=40)
        shoe.location = (sx * (HIP_X + 0.035), -0.06, -1.07); give(shoe, M['glove'], outline=0.010); shoe.parent = hip; P[f'shoe_{nm}'] = shoe
        sole = superq_mesh(f'sole_{nm}', 0.122, 0.178, 0.026, e1=0.5, e2=0.6, nu=12, nv=40)
        sole.location = (sx * (HIP_X + 0.035), -0.06, -1.13); give(sole, M['red'], outline=0.008); sole.parent = hip; P[f'sole_{nm}'] = sole

    # 몸은 hip 기준(발이 땅) — 발바닥이 z=0 이 되도록 root 높이
    root.location = (0, 0, 1.16)
    lights(); world()
    pose()
    return P

def lights():
    def area(name, loc, rot, energy, size, color=(1, 1, 1)):
        ld = bpy.data.lights.new(name, 'AREA'); ld.energy = energy; ld.size = size; ld.color = color
        ob = bpy.data.objects.new(name, ld); bpy.context.scene.collection.objects.link(ob)
        ob.location = loc; ob.rotation_euler = [math.radians(a) for a in rot]
        return ob
    area('key', (-2.2, -3.0, 3.6), (52, 0, -36), 520, 2.6, (1.0, 0.97, 0.93))
    area('fill', (2.8, -2.6, 1.6), (70, 0, 46), 170, 3.0, (0.92, 0.95, 1.0))
    area('rim', (1.6, 2.6, 3.0), (-50, 0, 150), 380, 1.6, (1.0, 0.93, 0.88))
    area('rimL', (-2.2, 2.2, 1.8), (-65, 0, -135), 160, 1.6, (0.9, 0.93, 1.0))

def world():
    w = bpy.data.worlds.get('W') or bpy.data.worlds.new('W'); bpy.context.scene.world = w
    w.use_nodes = True; bg = w.node_tree.nodes['Background']
    bg.inputs['Color'].default_value = (0.82, 0.83, 0.86, 1); bg.inputs['Strength'].default_value = 0.42

# ---------------------------------------------------------------- 자세·표정
def _arm(nm, sx, off):
    sh = P[f'shoulder_{nm}']; hd = P[f'hand_{nm}']
    hx, hy, hz = 0.66 + off[0], -0.17 + off[1], -0.34 + off[2]
    hd.location = (sx * hx, hy, hz)
    S = Vector(sh.location); H = Vector(hd.location)
    mid = (S + H) / 2 + Vector((sx * 0.07, -0.02, 0.05))
    end = H + (S - H).normalized() * 0.07
    pts = [S + Vector((-sx * 0.04, 0, 0)), mid, end]
    for p, q in zip(P[f'arm_{nm}'].data.splines[0].points, pts): p.co = (*q, 1)
    # 손목 방향: 팔 진행 방향으로 기울임
    tw = off[3] if len(off) > 3 else 0.0                 # 손목 비틀기(도)
    hd.rotation_euler = (0.0, math.radians(sx * -18), math.radians(sx * -25 + tw))

def pose(open=0.0, blink=0.0, look=(0.0, 0.0), brow=0.0, smile=1.0, lean=0.0, nod=0.0, bob=0.0, squash=0.0, yaw=0.0,
         arm_l=(0, 0, 0), arm_r=(0, 0, 0)):
    hip = P['hip']; body = P['body']
    hip.rotation_euler = (math.radians(nod * 0.5), math.radians(lean), math.radians(yaw))
    body.location = (0, 0, bob)
    body.rotation_euler = (math.radians(nod * 0.5), math.radians(lean * 0.4), 0)
    body.scale = (1 + squash * 0.5, 1 + squash * 0.5, 1 - squash)
    for nm in 'LR':
        e = P[f'eye_{nm}']
        b = min(1.0, max(0.0, blink))
        e.scale = (1.0, 1.0, max(0.06, 1 - 0.94 * b))
        e.location.z = EYE_Z - 0.035 * b
        sx = -1 if nm == 'L' else 1
        P[f'look_{nm}'].location = (sx * 0.012 + 0.030 * look[0], 0, -0.012 + 0.030 * look[1])
        P[f'brow_{nm}'].location.z = EYE_Z + 0.205 + 0.035 * brow - 0.03 * b
        P[f'brow_{nm}'].rotation_euler = (0, math.radians(-sx * 6 * brow), 0)
    update_mouth(open, smile)
    _arm('L', -1, arm_l); _arm('R', 1, arm_r)

# ---------------------------------------------------------------- 렌더 설정
def setup_render(mode='pip', res=520, samples=40):
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'
    sc.cycles.device = 'CPU'; sc.cycles.samples = samples
    sc.cycles.use_denoising = True
    try: sc.cycles.denoiser = 'OPENIMAGEDENOISE'
    except Exception: pass
    sc.cycles.max_bounces = 6; sc.cycles.transparent_max_bounces = 12
    sc.render.film_transparent = True
    sc.view_settings.view_transform = 'AgX'
    try: sc.view_settings.look = 'AgX - Medium High Contrast'
    except Exception: pass
    sc.render.image_settings.file_format = 'PNG'; sc.render.image_settings.color_mode = 'RGBA'
    cam = bpy.data.objects.get('cam')
    if cam is None:
        cd = bpy.data.cameras.new('cam'); cam = bpy.data.objects.new('cam', cd); sc.collection.objects.link(cam)
    sc.camera = cam
    tgt = bpy.data.objects.get('cam_tgt') or empty('cam_tgt')
    con = cam.constraints.get('track') or cam.constraints.new('TRACK_TO'); con.name = 'track'; con.target = tgt
    con.track_axis = 'TRACK_NEGATIVE_Z'; con.up_axis = 'UP_Y'
    if mode == 'pip':           # 원형 인서트: 단자 끝~손까지 (상반신)
        sc.render.resolution_x = sc.render.resolution_y = res
        cam.data.lens = 85; cam.location = (1.05, -6.4, 2.25); tgt.location = (0.0, 0, 1.38)
    elif mode == 'full':        # 전신 정면 3/4
        sc.render.resolution_x = res; sc.render.resolution_y = int(res * 1.25)
        cam.data.lens = 70; cam.location = (1.6, -8.0, 1.9); tgt.location = (0.0, 0, 1.12)
    elif mode in ('front', 'side', 'back'):
        sc.render.resolution_x = res; sc.render.resolution_y = int(res * 1.25)
        cam.data.lens = 70
        d = {'front': (0, -8.2, 1.3), 'side': (8.2, 0, 1.3), 'back': (0, 8.2, 1.3)}[mode]
        cam.location = d; tgt.location = (0, 0, 1.12)
    sc.render.resolution_percentage = 100

def render(path):
    bpy.context.scene.render.filepath = path
    bpy.ops.render.render(write_still=True)

def save(path):
    bpy.ops.wm.save_as_mainfile(filepath=path)

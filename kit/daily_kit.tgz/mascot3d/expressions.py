"""마스코트 표정 프리셋 (2026-11-11 v3) — M.pose(**EXPR[이름]) · 동작(gestures.py)과 겹쳐 쓸 수 있음"""
EXPR = {
 '기본':   dict(smile=1.0),
 '활짝':   dict(open=0.75, smile=1.5, brow=0.6, squint=0.45, blush=1),
 '웃는눈': dict(open=0.25, smile=1.5, squint=0.78, brow=0.5, blush=1),
 '놀람':   dict(open=0.8, smile=0.0, widen=1.0, brow=1.2),
 '궁금':   dict(smile=0.5, brow=0.8, brow_tilt=0.6, look=(0.2, 0.35), lean=4),
 '생각':   dict(smile=0.6, look=(-0.6, 0.55), brow=0.3, brow_tilt=0.3, lid=0.2),
 '걱정':   dict(open=0.15, smile=-0.7, brow_tilt=1.0, look=(0, -0.2), widen=0.3),
 '시무룩': dict(smile=-1.0, brow_tilt=1.0, lid=0.5, look=(0, -0.6), nod=5),
 '단호':   dict(smile=0.1, brow_tilt=-1.0, brow=-0.5, lid=0.28),
 '한심':   dict(smile=0.0, lid=0.55, brow=-0.3, look=(0.5, 0)),
 '윙크':   dict(open=0.3, smile=1.5, blink=(0, 1), brow=0.5, blush=1),
 '당황':   dict(open=0.4, smile=-0.6, widen=1.0, brow=1.0, brow_tilt=0.9, look=(-0.3, 0)),
}

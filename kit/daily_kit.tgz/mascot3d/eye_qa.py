import sys, os, bpy, usb_mascot as M
from expressions import EXPR
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
M.build(); M.setup_render('pip', 360, 14); M.stage_light_v4('neutral'); c = bpy.data.objects['cam']; c.data.lens = 170; bpy.data.objects['cam_tgt'].location = (0, 0, 1.62)
T = [('01_lid0', {}), ('02_lid03', dict(lid=.3)), ('03_lid05', dict(lid=.5)), ('04_lid07', dict(lid=.7)), ('05_lid10', dict(lid=1)), ('06_sq05', dict(squint=.5)), ('07_sq08', dict(squint=.8)), ('08_sq10', dict(squint=1)),
     ('09_blink05', dict(blink=.5)), ('10_blink1', dict(blink=1)), ('11_wink', dict(blink=(0, 1))), ('12_lid05_look', dict(lid=.5, look=(.6, .5)))]
T += [(f'{20 + i}_' + k, v) for i, (k, v) in enumerate(EXPR.items())]
for n, kw in T: M.pose(**kw); M.render(f'{out}/{n}.png')

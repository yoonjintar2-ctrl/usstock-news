"""마스코트 동작·표정 라이브러리 (2026-11-11) — talk_render2.py와 도감 렌더가 같이 씀
gest(kind, d, side) → (L[4], R[4], extra dict). d = 동작 시작 후 초, side = +1 오른손 / -1 왼손(마스코트 기준)
손 오프셋은 (x 바깥, y 앞(-), z 위, 손목 비틀기°)"""
import math
def ease(u): u = min(1, max(0, u)); return u * u * (3 - 2 * u)
DUR = dict(explain=1.9, open=2.0, point=2.0, ask=2.2, wave=1.8, think=2.4, beat=1.6, yes=1.5, wow=1.6, no=1.6, cheer=1.8, facepalm=2.2, panic=1.8, clap=1.8, bow=1.6, sad=2.4, side=2.4, count=2.2, jump=1.2, proud=2.0,
           rise=2.2, fall=2.4, weigh=2.6, present=2.2, shh=2.0, salute=1.8, pump=1.5, around=2.6, peek=2.2, dance=2.6, shiver=2.2, stretch=2.6, doze=3.0, laugh=2.2, cry=2.4, dizzy=2.6)
def gest(kind, d, side=1):
    T = DUR[kind]; L = [0, 0, 0, 0]; R = [0, 0, 0, 0]; ex = {}
    if not (-0.1 < d < T): return L, R, ex
    up = ease((d + 0.1) / 0.32) * (1 - ease((d - (T - 0.55)) / 0.5))
    A, B = (R, L) if side > 0 else (L, R)
    if kind == 'explain':
        wob = math.sin(d * 7.5) * 0.035
        A[0] += 0.06 * up; A[1] += -0.12 * up; A[2] += (0.42 + wob) * up; A[3] += 20 * up
    elif kind == 'open':          # 두 손을 벌려 보여 주기
        for h, s in ((L, -1), (R, 1)): h[0] += 0.13 * up; h[1] += -0.10 * up; h[2] += (0.30 + 0.03 * math.sin(d * 6 + s)) * up; h[3] += 28 * up
        ex = dict(brow=0.4 * up, squash=-0.02 * up)
    elif kind == 'point':         # 한 손 높이 들어 짚기(두 번 톡톡)
        tap = max(0, math.sin(d * 9.0)) * 0.05 * (1 if d < 1.1 else 0)
        A[0] += 0.03 * up; A[1] += -0.10 * up; A[2] += (0.60 + tap) * up; A[3] += 34 * up
        B[2] += 0.06 * up
        ex = dict(brow=0.5 * up, nod=-2.5 * tap * 20 * up, lean=-2.0 * side * up)
    elif kind == 'ask':           # 어깨 으쓱 + 고개 갸웃(질문)
        for h in (L, R): h[0] += 0.17 * up; h[1] += -0.05 * up; h[2] += 0.17 * up; h[3] += 42 * up
        ex = dict(brow=0.9 * up, brow_tilt=0.6 * up, lean=3.2 * side * up, bob=0.02 * up, look=(0.0, 0.25 * up))
    elif kind == 'wave':          # 손 흔들기(인사)
        A[0] += (0.10 + 0.08 * math.sin(d * 12)) * up; A[1] += -0.06 * up; A[2] += 0.60 * up; A[3] += 18 * math.sin(d * 12) * up
        ex = dict(smile=1.25, widen=0.3 * up, lean=-3.0 * side * up)
    elif kind == 'think':         # 위를 보며 생각
        A[0] += -0.10 * up; A[1] += -0.16 * up; A[2] += 0.40 * up; A[3] += 10 * up
        ex = dict(look=(-0.55 * side * up, 0.5 * up), lean=-4.0 * side * up, brow=0.3 * up, brow_tilt=0.3 * up, smile=0.7)
    elif kind == 'beat':          # 두 손 박자(강조)
        bt = abs(math.sin(d * 6.2)) * 0.10
        for h in (L, R): h[0] += 0.05 * up; h[1] += -0.10 * up; h[2] += (0.22 + bt) * up; h[3] += 15 * up
        ex = dict(nod=-3.0 * bt * 10 * up)
    elif kind == 'yes':           # 크게 끄덕
        ex = dict(nod=-7.0 * abs(math.sin(d * 6.0)) * up, smile=1.2); A[2] += 0.12 * up
    elif kind == 'wow':           # 깜짝(눈 크게, 두 손 번쩍)
        pop = ease(d / 0.18) * (1 - ease((d - 0.9) / 0.6))
        for h in (L, R): h[0] += 0.10 * pop; h[2] += 0.50 * pop; h[3] += 20 * pop
        ex = dict(widen=1.0 * pop, brow=1.2 * pop, squash=-0.05 * pop, bob=0.04 * pop, mouth=0.7 * pop)
    elif kind == 'no':            # 절레절레
        ex = dict(yaw=9.0 * math.sin(d * 9.0) * up, brow_tilt=-0.4 * up, smile=0.6); A[0] += 0.12 * up; A[2] += 0.30 * up; A[3] += 30 * up
    elif kind == 'cheer':         # 만세(두 손 번쩍 + 살짝 뜀)
        hop = abs(math.sin(d * 7.0)) * 0.05 * up
        for h, s in ((L, -1), (R, 1)): h[0] += 0.10 * up; h[1] += -0.04 * up; h[2] += (0.86 + 0.05 * math.sin(d * 14 + s)) * up; h[3] += 10 * up
        ex = dict(hop=hop, squash=-0.04 * up + 0.5 * hop, smile=1.5, mouth=0.75 * up, brow=0.9 * up, squint=0.55 * up, blush=up)
    elif kind == 'facepalm':      # 이마 짚기(아이고)
        A[0] += -0.40 * up; A[1] += -0.24 * up; A[2] += 0.97 * up; A[3] += -30 * up
        ex = dict(nod=7.0 * up, lid=0.85 * up, brow_tilt=0.7 * up, smile=-0.5, lean=2.5 * side * up)
    elif kind == 'panic':         # 허둥지둥(두 손 머리 옆 + 떨림)
        j = math.sin(d * 34) * 0.018 * up
        for h, s in ((L, -1), (R, 1)): h[0] += (0.02 + j * s) * up; h[1] += -0.06 * up; h[2] += (0.78 + j) * up; h[3] += 24 * up
        ex = dict(widen=1.0 * up, brow=1.0 * up, brow_tilt=0.9 * up, mouth=0.55 * up, smile=-0.6, yaw=4 * math.sin(d * 17) * up, bob=abs(j))
    elif kind == 'clap':          # 박수
        c = abs(math.sin(d * 11.0))
        for h in (L, R): h[0] += (-0.52 + 0.14 * c) * up; h[1] += -0.30 * up; h[2] += 0.10 * up; h[3] += 60 * up
        ex = dict(smile=1.4, squint=0.5 * up, mouth=0.4 * up, bob=0.012 * c * up, blush=up)
    elif kind == 'bow':           # 꾸벅 인사
        bw = ease(d / 0.35) * (1 - ease((d - 0.85) / 0.45))
        for h in (L, R): h[0] += -0.10 * bw; h[1] += -0.12 * bw
        ex = dict(nod=17.0 * bw, lid=0.9 * bw, smile=1.2, bob=-0.03 * bw)
    elif kind == 'sad':           # 시무룩(어깨 처짐)
        for h in (L, R): h[0] += -0.08 * up; h[2] += -0.05 * up
        ex = dict(nod=6.0 * up, lid=0.45 * up, brow_tilt=1.0 * up, brow=-0.2 * up, smile=1 - 2.0 * up, look=(0, -0.6 * up), squash=0.03 * up, bob=-0.02 * up)
    elif kind == 'side':          # 옆 화면을 보며 가리키기(그래프·카드 소개)
        A[0] += 0.34 * up; A[1] += -0.04 * up; A[2] += (0.50 + 0.03 * math.sin(d * 8)) * up; A[3] += -8 * up
        ex = dict(yaw=-16.0 * side * up, look=(0.85 * side * up, 0.15 * up), lean=-2.5 * side * up, brow=0.5 * up)
    elif kind == 'count':         # 하나·둘·셋 세기(손 위아래 세 번)
        n = min(3, int(d / 0.55) + 1); tap = max(0, math.sin((d % 0.55) / 0.55 * math.pi)) * 0.10
        A[0] += 0.02 * up; A[1] += -0.14 * up; A[2] += (0.52 + tap) * up; A[3] += (10 + 25 * n) * up
        ex = dict(nod=-3.0 * tap * 10 * up, brow=0.4 * up)
    elif kind == 'jump':          # 폴짝(웅크림 → 뜀 → 착지)
        if d < 0.22: h0, sq = 0.0, 0.07 * ease(d / 0.22)
        elif d < 0.75: u = (d - 0.22) / 0.53; h0, sq = 0.26 * 4 * u * (1 - u), -0.06
        else: h0, sq = 0.0, 0.06 * (1 - ease((d - 0.75) / 0.3))
        for h in (L, R): h[0] += 0.10 * min(1, h0 * 6); h[2] += 2.2 * h0
        ex = dict(hop=h0, squash=sq, smile=1.4, mouth=0.5 * min(1, h0 * 6), brow=0.8 * min(1, h0 * 6))
    elif kind == 'proud':         # 허리 손(뿌듯)
        for h in (L, R): h[0] += -0.20 * up; h[1] += -0.02 * up; h[2] += 0.20 * up; h[3] += -50 * up
        ex = dict(smile=1.45, lid=0.3 * up, brow=0.5 * up, lean=1.5 * up, squash=-0.02 * up, blush=up)
    elif kind == 'rise':          # 위로 쭉 가리키기(올랐다) — 색 대신 몸짓으로 상승 표현
        go = ease(d / 0.5); A[0] += 0.10 * up; A[1] += -0.06 * up; A[2] += (0.35 + 0.62 * go) * up; A[3] += 20 * up; B[2] += 0.10 * up
        ex = dict(look=(0.25 * side * up, 0.9 * go * up), nod=-6.0 * go * up, brow=0.9 * up, smile=1.4, mouth=0.5 * go * up, hop=0.03 * go * up, squash=-0.03 * go * up)
    elif kind == 'fall':          # 아래로 뚝 가리키기(떨어졌다)
        go = ease((d - 0.25) / 0.35); A[0] += 0.16 * up; A[1] += -0.14 * up; A[2] += (0.55 - 0.72 * go) * up; A[3] += -25 * up
        ex = dict(look=(0.3 * side * up, -0.9 * go * up), nod=8.0 * go * up, brow_tilt=0.8 * go * up, smile=1 - 1.6 * go * up, widen=0.5 * go * up, squash=0.04 * go * up, bob=-0.02 * go * up)
    elif kind == 'weigh':         # 저울질(이쪽 vs 저쪽): 두 손을 번갈아 위아래
        s = math.sin(d * 4.2)
        L[0] += 0.14 * up; L[1] += -0.10 * up; L[2] += (0.28 + 0.14 * s) * up; L[3] += 50 * up
        R[0] += 0.14 * up; R[1] += -0.10 * up; R[2] += (0.28 - 0.14 * s) * up; R[3] += 50 * up
        ex = dict(lean=3.0 * s * up, look=(0.5 * s * up, 0), brow=0.4 * up, brow_tilt=0.4 * up, smile=0.6)
    elif kind == 'present':       # 짜잔(한쪽으로 두 팔 펼쳐 소개)
        sw = ease(d / 0.45)
        A[0] += 0.40 * sw * up; A[1] += -0.02 * up; A[2] += 0.46 * up; A[3] += -10 * up
        B[0] += -0.28 * sw * up; B[1] += -0.24 * up; B[2] += 0.34 * up; B[3] += 20 * up
        ex = dict(lean=-4.0 * side * up, yaw=-10.0 * side * up, smile=1.5, mouth=0.5 * up, brow=0.8 * up, squint=0.4 * up, blush=up)
    elif kind == 'shh':           # 쉿(비밀 얘기)
        A[0] += -0.43 * up; A[1] += -0.30 * up; A[2] += 0.36 * up; A[3] += 10 * up
        ex = dict(lean=3.0 * side * up, nod=3.0 * up, lid=0.25 * up, brow=-0.2 * up, smile=0.5, mouth=0.05, look=(0.3 * math.sin(d * 3) * up, 0))
    elif kind == 'salute':        # 경례
        A[0] += -0.16 * up; A[1] += -0.16 * up; A[2] += 1.02 * up; A[3] += -40 * up
        ex = dict(brow_tilt=-0.5 * up, smile=1.2, squash=-0.03 * up, nod=-2.0 * up)
    elif kind == 'pump':          # 주먹 불끈(좋았어)
        hit = ease(d / 0.16) * (1 - 0.35 * ease((d - 0.3) / 0.3))
        A[0] += 0.04 * up; A[1] += -0.14 * up; A[2] += 0.78 * hit * up; A[3] += 30 * up
        ex = dict(squash=0.05 * (1 - hit) * up - 0.03 * hit * up, hop=0.04 * hit * up, brow_tilt=-0.6 * up, smile=1.5, mouth=0.6 * up, squint=0.4 * up)
    elif kind == 'around':        # 두리번두리번
        s = math.sin(d * 3.4)
        A[0] += -0.30 * up; A[1] += -0.26 * up; A[2] += 0.98 * up; A[3] += -30 * up      # 이마에 손 차양
        ex = dict(yaw=22.0 * s * up, look=(0.8 * s * up, 0.1), lean=2.0 * s * up, brow=0.6 * up, widen=0.3 * up, smile=0.6)
    elif kind == 'peek':          # 빼꼼(옆으로 기울여 엿보기)
        ex = dict(lean=13.0 * side * up, look=(-0.7 * side * up, 0.1), brow=0.9 * up, widen=0.5 * up, smile=1.2, bob=-0.02 * up)
        A[0] += 0.10 * up; A[2] += 0.30 * up; A[3] += 30 * up
    elif kind == 'dance':         # 흔들흔들 신남
        s = math.sin(d * 8.4); c = math.cos(d * 8.4)
        L[0] += 0.08 * up; L[1] += -0.08 * up; L[2] += (0.40 + 0.22 * s) * up; L[3] += 20 * up
        R[0] += 0.08 * up; R[1] += -0.08 * up; R[2] += (0.40 - 0.22 * s) * up; R[3] += 20 * up
        ex = dict(lean=7.0 * s * up, hop=0.035 * abs(c) * up, squash=0.03 * abs(s) * up, smile=1.5, squint=0.6 * up, mouth=0.4 * up, blush=up, yaw=6.0 * c * up)
    elif kind == 'shiver':        # 덜덜(무섭다)
        j = math.sin(d * 46) * 0.012 * up
        for h, s in ((L, -1), (R, 1)): h[0] += (-0.44 + j) * up; h[1] += -0.26 * up; h[2] += (0.30 + j * s) * up; h[3] += 60 * up
        ex = dict(widen=0.8 * up, brow_tilt=1.0 * up, brow=0.6 * up, smile=-0.8, mouth=0.25 * up, squash=0.05 * up, bob=j, yaw=j * 120, look=(0, -0.2 * up))
    elif kind == 'stretch':       # 기지개
        go = ease(d / 0.7)
        for h, s in ((L, -1), (R, 1)): h[0] += 0.16 * go * up; h[2] += 0.95 * go * up; h[3] += 15 * up
        ex = dict(squash=-0.06 * go * up, hop=0.02 * go * up, lid=0.9 * go * up, mouth=0.8 * go * up, smile=0.4, nod=-5.0 * go * up)
    elif kind == 'doze':          # 꾸벅꾸벅 졸다 깜짝 깸
        if d < 2.2: k = (d % 1.1) / 1.1; nd = ease(k / 0.8) * (1 - ease((k - 0.85) / 0.15)); ex = dict(nod=13.0 * nd * up, lid=(0.6 + 0.4 * nd) * up, smile=0.2, bob=-0.02 * nd * up)
        else: wk = 1 - ease((d - 2.2) / 0.6); ex = dict(widen=1.0 * wk, brow=1.0 * wk, hop=0.05 * wk, mouth=0.4 * wk, smile=0.2)
    elif kind == 'laugh':         # 깔깔(배 잡고 웃음)
        j = abs(math.sin(d * 13.0))
        A[0] += -0.42 * up; A[1] += -0.26 * up; A[2] += 0.16 * up; A[3] += 60 * up
        ex = dict(bob=0.028 * j * up, squash=0.03 * j * up, nod=-4.0 * up + 3.0 * j * up, squint=0.85 * up, mouth=(0.55 + 0.35 * j) * up, smile=1.5, blush=up, lean=2.0 * math.sin(d * 3) * up)
    elif kind == 'cry':           # 엉엉(두 손 눈가)
        j = abs(math.sin(d * 9.0))
        for h, s in ((L, -1), (R, 1)): h[0] += -0.30 * up; h[1] += -0.30 * up; h[2] += (0.84 + 0.03 * j) * up; h[3] += 30 * up
        ex = dict(smile=1 - 2.0 * up, mouth=(0.35 + 0.3 * j) * up, lid=0.9 * up, brow_tilt=1.0 * up, nod=6.0 * up, bob=-0.02 * j * up, squash=0.03 * up)
    elif kind == 'dizzy':         # 어질어질
        s = math.sin(d * 4.6); c = math.cos(d * 4.6)
        A[0] += -0.34 * up; A[1] += -0.22 * up; A[2] += 0.94 * up; A[3] += -20 * up
        ex = dict(lean=7.0 * s * up, yaw=9.0 * c * up, nod=4.0 * c * up, look=(0.8 * c * up, 0.6 * s * up), lid=0.4 * up, brow_tilt=0.7 * up, smile=-0.3, mouth=0.2 * up)
    return L, R, ex

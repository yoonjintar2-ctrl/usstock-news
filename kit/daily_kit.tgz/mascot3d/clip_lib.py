"""마스코트 반응 클립 라이브러리(11/11 밤) — 말 없는 동작 36종을 투명 배경 30fps로 미리 렌더해 둠(자연광 v4_neutral, 480×640).
다음 영상부터는 렌더 없이 host_compose/8비트 본론 장면에 바로 끼워 넣을 수 있음. 결과: /mnt/user-data/outputs/mascot_clips/<동작>.webm (VP9 알파) + manifest.json
python3 clip_lib.py [동작 ...]   (이미 만든 건 건너뜀)"""
import sys, os, math, json, subprocess, shutil, numpy as np, bpy, usb_mascot as M, gestures as G
OUT = '/mnt/user-data/outputs/mascot_clips'; TMP = '/home/claude/mascot3d/cliptmp'; os.makedirs(OUT, exist_ok=True)
ORDER = ['wow', 'cheer', 'facepalm', 'rise', 'fall', 'ask', 'think', 'present', 'side', 'panic', 'laugh', 'sad', 'pump', 'yes', 'no', 'wave', 'point', 'weigh', 'shiver', 'clap',
         'proud', 'jump', 'bow', 'cry', 'around', 'peek', 'dance', 'shh', 'dizzy', 'doze', 'stretch', 'salute', 'count', 'explain', 'open', 'beat']
kinds = sys.argv[1:] or ORDER
M.build(); M.setup_render('host', 480, 12); M.stage_light_v4('neutral')
man = json.load(open(f'{OUT}/manifest.json')) if os.path.exists(f'{OUT}/manifest.json') else {}
for k in kinds:
    if os.path.exists(f'{OUT}/{k}.webm'): continue
    T = G.DUR[k]; n = int((T + 0.5) * 30); d = f'{TMP}/{k}'; os.makedirs(d, exist_ok=True)
    hl = np.zeros(4); hr = np.zeros(4); vl = np.zeros(4); vr = np.zeros(4)
    for f in range(n):
        t = f / 30; L, R, EX = G.gest(k, t - 0.15, 1); L = np.array(L, float); R = np.array(R, float); br = math.sin(2 * math.pi * t / 3.6)
        vl += (L - hl) * 0.22 - vl * 0.42; hl += vl; vr += (R - hr) * 0.22 - vr * 0.42; hr += vr
        fp = f'{d}/{f:05d}.png'
        if os.path.exists(fp): continue
        M.pose(open=EX.get('mouth', 0.0), blink=0, look=EX.get('look', (0, 0)), brow=0.15 + EX.get('brow', 0), smile=EX.get('smile', 1.0), lean=EX.get('lean', 0), nod=EX.get('nod', 0),
               bob=0.008 * br + EX.get('bob', 0), squash=0.008 * br + EX.get('squash', 0), yaw=EX.get('yaw', 0), arm_l=tuple(hl), arm_r=tuple(hr), widen=EX.get('widen', 0),
               brow_tilt=EX.get('brow_tilt', 0), lid=EX.get('lid', 0), squint=EX.get('squint', 0), blush=EX.get('blush', 0), hop=EX.get('hop', 0))
        M.render(fp)
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-framerate', '30', '-i', f'{d}/%05d.png', '-c:v', 'libvpx-vp9', '-pix_fmt', 'yuva420p', '-b:v', '0', '-crf', '24', '-row-mt', '1', f'{OUT}/{k}.tmp.webm'], check=True)
    os.replace(f'{OUT}/{k}.tmp.webm', f'{OUT}/{k}.webm'); shutil.copy(f'{d}/{min(n - 1, int((T * 0.45 + 0.15) * 30)):05d}.png', f'{OUT}/{k}_poster.png')
    man[k] = dict(frames=n, fps=30, size=[480, 640], light='v4_neutral'); json.dump(man, open(f'{OUT}/manifest.json', 'w'), indent=1); shutil.rmtree(d); print('CLIP', k, n, flush=True)
print('LIBDONE')

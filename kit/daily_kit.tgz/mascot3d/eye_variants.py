"""마스코트 눈 시안 3종 (2026-11-10 사용자: '눈만 너무 또렷·맑고 초롱거린다')
python3 eye_variants.py <variant> <out.png> [res] [mode]
variant: cur(현재) · A(무광 프린트 눈) · B(반쯤 덮은 눈꺼풀) · C(LED 도트 눈)"""
import sys, math, bpy
import usb_mascot as M

def m(name, color, rough=0.5, coat=0.0, emit=None, strength=1.0):
    x = M.mat(name, color, rough=rough, coat=coat, emit=emit)
    if emit is not None:
        x.node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value = strength
    return x

def setmat(ob, mt):
    ob.data.materials.clear(); ob.data.materials.append(mt)

def variant_A():
    """무광 프린트 눈 — 형태·색은 그대로 두고 '유리알 광택'만 뺌.
    흰자를 따뜻한 회백색 무광으로, 눈알 볼록함을 납작하게(몸에 인쇄된 듯), 큰 하이라이트 제거·작은 점 하나만 흐리게."""
    wh = m('EyeWhiteMatte', (0.46, 0.44, 0.40), rough=0.7)
    ir = m('IrisMatte', (0.11, 0.050, 0.022), rough=0.6)
    pu = m('PupilMatte', (0.006, 0.005, 0.005), rough=0.5)
    hi = m('HiDim', (0.85, 0.82, 0.78), rough=0.7, emit=(0.6, 0.58, 0.55), strength=0.35)
    for nm in 'LR':
        P = M.P
        P[f'eye_white_{nm}'].scale.y *= 0.45; P[f'eye_ink_{nm}'].scale.y *= 0.55
        setmat(P[f'eye_white_{nm}'], wh); setmat(P[f'iris_{nm}'], ir); setmat(P[f'pupil_{nm}'], pu)
        setmat(P[f'iris_ring_{nm}'], pu)
        P[f'look_{nm}'].scale = (1.0, 0.6, 1.0)
        P[f'hi1_{nm}'].scale = tuple(v * 0.45 for v in P[f'hi1_{nm}'].scale); setmat(P[f'hi1_{nm}'], hi)
        P[f'hi2_{nm}'].hide_render = True

def variant_B():
    """반쯤 덮은 눈꺼풀 — 몸체와 같은 차콜 눈꺼풀이 위 1/3을 덮어 '맑은 왕눈'을 차분한 반눈으로.
    흰자 살짝 톤다운, 하이라이트 1개만 작게. 눈 깜빡임(eye 피벗 z스케일)과 같이 움직이도록 eye_X 아래에 붙임."""
    wh = m('EyeWhiteSoft', (0.80, 0.78, 0.74), rough=0.35, coat=0.15)
    ir = m('IrisSoft', (0.15, 0.06, 0.024), rough=0.35)
    lid_m = M.mat('Charcoal', (0.030, 0.030, 0.034))
    for nm in 'LR':
        P = M.P; sx = -1 if nm == 'L' else 1
        setmat(P[f'eye_white_{nm}'], wh); setmat(P[f'iris_{nm}'], ir)
        P[f'hi2_{nm}'].hide_render = True
        P[f'hi1_{nm}'].scale = tuple(v * 0.7 for v in P[f'hi1_{nm}'].scale)
        e = P[f'eye_{nm}']
        lid = M.sphere(f'lid_{nm}', (0, -0.028, 0.088), (0.118, 0.050, 0.060), lid_m, pa=e)
        lid.rotation_euler = (0, math.radians(sx * 7), 0); lid.scale.y = 0.032
        # 눈꺼풀 아래 테(선)
        M.tube_curve(f'lidline_{nm}', [(-0.110, -0.052, 0.040 - sx * 0.010), (0, -0.062, 0.026), (0.110, -0.052, 0.040 + sx * 0.010)], 0.0100, M.mat('Ink', (0.006, 0.006, 0.008)), pa=e)
        pass

def variant_C():
    """LED 도트 눈 — USB 기기답게 흰자·홍채를 없애고, 몸에 살짝 파인 검은 창 안에 은은하게 켜진 둥근 LED 두 점.
    반짝이는 유리알 대신 '기기 상태등' 느낌. 웃을 땐 LED를 반달(^)로 바꾸는 것도 가능."""
    win = m('EyeWindow', (0.010, 0.010, 0.013), rough=0.25, coat=0.5)
    led = m('EyeLED', (1.0, 0.70, 0.35), rough=0.4, emit=(1.0, 0.58, 0.20), strength=1.3)
    for nm in 'LR':
        P = M.P
        P[f'eye_white_{nm}'].scale = (0.100, 0.020, 0.122); setmat(P[f'eye_white_{nm}'], win)
        P[f'eye_ink_{nm}'].scale = (0.112, 0.024, 0.134)
        for k in ('iris_ring', 'iris', 'pupil', 'hi1', 'hi2'):
            P[f'{k}_{nm}'].hide_render = True
        lk = P[f'look_{nm}']
        sx = -1 if nm == 'L' else 1
        d = M.sphere(f'led_{nm}', (-sx * 0.012, -0.016, 0.016), (0.038, 0.010, 0.048), led, pa=lk)

def variant_A2():
    """A2 · 무광 프린트 눈, 반사점 완전 제거 (11/10 사용자: A가 좋은데 흰 점 반사도 빼 달라)"""
    variant_A()
    for nm in 'LR': M.P[f'hi1_{nm}'].hide_render = True

def variant_D():
    """D · 테두리 없는 플랫 눈 — A2에서 굵은 검은 외곽선까지 없애고 흰자를 한 톤 더 낮춤. 그림책 속 인쇄 눈처럼 몸에 녹아듦"""
    variant_A2()
    wh = m('EyeWhiteFlat', (0.38, 0.36, 0.33), rough=0.75)
    for nm in 'LR':
        P = M.P
        P[f'eye_ink_{nm}'].hide_render = True
        setmat(P[f'eye_white_{nm}'], wh)
        P[f'eye_white_{nm}'].scale = (0.100, 0.016, 0.126)

def variant_E():
    """E · 눈웃음(반달) 눈 — A2에 몸 색 아래 눈꺼풀이 위로 볼록하게 올라와 눈 아래쪽을 덮음. 동그랗게 쳐다보는 대신 늘 살짝 웃는 눈"""
    variant_A2()
    lid_m = M.mat('Charcoal', (0.030, 0.030, 0.034))
    ink = M.mat('Ink', (0.006, 0.006, 0.008))
    for nm in 'LR':
        P = M.P; sx = -1 if nm == 'L' else 1
        e = P[f'eye_{nm}']
        M.sphere(f'lowlid_{nm}', (0, -0.020, -0.110), (0.128, 0.016, 0.090), lid_m, pa=e)
        M.tube_curve(f'lowline_{nm}', [(-0.112, -0.037, -0.064), (-0.080, -0.039, -0.040), (0, -0.040, -0.019), (0.080, -0.039, -0.040), (0.112, -0.037, -0.064)], 0.0090, ink, pa=e)

if __name__ == '__main__':
    v, out = sys.argv[1], sys.argv[2]
    res = int(sys.argv[3]) if len(sys.argv) > 3 else 700
    mode = sys.argv[4] if len(sys.argv) > 4 else 'pip'
    M.build()
    {'cur': lambda: None, 'A': variant_A, 'B': variant_B, 'C': variant_C, 'A2': variant_A2, 'D': variant_D, 'E': variant_E}[v]()
    M.pose(open=0.25, blink=0.0, look=(0.0, 0.0), brow=0.1, smile=1.0, arm_l=(0, 0, 0), arm_r=(0.05, 0.05, 0.25))
    M.setup_render(mode, res, 48)
    M.render(out)
    print('ok', out)
